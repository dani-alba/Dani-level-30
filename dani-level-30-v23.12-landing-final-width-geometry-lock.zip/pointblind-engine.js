/* PUNTO CIEGO 30 · timing / temporal perception engine V1.
 * Three deterministic random patrol windows. Ranking: lowest total absolute error.
 */
(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.DANI_POINTBLIND_ENGINE=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const VERSION=1;
  const ROUNDS=3;
  const READY_MS=900;
  const BETWEEN_MS=1500;
  const MIN_TARGET_MS=1750;
  const MAX_TARGET_MS=5650;
  const MIN_VARIATION_MS=650;
  const MAX_LATE_MS=4000;
  const MAX_DURATION_MS=36000;
  const FADE_START=.42;
  const FADE_END=.59;

  function hashSeed(value){
    const text=String(value||'');let h=2166136261>>>0;
    for(let i=0;i<text.length;i+=1){h^=text.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}
    h^=h>>>16;h=Math.imul(h,2246822507)>>>0;h^=h>>>13;h=Math.imul(h,3266489909)>>>0;h^=h>>>16;
    return h>>>0||0x6d2b79f5;
  }
  function seedForRun(runId){return hashSeed(`PUNTOCIEGO30:V${VERSION}:${String(runId||'')}`);}
  function rng(seed){let x=(Number(seed)>>>0)||0x6d2b79f5;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function makeDurations(seed){
    // One fast, one medium and one slow patrol per run. Their exact timings and
    // order vary deterministically, so nobody learns a fixed round pattern
    // while every player faces a comparable overall difficulty curve.
    const random=rng(seed);
    const bands=[[1750,2450],[3000,3900],[4650,5650]];
    const out=bands.map(([min,max])=>Math.round((min+random()*(max-min))/10)*10);
    for(let i=out.length-1;i>0;i-=1){const j=Math.floor(random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
    return out;
  }
  function plan(runId){const seed=seedForRun(runId);return{seed,durations:makeDurations(seed)};}
  function replay(runId,events,durationMs){
    if(!Array.isArray(events)||events.length!==ROUNDS)throw Error('PUNTO CIEGO requiere exactamente 3 pulsaciones');
    const duration=Math.round(Number(durationMs));if(!Number.isInteger(duration)||duration<READY_MS||duration>MAX_DURATION_MS)throw Error('Duración de PUNTO CIEGO inválida');
    const p=plan(runId);let start=READY_MS;const attempts=[];
    for(let i=0;i<ROUNDS;i+=1){
      const raw=events[i]||{};if(raw.type!=='tap')throw Error('Evento de PUNTO CIEGO inválido');
      const t=Math.round(Number(raw.t));if(!Number.isInteger(t))throw Error('Tiempo de pulsación inválido');
      const target=start+p.durations[i];
      if(t<start-80)throw Error('Pulsación anterior al inicio de la ronda');
      if(t>target+MAX_LATE_MS)throw Error('Pulsación demasiado tardía');
      const signedError=t-target,absoluteError=Math.abs(signedError);
      attempts.push({round:i+1,startMs:start,targetDurationMs:p.durations[i],targetAtMs:target,tapAtMs:t,signedErrorMs:signedError,absoluteErrorMs:absoluteError});
      start=t+BETWEEN_MS;
    }
    const lastTap=attempts[attempts.length-1].tapAtMs;if(duration+100<lastTap)throw Error('Duración inferior a la última pulsación');
    const totalErrorMs=attempts.reduce((sum,item)=>sum+item.absoluteErrorMs,0);
    const worstErrorMs=Math.max(...attempts.map(item=>item.absoluteErrorMs));
    const bestErrorMs=Math.min(...attempts.map(item=>item.absoluteErrorMs));
    return{complete:true,rulesVersion:VERSION,seed:p.seed,durations:p.durations,attempts,totalErrorMs,worstErrorMs,bestErrorMs,averageErrorMs:Math.round(totalErrorMs/ROUNDS),durationMs:duration};
  }
  return{VERSION,ROUNDS,READY_MS,BETWEEN_MS,MIN_TARGET_MS,MAX_TARGET_MS,MIN_VARIATION_MS,MAX_LATE_MS,MAX_DURATION_MS,FADE_START,FADE_END,hashSeed,seedForRun,makeDurations,plan,replay};
});
