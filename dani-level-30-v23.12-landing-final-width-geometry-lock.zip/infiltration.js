(()=>{
  'use strict';
  const core=window.DANI_CORE,crew=window.DANI_CREW,engine=window.DANI_INFILTRATION_ENGINE;
  if(!core||!crew||!engine)return;
  const $=(s)=>document.querySelector(s),dialog=$('#infiltrationDialog'),reducedMotion=Boolean(core.reducedMotion);
  const state={game:null,status:null,mode:'home',paused:false,pauseStarted:0,generation:0,raf:0,runId:'',freePlay:false,owner:'',starting:false,finishing:false,audio:null,audioMaster:null,previewStart:0,previewDuration:0,previewRemaining:0,transitionUntil:0,failUntil:0,width:0,celebrationView:null};
  const profile=()=>crew.getLocalProfile?.();
  function syncOperationLoadingViewport(){document.documentElement?.style?.setProperty?.('--operation-loading-height',`${Math.round(window.visualViewport?.height||window.innerHeight||700)}px`);}
const fmt=(v)=>Math.max(0,Math.round(Number(v)||0)).toLocaleString('es-ES');
  const rewardForRank=(rank,data=state.status)=>data?.rewards?.find?.((x)=>Number(x.rank)===Number(rank))||null;

  function ensureAudio(){if(state.audio){if(state.audio.state==='suspended')state.audio.resume?.().catch?.(()=>{});return state.audio;}try{state.audio=new (window.AudioContext||window.webkitAudioContext)();state.audioMaster=state.audio.createGain();state.audioMaster.gain.value=1.9;state.audioMaster.connect(state.audio.destination);}catch{state.audio=null;state.audioMaster=null;}return state.audio;}
  function tone(freq=440,duration=.06,type='sine',gain=.022,delay=0,end=0){const audio=ensureAudio();if(!audio)return;try{if(audio.state==='suspended')audio.resume();const o=audio.createOscillator(),g=audio.createGain(),start=audio.currentTime+delay;o.type=type;o.frequency.setValueAtTime(freq,start);if(end)o.frequency.exponentialRampToValueAtTime(Math.max(1,end),start+duration);g.gain.setValueAtTime(Math.max(.0001,gain),start);g.gain.exponentialRampToValueAtTime(.0001,start+duration);o.connect(g);g.connect(state.audioMaster||audio.destination);o.start(start);o.stop(start+duration+.015);}catch{}}
  function vibrate(p){try{navigator.vibrate?.(p);}catch{}}
  function cue(kind,index=0,total=1){
    if(kind==='scan'){tone(145,.10,'square',.014);tone(275,.16,'sine',.019,.06,410);tone(540,.08,'sine',.012,.20);}
    if(kind==='hide'){tone(620,.045,'square',.015);tone(420,.065,'square',.012,.045);tone(240,.08,'triangle',.012,.10);}
    if(kind==='key'){const p=Math.min(1,index/Math.max(1,total)),f=520+Math.round(p*310);tone(f,.045,'sine',.021);tone(f*1.5,.035,'sine',.009,.025);vibrate(8);}
    if(kind==='repeat'){tone(260,.025,'triangle',.007);}
    if(kind==='clear'){tone(590,.05,'sine',.021);tone(790,.07,'sine',.023,.055);tone(1050,.10,'sine',.026,.13);tone(1420,.12,'sine',.018,.22);vibrate([9,18,13]);}
    if(kind==='fail'){tone(210,.13,'sawtooth',.034,0,88);tone(110,.22,'square',.022,.075);tone(72,.25,'sawtooth',.014,.15);vibrate([32,28,58]);}
  }

  function renderAvatar(root,entry){root.replaceChildren();if(entry.photoUrl){const img=document.createElement('img');img.src=entry.photoUrl;img.alt='';root.appendChild(img);}else root.textContent=entry.avatar||'🕶️';}
  function podiumCopy(entry){return `PATRÓN ${fmt(entry?.failedRound||1)} · ${entry?.zone||'ACCESO'}`;}
  function renderStatus(data){
    state.status=data;const best=data.playerBest?`${fmt(data.playerBest)} TECLAS`:'SIN MARCA';
    $('#infBest')&&($('#infBest').textContent=best);$('#clandestineInfiltrationRecord')&&($('#clandestineInfiltrationRecord').textContent=best);
    const closed=data.phase==='closed',cardState=$('#clandestineInfiltrationState');if(cardState){cardState.hidden=!closed;cardState.textContent='FINAL';}
    $('#infStart')&&($('#infStart').textContent=closed?'JUGAR POR DIVERSIÓN':'INICIAR BRECHA');$('#clandestinePlayInfiltration')&&($('#clandestinePlayInfiltration').textContent=closed?'JUGAR POR DIVERSIÓN':'JUGAR');
    $('#infRankLabel')&&($('#infRankLabel').textContent=closed?'MARCAS FINALES':'RANKING DEL JUEGO');if($('#infPhaseBadge')){$('#infPhaseBadge').textContent=closed?'FINAL':'ABIERTO';$('#infPhaseBadge').classList.toggle('is-closed',closed);}
    const list=$('#infLeaderboard');if(!list)return;list.replaceChildren();const rows=Array.isArray(data.leaderboard)?data.leaderboard:[];
    if(!rows.length){const empty=document.createElement('p');empty.className='arcade-leaderboard-empty';empty.textContent='Todavía nadie ha reconstruido un patrón. La primera referencia puede ser tuya.';list.appendChild(empty);return;}
    rows.slice(0,10).forEach((entry)=>{const row=document.createElement('div');row.className=`arcade-rank-row${entry.isViewer?' is-me':''}${entry.rank<=3?` is-podium is-rank-${entry.rank}`:''}`;const rank=document.createElement('span');rank.className='arcade-rank-row__rank';rank.textContent=entry.rank===1?'🥇':entry.rank===2?'🥈':entry.rank===3?'🥉':String(entry.rank);const avatar=document.createElement('span');avatar.className='arcade-rank-row__avatar';renderAvatar(avatar,entry);const name=document.createElement('span');name.className='arcade-rank-row__name';const strong=document.createElement('b');strong.textContent=entry.name;const small=document.createElement('small');small.textContent=entry.rank<=3?podiumCopy(entry):`PATRÓN ${fmt(entry.failedRound||1)} · ${entry.zone||'ACCESO'}`;name.append(strong,small);const score=document.createElement('strong');score.className='arcade-rank-row__score';score.textContent=`${fmt(entry.score)} teclas`;row.append(rank,avatar,name,score);list.appendChild(row);});
  }
  async function refresh(){if(!profile()?.id)return null;try{const data=await crew.infiltrationLeaderboard();renderStatus(data);return data;}catch(error){$('#infMessage')&&($('#infMessage').textContent=error.message||'No se ha podido cargar BRECHA 30.');return null;}}
  function fit(){if(document.body.classList.contains('infiltration-playing'))document.documentElement.style.setProperty('--inf-height',`${Math.round(window.visualViewport?.height||window.innerHeight)}px`);}
  function unlock(){document.body.classList.remove('infiltration-playing');if(document.fullscreenElement===dialog)document.exitFullscreen?.().catch(()=>{});}
  function showOperationLoading(message='Interceptando patrón…',error=false){const root=$('#infLoading');if(!root)return;syncOperationLoadingViewport();document.body.classList.add('operation-loading-open');root.hidden=false;root.classList.toggle('is-error',Boolean(error));const copy=$('#infLoadingText');if(copy)copy.textContent=message;$('#infIntro')&&($('#infIntro').hidden=true);$('#infGame')&&($('#infGame').hidden=true);$('#infResult')&&($('#infResult').hidden=true);}
  function hideOperationLoading(){const root=$('#infLoading');document.body.classList.remove('operation-loading-open');if(root){root.hidden=true;root.classList.remove('is-error');}}
  function resetView(){document.body.classList.remove('operation-result-open','operation-loading-open');state.generation++;cancelAnimationFrame(state.raf);state.raf=0;state.game=null;state.mode='home';state.paused=false;state.pauseStarted=0;state.runId='';state.freePlay=false;state.owner='';state.starting=false;state.finishing=false;state.previewRemaining=0;state.celebrationView=null;unlock();$('#infIntro')&&($('#infIntro').hidden=true);hideOperationLoading();$('#infGame')&&($('#infGame').hidden=true);$('#infResult')&&($('#infResult').hidden=true);$('#infStart')&&($('#infStart').disabled=false);$('#infRetry')&&($('#infRetry').disabled=false);$('#infStartMessage')&&($('#infStartMessage').textContent='');$('#infMessage')&&($('#infMessage').textContent='');const pause=$('#infPauseMenu');if(pause)pause.hidden=true;}
  async function open(options={}){const player=profile();if(!player||player.attendance!=='yes')return;$('#clandestineDialog')?.close();window.DANI_APP?.setHudMenuOpen?.(false);resetView();if(!dialog.open)dialog.showModal();document.body.classList.add('arcade-open');if(options.play)showOperationLoading('Interceptando patrón…');dialog.querySelector('.arcade-shell')?.scrollTo?.({top:0});await refresh();if(options.play)await startGame();}
  function close(){resetView();if(dialog?.open)dialog.close();document.body.classList.remove('arcade-open');}
  function returnToArea(){close();window.DANI_ARCADE?.openArea?.();}
  function zoneLabel(pattern){return pattern.zone.depth?`${pattern.zone.name} · ${String(pattern.zone.depth).padStart(2,'0')}`:pattern.zone.name;}

  function makeBoardView(route,selected=[],extra={}){
    return {route,selected:[...selected],score:extra.score??state.game?.score??0,round:extra.round??route?.round??state.game?.round??1,wrongSlot:extra.wrongSlot??null};
  }
  function boardFrame(){return document.querySelector('.inf-board-frame');}
  function clearBoardFrameState(){boardFrame()?.classList.remove('is-cleared');}

  function renderBoard(reveal=false,failed=false,view=null){
    const current=view||state.celebrationView||state.game;
    const board=$('#infBoard');
    if(!current?.route||!board)return false;
    const pattern=current.route;
    const keys=Array.isArray(pattern.pattern)?pattern.pattern:[];
    const keySet=new Set(keys);
    const selected=new Set(Array.isArray(current.selected)?current.selected:[]);
    const wrongSlot=Number.isInteger(current.wrongSlot)?current.wrongSlot:state.game?.wrongSlot;
    clearBoardFrameState();
    board.style.setProperty('--grid-size',String(Math.max(1,Number(pattern.size)||3)));
    board.replaceChildren();
    for(let slot=0;slot<pattern.size*pattern.size;slot++){
      const button=document.createElement('button');
      button.type='button';button.className='inf-tile';button.dataset.slot=String(slot);
      button.style.setProperty('--tile-order',String(Math.max(0,keys.indexOf(slot))));
      const inPattern=keySet.has(slot),isSelected=selected.has(slot);
      if(reveal&&inPattern)button.classList.add('is-pattern');
      if(isSelected)button.classList.add('is-verified');
      if(failed&&inPattern&&!isSelected)button.classList.add('is-missed');
      if(failed&&slot===wrongSlot)button.classList.add('is-wrong');
      if(failed&&!inPattern&&slot!==wrongSlot)button.classList.add('is-dim');
      button.innerHTML='<span class="inf-tile-inner"><span class="inf-tile-face inf-tile-front"><i></i></span><span class="inf-tile-face inf-tile-back"><i></i></span></span>';
      button.setAttribute('aria-label',`Tecla de seguridad ${slot+1}`);
      button.addEventListener('pointerdown',(event)=>{if(event.pointerType==='mouse'&&event.button!==0)return;event.preventDefault();tap(slot);},{passive:false});
      button.addEventListener('click',(event)=>{if(event.detail===0)tap(slot);});
      board.appendChild(button);
    }
    const round=Math.max(1,Number(current.round||pattern.round||1));
    const score=Math.max(0,Number(current.score||0));
    $('#infRoute')&&($('#infRoute').textContent=String(round).padStart(2,'0'));
    $('#infSector')&&($('#infSector').textContent=zoneLabel(pattern));
    $('#infScore')&&($('#infScore').textContent=fmt(score));
    $('#infRouteLength')&&($('#infRouteLength').textContent=`${pattern.count||pattern.length||keys.length} TECLAS`);
    return true;
  }
  function feedback(title,text='',toneName='normal'){const root=$('#infFeedback');if(!root)return;root.dataset.tone=toneName;root.querySelector('strong').textContent=title;root.querySelector('span').textContent=text;}
  function markTileHit(slot){const tile=$('#infBoard')?.querySelector(`[data-slot="${slot}"]`);if(!tile)return;tile.classList.add('is-hit');setTimeout(()=>tile.classList.remove('is-hit'),220);}
  function startRecall(){state.mode='recall';state.previewRemaining=0;state.celebrationView=null;clearBoardFrameState();renderBoard(false);$('#infScanBar').style.transform='scaleX(0)';feedback('RECONSTRUYE','Toca las mismas teclas.');cue('hide');}
  function beginPreview(duration=null){if(!state.game||state.game.over)return;state.celebrationView=null;clearBoardFrameState();state.mode='preview';state.previewDuration=Math.max(80,duration??state.game.route.previewMs);state.previewRemaining=state.previewDuration;state.previewStart=performance.now();renderBoard(true);$('#infScanBar').style.transform='scaleX(1)';feedback('MEMORIZA',`${state.game.route.count||state.game.route.length} teclas`);cue('scan');state.raf=requestAnimationFrame(loop);}
  function loop(now){
    if(state.paused)return;
    if(state.mode==='preview'){const elapsed=now-state.previewStart,progress=Math.min(1,elapsed/state.previewDuration);state.previewRemaining=Math.max(0,state.previewDuration-elapsed);$('#infScanBar').style.transform=`scaleX(${1-progress})`;if(progress>=1){startRecall();return;}state.raf=requestAnimationFrame(loop);return;}
    if(state.mode==='celebrate'){if(now>=state.transitionUntil){state.celebrationView=null;beginPreview();return;}state.raf=requestAnimationFrame(loop);return;}
    if(state.mode==='failed'){if(now>=state.failUntil){finishGame();return;}state.raf=requestAnimationFrame(loop);}
  }
  function tap(slot){
    if(state.paused||!state.game||state.game.over)return;
    if(state.mode==='preview'){cancelAnimationFrame(state.raf);startRecall();}
    if(state.mode!=='recall')return;
    const priorRoute=state.game.route?{...state.game.route,pattern:[...state.game.route.pattern]}:null;
    const priorSelected=[...(state.game.selected||[])];
    const priorRound=state.game.round;
    try{engine.act(state.game,{kind:'tap',slot});}catch(error){feedback('ERROR DE SISTEMA','Reinicia la infiltración e inténtalo de nuevo.','error');console.error('BRECHA 30 · error de motor',error);return;}
    const fx=engine.drain(state.game),fail=fx.find(x=>x.type==='fail'),key=fx.find(x=>x.type==='key'),repeat=fx.find(x=>x.type==='repeat'),cleared=fx.find(x=>x.type==='round');
    if(repeat){cue('repeat');return;}
    if(key){
      const tile=$('#infBoard')?.querySelector(`[data-slot="${slot}"]`);
      tile?.classList.add('is-verified');
      markTileHit(slot);
      $('#infScore').textContent=fmt(state.game.score);
      feedback('CORRECTA',`${key.selected}/${key.total}`,'success');
      cue('key',key.selected,key.total);
    }
    if(fail){renderBoard(false,true);feedback('INTRUSIÓN DETECTADA','Ese nodo no pertenecía al patrón.','error');document.body.classList.add('infiltration-alarm');setTimeout(()=>document.body.classList.remove('infiltration-alarm'),reducedMotion?50:720);cue('fail');state.mode='failed';state.failUntil=performance.now()+(reducedMotion?320:1250);state.raf=requestAnimationFrame(loop);return;}
    if(cleared&&priorRoute){
      const completeView=makeBoardView(priorRoute,[...priorSelected,slot],{score:state.game.score,round:priorRound});
      state.celebrationView=completeView;
      renderBoard(false,false,completeView);
      boardFrame()?.classList.add('is-cleared');
      feedback('PATRÓN VALIDADO',`${fmt(state.game.score)} teclas`,'celebrate');
      cue('clear');
      state.mode='celebrate';
      state.transitionUntil=performance.now()+(reducedMotion?320:980);
      state.raf=requestAnimationFrame(loop);
    }
  }


  function setResultMessage(text=''){const node=$('#infResultText');if(!node)return;node.textContent=text;node.hidden=!text;}
  function renderResult(data,unsaved=false){const score=Math.max(0,Number(data.score)||0),rank=Math.max(0,Number(data.playerRank)||0);$('#infResultScore').textContent=fmt(score);$('#infResultKicker').textContent=data.freePlay?'PARTIDA LIBRE':'BRECHA COMPLETADA';const context=[];if(data.newRecord&&!data.freePlay)context.push('NUEVO RÉCORD');if(rank)context.push(`#${rank} DE LA BANDA`);if(unsaved)context.splice(0,context.length,'MARCA NO ENVIADA');if(data.freePlay&&!rank)context.push('FUERA DE COMPETICIÓN');$('#infResultRank').textContent=context.join(' · ')||(unsaved?'MARCA NO ENVIADA':'MARCA REGISTRADA');setResultMessage(unsaved?'La marca no se ha podido enviar.':'');const metrics=$('#infMetrics');if(metrics)metrics.innerHTML=`<span><small>PATRONES</small><b>${fmt(data.roundsCompleted||0)}</b></span><span><small>FALLO</small><b>P${fmt(data.failedRound||1)}</b></span><span><small>CAPA</small><b>${String(data.zone||'—')}</b></span>`;const prizeNode=$('#infResultPrize');if(prizeNode)prizeNode.hidden=true;$('#infRetry').disabled=false;}
  async function finishGame(){if(!state.game||state.finishing)return;const generation=state.generation;state.finishing=true;state.mode='result';cancelAnimationFrame(state.raf);state.raf=0;unlock();document.body.classList.add('operation-result-open');$('#infGame').hidden=true;$('#infResult').hidden=false;const local={...engine.result(state.game),freePlay:state.freePlay};renderResult(local,false);try{const data=await crew.infiltrationFinish(state.runId,state.game.events.slice());if(generation!==state.generation)return;renderStatus(data);renderResult(data,false);if(data.newRecord&&!data.freePlay)window.DANI_APP?.announceHud?.('NUEVA MARCA · BRECHA 30',{detail:`${fmt(data.score)} teclas`,tone:'success',duration:2800});}catch(error){if(generation!==state.generation)return;$('#infMessage')&&($('#infMessage').textContent=error.message||'La partida terminó, pero no se ha podido guardar.');renderResult(local,true);}finally{if(generation===state.generation)state.finishing=false;}}
  function pauseGame(){
    if(state.paused||!state.game||['home','result'].includes(state.mode))return;
    state.paused=true;state.pauseStarted=performance.now();cancelAnimationFrame(state.raf);state.raf=0;const menu=$('#infPauseMenu');if(menu)menu.hidden=false;
  }
  function resumeGame(){
    if(!state.paused||!state.game)return;const now=performance.now(),delta=Math.max(0,now-state.pauseStarted);state.paused=false;state.pauseStarted=0;const menu=$('#infPauseMenu');if(menu)menu.hidden=true;
    if(state.mode==='preview')state.previewStart+=delta;else if(state.mode==='celebrate')state.transitionUntil+=delta;else if(state.mode==='failed')state.failUntil+=delta;
    if(['preview','celebrate','failed'].includes(state.mode))state.raf=requestAnimationFrame(loop);
  }
  async function startGame(){
    if(state.starting||state.finishing)return;
    const player=profile();if(!player||player.attendance!=='yes')return;
    const generation=++state.generation;state.starting=true;state.owner=player.id;document.body.classList.remove('operation-result-open');showOperationLoading('Interceptando patrón…');
    $('#infStart')&&($('#infStart').disabled=true);$('#infRetry')&&($('#infRetry').disabled=true);
    $('#infStartMessage')&&($('#infStartMessage').textContent='PREPARANDO PATRÓN…');ensureAudio();
    try{
      const start=await crew.infiltrationStart();
      if(generation!==state.generation||state.owner!==profile()?.id)return;
      if(!start?.runId)throw new Error('No se ha podido crear la partida.');
      const game=engine.create(Number(start.seed)||engine.SEED);
      if(!game?.route?.pattern?.length)throw new Error('No se ha podido generar el patrón.');
      state.runId=start.runId;state.freePlay=Boolean(start.freePlay);state.game=game;state.mode='preview';state.paused=false;state.pauseStarted=0;state.width=window.innerWidth;
      hideOperationLoading();$('#infIntro')&&($('#infIntro').hidden=true);$('#infResult')&&($('#infResult').hidden=true);$('#infGame')&&($('#infGame').hidden=false);$('#infPractice')&&($('#infPractice').hidden=!state.freePlay);
      $('#infStartMessage')&&($('#infStartMessage').textContent='');document.body.classList.add('infiltration-playing');fit();
      beginPreview();
    }catch(error){
      if(generation!==state.generation)return;
      cancelAnimationFrame(state.raf);state.raf=0;state.mode='home';state.runId='';state.game=null;state.celebrationView=null;unlock();
      const message=error?.message||'No se ha podido iniciar la partida.';showOperationLoading(message,true);$('#infGame')&&($('#infGame').hidden=true);$('#infResult')&&($('#infResult').hidden=true);
      $('#infStartMessage')&&($('#infStartMessage').textContent=message);
      $('#infStart')&&($('#infStart').disabled=false);$('#infRetry')&&($('#infRetry').disabled=false);
      console.error('BRECHA 30 · error al iniciar',error);
    }finally{if(generation===state.generation)state.starting=false;}
  }
  async function showRanking(){close();await window.DANI_ARCADE?.openArea?.();await window.DANI_ARCADE?.openHubSheet?.('ranking','infiltration');}
  function bind(){
    $('#clandestinePlayInfiltration')?.addEventListener('click',(e)=>{e.stopPropagation();open({play:true});});
    $('#infStart')?.addEventListener('click',startGame);$('#infRetry')?.addEventListener('click',startGame);
    $('#infBack')?.addEventListener('click',returnToArea);
    $('#infExitGame')?.addEventListener('click',()=>{if(state.game&&!['home','result'].includes(state.mode)&&!state.paused)pauseGame();else if(!state.game||['home','result'].includes(state.mode))returnToArea();});
    $('#infResume')?.addEventListener('click',resumeGame);$('#infPauseExit')?.addEventListener('click',returnToArea);$('#infResultBack')?.addEventListener('click',returnToArea);
    $('#infIntroRank')?.addEventListener('click',showRanking);$('#infResultRanking')?.addEventListener('click',showRanking);
    dialog?.addEventListener('cancel',(e)=>{e.preventDefault();if(state.game&&!['home','result'].includes(state.mode)&&!state.paused)pauseGame();else if(!state.game||['home','result'].includes(state.mode))returnToArea();});
    dialog?.addEventListener('close',()=>{resetView();if(!$('#clandestineDialog')?.open)document.body.classList.remove('arcade-open');});
    window.addEventListener('resize',fit);window.visualViewport?.addEventListener('resize',fit);
    document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.game&&!['home','result'].includes(state.mode))pauseGame();});
  }
  bind();window.setInterval(()=>{if(document.visibilityState==='visible'&&['home','result'].includes(state.mode))refresh();},120000);window.DANI_INFILTRATION={open,refresh,stop:resetView,syncProfile(){if(state.owner&&state.owner!==profile()?.id)close();if(profile()?.id)refresh();},getDiagnostics:()=>({mode:state.mode,paused:state.paused,running:Boolean(state.game&&!['home','result'].includes(state.mode))})};
})();
