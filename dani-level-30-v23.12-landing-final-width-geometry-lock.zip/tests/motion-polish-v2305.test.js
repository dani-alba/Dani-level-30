'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=(name)=>fs.readFileSync(path.join(root,name),'utf8');
const html=read('index.html'),css=read('motion-polish.css'),motion=read('motion-polish.js'),app=read('app.js'),arcade=read('arcade.js'),guide=read('PROJECT-GUIDE.md');

test('current release loads the shared motion layer after the base visual assets',()=>{
  const version=html.match(/const version = '([^']+)'/)?.[1];
  assert.ok(version,'boot version is declared');
  assert.ok(html.includes(`motion-polish.css?v=${version}`));
  assert.match(html,/['"]motion-polish\.js['"]/);
  assert.ok(html.indexOf(`pointblind.css?v=${version}`) < html.indexOf(`motion-polish.css?v=${version}`));
});

test('motion system covers the requested experience beats without changing game engines',()=>{
  for(const token of ['motion-first-entry','motion-stage-open','motion-profile-enter','motion-clandestine-entering','motion-result-enter','motionGameLaunch','motionHeistTitle']) assert.match(css,new RegExp(token));
  assert.match(app,/DANI_MOTION\?\.pulseProgress/);
  assert.match(app,/DANI_MOTION\?\.pulseCash/);
  assert.match(arcade,/chapterEntry/);
  assert.match(arcade,/motion-clandestine-entering/);
});

test('motion layer has a reduced-motion path and the project guide owns the contract',()=>{
  assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);
  assert.match(motion,/prefers-reduced-motion: reduce/);
  assert.match(guide,/Motion design contract/);
  assert.match(guide,/never decoration for its own sake/);
});
