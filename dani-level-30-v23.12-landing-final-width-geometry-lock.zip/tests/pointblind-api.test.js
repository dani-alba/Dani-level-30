'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),{DatabaseSync}=require('node:sqlite');
const workerCode=fs.readFileSync(require.resolve('../_worker.js'),'utf8'),E=require('../pointblind-engine.js');
function setup(){const sql=new DatabaseSync(':memory:');const DB={prepare(text){let args=[];return{bind(...a){args=a;return this;},async first(){return sql.prepare(text).get(...args)||null;},async all(){return{results:sql.prepare(text).all(...args)};},async run(){const r=sql.prepare(text).run(...args);return{meta:{changes:Number(r.changes)}};}};},async batch(statements){sql.exec('BEGIN');try{const out=[];for(const q of statements)out.push(await q.run());sql.exec('COMMIT');return out}catch(e){sql.exec('ROLLBACK');throw e}}};const ctx={console,crypto:require('node:crypto').webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};vm.createContext(ctx);vm.runInContext(workerCode.replace('export default','globalThis.worker ='),ctx);return{sql,ctx,env:{DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}}}}
async function readOk(r){const b=await r.json();assert.equal(r.ok,true,JSON.stringify(b));return b}
function proof(runId,offsets=[0,0,0]){const plan=E.plan(runId),events=[];let start=E.READY_MS;for(let i=0;i<3;i++){const t=start+plan.durations[i]+offsets[i];events.push({type:'tap',t});start=t+E.BETWEEN_MS;}const durationMs=start;return{events,durationMs,result:E.replay(runId,events,durationMs)}}

test('PUNTO CIEGO V1 is server-authoritative, sums absolute error, accepts zero and finishes idempotently',async()=>{
  const {sql,ctx,env}=setup();const call=(path,body,token,method='POST')=>ctx.worker.fetch(new Request('https://test.local/api/'+path,{method,headers:{'x-admin-pin':'4321','content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},...(method==='GET'?{}:{body:JSON.stringify(body||{})})}),env);
  await readOk(await call('admin/database/reset',{mode:'seed'}));
  const login=await readOk(await call('login',{playerId:'admin-test-01',pin:'1234'})),token=login.sessionToken;
  sql.exec('DELETE FROM pointblind_v1_podium_awards; DELETE FROM pointblind_v1_runs; DELETE FROM pointblind_v1_scores;');
  const start=await readOk(await call('pointblind/start',{rulesVersion:1},token));const p=proof(start.runId,[-200,100,-50]);
  sql.prepare('UPDATE pointblind_v1_runs SET started_at_ms=? WHERE run_id=?').run(Date.now()-p.durationMs-2500,start.runId);
  const first=await readOk(await call('pointblind/finish',{runId:start.runId,rulesVersion:1,durationMs:p.durationMs,events:p.events,score:0},token));
  assert.equal(first.score,350);assert.deepEqual(first.attempts.map(a=>a.absoluteErrorMs),[200,100,50]);assert.equal(first.newRecord,true);
  await readOk(await call('pointblind/finish',{runId:start.runId,rulesVersion:1,durationMs:p.durationMs,events:p.events},token));
  assert.equal(sql.prepare('SELECT games_played FROM pointblind_v1_scores WHERE player_id=?').get('admin-test-01').games_played,1);
  const start2=await readOk(await call('pointblind/start',{rulesVersion:1},token)),perfect=proof(start2.runId,[0,0,0]);
  sql.prepare('UPDATE pointblind_v1_runs SET started_at_ms=? WHERE run_id=?').run(Date.now()-perfect.durationMs-2500,start2.runId);
  const zero=await readOk(await call('pointblind/finish',{runId:start2.runId,rulesVersion:1,durationMs:perfect.durationMs,events:perfect.events},token));
  assert.equal(zero.score,0);assert.equal(zero.newRecord,true);assert.equal(zero.playerBest,0);assert.equal(zero.playerRank,1);
  const board=await readOk(await call('pointblind/leaderboard',null,token,'GET'));assert.equal(board.playerBest,0);assert.equal(board.leaderboard[0].score,0);
});
