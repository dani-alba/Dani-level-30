'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../pointblind-engine.js');

test('PUNTO CIEGO V1 always gives one fast, one medium and one slow patrol in shuffled order',()=>{
  assert.equal(E.VERSION,1);assert.equal(E.ROUNDS,3);
  const orders=new Set();
  for(const id of ['a','b','c','d','e','f']){
    const d=E.plan(id).durations;
    assert.equal(d.length,3);
    const sorted=[...d].sort((a,b)=>a-b);
    assert.ok(sorted[0]>=1750&&sorted[0]<=2450);
    assert.ok(sorted[1]>=3000&&sorted[1]<=3900);
    assert.ok(sorted[2]>=4650&&sorted[2]<=5650);
    orders.add(d.map(v=>v<2500?'F':v<4000?'M':'S').join(''));
  }
  assert.ok(orders.size>1,'round order must not be fixed');
});

test('early and late errors never compensate: absolute differences are accumulated',()=>{
  const id='absolute-errors',plan=E.plan(id),offsets=[-200,100,-50],events=[];let start=E.READY_MS;
  for(let i=0;i<3;i++){const t=start+plan.durations[i]+offsets[i];events.push({type:'tap',t});start=t+E.BETWEEN_MS;}
  const result=E.replay(id,events,start);
  assert.deepEqual(result.attempts.map(a=>a.signedErrorMs),offsets);
  assert.deepEqual(result.attempts.map(a=>a.absoluteErrorMs),[200,100,50]);
  assert.equal(result.totalErrorMs,350);
});

test('a mathematically perfect three-patrol run scores exactly zero',()=>{
  const id='perfect-zero',plan=E.plan(id),events=[];let start=E.READY_MS;
  for(const duration of plan.durations){const t=start+duration;events.push({type:'tap',t});start=t+E.BETWEEN_MS;}
  const result=E.replay(id,events,start);
  assert.equal(result.totalErrorMs,0);assert.equal(result.worstErrorMs,0);assert.equal(result.bestErrorMs,0);
});
