'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const worker=fs.readFileSync(path.join(root,'_worker.js'),'utf8');
function embedded(name){const a=`// BEGIN SHARED ${name} ENGINE\n`,b=`// END SHARED ${name} ENGINE`;const start=worker.indexOf(a),end=worker.indexOf(b,start+a.length);assert.notEqual(start,-1);assert.notEqual(end,-1);return worker.slice(start+a.length,end).trim();}
test('Worker embeds exactly the browser FUGA crossing engine',()=>{assert.equal(embedded('CROSSING'),fs.readFileSync(path.join(root,'arcade-engine.js'),'utf8').trim());});
test('Worker embeds exactly the browser CAJA precision engine',()=>{assert.equal(embedded('SAFE'),fs.readFileSync(path.join(root,'safe-engine.js'),'utf8').trim());});
test('Worker embeds exactly the browser BRECHA memory engine',()=>{assert.equal(embedded('INFILTRATION'),fs.readFileSync(path.join(root,'infiltration-engine.js'),'utf8').trim());});
