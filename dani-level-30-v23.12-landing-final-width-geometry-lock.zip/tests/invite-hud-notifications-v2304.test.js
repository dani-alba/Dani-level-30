'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');

test('invite HUD uses four readable duration tiers and starts dwell after roll-in',()=>{
  assert.match(app,/routine:2800/);
  assert.match(app,/social:3800/);
  assert.match(app,/important:4700/);
  assert.match(app,/critical:5800/);
  assert.match(app,/const rollMs = reduceMotion \? 0 : 340/);
  assert.match(app,/El tiempo de lectura empieza cuando termina la entrada/);
  assert.match(app,/\}, rollMs\);/);
});

test('spontaneous invite notices are throttled and never interrupt the hack',()=>{
  assert.match(app,/HUD_SPONTANEOUS_COOLDOWN_MS = 45000/);
  assert.match(app,/if \(hackPlaying \|\| hackSaving\) return false/);
  assert.match(app,/spontaneous:Boolean\(spontaneous\)/);
  assert.match(app,/hudAnnouncementSeen = new Set\(\)/);
});

test('core invite notification copy stays concise and narrative',()=>{
  for(const phrase of [
    'ESTÁS DENTRO','NUEVA FASE DISPONIBLE','LOCALIZA EL REFUGIO',
    'REFUGIO LOCALIZADO','PREPARACIÓN COMPLETA','BOTÍN RECUPERADO',
    'EL GOLPE ES ESTA SEMANA','MAÑANA ES EL DÍA','HOY ES EL GOLPE'
  ]) assert.match(app,new RegExp(phrase));
  assert.match(app,/\+\$\$\{amount\} ENCONTRADOS/);
  assert.match(app,/\$\{Math\.min\(count, 5\)\}\/5 BILLETES/);
});

test('crew polling announces only real invite-side social changes',()=>{
  assert.match(crew,/const delay = activeMode === 'party' \? 20000 : 45000/);
  assert.match(crew,/NUEVO MIEMBRO/);
  assert.match(crew,/LA BANDA CRECE/);
  assert.match(crew,/LA BANDA SE PREPARA/);
  assert.match(crew,/spontaneous:true/);
  assert.match(crew,/id !== ownId/);
});

test('character recovery and dossier save use the shared HUD channel',()=>{
  assert.match(crew,/PERSONAJE RECUPERADO/);
  assert.match(crew,/BIENVENIDO DE NUEVO/);
  assert.match(crew,/EXPEDIENTE ACTUALIZADO/);
  assert.match(crew,/level:'routine'/);
});
