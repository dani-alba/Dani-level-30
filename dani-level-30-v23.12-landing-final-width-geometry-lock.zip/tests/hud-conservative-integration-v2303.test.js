'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('v23.03 keeps HUD structure conservative and adds only the integration treatment',()=>{
  assert.match(css,/v23\.03 · Conservative HUD integration/);
  assert.match(css,/\.hud::after\s*\{/);
  assert.match(css,/background:rgba\(27,23,32,\.985\)/);
  assert.match(css,/height:7px/);
  assert.match(css,/linear-gradient\(to bottom,rgba\(27,23,32,\.085\)/);
});
