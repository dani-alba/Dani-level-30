'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');

class ClassList{
  constructor(){this.s=new Set();}
  add(...v){v.forEach(x=>this.s.add(x));}
  remove(...v){v.forEach(x=>this.s.delete(x));}
  contains(v){return this.s.has(v);}
  toggle(v,force){if(force===true){this.s.add(v);return true;}if(force===false){this.s.delete(v);return false;}if(this.s.has(v)){this.s.delete(v);return false;}this.s.add(v);return true;}
}
class Element{
  constructor(tag='div',id=''){this.tagName=tag.toUpperCase();this.id=id;this.hidden=false;this.disabled=false;this.textContent='';this.dataset={};this.style={setProperty(k,v){this[k]=v;}};this.classList=new ClassList();this.children=[];this.listeners={};this.open=false;this._innerHTML='';}
  addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
  click(){for(const fn of this.listeners.click||[])fn({detail:0,target:this,stopPropagation(){},preventDefault(){}});}
  appendChild(el){this.children.push(el);return el;}
  append(...els){this.children.push(...els);}
  replaceChildren(...els){this.children=[...els];}
  setAttribute(){}
  scrollTo(){}
  showModal(){this.open=true;}
  close(){this.open=false;for(const fn of this.listeners.close||[])fn({target:this});}
  querySelector(sel){
    if(sel==='.arcade-shell')return this.shell||null;
    if(sel==='strong')return this.strongChild||null;
    if(sel==='span')return this.spanChild||null;
    const m=sel.match(/^\[data-slot="(\d+)"\]$/);if(m)return this.children.find(c=>c.dataset.slot===m[1])||null;
    return null;
  }
  set innerHTML(v){this._innerHTML=v;} get innerHTML(){return this._innerHTML;}
}

function createRuntime(){
  const ids=[...fs.readFileSync(path.join(root,'infiltration.js'),'utf8').matchAll(/\$\('#([^']+)'\)/g)].map(m=>m[1]);
  const map=new Map(ids.map(id=>[id,new Element('div',id)]));
  const start=map.get('infStart');start.tagName='BUTTON';
  const retry=map.get('infRetry');retry.tagName='BUTTON';
  const board=map.get('infBoard');
  const feedback=map.get('infFeedback');feedback.strongChild=new Element('strong');feedback.spanChild=new Element('span');
  const dialog=map.get('infiltrationDialog');dialog.shell=new Element('div');
  const frame=new Element('div');frame.classList.add('inf-board-frame');
  const body=new Element('body'),documentElement=new Element('html');
  const document={
    body,documentElement,fullscreenElement:null,visibilityState:'visible',
    querySelector(sel){if(sel.startsWith('#'))return map.get(sel.slice(1))||null;if(sel==='.inf-board-frame')return frame;return null;},
    createElement(tag){return new Element(tag);},addEventListener(){},exitFullscreen(){return Promise.resolve();}
  };
  const errors=[];
  const ctx={document,navigator:{vibrate(){}},performance:{now:()=>1000},requestAnimationFrame:()=>1,cancelAnimationFrame(){},setTimeout,clearTimeout,setInterval:()=>0,clearInterval(){},console:{...console,error(...args){errors.push(args.map(String).join(' '));}},innerWidth:390};
  ctx.window=ctx;ctx.globalThis=ctx;ctx.addEventListener=()=>{};ctx.DANI_CORE={reducedMotion:true};
  ctx.DANI_APP={setHudMenuOpen(){},announceHud(){}};ctx.DANI_ARCADE={openArea(){}};
  ctx.DANI_CREW={getLocalProfile:()=>({id:'p1',attendance:'yes'}),infiltrationStart:async()=>({runId:'r1',seed:30122026,freePlay:false}),infiltrationLeaderboard:async()=>({phase:'open',rewards:[],leaderboard:[],playerBest:0}),infiltrationFinish:async()=>({score:0,roundsCompleted:0,failedRound:1,zone:'ACCESO',playerRank:null,rewards:[],leaderboard:[],phase:'open'})};
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(root,'infiltration-engine.js'),'utf8'),ctx);
  vm.runInContext(fs.readFileSync(path.join(root,'infiltration.js'),'utf8'),ctx);
  return {ctx,map,board,feedback,errors};
}

test('client runtime starts, renders the first pattern and completes it without a render exception',async()=>{
  const {ctx,map,board,feedback,errors}=createRuntime();
  map.get('infStart').click();
  await new Promise(resolve=>setImmediate(resolve));await new Promise(resolve=>setImmediate(resolve));
  assert.equal(map.get('infGame').hidden,false);
  assert.equal(board.children.length,9);
  const pattern=ctx.DANI_INFILTRATION_ENGINE.create(ctx.DANI_INFILTRATION_ENGINE.SEED).route.pattern.slice();
  for(const slot of pattern){const tile=board.querySelector(`[data-slot="${slot}"]`);assert.ok(tile,`missing slot ${slot}`);tile.click();}
  assert.equal(map.get('infScore').textContent,String(pattern.length));
  assert.equal(feedback.strongChild.textContent,'PATRÓN VALIDADO');
  assert.equal(errors.length,0,errors.join('\n'));
});

test('Hub JUGAR launches INFILTRACIÓN directly and back opens the unified pause menu',async()=>{
  const {ctx,map}=createRuntime();map.get('clandestinePlayInfiltration').click();await new Promise(resolve=>setImmediate(resolve));await new Promise(resolve=>setImmediate(resolve));assert.equal(map.get('infGame').hidden,false);assert.equal(ctx.DANI_INFILTRATION.getDiagnostics().running,true);map.get('infExitGame').click();assert.equal(ctx.DANI_INFILTRATION.getDiagnostics().paused,true);assert.equal(map.get('infPauseMenu').hidden,false);map.get('infResume').click();assert.equal(ctx.DANI_INFILTRATION.getDiagnostics().paused,false);
});
