'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'motion-polish.css'),'utf8');
const baseCss=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const motion=fs.readFileSync(path.join(root,'motion-polish.js'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');

test('landing identity keeps the final GTA Birthday angle throughout its entrance',()=>{
  assert.ok(css.includes('@keyframes motionLandingVice'));
  assert.ok(css.includes('100%{opacity:1;transform:rotate(-3deg) scale(1)}'));
  assert.match(baseCss,/\.vice\{[^}]*transform:rotate\(-3deg\)/);
});

test('landing poster exits before invitation typography appears',()=>{
  assert.match(html,/id="home"/);
  assert.ok(app.includes('HERO_TRANSITION_MS = 2280'));
  assert.ok(css.includes('motionInvitePosterOut'));
  assert.ok(css.includes('motionInviteCopyFromSun'));
  assert.ok(motion.includes('motion-invite-content-ready'));
  assert.doesNotMatch(motion,/motion-invite-content-ghost-host|stripCloneIds|cloneNode/);
});

test('sun is the visual bridge between landing and invitation',()=>{
  assert.ok(css.includes('motionInviteSunPortal'));
  assert.ok(css.includes('motionInviteSunRing'));
  assert.ok(css.includes('motionInviteSunBloom'));
  assert.ok(motion.includes("motion-invite-sun-focus"));
  assert.ok(motion.includes("motion-invite-shell-final"));
});

test('HUD and Operation 30 peel out from behind the cover in opposite directions',()=>{
  assert.ok(css.includes('motionInviteHudPeel'));
  assert.ok(css.includes('translate(-50%,54px)'));
  assert.ok(css.includes('translateY(-94px) scale(.99)'));
  assert.ok(css.includes('z-index:90'));
  assert.ok(css.includes('z-index:80'));
  assert.ok(css.includes('z-index:60'));
  assert.ok(motion.includes('motion-invite-split-ready'));
  assert.ok(app.includes("flow.classList.add('mission-flow--visible')"));
});

test('final shell matches invitation geometry before landing classes are removed',()=>{
  assert.ok(css.includes('motion-invite-shell-final'));
  assert.ok(css.includes('min-height:440px!important'));
  assert.ok(css.includes('max-width:660px!important'));
  assert.ok(css.includes('text-align:left!important'));
});

test('chapter transition preserves reduced-motion fallback',()=>{
  assert.ok(css.includes('@media(prefers-reduced-motion:reduce)'));
  assert.ok(css.includes('body.motion-invite-entering{overflow:auto!important}'));
});
