'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../arcade-engine.js');

function advance(s,n){for(let i=0;i<n&&!s.over;i++)E.step(s);}
function safeRow(index){return {index,safe:true,dir:0,speed:0,speedClass:'safe',length:0,period:0,phase:0,color:0,family:'safe',pattern:[],gapSeconds:[],blocked:[]};}
function prepareCrosswalks(seed=12345,count=3){
 const s=E.create(seed);let y=1;
 while(s.segments.filter(seg=>seg.crosswalk).length<count&&y<1400){E.rowAt(s,y);y+=12;}
 return {s,crosswalks:s.segments.filter(seg=>seg.crosswalk)};
}
function crossWithoutTraffic(s,seg,{inside=true}={}){
 s.y=seg.start;s.maxRow=Math.max(s.maxRow,seg.start);s.x=inside?seg.crosswalk.center:0;s.move=null;s.queued=null;s.over=false;s.reason='';
 for(let y=seg.start;y<=seg.end;y++)s.rows.set(y,safeRow(y));
 for(let step=0;step<seg.end-seg.start;step++){
  assert.equal(E.input(s,'forward'),true,`segment ${seg.index} step ${step}`);
  advance(s,E.FORWARD_STEP);
 }
}

test('V11 crosswalks are sparse and reserve clear access on both safe-zone ends',()=>{
 assert.equal(E.VERSION,11);assert.equal(E.CROSSWALK_GOAL,1);
 let checked=0,total=0;
 for(let seed=1;seed<=35;seed++){
  let start=0;
  for(let index=0;index<40;index++){
   const seg=E.buildSegment(seed,index,start);start=seg.end;total++;if(!seg.crosswalk)continue;checked++;
   const clearance=seg.crosswalk.width/2+.58;
   for(const row of [seg.rows[0],seg.rows.at(-1)])for(const c of row.blocked||[])assert.ok(Math.abs(c-seg.crosswalk.center)>=clearance,`blocked exit ${c} at cw ${seg.crosswalk.center}`);
  }
 }
 assert.ok(checked>=20,'crosswalks should still appear across runs');
 assert.ok(checked/total<.22,'crosswalks should remain special rather than dominate the city');
});

test('one valid normal crossing unlocks the next zebra and the golden crossing resets the cycle',()=>{
 const {s,crosswalks}=prepareCrosswalks();assert.ok(crosswalks.length>=2);
 crossWithoutTraffic(s,crosswalks[0]);
 let snap=E.crosswalkSnapshot(s);assert.equal(snap.goodCrossings,1);assert.equal(snap.rewardReady,true);assert.ok(Number.isInteger(snap.goldenSegmentIndex));assert.equal(snap.lastEvent.type,'unlock');
 const golden=s.segments.find(seg=>seg.index===snap.goldenSegmentIndex);assert.ok(golden?.crosswalk);
 for(const row of golden.rows)s.rows.set(row.index,row);
 s.y=golden.start;s.maxRow=golden.start;s.x=golden.crosswalk.center;s.move=null;s.queued=null;s.over=false;s.reason='';
 assert.equal(E.input(s,'forward'),true);snap=E.crosswalkSnapshot(s);assert.equal(snap.activeSegmentIndex,golden.index);assert.equal(snap.lastEvent.type,'priority');
 for(let y=golden.start;y<=golden.end;y++)s.rows.set(y,safeRow(y));
 advance(s,E.FORWARD_STEP);
 for(let step=1;step<golden.end-golden.start;step++){assert.equal(E.input(s,'forward'),true);advance(s,E.FORWARD_STEP);}
 snap=E.crosswalkSnapshot(s);assert.equal(snap.goodCrossings,0);assert.equal(snap.rewardReady,false);assert.equal(snap.goldenSegmentIndex,null);assert.equal(snap.lastEvent.type,'consumed');
});

test('golden priority lets cars already inside finish and holds later civilian traffic',()=>{
 const {s,crosswalks}=prepareCrosswalks(12345,3);crossWithoutTraffic(s,crosswalks[0]);
 const golden=s.segments.find(seg=>seg.index===E.crosswalkSnapshot(s).goldenSegmentIndex);assert.ok(golden);
 for(const row of golden.rows)s.rows.set(row.index,row);
 s.y=golden.start;s.maxRow=golden.start;s.x=golden.crosswalk.center;s.move=null;s.queued=null;s.over=false;s.reason='';assert.equal(E.input(s,'forward'),true);
 const left=golden.crosswalk.center-golden.crosswalk.width/2,right=golden.crosswalk.center+golden.crosswalk.width/2;
 let sawAllowed=false,sawStopped=false;
 for(const row of golden.rows.filter(r=>!r.safe&&!E.isFireLane(r))){
  for(let tick=s.tick;tick<s.tick+E.HZ*8;tick+=4){
   const base=E.cars(row,tick),gated=E.carsForState(s,row,tick),byId=new Map(gated.map(c=>[c.id,c]));
   for(const car of base){const g=byId.get(car.id);if(!g)continue;const overlaps=car.x+car.width/2>=left&&car.x-car.width/2<=right;if(overlaps&&Math.abs(g.x-car.x)<1e-9)sawAllowed=true;if(!overlaps&&Math.abs(g.x-car.x)>.01)sawStopped=true;}
   if(sawAllowed&&sawStopped)break;
  }
 }
 assert.equal(sawAllowed,true);assert.equal(sawStopped,true);
});

test('fire brigade activates only in the current block, close to its entry, and ignores pedestrian priority',()=>{
 let found=null;
 for(let seed=1;seed<120&&!found;seed++){
  const s=E.create(seed);for(let y=1;y<900&&!found;y+=8){E.rowAt(s,y);for(const seg of s.segments){const row=seg.rows.find(r=>E.isFireLane(r));if(row){found={s,seg,row};break;}}}
 }
 assert.ok(found,'expected an emergency segment');
 const {s,seg,row}=found;assert.ok(row.speed>=4.35,`emergency speed ${row.speed}`);assert.ok(row.laneIndex>=1&&row.laneIndex<=3,`fire lane too deep in block: ${row.laneIndex}`);
 // While the player is elsewhere, future emergency traffic is not spawned/rendered.
 s.y=Math.max(0,seg.start-1);s.maxRow=s.y;assert.equal(E.carsForState(s,row,s.tick).length,0);
 // Entering the block arms the warning window; the first truck starts outside and arrives shortly after.
 s.y=seg.start;s.maxRow=seg.start;const local0=E.fireLaneTickForState(s,row,s.tick);assert.equal(local0,0);assert.equal(E.isFireLaneActive(s,row),true);assert.equal(E.carsForState(s,row,s.tick).length,0);
 s.crosswalk.gate={segmentIndex:seg.index,activatedTick:s.tick,releaseTick:null,allowedByRow:{}};
 const laterTick=s.tick+Math.round(E.HZ*1.30),localLater=E.fireLaneTickForState(s,row,laterTick);
 const expected=E.cars(row,localLater);assert.deepEqual(E.carsForState(s,row,laterTick),expected,'fire brigade must ignore pedestrian priority');assert.ok(expected.length>0,'fire truck should enter shortly after the block activates');
});

test('ignoring the golden crossing consumes the opportunity and requires another normal crossing',()=>{
 const {s,crosswalks}=prepareCrosswalks(54321,3);crossWithoutTraffic(s,crosswalks[0]);
 const golden=s.segments.find(seg=>seg.index===E.crosswalkSnapshot(s).goldenSegmentIndex);assert.ok(golden);
 crossWithoutTraffic(s,golden,{inside:false});
 const snap=E.crosswalkSnapshot(s);assert.equal(snap.goodCrossings,0);assert.equal(snap.rewardReady,false);assert.equal(snap.goldenSegmentIndex,null);assert.equal(snap.lastEvent.type,'lost');
});

test('pedestrian-priority queue keeps physical spacing and resumes from the held positions without teleporting',()=>{
 const {s,crosswalks}=prepareCrosswalks(24680,3);crossWithoutTraffic(s,crosswalks[0]);
 const golden=s.segments.find(seg=>seg.index===E.crosswalkSnapshot(s).goldenSegmentIndex);assert.ok(golden);
 for(const row of golden.rows)s.rows.set(row.index,row);
 const candidates=golden.rows.filter(r=>!r.safe&&!E.isFireLane(r)).sort((a,b)=>a.period-b.period);assert.ok(candidates.length);
 const row=candidates[0];
 s.y=golden.start;s.maxRow=0;s.x=golden.crosswalk.center;s.move=null;s.queued=null;s.over=false;s.reason='';
 assert.equal(E.input(s,'forward'),true);s.move=null; // activate the gate but keep the player safely on the pavement
 let stopped=[];
 for(let i=0;i<E.HZ*10&&!s.over;i++){
  E.step(s);stopped=E.carsForState(s,row,s.tick).filter(c=>c.stopped);
  if(stopped.length>=2)break;
 }
 assert.ok(stopped.length>=2,'expected at least two queued civilian vehicles');
 const dir=row.dir||1,ordered=[...stopped].sort((a,b)=>dir>0?b.x-a.x:a.x-b.x);
 for(let i=1;i<ordered.length;i++){
  const front=ordered[i-1],back=ordered[i],gap=Math.abs(front.x-back.x)-(front.width+back.width)/2;
  assert.ok(gap>=.33,`queued vehicles overlap: gap=${gap}`);
 }
 const before=new Map(E.carsForState(s,row,s.tick).filter(c=>c.stopped).map(c=>[c.id,c.x]));
 s.crosswalk.gate.releaseTick=s.tick;E.step(s);
 const after=new Map(E.carsForState(s,row,s.tick).map(c=>[c.id,c.x]));
 let resumed=0;
 for(const [id,x0] of before){if(!after.has(id))continue;const delta=after.get(id)-x0;assert.ok(Math.abs(delta)<=row.speed/E.HZ*1.15+.002,`vehicle ${id} teleported by ${delta}`);if(delta*dir>0)resumed++;}
 assert.ok(resumed>0,'queued traffic should resume forward from its held coordinates');
});
