'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),{DatabaseSync}=require('node:sqlite');
const workerCode=fs.readFileSync(require.resolve('../_worker.js'),'utf8');
function setup(){const sql=new DatabaseSync(':memory:');const DB={prepare(text){let args=[];return {bind(...a){args=a;return this;},async first(){return sql.prepare(text).get(...args)||null;},async all(){return {results:sql.prepare(text).all(...args)};},async run(){const r=sql.prepare(text).run(...args);return {meta:{changes:Number(r.changes)}};}};},async batch(statements){sql.exec('BEGIN');try{const out=[];for(const q of statements)out.push(await q.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};const ctx={console,crypto:require('node:crypto').webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};vm.createContext(ctx);vm.runInContext(workerCode.replace('export default','globalThis.worker ='),ctx);return {sql,ctx,env:{DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}}};}
async function readOk(response){const body=await response.json();assert.equal(response.ok,true,JSON.stringify(body));return body;}

const E=require('../arcade-engine.js');
test('crossing official start, verified score, rejected tampering and idempotent finish',async()=>{
 const {sql,ctx,env}=setup();
 const call=(path,body,token)=>ctx.worker.fetch(new Request('https://test.local/api/'+path,{method:'POST',headers:{'x-admin-pin':'4321','content-type':'application/json',...(token?{authorization:'Bearer '+token}:{})},body:JSON.stringify(body)}),env);
 await readOk(await call('admin/database/reset',{mode:'seed'}));
 const login=await readOk(await call('login',{playerId:'admin-test-01',pin:'1234'}));
 const token=login.sessionToken;
 const start=await readOk(await call('arcade/start',{},token));
 assert.equal(start.rulesVersion,E.VERSION);
 assert.equal(start.seed,E.hashSeed(start.runId));
 const s=E.create(start.seed);E.input(s,'forward');while(!s.over)E.step(s);
 sql.prepare('UPDATE crossing_v11_runs SET started_at_ms=? WHERE run_id=?').run(Date.now()-15000,start.runId);
 const payload={runId:start.runId,rulesVersion:11,ticks:s.tick,events:s.events,score:999999};
 const before=sql.prepare('SELECT games_played FROM crossing_v11_scores WHERE player_id=?').get('admin-test-01').games_played;
 const result=await readOk(await call('arcade/finish',payload,token));assert.equal(result.score,s.maxRow);
 await readOk(await call('arcade/finish',payload,token));
 assert.equal(sql.prepare('SELECT games_played FROM crossing_v11_scores WHERE player_id=?').get('admin-test-01').games_played,before+1);
 const second=await readOk(await call('arcade/start',{rulesVersion:11},token));
 assert.equal((await call('arcade/finish',{...payload,runId:second.runId,events:[{t:0,d:'teleport'}]},token)).status,400);
 assert.equal(sql.prepare('SELECT score FROM crossing_v11_runs WHERE run_id=?').get(second.runId).score,null);
});
