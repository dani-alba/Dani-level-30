'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const css=fs.readFileSync(path.join(__dirname,'..','styles.css'),'utf8');

test('BOTÍN layout rebalance centers a larger vault below the bar',()=>{
  assert.match(css,/v22\.88 · BOTÍN 30 layout rebalance/);
  assert.match(css,/body\.safe-playing \.safe-machine--precision\{[\s\S]*place-items:center center!important;/);
  assert.match(css,/body\.safe-playing \.safe-vault\{[\s\S]*width:min\(69vw,34dvh,274px\)!important;/);
  assert.match(css,/body\.safe-playing \.safe-game--precision\{[\s\S]*grid-template-rows:auto minmax\(82px,\.35fr\) 38px minmax\(0,1fr\)!important;/);
});
