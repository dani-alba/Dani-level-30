'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),js=fs.readFileSync(path.join(root,'arcade.js'),'utf8'),html=fs.readFileSync(path.join(root,'index.html'),'utf8'),css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('pursuit audio is event-based, has no siren loop and ships without a dedicated mute button',()=>{
 assert.match(js,/policeCueTimes/);assert.match(js,/15000/);assert.doesNotMatch(js,/dani30:fuga-sfx-muted/);assert.doesNotMatch(js,/\.loop\s*=\s*true/);assert.doesNotMatch(js,/setInterval\([^)]*Police/i);assert.doesNotMatch(html,/id="crossingSoundToggle"/);
});

test('legacy FUGA police HUD, car and proximity copy are removed instead of hidden',()=>{
 assert.doesNotMatch(html,/id="crossingPursuit"|id="crossingPursuitBar"|id="crossingPursuitText"/);
 assert.doesNotMatch(html,/🚓/);
 assert.doesNotMatch(css,/\.crossing-pursuit/);
 assert.doesNotMatch(js,/Luces proyectadas delante del coche|carY=h\+30-closeness|crossingPursuitBar|crossingPursuitText|#crossingPursuit/);
});

test('pursuit presentation is environmental, interpolated and driven by internal police distance',()=>{
 assert.match(js,/function drawPursuitPressure\(/);
 assert.match(js,/1-\(Number\(pursuit\.distance\)\|\|0\)\/maxDistance/);
 assert.match(js,/visual\.frontY\+=\(targetFront-visual\.frontY\)\*follow/);
 assert.match(js,/visual\.intensity\+=\(targetIntensity-visual\.intensity\)/);
 assert.match(js,/Reflejos de patrullas fuera de cámara/);
 assert.match(js,/Frente irregular: una presión del mundo, no una barra de interfaz/);
});

test('pursuit presentation is draw-only and does not participate in engine collision or input',()=>{
 const start=js.indexOf('function drawPursuitPressure('),end=js.indexOf('function updatePursuitSignals()',start),block=js.slice(start,end);
 assert.ok(start>=0&&end>start);
 assert.doesNotMatch(block,/engine\.input|engine\.collision|engine\.step|s\.over\s*=|reason\s*=/);
});

test('pursuit render uses the engine timestep and cannot reference an undefined global HZ',()=>{
 assert.match(js,/state\.game\.tick\/engine\.HZ/);assert.doesNotMatch(js,/state\.game\.tick\/HZ/);
});

test('movement has one explicit lightweight feedback call after an accepted engine input',()=>{
 const move=js.slice(js.indexOf('function move(dir)'),js.indexOf('function pauseGame'));assert.match(move,/engine\.input/);assert.equal((move.match(/playMoveSfx\(/g)||[]).length,1);
});

test('refuge obstacles remain rendered as gameplay geometry',()=>{
 assert.match(js,/function drawRefugeObstacle/);
 assert.match(js,/for\(const c of row\.blocked\|\|\[\]\)drawRefugeObstacle/);
});
