'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');

test('project handoff contract is present and points to current source of truth',()=>{
  const guide=read('PROJECT-GUIDE.md'),readme=read('README.txt'),pkg=JSON.parse(read('package.json')),map=JSON.parse(read('test-impact-map.json'));
  assert.match(guide,/Source of truth for development and handoff/);
  assert.match(guide,/Operación 30 · five phases/);
  assert.match(guide,/Phase 5 remains \*\*EN CURSO\*\*/);
  assert.match(guide,/PREPARADO.*completed Phase 4/s);
  assert.match(guide,/test:impact/);
  assert.match(readme,/PROJECT-GUIDE\.md/);
  const release=guide.match(/Current project release: \*\*v(\d+)\.(\d+)\*\*/);
  assert.ok(release,'PROJECT-GUIDE.md must declare the current release');
  assert.equal(pkg.version,`${Number(release[1])}.${Number(release[2])}.0`);
  assert.ok(fs.existsSync(path.join(root,`VERSION-${release[1]}.${release[2]}`)),'current VERSION file must match PROJECT-GUIDE.md');
  assert.equal(pkg.scripts['test:impact'],'node scripts/test-impact.mjs');
  assert.ok(map.groups.release.includes('tests/project-maintenance-contract.test.js'));
  for(const entries of Object.values(map.groups))for(const file of entries)assert.ok(fs.existsSync(path.join(root,file)),`impact map references missing test: ${file}`);
});
