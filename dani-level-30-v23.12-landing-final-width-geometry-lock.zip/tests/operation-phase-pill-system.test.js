'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8'),css=fs.readFileSync(path.join(root,'styles.css'),'utf8'),arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8');

test('all five preparation phases keep the shared rounded information-block language',()=>{
  const phase1=(html.match(/brief-row[^\"]*operation-info-block/g)||[]).length;
  assert.ok(phase1>=4,'Phase 1 briefing units should use the common shell');
  assert.match(html,/rsvp-confirmed__summary operation-info-block operation-info-block--status/);
  assert.match(html,/card hack operation-info-block operation-info-block--feature/);
  assert.match(html,/safehouse card operation-info-block operation-info-block--feature/);
  assert.match(html,/npc-card operation-info-block operation-info-block--feature/);
  assert.match(html,/before-party operation-info-block operation-info-block--feature/);
  assert.match(html,/operation-stage5__intro operation-info-block operation-info-block--narrative/);
  assert.match(html,/operation-stage5__competition operation-info-block operation-info-block--competition/);
  assert.match(css,/v22\.93 · Unified Operation 30 phase information system/);
  assert.match(css,/v22\.94 · Five-phase preparation architecture/);
  assert.match(css,/\.operation-stage__panel \.operation-info-block\{/);
});

test('Phase 5 keeps the explanatory note inside the competition pill and the CTA outside',()=>{
  const competition=html.match(/<div class="operation-stage5__competition[\s\S]*?<\/div>\n<button class="btn btn--accent operation-stage5__cta"/);
  assert.ok(competition,'Phase 5 competition card should contain the note before the external CTA');
  assert.match(competition[0],/id="operationStage5CompetitionNote"/);
});

test('Phase 5 renders podium positions with medals and later positions with hash numbers',()=>{
  assert.match(arcade,/function formatStageCompetitionRank\(rank\)/);
  assert.match(arcade,/n===1\?'🥇':n===2\?'🥈':n===3\?'🥉':n\?`#\$\{n\}`/);
  assert.match(arcade,/formatStageCompetitionRank\(rank\).*PROVISIONALES/);
});
