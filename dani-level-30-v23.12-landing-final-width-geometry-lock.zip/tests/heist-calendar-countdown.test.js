
'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');

function loadCore(){
  const code=fs.readFileSync(path.join(root,'ui-core.js'),'utf8');
  const document={querySelector(){return null},querySelectorAll(){return []}};
  const window={document,matchMedia(){return {matches:false}},DANI_CORE:null};
  const context={window,document,Intl,Date,Math,Object,Array,String,Number,JSON,console,setTimeout,clearTimeout};
  vm.createContext(context);
  vm.runInContext(code,context);
  return context.window.DANI_CORE;
}

test('El Golpe visual days change at Madrid midnight, not at the 13:00 event hour',()=>{
  const core=loadCore();
  const clock=core.createEventClock({start:'2026-12-12T13:00:00+01:00',timeZone:'Europe/Madrid'});
  const beforeMidnight=clock.snapshot(Date.parse('2026-12-10T23:59:00+01:00'));
  const afterMidnight=clock.snapshot(Date.parse('2026-12-11T00:01:00+01:00'));
  assert.equal(beforeMidnight.calendarDaysRemaining,2);
  assert.equal(afterMidnight.calendarDaysRemaining,1);
  assert.ok(afterMidnight.remainingMs>24*60*60*1000,'exact event clock still has more than 24h remaining');
});

test('event day is zero calendar days while exact clock still counts down to 13:00',()=>{
  const core=loadCore();
  const clock=core.createEventClock({start:'2026-12-12T13:00:00+01:00',timeZone:'Europe/Madrid'});
  const snap=clock.snapshot(Date.parse('2026-12-12T00:01:00+01:00'));
  assert.equal(snap.calendarDaysRemaining,0);
  assert.equal(snap.isEventDay,true);
  assert.ok(snap.remainingMs>12*60*60*1000);
});

test('heist card uses calendar days, tomorrow and exact event-day clock states',()=>{
  const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
  const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
  assert.match(app,/snapshot\.calendarDaysRemaining/);
  assert.match(app,/previewValue\.textContent = 'MAÑANA'/);
  assert.match(app,/previewLabel\.textContent = 'HOY · EMPIEZA EN'/);
  assert.match(crew,/stateLabel = 'ESTA SEMANA'/);
  assert.match(crew,/button\.hidden = !live/);
  assert.match(crew,/button\.textContent = 'ENTRAR AL GOLPE →'/);
  assert.match(crew,/function heistPreparationContext\(profile, snapshot\)/);
});
