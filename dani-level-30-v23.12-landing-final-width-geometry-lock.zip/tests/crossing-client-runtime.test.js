'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');

class ClassList{
  constructor(){this.s=new Set();}
  add(...v){v.forEach(x=>this.s.add(x));}
  remove(...v){v.forEach(x=>this.s.delete(x));}
  contains(v){return this.s.has(v);}
  toggle(v,force){if(force===true){this.s.add(v);return true;}if(force===false){this.s.delete(v);return false;}if(this.s.has(v)){this.s.delete(v);return false;}this.s.add(v);return true;}
}
class Element{
  constructor(tag='div',id=''){this.tagName=tag.toUpperCase();this.id=id;this.hidden=false;this.disabled=false;this.textContent='';this.dataset={};this.style={setProperty(k,v){this[k]=v;}};this.classList=new ClassList();this.children=[];this.listeners={};this.open=false;this._innerHTML='';}
  addEventListener(type,fn){(this.listeners[type]??=[]).push(fn);}
  click(){for(const fn of this.listeners.click||[])fn({detail:0,target:this,stopPropagation(){},preventDefault(){}});}
  appendChild(el){this.children.push(el);return el;}
  append(...els){this.children.push(...els);}
  replaceChildren(...els){this.children=[...els];}
  setAttribute(){}
  scrollTo(){}
  showModal(){this.open=true;}
  close(){this.open=false;for(const fn of this.listeners.close||[])fn({target:this});}
  querySelector(sel){
    if(sel==='.arcade-shell')return this.shell||null;
    if(sel==='strong')return this.strongChild||null;
    if(sel==='span')return this.spanChild||null;
    const m=sel.match(/^\[data-slot="(\d+)"\]$/);if(m)return this.children.find(c=>c.dataset.slot===m[1])||null;
    return null;
  }
  set innerHTML(v){this._innerHTML=v;} get innerHTML(){return this._innerHTML;}
}


Element.prototype.getBoundingClientRect=function(){return {width:390,height:844,left:0,top:0};};
Element.prototype.setPointerCapture=function(){};
Element.prototype.scrollIntoView=function(){};
Element.prototype.scrollBy=function(){};
Element.prototype.fire=function(type,values={}){for(const fn of this.listeners[type]||[])fn({target:this,isPrimary:true,button:0,pointerId:1,clientX:180,clientY:400,preventDefault(){},stopPropagation(){},...values});};
function setup(){
 const source=fs.readFileSync(path.join(root,'index.html'),'utf8');
 const map=new Map([...source.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element('div',m[1])]));
 const buttons=[...source.matchAll(/data-crossing-dir=\"([^\"]+)\"/g)].map(m=>{const e=new Element('button');e.dataset.crossingDir=m[1];return e;});
 let time=1000,seq=0;const frames=new Map(),windowEvents={},documentEvents={};
 const drawing=new Proxy({},{get:()=>()=>{},set:()=>true});map.get('arcadeCanvas').getContext=()=>drawing;
 const document={body:new Element('body'),documentElement:new Element('html'),hidden:false,querySelector(sel){if(sel[0]==='#')return map.get(sel.slice(1))||null;return buttons.find(b=>sel.includes('"'+b.dataset.crossingDir+'"'))||null;},querySelectorAll:()=>buttons,createElement:t=>new Element(t),addEventListener(t,f){documentEvents[t]=f;}};
 let finishCalls=0,failSave=false;const status={phase:'open',playerBest:0,leaderboard:[],rewards:[],awards:[]};
 const ctx={document,console,performance:{now:()=>time},innerHeight:844,devicePixelRatio:2,setTimeout:f=>setImmediate(f),clearTimeout:clearImmediate,requestAnimationFrame:f=>{frames.set(++seq,f);return seq;},cancelAnimationFrame:id=>frames.delete(id),localStorage:{getItem:()=>null,setItem(){}}};
 ctx.window=ctx;ctx.globalThis=ctx;ctx.addEventListener=(t,f)=>windowEvents[t]=f;ctx.DANI_CORE={$:s=>document.querySelector(s),reducedMotion:true};
 ctx.DANI_CREW={getLocalProfile:()=>({id:'p1',attendance:'yes',uiPrefs:{arcadeDiscovered:true}}),arcadeLeaderboard:async()=>({...status}),arcadeStart:async()=>({runId:'runtime-test',seed:2,rulesVersion:11}),arcadeFinish:async(runId,score,proof)=>{finishCalls++;if(failSave)throw Error('Sin conexión');const verified=ctx.DANI_ARCADE_ENGINE.replay(2,proof.events,proof.ticks);assert.equal(verified.score,score);return {...status,score,newRecord:true};}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'arcade-engine.js'),'utf8'),ctx);vm.runInContext(fs.readFileSync(path.join(root,'arcade.js'),'utf8'),ctx);
 function advance(count){for(let i=0;i<count;i++){time+=1000/60;const callbacks=[...frames.values()];frames.clear();callbacks.forEach(f=>f(time));}}
 return {ctx,map,buttons,advance,windowEvents,documentEvents,finishCalls:()=>finishCalls,setFail:v=>failSave=v};
}
const flush=async()=>{for(let i=0;i<6;i++)await new Promise(r=>setImmediate(r));};
test('touch, swipe, cancel, pause, verified finish and repeated retry lifecycle',async()=>{
 const r=setup(),{ctx,map,advance}=r;assert.equal(r.buttons.length,0,'Fuga should ship without visible directional buttons');await ctx.DANI_ARCADE.open();map.get('arcadeStart').click();await flush();assert.equal(ctx.DANI_ARCADE.getDiagnostics().running,true);
 const surface=map.get('arcadeTouchSurface');surface.fire('pointerdown');surface.fire('pointerup');advance(12);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.y,1);
 surface.fire('pointerdown');surface.fire('pointermove',{clientX:135});surface.fire('pointerup',{clientX:135});advance(12);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.x,3.5);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.y,1);
 surface.fire('pointerdown');surface.fire('pointercancel');surface.fire('pointerup');advance(12);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.y,1);
 r.windowEvents.blur();const pausedTick=ctx.DANI_ARCADE.getDiagnostics().game.tick;advance(30);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.tick,pausedTick);map.get('crossingResume').click();advance(420);await flush();
 assert.equal(map.get('arcadeResult').hidden,false);assert.equal(map.get('arcadeResultScore').textContent,'1');assert.equal(r.finishCalls(),1);
 for(let i=0;i<3;i++){map.get('arcadeRetry').click();await flush();assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.y,0);surface.fire('pointerdown');surface.fire('pointerup');advance(12);assert.equal(ctx.DANI_ARCADE.getDiagnostics().game.y,1);advance(420);await flush();}
 assert.equal(r.finishCalls(),4);map.get('arcadeRetry').click();await flush();map.get('arcadeExitGame').click();assert.equal(ctx.DANI_ARCADE.getDiagnostics().paused,true);map.get('arcadePauseExit').click();await flush();assert.equal(ctx.DANI_ARCADE.getDiagnostics().running,false);
});
test('failed save retains proof and can be retried without replaying the game',async()=>{const r=setup();await r.ctx.DANI_ARCADE.open();r.map.get('arcadeStart').click();await flush();const surf=r.map.get('arcadeTouchSurface');surf.fire('pointerdown');surf.fire('pointerup');r.setFail(true);r.advance(420);await flush();assert.equal(r.map.get('crossingSave').hidden,false);r.setFail(false);r.map.get('crossingSave').click();await flush();assert.equal(r.map.get('crossingSave').hidden,true);assert.equal(r.map.get('arcadeResultKicker').textContent,'FUGA TERMINADA');assert.match(r.map.get('arcadeResultRank').textContent,/NUEVO RÉCORD/);});

test('pause survives tab blur, but navigation discards the active run instead of restoring it',async()=>{
 const r=setup(),{ctx,map,windowEvents}=r;await ctx.DANI_ARCADE.open();map.get('arcadeStart').click();await flush();
 assert.equal(ctx.DANI_ARCADE.getDiagnostics().running,true);
 windowEvents.blur();assert.equal(ctx.DANI_ARCADE.getDiagnostics().paused,true);assert.equal(map.get('arcadePauseMenu').hidden,false);
 windowEvents.pagehide({persisted:true});
 const after=ctx.DANI_ARCADE.getDiagnostics();assert.equal(after.running,false);assert.equal(after.paused,false);assert.equal(after.game,null);assert.equal(map.get('arcadePauseMenu').hidden,true);
 windowEvents.pageshow({persisted:true});assert.equal(ctx.DANI_ARCADE.getDiagnostics().game,null);
});

test('Hub JUGAR launches FUGA directly without requiring the intro CTA',async()=>{
 const r=setup();r.map.get('clandestinePlayFuga').click();await flush();assert.equal(r.ctx.DANI_ARCADE.getDiagnostics().running,true);assert.equal(r.map.get('arcadeIntro').hidden,true);assert.equal(r.map.get('arcadeGame').hidden,false);
});
