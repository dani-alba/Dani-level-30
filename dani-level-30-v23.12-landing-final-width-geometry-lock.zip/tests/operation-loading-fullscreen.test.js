'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const inf=fs.readFileSync(path.join(root,'infiltration.js'),'utf8');
const blind=fs.readFileSync(path.join(root,'pointblind.js'),'utf8');
const safe=fs.readFileSync(path.join(root,'safe.js'),'utf8');
const fuga=fs.readFileSync(path.join(root,'arcade.js'),'utf8');

test('all operation loaders share the same fullscreen shell behaviour',()=>{
  assert.match(css,/body\.operation-loading-open\{overflow:hidden!important;overscroll-behavior:none\}/);
  assert.match(css,/\.operation-loading\{\n  position:fixed;inset:0;z-index:1400;/);
  assert.match(css,/height:var\(--operation-loading-height,100dvh\)/);
  for (const js of [inf,blind,safe,fuga]) {
    assert.match(js,/function syncOperationLoadingViewport\(\)/);
    assert.match(js,/document\.body\.classList\.add\('operation-loading-open'\)/);
    assert.match(js,/document\.body\.classList\.remove\('operation-loading-open'\)/);
  }
});
