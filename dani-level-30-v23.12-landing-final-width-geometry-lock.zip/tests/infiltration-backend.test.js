'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const cryptoNode=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const E=require('../infiltration-engine.js');
const workerCode=fs.readFileSync(require.resolve('../_worker.js'),'utf8');

function setup(){
  const sql=new DatabaseSync(':memory:');
  sql.exec(fs.readFileSync(require.resolve('../schema.sql'),'utf8'));
  let now=Date.parse('2026-09-23T10:00:00Z');
  class Clock extends Date{static now(){return now;}}
  const DB={
    prepare(text){let args=[];return {bind(...a){args=a;return this;},async first(){return sql.prepare(text).get(...args)||null;},async all(){return {results:sql.prepare(text).all(...args)};},async run(){const r=sql.prepare(text).run(...args);return {meta:{changes:Number(r.changes)}};}};},
    async batch(statements){sql.exec('BEGIN');try{const out=[];for(const q of statements)out.push(await q.run());sql.exec('COMMIT');return out;}catch(error){sql.exec('ROLLBACK');throw error;}}
  };
  const ctx={Date:Clock,console,crypto:cryptoNode.webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};
  vm.createContext(ctx);vm.runInContext(workerCode.replace('export default','globalThis.worker ='),ctx);
  const env={DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}};
  return {sql,ctx,env,setTime:(value)=>{now=value;},getTime:()=>now};
}

function tokenHash(token){return cryptoNode.createHash('sha256').update(token).digest('hex');}
function addPlayer(sql,id='p1',token='token-1'){sql.prepare('INSERT INTO players(id,name,attendance,avatar,session_hash,briefing_completed) VALUES(?,?,?,?,?,1)').run(id,id,'yes','🕶️',tokenHash(token));return token;}
function goodEvents(rounds=5,seed=E.SEED){const state=E.create(seed);for(let r=0;r<rounds;r+=1){for(const slot of state.route.pattern.slice().reverse())E.act(state,{kind:'tap',slot});}const used=new Set(state.route.pattern);let wrong=0;while(used.has(wrong))wrong+=1;E.act(state,{kind:'tap',slot:wrong});return state.events.slice();}
async function api(ctx,env,path,{method='GET',token,body}={}){const headers={};if(token)headers.authorization=`Bearer ${token}`;if(body!==undefined)headers['content-type']='application/json';const response=await ctx.worker.fetch(new Request(`https://test.local/api/${path}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),env);const data=await response.json();return {response,data};}

test('worker embeds exactly the browser infiltration engine',()=>{assert.ok(workerCode.includes('// BEGIN SHARED INFILTRATION ENGINE\n'+fs.readFileSync(require.resolve('../infiltration-engine.js'),'utf8')+'// END SHARED INFILTRATION ENGINE'));});

test('start -> finish -> leaderboard uses the same three-table skeleton as the other operations',async()=>{
  const {sql,ctx,env,setTime,getTime}=setup();
  const token=addPlayer(sql);
  let result=await api(ctx,env,'infiltration/start',{method:'POST',token});
  assert.equal(result.response.status,200,JSON.stringify(result.data));
  assert.ok(result.data.runId);
  assert.equal(sql.prepare('SELECT COUNT(*) n FROM operation_infiltration_v6_runs WHERE run_id=?').get(result.data.runId).n,1);
  const startSeed=result.data.seed;
  const events=goodEvents(5,startSeed);
  setTime(getTime()+120000);
  result=await api(ctx,env,'infiltration/finish',{method:'POST',token,body:{runId:result.data.runId,events}});
  assert.equal(result.response.status,200,JSON.stringify(result.data));
  assert.equal(result.data.score,E.replay(events,startSeed).score);
  assert.equal(result.data.playerRank,1);
  assert.equal(sql.prepare('SELECT COUNT(*) n FROM operation_infiltration_v6_scores WHERE player_id=?').get('p1').n,1);
  result=await api(ctx,env,'infiltration/leaderboard',{token});
  assert.equal(result.response.status,200,JSON.stringify(result.data));
  assert.equal(result.data.leaderboard[0].playerId,'p1');
  assert.equal(result.data.leaderboard[0].score,E.replay(events,startSeed).score);
});

test('finish is idempotent and a run belongs only to its player',async()=>{
  const {sql,ctx,env,setTime,getTime}=setup();
  const token1=addPlayer(sql,'p1','token-1');
  const token2=addPlayer(sql,'p2','token-2');
  const started=await api(ctx,env,'infiltration/start',{method:'POST',token:token1});
  const events=goodEvents(5,started.data.seed);setTime(getTime()+120000);
  const first=await api(ctx,env,'infiltration/finish',{method:'POST',token:token1,body:{runId:started.data.runId,events}});
  const second=await api(ctx,env,'infiltration/finish',{method:'POST',token:token1,body:{runId:started.data.runId,events:[]}});
  assert.equal(first.response.status,200);assert.equal(second.response.status,200);assert.equal(second.data.score,first.data.score);
  const other=await api(ctx,env,'infiltration/finish',{method:'POST',token:token2,body:{runId:started.data.runId,events}});
  assert.equal(other.response.status,404);
  assert.equal(sql.prepare('SELECT COUNT(*) n FROM operation_infiltration_v6_runs WHERE score IS NOT NULL').get().n,1);
});

test('only the general championship pays once after contest close',async()=>{
  const {sql,ctx,env,setTime}=setup();
  await ctx.worker.fetch(new Request('https://test.local/api/admin/database/reset',{method:'POST',headers:{'x-admin-pin':'4321','content-type':'application/json'},body:JSON.stringify({mode:'seed'})}),env);
  setTime(Date.parse('2026-12-12T12:00:01Z'));
  await ctx.settleClandestineChampionship(env.DB);
  await ctx.settleClandestineChampionship(env.DB);
  assert.equal(sql.prepare("SELECT COUNT(*) n FROM clandestine_championship_awards").get().n,3);
  assert.equal(sql.prepare("SELECT COUNT(*) n FROM operation_infiltration_v6_podium_awards").get().n,0);
  assert.equal(sql.prepare("SELECT COUNT(*) n FROM economy_events WHERE source_id='OPERACION30'").get().n,3);
  const totals=sql.prepare("SELECT SUM(cash_reward) cash,SUM(respect_reward) respect FROM clandestine_championship_awards").get();
  assert.equal(totals.cash,1750);assert.equal(totals.respect,19);
});
