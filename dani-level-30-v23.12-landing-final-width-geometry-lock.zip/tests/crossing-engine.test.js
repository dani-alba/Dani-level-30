'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../arcade-engine.js');
const advance=(s,n)=>{for(let i=0;i<n&&!s.over;i++)E.step(s);};
const safeRow=index=>({index,safe:true,dir:0,speed:0,length:0,period:0,phase:0,color:0,pattern:[],gapSeconds:[],blocked:[]});

test('one queued step at most; no ghost movements from repeated taps',()=>{
 const s=E.create(2);assert.ok(E.input(s,'right'));assert.ok(E.input(s,'left'));assert.equal(E.input(s,'forward'),false);advance(s,E.LATERAL_STEP*2+4);assert.equal(s.x,4);assert.equal(s.y,0);assert.equal(s.move,null);assert.equal(s.events.length,2);
});

test('lateral movement uses half-cell precision, backtracking never farms score and edges still reject movement',()=>{
 const s=E.create(3);s.rows.set(1,safeRow(1));E.input(s,'forward');advance(s,E.FORWARD_STEP);assert.equal(s.maxRow,1);E.input(s,'backward');advance(s,E.FORWARD_STEP);E.input(s,'forward');advance(s,E.FORWARD_STEP);assert.equal(s.maxRow,1);
 assert.equal(E.input(s,'left'),true);advance(s,E.LATERAL_STEP);assert.equal(s.x,3.5);
 for(let i=0;i<7;i++){assert.equal(E.input(s,'left'),true);advance(s,E.LATERAL_STEP);}assert.equal(s.x,0);assert.equal(E.input(s,'left'),false);
});

test('collision checks destination lane during hop, before discrete landing',()=>{
 const s=E.create(4);s.y=1;s.rows.set(2,{index:2,safe:false,dir:1,speed:0,length:1.2,period:100,phase:4,blocked:[]});E.input(s,'forward');advance(s,E.FORWARD_STEP);assert.equal(s.reason,'traffic');assert.ok(s.tick<E.FORWARD_STEP);assert.equal(s.y,1);
});

test('waiting and repositioning on a refuge has no inactivity death',()=>{
 const s=E.create(4);E.input(s,'right');advance(s,E.LATERAL_STEP);advance(s,E.HZ*30);assert.equal(s.over,false);assert.equal(s.reason,'');assert.equal(s.maxRow,0);
});

test('recorded commands replay identically across varied runs',()=>{
 for(let seed=1;seed<=40;seed++){const s=E.create(seed);for(let i=0;i<18000&&!s.over;i++){if(i%23===0)E.input(s,i%7===0?'right':'forward');E.step(s);}assert.equal(s.over,true,`seed ${seed} should reach traffic in diagnostic run`);const r=E.replay(seed,s.events,s.tick);assert.equal(r.score,s.maxRow);assert.equal(r.reason,s.reason);}
});

test('replay rejects impossible events, unfinished and extended runs',()=>{
 assert.throws(()=>E.replay(1,[{t:0,d:'teleport'}],20));assert.throws(()=>E.replay(1,[{t:0,d:'left'},{t:0,d:'left'},{t:0,d:'left'}],20));assert.throws(()=>E.replay(1,[],100));assert.throws(()=>E.replay(1,[],E.MAX_TICKS+1));
});

test('opening traffic is deliberately breathable and teaches the player before pressure grows',()=>{
 for(let seed=1;seed<=20;seed++){
  const s=E.create(seed);const first=s.segments[0];assert.equal(first.roads,2);assert.equal(first.fallback,false);
  for(const row of first.rows.filter(r=>!r.safe)){
   assert.ok(row.occupancy<=.38,`seed ${seed} opening occupancy ${row.occupancy}`);
   assert.ok(row.maxGapSeconds>=3.3,`seed ${seed} opening gap ${row.maxGapSeconds}`);
   assert.notEqual(row.family,'dense');
  }
  assert.equal(E.segmentValid(first),true);
 }
});

test('traffic vocabulary creates real decisions: large invitations, bursts, lone fast cars, slow convoys and varied speeds',()=>{
 const families=new Set(),types=new Set();let hugeGap=false,platoon=false,fastScout=false,slowConvoy=false,sameDirection=false;
 for(let seed=1;seed<=8;seed++){
  let start=0;
  for(let idx=0;idx<22;idx++){
   const seg=E.buildSegment(seed,idx,start);start=seg.end;const roads=seg.rows.filter(r=>!r.safe),dirs=roads.map(r=>r.dir);
   if(dirs.some((d,i)=>i&&d===dirs[i-1]))sameDirection=true;
   for(const row of roads){families.add(row.family);for(const v of row.pattern)types.add(v.type);if(row.maxGapSeconds>=5.2)hugeGap=true;if(row.family==='platoon'&&row.pattern.length>=3&&row.gapSeconds.some(g=>g>=4.6))platoon=true;if(row.family==='scout'&&row.speed>=1.55&&row.pattern.length===1)fastScout=true;if(row.family==='convoy'&&row.speed<=1.2)slowConvoy=true;}
   assert.equal(E.segmentValid(seg),true);
  }
 }
 for(const family of ['open','regular','irregular','platoon','heavy','scout','convoy'])assert.ok(families.has(family),`missing ${family}`);
 for(const type of ['car','van','bus'])assert.ok(types.has(type),`missing ${type}`);
 assert.equal(hugeGap,true);assert.equal(platoon,true);assert.equal(fastScout,true);assert.equal(slowConvoy,true);assert.equal(sameDirection,true);
});

test('road blocks grow from a gentle 2-lane opening to interleaved 6–9 lane challenges instead of a monotonic wall',()=>{
 const seen=new Set(),late=[];for(let seed=1;seed<=6;seed++){let start=0;for(let idx=0;idx<46;idx++){const seg=E.buildSegment(seed,idx,start);start=seg.end;seen.add(seg.roads);if(idx>=24)late.push(seg.roads);}}
 for(let n=2;n<=9;n++)assert.ok(seen.has(n),`missing ${n}-lane block`);
 assert.ok(late.some(n=>n>=8));assert.ok(late.some(n=>n<=5));
 let changes=0;for(let i=1;i<late.length;i++)if(late[i]!==late[i-1])changes++;assert.ok(changes/(late.length-1)>.72,'late blocks should keep changing size frequently');
});

test('human-playability validation caps occupancy and rejects one-perfect-window designs',()=>{
 for(let seed=1;seed<=10;seed++){let start=0;for(let idx=0;idx<28;idx++){const seg=E.buildSegment(seed,idx,start);start=seg.end;assert.equal(E.humanReadableSegment(seg),true);for(const row of seg.rows.filter(r=>!r.safe)){assert.ok(row.occupancy<=.50);assert.ok(row.maxGapSeconds>=2.45);}}}
});

test('police is foreshadowed before it becomes active and short observation remains free',()=>{
 const s=E.create(77);s.maxRow=24;E.step(s);let p=E.policeSnapshot(s);assert.equal(p.warning,false);assert.equal(p.active,false);
 s.maxRow=30;E.step(s);p=E.policeSnapshot(s);assert.equal(p.warning,true);assert.equal(p.active,false);assert.equal(p.band,'signal');
 s.maxRow=40;E.step(s);p=E.policeSnapshot(s);assert.equal(p.active,true);const start=p.distance;
 advance(s,Math.floor(E.HZ*3));p=E.policeSnapshot(s);assert.ok(Math.abs(p.distance-start)<.02,'short observation should stay inside grace');assert.equal(s.over,false);
});

test('waiting too long costs police distance, progress restores it and lateral motion cannot farm it',()=>{
 const s=E.create(78);s.maxRow=70;E.step(s);const initial=E.policeSnapshot(s).distance;
 advance(s,Math.floor(E.HZ*7));const pressured=E.policeSnapshot(s).distance;assert.ok(pressured<initial-.5,'long idle should cost distance');
 E.input(s,'left');advance(s,E.LATERAL_STEP);const lateral=E.policeSnapshot(s).distance;assert.ok(lateral<=pressured+.02,'lateral movement must not restore pursuit distance');
 s.maxRow+=1;E.step(s);const recovered=E.policeSnapshot(s).distance;assert.ok(recovered>lateral+.4,'new maximum row should restore meaningful distance');
});

test('chained progress is rewarded more than isolated progress and pursuit pressure has a hard ceiling',()=>{
 const a=E.create(79);a.maxRow=120;E.step(a);advance(a,Math.floor(E.HZ*6));const base=E.policeSnapshot(a).distance;a.maxRow+=1;E.step(a);const single=E.policeSnapshot(a).distance-base;
 const b=E.create(80);b.maxRow=120;E.step(b);advance(b,Math.floor(E.HZ*6));const before=E.policeSnapshot(b).distance;for(let i=0;i<5;i++){b.maxRow+=1;E.step(b);advance(b,Math.floor(E.HZ*.25));}const chain=(E.policeSnapshot(b).distance-before)/5;
 assert.ok(chain>single,'rapid consecutive rows should recover more per row');
 const early=E.policeTuningForRow(45),late=E.policeTuningForRow(500),later=E.policeTuningForRow(5000);assert.ok(late.approachRowsPerSecond>early.approachRowsPerSecond);assert.equal(late.approachRowsPerSecond,later.approachRowsPerSecond);
});

test('police can catch an inactive player after the grace window and reports a distinct defeat reason',()=>{
 const s=E.create(81);s.maxRow=180;E.step(s);advance(s,E.HZ*40);assert.equal(s.over,true);assert.equal(s.reason,'police');assert.equal(E.policeSnapshot(s).distance,0);
});

test('advanced generation includes reproducible chained windows without sacrificing segment validity',()=>{
 let chains=0;for(let seed=1;seed<=12;seed++){let start=0;for(let idx=0;idx<24;idx++){const seg=E.buildSegment(seed,idx,start);start=seg.end;if(seg.chainWindow){chains++;assert.ok(seg.chainWindow.span>=3);assert.equal(E.segmentValid(seg),true);}}}assert.ok(chains>=8,`expected chained windows, got ${chains}`);
});


test('pursuit pressure is tighter than V6 but still leaves a real observation window',()=>{
 const early=E.create(991);early.maxRow=40;E.step(early);const start=E.policeSnapshot(early);
 assert.ok(start.distance<=8.7&&start.distance>=8.5);
 advance(early,Math.floor(E.HZ*2.8));assert.ok(E.policeSnapshot(early).distance>start.distance-.1,'brief reading time should remain nearly free');
 let seconds=0;while(!early.over&&seconds<30){advance(early,E.HZ);seconds++;}
 assert.equal(early.reason,'police');assert.ok(seconds>=13&&seconds<=19,`opening pursuit capture took ${seconds}s`);

 const late=E.create(992);late.maxRow=300;E.step(late);seconds=0;while(!late.over&&seconds<25){advance(late,E.HZ);seconds++;}
 assert.equal(late.reason,'police');assert.ok(seconds>=9&&seconds<=13,`late pursuit capture took ${seconds}s`);
});

test('advanced refuge rows sometimes block approaches, never at the opening, and stay solver-valid',()=>{
 for(let seed=1;seed<=20;seed++)assert.deepEqual(E.safeBlockedFor(seed,20),[]);
 let blockedRows=0, multi=0;
 for(let seed=1;seed<=18;seed++){
  let start=0;
  for(let idx=0;idx<30;idx++){
   const seg=E.buildSegment(seed,idx,start);start=seg.end;
   for(const row of seg.rows.filter(r=>r.safe&&r.index>=34)){
    if(row.blocked.length){blockedRows++;if(row.blocked.length>=2)multi++;}
   }
   assert.equal(E.segmentValid(seg),true);
  }
 }
 assert.ok(blockedRows>=40,`expected visible refuge blockers, got ${blockedRows}`);
 assert.ok(multi>=10,`expected multi-cell refuge obstacles, got ${multi}`);
});

test('refuge obstacles are real geometry: a blocked approach rejects input while an open approach remains usable',()=>{
 const s=E.create(993);s.x=4;s.y=10;s.maxRow=10;s.move=null;s.queued=null;
 s.rows.set(10,{index:10,safe:true,dir:0,speed:0,blocked:[]});
 s.rows.set(11,{index:11,safe:true,dir:0,speed:0,blocked:[4]});
 assert.equal(E.input(s,'forward'),false,'cannot enter a blocked refuge opening');
 s.x=1;
 assert.equal(E.input(s,'forward'),true,'another open refuge opening remains available');
});
