'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
test('crew refresh stays silent during normal loading',()=>{
  assert.doesNotMatch(crew,/ACTUALIZANDO LA BANDA/i);
  assert.match(crew,/function setCrewRefreshBusy\(busy\)/);
  assert.match(crew,/grid\.setAttribute\('aria-busy', busy \? 'true' : 'false'\)/);
  assert.match(crew,/if \(refresh\) await refreshCrew\(\)/);
});
test('crew status remains reserved for real refresh errors',()=>{
  assert.match(crew,/crewError = 'No se ha podido actualizar la banda\./);
  assert.match(crew,/\$\('#retryCrew'\)\.hidden = !crewError/);
});
