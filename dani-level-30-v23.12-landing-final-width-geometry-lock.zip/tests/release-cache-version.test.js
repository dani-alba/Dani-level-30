'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
test('release cache-busts every boot asset consistently',()=>{
 const version=html.match(/const version = '([^']+)'/)?.[1];
 assert.ok(version,'boot version is declared');
 for(const asset of ['styles.css','infiltration.css','pointblind.css','motion-polish.css','desktop.css']) {
   assert.ok(html.includes(`${asset}?v=${version}`),`${asset} uses current boot version`);
 }
 assert.match(html,/['"]motion-polish\.js['"]/);
 assert.doesNotMatch(html,/22\.66\.4/);
});
