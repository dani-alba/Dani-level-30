'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const fuga=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
const safe=fs.readFileSync(path.join(root,'safe.js'),'utf8');
const inf=fs.readFileSync(path.join(root,'infiltration.js'),'utf8');
const blind=fs.readFileSync(path.join(root,'pointblind.js'),'utf8');

test('all four arcade games use a shared-level master gain boost',()=>{
 for(const [name,src] of [['FUGA',fuga],['BOTÍN',safe],['BRECHA',inf],['PUNTO CIEGO',blind]]){
  assert.match(src,/audioMaster/ ,`${name} must expose a master audio node`);
  assert.match(src,/audioMaster\.gain\.value=1\.9/,`${name} master gain must be 1.9`);
 }
});

test('fire warning uses short fixed emergency pulses instead of swept sawtooth siren',()=>{
 const start=fuga.indexOf('function playFireWarningSfx()');const end=fuga.indexOf('function visualHash',start);const fn=fuga.slice(start,end);
 assert.match(fn,/tone\(515,/);
 assert.match(fn,/tone\(675,/);
 assert.doesNotMatch(fn,/type:'sawtooth'/);
 assert.doesNotMatch(fn,/endFreq/);
});
