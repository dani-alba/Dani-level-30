const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const css=fs.readFileSync('styles.css','utf8'),js=fs.readFileSync('arcade.js','utf8');
test('play buttons use per-game theme colors',()=>{assert.match(css,/#clandestinePlayInfiltration[\s\S]*#56b8ff/);assert.match(css,/#clandestinePlaySafe[\s\S]*#5ddc6e/);assert.match(css,/#clandestinePlayFuga[\s\S]*#ff5555/);});
test('results center in viewport and retain per-game theme',()=>{assert.match(css,/min-height:calc\(100dvh - 118px\)!important/);assert.match(css,/operation-result--inf[\s\S]*#56b8ff/);assert.match(css,/operation-result--safe[\s\S]*#5ddc6e/);assert.match(css,/operation-result--fuga[\s\S]*#ff5555/);});
test('clandestine close hover is visually inert',()=>{assert.match(css,/clandestine-hub-head \.icon-close:hover[\s\S]*filter:none!important[\s\S]*transform:none!important/);});
test('fuga has proximity panic, speech bubble and subtle pulse',()=>{assert.match(js,/playArrestProximityPulse/);assert.match(js,/¡DATE PRISA!/);assert.match(js,/fearShake/);assert.match(js,/rgba\(121,210,255/);assert.match(js,/Number\(p\.distance\)<=3\.55/);});

test('fuga panic uses restrained shake and continuous falling sweat',()=>{
  assert.match(js,/Math\.sin\(state\.game\.tick\*\.91\)\*\(\.16\+fear\*\.42\)/);
  assert.match(js,/const sweatSpeed=\.022\+fear\*\.050/);
  assert.match(js,/for\(let i=0;i<4;i\+\+\)/);
  assert.match(js,/dropY=-rowH\*\.18\+phase\*rowH\*\.38/);
});
