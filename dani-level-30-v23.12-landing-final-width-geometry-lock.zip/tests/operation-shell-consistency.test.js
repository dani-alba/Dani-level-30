'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
const safe=fs.readFileSync(path.join(root,'safe.js'),'utf8');
const inf=fs.readFileSync(path.join(root,'infiltration.js'),'utf8');
const blind=fs.readFileSync(path.join(root,'pointblind.js'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8')+fs.readFileSync(path.join(root,'infiltration.css'),'utf8')+fs.readFileSync(path.join(root,'pointblind.css'),'utf8');

test('Arcade Hub is play-first and exposes direct play plus secondary info/ranking actions',()=>{
  for(const id of ['clandestinePlayInfiltration','clandestinePlayBlind','clandestinePlaySafe','clandestinePlayFuga'])assert.match(html,new RegExp(`id="${id}"[^>]*>JUGAR`));
  for(const id of ['clandestineInfoInfiltration','clandestineRankInfiltration','clandestineInfoBlind','clandestineRankBlind','clandestineInfoSafe','clandestineRankSafe','clandestineInfoFuga','clandestineRankFuga'])assert.match(html,new RegExp(`id="${id}"`));
  assert.match(html,/id="arcadeHubSheet"/);
  assert.match(html,/class="app-surface arcade-hub-sheet__panel mobile-bottom-sheet" id="arcadeHubSheetPanel"/);
  assert.match(html,/class="app-surface__drag-zone arcade-hub-sheet__drag-zone"/);
  assert.match(html,/class="app-surface__grabber arcade-hub-sheet__grabber mobile-bottom-sheet__grabber"/);
  assert.match(html,/class="app-surface__scroll arcade-hub-sheet__body"/);
  assert.doesNotMatch(html,/id="arcadeHubSheetClose"/);
  assert.match(css,/\.arcade-hub-sheet/);
  assert.match(arcade,/createMobileBottomSheetController/);
  assert.match(arcade,/panel\.dataset\.sheetType=type/);
  assert.match(arcade,/panel\.dataset\.game=game/);
  assert.match(css,/arcade-hub-sheet__panel\[data-game=\"fuga\"\]/);
  assert.match(css,/arcade-hub-sheet__panel\[data-sheet-type=\"info\"\]/);
  assert.match(css,/height:auto!important/);
  assert.match(arcade,/clandestinePlayFuga[^\n]*open\(\{play:true\}\)/);
  assert.match(safe,/clandestinePlaySafe[^\n]*open\(\{play:true\}\)/);
  assert.match(inf,/clandestinePlayInfiltration[^\n]*open\(\{play:true\}\)/);
  assert.match(blind,/clandestinePlayBlind[^\n]*open\(\{play:true\}\)/);
});

test('legacy detail intros stay optional across the four-operation arcade',()=>{
  assert.equal((html.match(/class="arcade-shell operation-shell/g)||[]).length,4);
  assert.equal((html.match(/operation-intro/g)||[]).length,2);assert.doesNotMatch(html,/id="safeIntro"/);
  assert.equal((html.match(/operation-ranking/g)||[]).length,4);
  assert.match(css,/\.arcade-dialog \.operation-ranking\{display:none!important\}/);
});

test('all four games use a unified back-to-pause contract and result return action',()=>{
  assert.match(html,/id="arcadeExitGame"[^>]*>←<\/button>/);
  assert.match(html,/id="safeExitGame"[^>]*>←<\/button>/);
  assert.match(html,/id="infExitGame"[^>]*>←<\/button>/);
  assert.match(html,/id="blindExitGame"[^>]*>←<\/button>/);
  for(const id of ['arcadePauseMenu','safePauseMenu','infPauseMenu','blindPauseMenu','arcadeResultBack','safeResultBack','infResultBack','blindResultBack'])assert.match(html,new RegExp(`id="${id}"`));
  assert.match(arcade,/function pauseGame\(/);assert.match(safe,/function pauseGame\(/);assert.match(inf,/function pauseGame\(/);assert.match(blind,/function pauseGame\(/);
  assert.match(arcade,/arcadePauseExit[^\n]*returnToArea/);assert.match(safe,/safePauseExit[^\n]*returnToArea/);assert.match(inf,/infPauseExit[^\n]*returnToArea/);assert.match(blind,/blindPauseExit[^\n]*returnToArea/);
});

test('all operation rankings still use the shared leaderboard contract',()=>{
  assert.match(html,/class="arcade-leaderboard" id="infLeaderboard"/);
  assert.match(html,/class="arcade-leaderboard" id="arcadeLeaderboard"/);
  assert.match(html,/class="arcade-leaderboard" id="safeLeaderboard"/);
  assert.match(html,/class="arcade-leaderboard" id="blindLeaderboard"/);
});


test('PUNTO CIEGO and BOTÍN reserve the shared top navigation band and fit short mobile viewports',()=>{
  assert.match(css,/body\.blind-playing \.blind-game\{[\s\S]*?padding:max\(58px,calc\(env\(safe-area-inset-top\) \+ 48px\)\)/);
  assert.match(css,/body\.blind-playing \.blind-corridor\{[\s\S]*?height:clamp\(190px,36dvh,330px\);[\s\S]*?min-height:0/);
  assert.match(css,/body\.safe-playing \.safe-game--precision\{[\s\S]*?grid-template-rows:auto minmax\(118px,.72fr\) minmax\(0,1fr\)/);
  assert.match(css,/body\.safe-playing \.safe-vault\{[\s\S]*?width:min\(62vw,31dvh,248px\)/);
  assert.match(css,/@media\(max-height:610px\)[\s\S]*?body\.safe-playing \.safe-vault\{width:min\(50vw,25dvh,178px\)\}/);
});

test('general championship stays compact in the hub and scoring rules have one disclosure point',()=>{
  assert.match(css,/\.clandestine-championship-card\{[\s\S]*?min-height:42px!important/);
  assert.match(css,/\.clandestine-championship-copy>span:last-child\{display:none!important\}/);
  assert.match(arcade,/rules\.className='overall-ranking-rules'/);
  assert.match(arcade,/<summary>¿CÓMO SE ORDENA\?<\/summary>/);
  assert.doesNotMatch(arcade,/No mostramos esa nota porque solo sirve para comparar juegos distintos/);
});


test('all result screens use one responsive fullscreen shell with short-height compaction',()=>{
  assert.match(css,/body\.operation-result-open \.arcade-dialog\[open\]/);
  assert.match(css,/body\.operation-result-open \.operation-result:not\(\[hidden\]\)[\s\S]*?height:100%!important;[\s\S]*?min-height:0!important/);
  assert.match(css,/@media\(max-height:640px\)[\s\S]*?grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
  assert.match(css,/@media\(max-height:520px\)[\s\S]*?operation-result__mark\{display:none!important\}/);
  for(const source of [arcade,safe,inf,blind]) assert.match(source,/operation-result-open/);
});
