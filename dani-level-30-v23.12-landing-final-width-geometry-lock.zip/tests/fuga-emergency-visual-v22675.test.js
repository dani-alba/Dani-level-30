'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),src=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
test('firetruck uses deterministic emergency lanes, advance warning and BOMBEROS label',()=>{
 assert.match(src,/function isFireLane\(row\)/);
 assert.match(src,/engine\.isFireLane/);
 assert.match(src,/function fireTruckETA\(row,tick\)/);
 assert.match(src,/eta>1\.45/);
 assert.match(src,/drawFireLaneWarning\(row,cy,w,rowH\)/);
 assert.match(src,/rgba\(95,166,255/);
 assert.match(src,/fillText\('BOMBEROS'/);
});
test('motorcycles are roughly halved by restricting the previous color candidate to alternating lanes',()=>{
 assert.match(src,/isMotorcycle=car\.type==='car'.*%7===0.*%2===0/);
});
