'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'infiltration.js'),'utf8');
const arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
const css=fs.readFileSync(path.join(root,'infiltration.css'),'utf8');
const worker=fs.readFileSync(path.join(root,'_worker.js'),'utf8');
const schema=fs.readFileSync(path.join(root,'schema.sql'),'utf8');
test('Infiltration runtime only references DOM ids that exist',()=>{const ids=new Set([...html.matchAll(/id="([^"]+)"/g)].map(m=>m[1]));for(const m of js.matchAll(/\$\('#([^']+)'\)/g))assert.ok(ids.has(m[1]),`missing #${m[1]}`);});
test('the three-operation skeleton is present: intro, game, result and ranking',()=>{assert.match(html,/id="infIntro" class="arcade-intro/);assert.match(html,/id="infGame" class="arcade-game/);assert.match(html,/id="infResult" class="arcade-result/);assert.match(html,/class="arcade-ranking operation-ranking inf-ranking" id="infRanking"/);assert.match(js,/async function refresh\(/);assert.match(js,/async function startGame\(/);assert.match(js,/async function finishGame\(/);});
test('gameplay is an unordered security pattern and allows early recall',()=>{assert.doesNotMatch(js,/inf-tile-order|inf-tile-glyph|glyph\(|⌂|Reconstrúyela en orden/);assert.match(arcade,/El orden no importa/);assert.match(js,/if\(state\.mode==='preview'\)\{cancelAnimationFrame\(state\.raf\);startRecall\(\);\}/);});
test('mobile cover keeps a responsive BRECHA / 30 treatment and uses only an abstract pattern',()=>{assert.match(css,/\.inf-cover>strong\{[^}]*white-space:nowrap[^}]*font-size:clamp\(/s);assert.match(css,/@media\(max-width:380px\)\{\.inf-cover>strong\{[^}]*font-size:clamp\(/s);const card=(html.match(/id="clandestineInfiltrationCard"[\s\S]*?<\/article>/)||[''])[0];assert.doesNotMatch(card,/BREACH CHANNEL|INTERCEPTED|SECURITY PATTERN/);assert.match(card,/BRECHA<br><b>30<\/b>/);assert.match(card,/class="inf-cover-pattern"/);});
test('board uses one symmetric inset around every edge of the key matrix',()=>{assert.match(css,/\.inf-board-frame\{[^}]*padding:0[^}]*\}/s);assert.match(css,/\.inf-board\{[^}]*position:absolute[^}]*inset:10px[^}]*width:auto[^}]*height:auto[^}]*\}/s);});
test('no obsolete Infiltration data model remains in shipped runtime',()=>{for(const [name,text] of [['worker',worker],['schema',schema],['client',js]]){assert.doesNotMatch(text,/infiltration_memory|infiltration_v2/gi,`${name} contains obsolete infiltration model`);}assert.match(worker,/operation_infiltration_v6_scores/);assert.match(worker,/operation_infiltration_v6_runs/);assert.match(worker,/operation_infiltration_v6_podium_awards/);});

test('renderBoard resolves its explicit/current view before reading score and round',()=>{const block=(js.match(/function renderBoard\([\s\S]*?return true;\n  }/)||[''])[0];assert.match(block,/const current=view\|\|state\.celebrationView\|\|state\.game/);assert.doesNotMatch(block,/if\(!state\.game\)return;const pattern=state\.game\.route/);});

test('no ordered-route gameplay fields remain in Infiltration',()=>{const engine=fs.readFileSync(path.join(root,'infiltration-engine.js'),'utf8');assert.doesNotMatch(engine,/\bpath:|\bturns:|\bstart:null|\bgoal:null|expectedSlot|chosenSlot|cursor:/);assert.doesNotMatch(js,/route\.path|mode==='transition'/);});
