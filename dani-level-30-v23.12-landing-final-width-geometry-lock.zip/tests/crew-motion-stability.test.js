'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'motion-polish.css'),'utf8');
test('La Banda animates the stable list shell rather than every player row',()=>{
  assert.match(css,/motion-dialog-enter \.crew-member-list\{animation:motionCrewListIn/);
  assert.doesNotMatch(css,/motion-dialog-enter \.crew-member-card\{animation:/);
  assert.doesNotMatch(css,/crew-member-card:nth-child\(/);
});
