'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
const worker=fs.readFileSync(path.join(root,'_worker.js'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('Operación 30 now has five sequential preparation phases',()=>{
  assert.match(html,/id="operationStage4"/);
  assert.match(html,/FASE 04<\/small><strong>PREPÁRATE PARA EL GOLPE<\/strong>/);
  assert.match(html,/id="operationStage5"/);
  assert.match(html,/FASE 05<\/small><strong>CONSIGUE DINERO PARA EL GOLPE<\/strong>/);
  assert.match(html,/id="operationProgressCount">0\/5<\/strong>/);
  assert.match(app,/items:\[1,2,3,4,5\]\.map/);
  assert.match(app,/4: !unlocked \? 'locked' : partyPrepReviewed \? 'completed' : 'active'/);
  assert.match(app,/5: !partyPrepReviewed \? 'locked' : preparationClosed \? 'completed' : 'active'/);
  assert.match(app,/if \(!snapshot\.partyPrepReviewed\) return 4;/);
  assert.match(app,/if \(!snapshot\.preparationClosed\) return 5;/);
});

test('after the hack, Fase 3 stays open on the newly unlocked refuge',()=>{
  assert.match(app,/let keepStage3OpenAfterHack = false/);
  assert.match(app,/keepStage3OpenAfterHack = true;[\s\S]*renderState\(\);[\s\S]*scrollToId\('safehouseLocation'\)/);
  assert.match(app,/holdRefugeOpen = keepStage3OpenAfterHack && previousProgressStage === 3 && nextProgressStage === 4/);
  assert.match(app,/operationAccordion\?\.setOpen\(3, \{ emit:false \}\)/);
  const stage3=html.slice(html.indexOf('id="operationStage3"'),html.indexOf('id="operationStage4"'));
  assert.match(stage3,/id="safehouseHack"/);
  assert.match(stage3,/id="safehouseLocation"/);
  assert.doesNotMatch(stage3,/Ven como un NPC/);
  assert.doesNotMatch(stage3,/Inventario del golpe/);
});

test('Fase 04 owns NPC and heist inventory and persists its completion',()=>{
  const stage4=html.slice(html.indexOf('id="operationStage4"'),html.indexOf('id="operationStage5"'));
  assert.match(stage4,/Ven como un NPC/);
  assert.match(stage4,/Inventario del golpe/);
  assert.match(stage4,/id="completePartyPrep"/);
  assert.match(app,/async function completePartyPrep\(\)/);
  assert.match(app,/window\.DANI_CREW\?\.completePartyPrep\?\.\(\)/);
  assert.match(crew,/async function completePartyPrep\(\)/);
  assert.match(crew,/partyPrepReviewed:true/);
  assert.match(worker,/typeof prefs\.partyPrepReviewed === 'boolean'/);
});

test('Fase 05 is the only invite entry to clandestine operations and reports live championship state',()=>{
  const stage5=html.indexOf('id="operationStage5"');
  const arcadeEntry=html.indexOf('id="arcadeEasterEgg"');
  assert.ok(stage5>=0 && arcadeEntry>stage5);
  assert.match(html,/id="operationStage5CompetitionValue"/);
  assert.match(html,/id="operationStage5CompetitionText"/);
  assert.match(arcade,/Boolean\(p\?\.uiPrefs\?\.partyPrepReviewed\)/);
  assert.match(arcade,/PROVISIONALES/);
  assert.match(arcade,/Fuera del botín por ahora/);
  assert.match(arcade,/Completa todas las operaciones para entrar en la clasificación general/);
});

test('El Golpe is the primary expandable status card above La Banda in Operation 30',()=>{
  const social=html.indexOf('id="crewQuickAccess"');
  const heist=html.indexOf('id="heistPreview"');
  const stages=html.indexOf('class="operation-stages"');
  assert.ok(heist>=0 && social>heist && stages>social);
  assert.match(html,/class="operation-heist heist-gateway" id="heistPreview"/);
  assert.match(html,/id="heistPreviewToggle"[^>]*aria-expanded="false"/);
  assert.match(html,/id="heistPreviewDetails" aria-hidden="true"/);
  assert.match(html,/id="heistDetailNextTitle"/);
  assert.match(html,/id="enterPartyFromInvite"[^>]*hidden[^>]*disabled/);
  assert.match(css,/v22\.98 · El Golpe expandable gateway \+ information hierarchy/);
  assert.match(css,/grid-template-rows:0fr/);
  assert.match(css,/is-expanded \.operation-heist__details-shell\{grid-template-rows:1fr/);
});

test('clandestine mode retains the active identity and returns explicitly to Fase 05',()=>{
  for(const id of ['clandestineActivePlayer','clandestineActivePlayerAvatar','clandestineActivePlayerName','clandestineActivePlayerCash']) assert.match(html,new RegExp(`id="${id}"`));
  assert.match(html,/id="clandestineClose"[^>]*>← <span>OPERACIÓN 30<\/span>/);
  assert.match(arcade,/renderArcadeIdentity/);
  assert.match(arcade,/target:'operationStage5'/);
  assert.match(css,/The clandestine area stays visually distinct, but the active identity travels with it/);
});
