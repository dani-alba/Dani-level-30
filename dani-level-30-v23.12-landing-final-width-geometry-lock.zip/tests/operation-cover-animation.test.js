'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const css=fs.readFileSync(path.resolve(__dirname,'../styles.css'),'utf8');
test('Fuga keeps the previous road geometry and uses a seamless 40px dashed belt',()=>{
  assert.match(css,/\.clandestine-cover--fuga i\{[^}]*width:80px;height:220px;right:45px;top:-10px;transform:rotate\(27deg\)[^}]*overflow:hidden/s);
  assert.match(css,/\.clandestine-cover--fuga i::before\{[^}]*repeating-linear-gradient\(0deg,transparent 0 22px,#ffffff60 22px 40px\)[^}]*clandestineRoadBelt/s);
  assert.match(css,/@keyframes clandestineRoadBelt\{from\{transform:translateX\(-50%\) translateY\(0\)\}to\{transform:translateX\(-50%\) translateY\(40px\)\}\}/);
  assert.doesNotMatch(css,/clandestineRoadSweep|clandestineRoadDash/);
});
