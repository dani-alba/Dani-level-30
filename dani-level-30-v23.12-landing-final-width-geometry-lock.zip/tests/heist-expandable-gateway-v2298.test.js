const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('El Golpe compact view stays concise and reveals richer secondary information',()=>{
  const heist=html.slice(html.indexOf('id="heistPreview"'),html.indexOf('id="crewQuickAccess"'));
  assert.match(heist,/id="heistPreviewToggle"/);
  assert.match(heist,/id="heistPreviewCountdownValue"/);
  assert.match(heist,/id="heistPreviewText"/);
  assert.match(heist,/id="heistDetailHeadline"/);
  assert.match(heist,/id="heistDetailAccessValue"/);
  assert.match(heist,/id="heistDetailNextText"/);
  assert.match(crew,/function setHeistPreviewExpanded\(expanded/);
  assert.match(crew,/toggleHeistPreview\(\)/);
  assert.match(crew,/preview\.classList\.toggle\('is-expanded'/);
});

test('El Golpe contextual copy covers preparation, event day, live and after states',()=>{
  assert.match(crew,/ÚNETE A LA BANDA/);
  assert.match(crew,/LOCALIZA EL REFUGIO/);
  assert.match(crew,/PREPÁRATE PARA EL GOLPE/);
  assert.match(crew,/CONSIGUE FONDOS/);
  assert.match(crew,/Hoy se ejecuta el plan\./);
  assert.match(crew,/El Golpe está en marcha\./);
  assert.match(crew,/Operación completada\./);
  assert.match(crew,/detailAccess\.textContent = live \? 'DISPONIBLE'/);
});

test('new heist typography respects the mobile readable scale and collapse animates smoothly',()=>{
  assert.match(css,/operation-heist__eyebrow>small\{font-size:10px!important/);
  assert.match(css,/operation-heist__countdown strong\{font-size:23px!important/);
  assert.match(css,/operation-heist__compact-text[^}]*font-size:11px/);
  assert.match(css,/operation-heist__detail-lead p[^}]*font-size:12px/);
  assert.match(css,/heistGatewayClosePop/);
  assert.match(css,/transition:grid-template-rows \.5s/);
});
