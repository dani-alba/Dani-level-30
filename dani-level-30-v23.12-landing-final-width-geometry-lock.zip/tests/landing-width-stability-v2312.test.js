'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const css=fs.readFileSync(path.join(root,'motion-polish.css'),'utf8');

test('landing invitation transition does not subtract a second horizontal gutter',()=>{
  assert.match(css,/motion-invite-shell-final #home\.hero--transitioning\{[\s\S]*?width:100%!important;[\s\S]*?margin:0!important;/);
  assert.match(css,/#missionFlow\.mission-flow--entering\{[\s\S]*?width:100%!important;margin:0!important;/);
  const transitionSlice=css.slice(css.indexOf('v23.12 geometry contract'),css.indexOf('@keyframes motionInvitePosterOut'));
  assert.doesNotMatch(transitionSlice,/width:\s*(?:min\()?calc\(100%\s*-\s*(?:18|24|32)px\)/);
});
