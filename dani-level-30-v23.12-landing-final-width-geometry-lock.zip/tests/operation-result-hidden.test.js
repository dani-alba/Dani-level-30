const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');

test('operation result remains truly hidden despite shared display:flex important',()=>{
  assert.match(css,/\.operation-result\s*\{[^}]*display\s*:\s*flex\s*!important[^}]*\}/s);
  assert.match(css,/\.operation-result\[hidden\]\s*\{\s*display\s*:\s*none\s*!important\s*\}/s);
});

test('all four game result containers start hidden',()=>{
  for(const id of ['arcadeResult','safeResult','infResult','blindResult']){
    assert.match(html,new RegExp(`id="${id}"[^>]*hidden|hidden[^>]*id="${id}"`));
  }
});
