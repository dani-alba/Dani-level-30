'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');const src=fs.readFileSync(require.resolve('../crew.js'),'utf8');
test('crew API sends BOTÍN V10 and preserves only server-verifiable tap timestamps',()=>{assert.match(src,/safe\/start'[\s\S]*?body:\{rulesVersion:10\}/);assert.match(src,/slice\(0,5\)/);assert.match(src,/type:'tap'/);assert.doesNotMatch(src,/type=\['down','move','up'\]/);assert.doesNotMatch(src,/safe\/start'[\s\S]*?rulesVersion:7/);});
