'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
const infCss=fs.readFileSync(path.join(root,'infiltration.css'),'utf8');
const blindCss=fs.readFileSync(path.join(root,'pointblind.css'),'utf8');

test('arcade covers keep one skeleton while giving each game a dedicated hero art',()=>{
  assert.match(html,/OPERACIÓN 01 · MEMORIA/);
  assert.match(html,/OPERACIÓN 02 · TIEMPO/);
  assert.match(html,/OPERACIÓN 03 · PRECISIÓN/);
  assert.match(html,/OPERACIÓN 04 · REFLEJOS/);
  assert.match(html,/class="inf-cover-pattern"/);
  assert.match(html,/class="blind-cover-scene"/);
  assert.match(html,/class="clandestine-safe-emblem"/);
  assert.match(html,/class="fuga-cover-scene"/);
  assert.match(html,/class="fuga-cover-stars"/);
});

test('cover themes are blue, yellow, green and red across the four-act operation',()=>{
  assert.match(infCss,/--cover-accent:#56b8ff/);
  assert.match(blindCss,/--blind:#ffd84a/);
  assert.match(css,/\.clandestine-cover--safe\{[\s\S]*?--cover-accent:#5ddc6e/);
  assert.match(css,/\.clandestine-cover--fuga\{[\s\S]*?--cover-accent:#ff5959/);
});

test('hero arts carry game-specific motion but respect reduced motion',()=>{
  assert.match(infCss,/infCoverScanV2/);
  assert.match(blindCss,/blindCoverPatrol/);
  assert.match(css,/safeCoverDialFloat/);
  assert.match(css,/fugaCoverLaneMove/);
  assert.match(css,/@media\(prefers-reduced-motion:reduce\)/);
});
