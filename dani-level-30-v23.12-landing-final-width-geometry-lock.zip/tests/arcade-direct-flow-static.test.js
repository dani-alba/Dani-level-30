
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
for(const [game,loader,result] of [['fuga','arcadeLoading','operation-result--fuga'],['botín','safeLoading','operation-result--safe'],['brecha','infLoading','operation-result--inf'],['punto ciego','blindLoading','operation-result--blind']]){
 test(`${game} uses the shared loading and result skeleton`,()=>{assert.match(html,new RegExp(`id="${loader}"`));assert.match(html,new RegExp(result));});
}
test('legacy intro screens are never initial visible states',()=>{
 assert.match(html,/id="arcadeIntro" hidden aria-hidden="true"/);
 assert.doesNotMatch(html,/id="safeIntro"/);
 assert.match(html,/id="infIntro"[^>]*hidden aria-hidden="true"/);
});
test('shared result actions prioritize replay, ranking, then arcade',()=>{
 assert.match(html,/id="arcadeRetry"[^>]*>OTRA FUGA</);
 assert.match(html,/id="safeRetry"[^>]*>OTRO BOTÍN</);
 assert.match(html,/id="infRetry"[^>]*>OTRA BRECHA</);
 assert.match(html,/id="blindRetry"[^>]*>OTRO INTENTO</);
 assert.match(css,/\.operation-result \.arcade-result-actions\{display:flex/);
});

test('all four results use the compact shared score-unit-context skeleton',()=>{
 for(const [score,unit] of [['arcadeResultScore','PASOS'],['safeResultScore','PRECISIÓN'],['infResultScore','TECLAS'],['blindResultScore','SEGUNDOS DE ERROR']]){
  assert.match(html,new RegExp(`id=\"${score}\"`));
  assert.match(html,new RegExp(`<span>${unit}</span>`));
 }
 assert.match(html,/operation-result__mark/);
 assert.match(html,/operation-result__score/);
 assert.match(html,/operation-result__message/);
});
