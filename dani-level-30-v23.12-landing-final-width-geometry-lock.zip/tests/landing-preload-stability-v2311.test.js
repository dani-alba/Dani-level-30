'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const read=(name)=>fs.readFileSync(path.join(root,name),'utf8');
const app=read('app.js'),motion=read('motion-polish.js'),css=read('motion-polish.css'),crew=read('crew.js'),guide=read('PROJECT-GUIDE.md');

test('invitation surface pre-renders and waits only a bounded amount for critical readiness',()=>{
  assert.match(app,/async function preloadInviteExperience\(\)/);
  assert.match(app,/renderState\(\);/);
  assert.match(app,/DANI_CREW\?\.whenReady\?\.\(\)/);
  assert.match(app,/document\.fonts\?\.ready/);
  assert.match(app,/Promise\.race\(\[critical, waitMs\(1350\)\]\)/);
  assert.match(app,/waitForFrames\(2\)/);
});

test('crew exposes its real initialization promise for the landing preload handshake',()=>{
  assert.match(crew,/whenReady:\(\) => crewReadyPromise/);
  assert.match(crew,/crewReadyPromise = init\(\)/);
});

test('copy and split surfaces reveal only after readiness-gated cinematic beat',()=>{
  assert.match(motion,/minimumCinematicBeat/);
  assert.match(motion,/Promise\.all\(\[minimumCinematicBeat, ready\]\)/);
  assert.match(motion,/motion-invite-content-ready/);
  assert.match(motion,/motion-invite-split-ready/);
  assert.match(css,/motion-invite-split-ready \.hud/);
  assert.match(css,/motion-invite-split-ready main/);
});

test('transition is deliberately longer but still bounded and interaction stays inert until settle',()=>{
  assert.match(app,/HERO_TRANSITION_MS = 2280/);
  assert.match(app,/flow\.inert = true/);
  assert.match(app,/hud\.inert = true/);
  assert.match(app,/flow\.inert = false/);
  assert.match(app,/hud\.inert = false/);
  assert.match(guide,/preload|stabil/i);
});
