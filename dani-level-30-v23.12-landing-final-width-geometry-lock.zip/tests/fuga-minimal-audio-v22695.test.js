'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const src=fs.readFileSync(path.join(__dirname,'..','arcade.js'),'utf8');
test('minimal FUGA audio keeps near-miss rare and emergency cues prioritized',()=>{
 assert.match(src,/now-state\.lastNearMissSfxAt<2800/);
 assert.match(src,/dx>hit\+\.035&&dx<hit\+\.145/);
 assert.match(src,/function playFireWarningSfx\(\)/);
 assert.match(src,/state\.fireCueRows\.has\(cueKey\)/);
 assert.match(src,/playFireWarningSfx\(\)/);
 assert.match(src,/state\.audioPriorityUntil=performance\.now\(\)\+1150/);
 assert.match(src,/function noiseBurst\(/);
});
