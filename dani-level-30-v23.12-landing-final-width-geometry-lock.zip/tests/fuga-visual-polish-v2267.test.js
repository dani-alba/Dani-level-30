'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8');
const engine=fs.readFileSync(path.join(root,'arcade-engine.js'),'utf8');

test('v22.69 retains the GTA-style visual polish while FUGA runs competitive rules V11',()=>{
  assert.match(engine,/const VERSION=11,/);
  assert.match(arcade,/WASTED/);
  assert.match(arcade,/BUSTED/);
  assert.match(arcade,/EL BOTÍN HA SALIDO VOLANDO/);
  assert.match(arcade,/ZONA DE ARRESTO/);
  assert.match(arcade,/function drawBill/);
  assert.match(arcade,/function drawPlayerCharacter/);
  assert.match(arcade,/function drawRoadDecor/);
  assert.match(arcade,/function drawSafeSurface/);
  assert.match(arcade,/function updateCosmeticMoments/);
});

test('safe-zone paving visually matches the half-cell lateral movement',()=>{
  assert.match(engine,/LATERAL_DISTANCE=\.5/);
  assert.match(arcade,/const paverW=cell\/2,paverCols=engine\.COLS\*2/);
});

test('blocked movement uses character feedback instead of the old orange box',()=>{
  assert.doesNotMatch(arcade,/strokeStyle='#ffb894'/);
  assert.match(arcade,/blockedShake/);
  assert.match(arcade,/blockedTilt/);
});
