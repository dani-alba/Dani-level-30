const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('La Banda keeps only members and prepared metrics',()=>{
  assert.match(html,/id="crewMembersMetric"/);
  assert.match(html,/id="crewPreparedMetric"/);
  assert.doesNotMatch(html,/crewLootMetric/);
  assert.doesNotMatch(html,/BOTÍN DE LA BANDA/);
  assert.match(css,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)!important/);
});

test('prepared means phase four reviewed, independently of the birthday closing phase five',()=>{
  assert.match(crew,/const prepDone = Boolean\(player\?\.partyPrepReviewed/);
  assert.match(crew,/prepared:prepDone/);
  assert.match(crew,/Han completado la Fase 4 y ya están en la fase final de preparación/);
});

test('crew member cards show only the phase stepper while profile can keep detail',()=>{
  assert.match(crew,/function renderCrewProgress\(root, progress, \{ compact = false \} = \{\}\)/);
  assert.match(crew,/renderCrewProgress\(progressLine, progress, \{ compact:true \}\)/);
  assert.match(crew,/if \(!compact\) \{/);
  assert.match(crew,/root\.setAttribute\('aria-label', progress\.label\)/);
});

test('hidden cash adapts to current phase blocks and never targets the hack',()=>{
  assert.match(app,/document\.querySelectorAll\('#missionFlow \.operation-info-block'\)/);
  assert.match(app,/element\.matches\?\.\('#safehouseHack,\.hack,\[data-money-exclude\]'\)/);
  assert.match(app,/function suspendMoneyHunt\(\)/);
  assert.match(app,/hackPlaying = true;\n    suspendMoneyHunt\(\);/);
  assert.match(app,/!activeProfile\?\.id \|\| state\.attendance !== 'yes'/);
  assert.doesNotMatch(app,/targets:\['#operationStage3'/);
});
