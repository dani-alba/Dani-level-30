'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8'),js=fs.readFileSync(path.join(root,'pointblind.js'),'utf8'),arcade=fs.readFileSync(path.join(root,'arcade.js'),'utf8'),crew=fs.readFileSync(path.join(root,'crew.js'),'utf8'),worker=fs.readFileSync(path.join(root,'_worker.js'),'utf8'),css=fs.readFileSync(path.join(root,'pointblind.css'),'utf8');

test('the arcade tells a four-act BRECHA → PUNTO CIEGO → BOTÍN → FUGA story',()=>{
  const cards=[...html.matchAll(/data-game-id="([^"]+)"/g)].map(m=>m[1]).slice(0,4);
  assert.deepEqual(cards,['brecha30','puntociego30','botin30','fuga30']);
  for(const text of ['BRECHA<br><b>30</b>','PUNTO CIEGO<br><b>30</b>','BOTÍN<br><b>30</b>','FUGA<br><b>30</b>'])assert.ok(html.includes(text));
  assert.match(html,/4 OPERACIONES · 1 CLASIFICACIÓN/);
  assert.match(arcade,/COMPLETA LAS 4 OPERACIONES/);
  assert.match(arcade,/\$1\.000/);
});

test('PUNTO CIEGO is yellow, has three patrols and accepts timing taps on the whole free game surface',()=>{
  assert.match(css,/--blind:#ffd84a/);assert.match(css,/blindCoverPatrol/);assert.match(html,/id="blindRound"[^>]*>1 \/ 3/);assert.match(html,/class="blind-hud blind-hud--solo"/);
  assert.match(js,/\$\('#blindGame'\)\?\.addEventListener\('pointerdown'/);
  assert.doesNotMatch(js,/\$\('#blindTapSurface'\)\?\.addEventListener\('pointerdown'/);
  assert.match(js,/e\.target\.closest\('button:not\(#blindTapSurface\)'\)/);
});

test('PUNTO CIEGO explains absolute non-compensating scoring and is wired through client, worker and admin',()=>{
  assert.match(arcade,/Se suma el valor absoluto de cada error: adelantarte y retrasarte nunca se compensan/);
  assert.match(crew,/pointBlindLeaderboard/);assert.match(crew,/pointBlindStart/);assert.match(crew,/pointBlindFinish/);
  assert.match(worker,/route === 'pointblind\/leaderboard'/);assert.match(worker,/route === 'pointblind\/start'/);assert.match(worker,/route === 'pointblind\/finish'/);
  for(const id of ['adminBlindPhase','adminBlindPlayers','adminBlindGames','adminBlindBest','adminBlindPodium'])assert.match(html,new RegExp(`id="${id}"`));
  assert.match(worker,/pointblind_v1_scores/);assert.match(worker,/pointblind_v1_runs/);assert.match(worker,/pointblind_v1_podium_awards/);
});


test('PUNTO CIEGO clarity-first rework keeps the mechanic but redesigns the scene to be more visual and intuitive',()=>{
  assert.doesNotMatch(html,/OBJETIVO<\/small>/);
  assert.doesNotMatch(html,/PATRULLA<\/small>/);
  assert.match(html,/class="blind-start-zone blind-start-zone--desk"/);
  assert.match(html,/class="blind-end-zone blind-end-zone--safe"/);
  assert.match(html,/class="safe-vault blind-mini-vault"/);
  assert.match(html,/class="blind-runner blind-runner--thief"/);
  assert.match(css,/v22\.89 · PUNTO CIEGO clarity-first scene rework/);
  assert.match(css,/blind-start-zone::before/);
  assert.match(css,/blind-corridor::before/);
  assert.match(css,/blind-path\{[\s\S]*bottom:76px!important/);
  assert.match(js,/showLoading\('Siguiendo al objetivo…'\)/);
  assert.match(js,/INTENTO \$\{i\+1\}/);
  assert.match(js,/function cueRoundStart\(index\)/);
  assert.match(js,/function cueTapImpact\(attempt\)/);
  assert.match(css,/v22\.91 · PUNTO CIEGO readable motion rework/);
  assert.match(css,/blind-progress-ratio/);
  assert.match(css,/Brighter scene, clearly visible moving character/);
  assert.match(js,/Sigue al ladrón hasta que desaparezca/);
});
