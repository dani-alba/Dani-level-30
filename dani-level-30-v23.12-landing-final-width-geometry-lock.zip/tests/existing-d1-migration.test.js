'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),cryptoNode=require('node:crypto'),{DatabaseSync}=require('node:sqlite');
const code=fs.readFileSync(require.resolve('../_worker.js'),'utf8');
function dbAdapter(sql){return {prepare(text){let args=[];return {bind(...a){args=a;return this;},async first(){return sql.prepare(text).get(...args)||null;},async all(){return {results:sql.prepare(text).all(...args)};},async run(){const r=sql.prepare(text).run(...args);return {meta:{changes:Number(r.changes)}};}};},async batch(stmts){sql.exec('BEGIN');try{const out=[];for(const q of stmts)out.push(await q.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}};}
function schemaWithoutInfiltration(){return fs.readFileSync(require.resolve('../schema.sql'),'utf8').replace(/\n-- INFILTRACIÓN 30[\s\S]*$/,'\n');}
test('an existing D1 with characters gains the rebuilt Infiltration tables without losing characters',async()=>{const sql=new DatabaseSync(':memory:');sql.exec(schemaWithoutInfiltration());const token='existing-token';const hash=cryptoNode.createHash('sha256').update(token).digest('hex');sql.prepare('INSERT INTO players(id,name,attendance,avatar,session_hash,briefing_completed) VALUES(?,?,?,?,?,1)').run('existing-player','Personaje existente','yes','🧪',hash);const DB=dbAdapter(sql),ctx={console,crypto:cryptoNode.webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};vm.createContext(ctx);vm.runInContext(code.replace('export default','globalThis.worker ='),ctx);const env={DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}};const response=await ctx.worker.fetch(new Request('https://test.local/api/infiltration/start',{method:'POST',headers:{authorization:`Bearer ${token}`}}),env);const body=await response.json();assert.equal(response.status,200,JSON.stringify(body));assert.equal(sql.prepare("SELECT COUNT(*) n FROM players WHERE id='existing-player'").get().n,1);assert.equal(sql.prepare('SELECT COUNT(*) n FROM operation_infiltration_v6_runs WHERE player_id=?').get('existing-player').n,1);});

test('an existing pre-22.60 D1 gains BOTÍN tables without losing characters',async()=>{
 const sql=new DatabaseSync(':memory:');
 const legacySchema=fs.readFileSync(require.resolve('../schema.sql'),'utf8').replace(/\n-- V22\.60 · CAJA 30 precision V4[\s\S]*$/,'\n');
 sql.exec(legacySchema);
 const token='existing-safe-token',hash=cryptoNode.createHash('sha256').update(token).digest('hex');
 sql.prepare('INSERT INTO players(id,name,attendance,avatar,session_hash,briefing_completed) VALUES(?,?,?,?,?,1)').run('existing-safe-player','Personaje Caja','yes','🔐',hash);
 const DB=dbAdapter(sql),ctx={console,crypto:cryptoNode.webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};
 vm.createContext(ctx);vm.runInContext(code.replace('export default','globalThis.worker ='),ctx);
 const env={DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}};
 const response=await ctx.worker.fetch(new Request('https://test.local/api/safe/start',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify({rulesVersion:10})}),env);
 const body=await response.json();assert.equal(response.status,200,JSON.stringify(body));
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM players WHERE id='existing-safe-player'").get().n,1);
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM safe_loot_v8_runs WHERE player_id=?').get('existing-safe-player').n,1);
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name IN ('safe_loot_v8_scores','safe_loot_v8_runs','safe_loot_v8_podium_awards')").get().n,3);
});

test('an existing V10 D1 gains FUGA V11 tables without losing characters or V10 history',async()=>{
 const sql=new DatabaseSync(':memory:');
 const current=fs.readFileSync(require.resolve('../schema.sql'),'utf8');
 const preV11=current.replace(/\n-- V22\.69\.6 · FUGA 30 Crossing V11:[\s\S]*$/,'\n');
 sql.exec(preV11);
 const token='existing-crossing-token',hash=cryptoNode.createHash('sha256').update(token).digest('hex');
 sql.prepare('INSERT INTO players(id,name,attendance,avatar,session_hash,briefing_completed) VALUES(?,?,?,?,?,1)').run('existing-crossing-player','Personaje Fuga','yes','🏃',hash);
 sql.prepare('INSERT INTO crossing_v10_scores(player_id,high_score,games_played,last_score) VALUES(?,?,?,?)').run('existing-crossing-player',123,5,101);
 const DB=dbAdapter(sql),ctx={console,crypto:cryptoNode.webcrypto,Response,Request,Headers,URL,TextEncoder,TextDecoder,atob,btoa};
 vm.createContext(ctx);vm.runInContext(code.replace('export default','globalThis.worker ='),ctx);
 const env={DB,ADMIN_PIN:'4321',ASSETS:{fetch:async()=>new Response('asset')}};
 const response=await ctx.worker.fetch(new Request('https://test.local/api/arcade/start',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},body:JSON.stringify({rulesVersion:11})}),env);
 const body=await response.json();assert.equal(response.status,200,JSON.stringify(body));
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM players WHERE id='existing-crossing-player'").get().n,1);
 assert.equal(sql.prepare("SELECT high_score FROM crossing_v10_scores WHERE player_id='existing-crossing-player'").get().high_score,123);
 assert.equal(sql.prepare('SELECT COUNT(*) n FROM crossing_v11_runs WHERE player_id=?').get('existing-crossing-player').n,1);
 assert.equal(sql.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name IN ('crossing_v11_scores','crossing_v11_runs','crossing_v11_podium_awards')").get().n,3);
});
