'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const root=path.resolve(__dirname,'..');
const js=fs.readFileSync(path.join(root,'safe.js'),'utf8'),css=fs.readFileSync(path.join(root,'styles.css'),'utf8');
test('BOTÍN V10 resets vault visuals before every replay',()=>{assert.match(js,/clearOutcomeClasses\(\);for\(let i=1;i<=5;i\+\+\).*?classList\.remove\('is-open'\)/s)});
test('BOTÍN V10 uses the whole game surface as the precision tap target',()=>{assert.match(js,/const safeTapSurface=\$\('#safeGame'\)[\s\S]*?addEventListener\('pointerdown'/);assert.doesNotMatch(js,/\$\('#safePrecisionTap'\)\?\.addEventListener\('pointerdown'/)});
test('precision track is thicker and moving needle is thinner',()=>{assert.match(css,/\.safe-precision-bar\{[^}]*height:42px/);assert.match(css,/\.safe-precision-marker\{[^}]*width:3px[^}]*height:58px/);assert.match(css,/\.safe-precision-stage\{[^}]*padding:24px 8px 0/)});

test('BOTÍN V10 keeps the target fixed at center and removes the on-screen tap button',()=>{assert.doesNotMatch(require('node:fs').readFileSync(require('node:path').join(root,'index.html'),'utf8'),/id="safePrecisionTap"/);assert.match(css,/safe-precision-target\{left:50%!important/);assert.match(css,/safe-game-hud--precision-solo/);});

test('BOTÍN V10 uses randomized starts, decimal feedback outside the bar and a dotless needle',()=>{const html=require('node:fs').readFileSync(require('node:path').join(root,'index.html'),'utf8');assert.match(html,/class="safe-round-feedback-slot"/);assert.match(js,/function fmtPrecision\(v,decimals=2\)/);assert.match(css,/safe-precision-marker::after\{content:none!important;display:none!important\}/);assert.match(css,/safe-round-feedback-slot \.safe-precision-feedback/);});
