const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const crew=fs.readFileSync(path.join(root,'crew.js'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const worker=fs.readFileSync(path.join(root,'_worker.js'),'utf8');
const css=fs.readFileSync(path.join(root,'styles.css'),'utf8');

test('La Banda uses a five-node phase stepper instead of the old three dots',()=>{
  assert.match(crew,/Array\.from\(\{ length:5 \}/);
  assert.match(crew,/className = 'crew-phase-stepper'/);
  assert.match(crew,/FASE \$\{String\(current\)\.padStart\(2,'0'\)\}/);
  assert.doesNotMatch(crew,/dots:'●●●'/);
  assert.match(css,/v22\.95 · five-phase operation progress language/);
  assert.match(css,/\.crew-phase-stepper>i\.is-active/);
  assert.match(css,/\.crew-phase-stepper>i\.is-completed/);
});

test('phase five remains active before the birthday and closes when the event starts',()=>{
  assert.match(crew,/const preparationComplete = prepDone && eventPhase !== 'before'/);
  assert.match(crew,/if \(prepDone\) current = 5/);
  assert.match(crew,/PREPARACIÓN COMPLETADA/);
  assert.match(app,/progress\.classList\.toggle\('is-final-stage', !complete && nextProgressStage === 5\)/);
  assert.match(app,/`FASE \$\{String\(nextProgressStage \|\| 5\)\.padStart\(2,'0'\)\} DE 05`/);
  assert.match(app,/progressCount\.textContent = complete \? 'LISTA ✓'/);
});

test('crew public payload exposes only the derived phase-4 completion flag needed by the stepper',()=>{
  assert.match(worker,/const publicPrefs = parseUiPrefs\(row\.ui_prefs_json\)/);
  assert.match(worker,/partyPrepReviewed: Boolean\(publicPrefs\.partyPrepReviewed\)/);
  assert.match(worker,/p\.location_unlocked, p\.ui_prefs_json, p\.updated_at/);
});
