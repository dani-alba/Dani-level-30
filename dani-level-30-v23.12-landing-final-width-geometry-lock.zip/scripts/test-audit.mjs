import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const testsDir=path.join(root,'tests');
const timeoutMs=Math.max(5000,Number(process.env.TEST_FILE_TIMEOUT_MS)||45000);
const files=fs.readdirSync(testsDir).filter(x=>x.endsWith('.test.js')).sort();
const rows=[];
for(const file of files){
  const started=Date.now();
  const r=spawnSync(process.execPath,['--test',path.join('tests',file)],{cwd:root,encoding:'utf8',timeout:timeoutMs});
  const ms=Date.now()-started;
  const timedOut=Boolean(r.error?.code==='ETIMEDOUT');
  const status=timedOut?'TIMEOUT':r.status===0?'PASS':'FAIL';
  rows.push({file,status,ms});
  console.log(`${status.padEnd(7)} ${String((ms/1000).toFixed(2)).padStart(7)}s  ${file}`);
  if(status==='FAIL'){
    const tail=`${r.stdout||''}\n${r.stderr||''}`.trim().split('\n').slice(-24).join('\n');
    if(tail)console.log(tail);
  }
}
const counts=rows.reduce((a,r)=>(a[r.status]=(a[r.status]||0)+1,a),{});
console.log(`\nAudit summary: ${counts.PASS||0} PASS · ${counts.FAIL||0} FAIL · ${counts.TIMEOUT||0} TIMEOUT · ${files.length} files`);
if((counts.FAIL||0)>0 || (counts.TIMEOUT||0)>0)process.exit(1);
