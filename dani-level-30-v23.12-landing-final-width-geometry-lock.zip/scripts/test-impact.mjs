import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const scriptDir=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(scriptDir,'..');
const map=JSON.parse(fs.readFileSync(path.join(root,'test-impact-map.json'),'utf8'));
const args=process.argv.slice(2);
const listOnly=args.includes('--list');
const groupFlags=[];
const files=[];
for(let i=0;i<args.length;i+=1){
  const a=args[i];
  if(a==='--list')continue;
  if(a==='--group'){if(args[i+1])groupFlags.push(args[++i]);continue;}
  if(a.startsWith('--group=')){groupFlags.push(a.slice(8));continue;}
  files.push(a.replaceAll('\\','/'));
}

const groups=new Set(groupFlags);
if(!groups.size && files.length){
  for(const file of files){
    const normalized=file.replace(/^\.\//,'');
    let matched=false;
    if(normalized.startsWith('tests/') && normalized.endsWith('.test.js')){
      matched=true;
      groups.add('release');
    }
    for(const rule of map.rules){
      if(rule.match.some(token=>normalized===token || normalized.startsWith(token) || normalized.includes(token))){
        matched=true;
        for(const g of rule.groups)groups.add(g);
      }
    }
    if(!matched)for(const g of map.fallbackGroups)groups.add(g);
  }
}
if(!groups.size){
  console.error('Usage: node scripts/test-impact.mjs [--list] <changed files...> OR --group <name>');
  console.error(`Groups: ${Object.keys(map.groups).join(', ')}`);
  process.exit(2);
}

const tests=new Set();
for(const group of groups){
  const entries=map.groups[group];
  if(!entries){console.error(`Unknown test group: ${group}`);process.exit(2);}
  for(const t of entries)tests.add(t);
}
for(const file of files){
  const normalized=file.replace(/^\.\//,'');
  if(normalized.startsWith('tests/') && normalized.endsWith('.test.js'))tests.add(normalized);
}
const selected=[...tests].filter(t=>fs.existsSync(path.join(root,t))).sort();
console.log(`Impact groups: ${[...groups].sort().join(', ')}`);
console.log(`Selected tests (${selected.length}):`);
for(const t of selected)console.log(`  - ${t}`);
if(listOnly)process.exit(0);
if(!selected.length){console.log('No executable tests selected.');process.exit(0);}
const result=spawnSync(process.execPath,['--test',...selected],{cwd:root,stdio:'inherit'});
process.exit(result.status??1);
