/* BRECHA 30: patrón de seguridad determinista, idéntico en navegador y Worker. */
(function(root){'use strict';
const VERSION=7,SEED=30122026,MAX_EVENTS=32768,MAX_ROUNDS=512,MAX_GRID_SIZE=8;
const ZONES=[
  {from:1,name:'ACCESO EXTERNO',subtitle:'Intercepta el patrón de entrada'},
  {from:4,name:'CONTROL DE IDENTIDAD',subtitle:'La seguridad empieza a endurecerse'},
  {from:7,name:'CÁMARAS',subtitle:'Reconstruye la firma antes de ser detectado'},
  {from:10,name:'RED INTERNA',subtitle:'Cada clave expone una capa más profunda'},
  {from:13,name:'CONTROL DE BÓVEDA',subtitle:'Estás entrando en el sistema de la caja'},
  {from:16,name:'CIFRADO',subtitle:'Los patrones ya no perdonan una duda'},
  {from:20,name:'NÚCLEO DE SEGURIDAD',subtitle:'A partir de aquí no existe margen de error'}
];
function zoneFor(round){let z=ZONES[0],index=0;for(let i=0;i<ZONES.length;i++)if(round>=ZONES[i].from){z=ZONES[i];index=i;}return {...z,index,depth:round>=20?round-19:0};}
function difficulty(round){
  const actualRound=Math.max(1,Math.floor(round||1)),curveRound=Math.min(MAX_ROUNDS,actualRound);
  // V7: la dificultad crece por carga de memoria + distractores, nunca por llenar casi toda la matriz.
  // Mantener el patrón alrededor del 50% evita el atajo cognitivo de memorizar solo las pocas casillas vacías.
  const desiredCount=Math.min(Math.ceil((MAX_GRID_SIZE*MAX_GRID_SIZE)/2),curveRound+2);
  let size=3;
  while(size<MAX_GRID_SIZE&&desiredCount>Math.ceil((size*size)/2))size++;
  const capacity=size*size,maxActive=Math.ceil(capacity/2);
  const count=Math.max(3,Math.min(maxActive,desiredCount));
  const previewMs=3200;
  return {round:actualRound,size,count,length:count,previewMs,density:count/capacity,zone:zoneFor(actualRound)};
}
function hashSeed(value){let h=2166136261;for(const c of String(value)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function runSeed(runId){return hashSeed(`INFILTRACION30:V${VERSION}:${String(runId||'')}`)||SEED;}
function mix(seed,round,attempt=0){let x=(seed^(round*0x9e3779b9)^(attempt*0x85ebca6b))>>>0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return x>>>0;}
function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return x/4294967296;};}
function shuffle(list,random){for(let i=list.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[list[i],list[j]]=[list[j],list[i]];}return list;}
function patternSpread(pattern,size){const rows=new Set(),cols=new Set();for(const slot of pattern){rows.add(Math.floor(slot/size));cols.add(slot%size);}return rows.size+cols.size;}
function patternTransitions(pattern,size){
  const active=new Set(pattern);let transitions=0;
  for(let row=0;row<size;row++)for(let col=0;col<size;col++){
    const slot=row*size+col,on=active.has(slot);
    if(col+1<size&&on!==active.has(slot+1))transitions++;
    if(row+1<size&&on!==active.has(slot+size))transitions++;
  }
  return transitions;
}
function buildRound(round,seed=SEED){
  const d=difficulty(round),all=Array.from({length:d.size*d.size},(_,i)=>i);let best=null;
  // Elegimos entre varios patrones aleatorios el más repartido y fragmentado: menos bloques visuales fáciles de memorizar.
  for(let attempt=0;attempt<32;attempt++){
    const random=rng(mix(seed,round,attempt)),pattern=shuffle(all.slice(),random).slice(0,d.count).sort((a,b)=>a-b);
    const spread=patternSpread(pattern,d.size),transitions=patternTransitions(pattern,d.size),quality=spread*100+transitions;
    const candidate={...d,pattern,spread,transitions,quality};
    if(!best||candidate.quality>best.quality)best=candidate;
  }
  return best;
}
/* Se puede cortar la memorización antes de tiempo, por eso la validación temporal es conservadora. */
function minimumRunMs(failedRound,score=0,roundsCompleted=0){return 350+Math.max(1,failedRound||1)*120+Math.max(0,score||0)*45+Math.max(0,roundsCompleted||0)*90;}
function create(seed=SEED){return {seed,round:1,route:buildRound(1,seed),selected:[],score:0,roundsCompleted:0,over:false,failedRound:0,failedAt:0,wrongSlot:null,events:[],fx:[]};}
function validateEvent(e){if(!e||e.kind!=='tap'||!Number.isInteger(e.slot)||e.slot<0||e.slot>=MAX_GRID_SIZE*MAX_GRID_SIZE)throw Error('Evento de infiltración inválido');return {kind:'tap',slot:e.slot};}
function act(s,event,{record=true}={}){
  if(s.over)throw Error('La partida ya había terminado');const e=validateEvent(event);
  if(record){if(s.events.length>=MAX_EVENTS)throw Error('Demasiados eventos');s.events.push(e);}
  const pattern=s.route.pattern;
  if(s.selected.includes(e.slot)){s.fx.push({type:'repeat',slot:e.slot,score:s.score});return s;}
  if(!pattern.includes(e.slot)){
    s.over=true;s.failedRound=s.round;s.failedAt=s.selected.length;s.wrongSlot=e.slot;
    s.fx.push({type:'fail',slot:e.slot,round:s.round,remembered:s.selected.length});return s;
  }
  s.selected.push(e.slot);s.score++;s.fx.push({type:'key',slot:e.slot,score:s.score,selected:s.selected.length,total:pattern.length});
  if(s.selected.length>=pattern.length){
    s.roundsCompleted++;s.fx.push({type:'round',round:s.round,score:s.score});s.round++;
    s.route=buildRound(s.round,s.seed);s.selected=[];
  }
  return s;
}
function result(s){const zone=zoneFor(s.failedRound||s.round);return {score:s.score,roundsCompleted:s.roundsCompleted,failedRound:s.failedRound||s.round,failedStep:(s.failedAt||0)+1,rememberedInFailed:s.failedAt||0,wrongSlot:s.wrongSlot,zone:zone.name,depth:zone.depth||0,gameOver:s.over,minDurationMs:minimumRunMs(s.failedRound||s.round,s.score,s.roundsCompleted)};}
function replay(events,seed=SEED){if(!Array.isArray(events)||events.length>MAX_EVENTS)throw Error('Registro de partida inválido');const s=create(seed);for(const raw of events)act(s,validateEvent(raw),{record:false});return result(s);}
function drain(s){return s.fx.splice(0);}
const api={VERSION,SEED,MAX_EVENTS,MAX_ROUNDS,MAX_GRID_SIZE,ZONES,zoneFor,difficulty,hashSeed,runSeed,buildRound,minimumRunMs,create,act,result,replay,drain};root.DANI_INFILTRATION_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
