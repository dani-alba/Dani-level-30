// BEGIN SHARED CROSSING ENGINE
/* FUGA 30 · crossing simulation V11 · Pursuit + pedestrian priority crosswalks.
 * Grid movement / cyclic traffic adapted from GeekBoySupreme/crossy-road,
 * Copyright (c) 2020 Shuvam Manna, MIT. See licenses/crossy-road-MIT.txt.
 * Deterministic fixed-step simulation, continuous collision, one-command input
 * buffer, human-playability validation, breathing traffic, surprise waves,
 * half-cell lateral precision, chained traffic windows, elastic police pursuit
 * and authoritative replay added for Operación 30.
 */
(function(root){'use strict';
const VERSION=11,HZ=120,STEP=17,FORWARD_STEP=17,LATERAL_STEP=12,LATERAL_DISTANCE=.5,COLS=9,MAX_TICKS=HZ*60*20,MAX_EVENTS=12000;
const CROSSWALK_GOAL=1,CROSSWALK_STOP_GAP=.18,CROSSWALK_QUEUE_GAP=.34,CROSSWALK_RELEASE_TICKS=Math.round(HZ*.55);
const WAIT_TICKS=10,SOLVER_HORIZON_TICKS=HZ*16,SEGMENT_ATTEMPTS=16,SOLVER_TIME_BUCKET=8;
const POLICE_WARNING_ROW=25,POLICE_ACTIVE_ROW=40,POLICE_MAX_DISTANCE=10.5,POLICE_INITIAL_DISTANCE=8.6,POLICE_CAPTURE_DISTANCE=0;
const POLICE_STREAK_TICKS=Math.round(HZ*2.15);
const DIR={forward:[0,1],backward:[0,-1],left:[-LATERAL_DISTANCE,0],right:[LATERAL_DISTANCE,0]};
const VEHICLE_SPECS=Object.freeze({
 car:Object.freeze({type:'car',minLength:.90,maxLength:1.08}),
 van:Object.freeze({type:'van',minLength:1.24,maxLength:1.50}),
 bus:Object.freeze({type:'bus',minLength:1.82,maxLength:2.20})
});
const TRAFFIC_FAMILIES=Object.freeze(['open','regular','irregular','platoon','heavy','scout','convoy','dense']);
const ROAD_CADENCES=Object.freeze([
 Object.freeze([2,2,3,2,4,3,2,4,3,5,3,4,6,4,5,3,6,5,7,4,6,5,8,6,5,7,4,8,6,9,5,7,6,8,5,9]),
 Object.freeze([2,3,2,3,2,4,3,2,5,3,4,2,5,4,6,3,5,7,4,6,5,8,4,7,6,5,9,6,8,5,7,9,6,8,5,7]),
 Object.freeze([2,2,3,4,2,3,5,3,2,4,6,3,5,4,7,4,6,5,3,7,5,8,6,4,7,5,9,6,5,8,7,6,9,5,8,6])
]);
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function lerp(a,b,t){return a+(b-a)*t;}
function hashSeed(v){let h=2166136261;for(const c of String(v)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function rng(seed){let x=seed>>>0;return ()=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return x/4294967296;};}
function tierForRow(row){return clamp(Math.max(0,Number(row)||0)/210,0,1);}
function pursuitTierForRow(row){return clamp((Math.max(0,Number(row)||0)-POLICE_ACTIVE_ROW)/150,0,1);}
function policeTuningForRow(row){
 const t=pursuitTierForRow(row);
 return {tier:t,graceSeconds:lerp(3.05,1.45,t),approachRowsPerSecond:lerp(.62,.98,t),recoveryPerRow:lerp(.54,.40,t)};
}
function mod(v,m){return ((v%m)+m)%m;}
function fireLaneIndexForSegment(seed,segmentIndex,roads){
 if(segmentIndex<2||roads<2)return null;
 const random=rng(hashSeed(`${seed}:fire-segment:${segmentIndex}:${roads}`));
 const chance=segmentIndex<8?.18:.24;if(random()>=chance)return null;
 // Keep the emergency inside the active block and close to its entry, so it is
 // perceived as an immediate hazard instead of distant scenery.
 return 1+Math.floor(random()*Math.min(3,roads));
}
function isFireLane(row){return Boolean(row&&!row.safe&&row.emergencyType==='fire');}
function primeEmergencyPhase(row,leadSeconds=1.18){
 if(!isFireLane(row)||!Array.isArray(row.pattern)||!row.pattern.length)return row;
 const v=row.pattern[0],half=(v.length||1)/2,offset=v.offset||0;
 row.phase=row.dir>0?(-half-row.speed*leadSeconds-offset):(COLS+half+row.speed*leadSeconds-offset);
 return row;
}
function tuneEmergencyRow(row){
 if(!isFireLane(row))return row;
 // Emergency vehicles are intentionally a distinct hazard: large safe gaps,
 // strong pre-warning in presentation, but materially faster traversal.
 row.speed=clamp(Math.max(row.speed*1.78,4.35),4.35,5.35);row.speedClass='emergency';
 if(Array.isArray(row.gapSeconds)&&row.gapSeconds.length){
  const built=buildPattern(rng(hashSeed(`fire-pattern:${row.index}:${row.speed}`)),'scout',tierForRow(row.index),row.speed,Math.max(0,row.index));
  row.pattern=built.pattern;row.period=built.period;row.gapSeconds=built.gapSeconds;row.minGapSeconds=built.minGapSeconds;row.maxGapSeconds=built.maxGapSeconds;row.occupancy=built.occupancy;row.length=Math.max(...row.pattern.map(v=>v.length));
 }
 return primeEmergencyPhase(row);
}
function roadCapForSegment(segmentIndex){if(segmentIndex<2)return 2;if(segmentIndex<5)return 3;if(segmentIndex<9)return 4;if(segmentIndex<14)return 5;if(segmentIndex<20)return 6;if(segmentIndex<27)return 7;if(segmentIndex<34)return 8;return 9;}
function roadCountFor(startRow,sample=.5){
 const tier=tierForRow(startRow),r=clamp(Number(sample)||0,0,.999999);
 const choices=tier<.08?[2,2,3]:tier<.22?[2,3,4,3]:tier<.42?[3,4,5,3,4]:tier<.62?[3,4,5,6,4]:tier<.82?[4,5,6,7,5]:[5,6,7,8,9,6];
 return choices[Math.floor(r*choices.length)];
}
function roadCountForSegment(seed,segmentIndex){
 const cadence=ROAD_CADENCES[hashSeed(`${seed}:road-cadence`)%ROAD_CADENCES.length],offset=hashSeed(`${seed}:road-offset`)%7;
 if(segmentIndex===0)return 2;
 if(segmentIndex===1)return 2;
 // Deep runs deliberately expose 6–9 lane reads, but keep shorter blocks mixed
 // in so difficulty breathes instead of becoming a permanent wall.
 if(segmentIndex>=34){const late=[6,7,5,8,6,9,7,5,8,6,9,7];return late[(segmentIndex+offset)%late.length];}
 const cap=roadCapForSegment(segmentIndex),raw=cadence[(segmentIndex+offset)%cadence.length];
 return clamp(raw,2,cap);
}
function crosswalkForSegment(seed,segmentIndex,start,end){
 const random=rng(hashSeed(`${seed}:crosswalk:${segmentIndex}:${start}:${end}`)),roads=Math.max(1,end-start-1);
 // Crosswalks are deliberately special. They become a little more likely in
 // long road blocks, where pedestrian priority has the most strategic value.
 const chance=roads>=7?.18:roads>=5?.13:roads>=4?.10:.065;
 if(random()>=chance)return null;
 const center=clamp(Math.round((1.5+random()*5)*2)/2,1.5,6.5);
 const width=random()>.56?2:1.5;
 return {segmentIndex,start,end,center,width};
}
function xInsideCrosswalk(cw,x,margin=.16){return Boolean(cw)&&Math.abs(x-cw.center)<=Math.max(.20,cw.width/2-margin);}
function reserveCrosswalkAccess(segment){
 const cw=crosswalkForSegment(segment.seed,segment.index,segment.start,segment.end);segment.crosswalk=cw;if(!cw)return segment;
 const clearance=cw.width/2+.58;
 for(const row of [segment.rows[0],segment.rows[segment.rows.length-1]])if(row?.safe)row.blocked=(row.blocked||[]).filter(c=>Math.abs(c-cw.center)>=clearance);
 return segment;
}
function safeBlockedFor(seed,index){
 index=Math.max(0,Math.floor(Number(index)||0));if(index<34)return [];
 const random=rng(hashSeed(`${seed}:safe-obstacles:${index}`)),tier=tierForRow(index);
 const chance=clamp(.20+tier*.46,.20,.66);if(random()>=chance)return [];
 const early=[[0],[8],[1],[7],[2],[6],[3],[5],[1,2],[6,7]];
 const advanced=[[0,1],[7,8],[1,2],[6,7],[2,3],[5,6],[3,4],[4,5],[0,1,2],[6,7,8],[2,3,4],[4,5,6]];
 const pool=tier<.35?early:advanced,blocked=[...pool[Math.floor(random()*pool.length)]];
 if(blocked.length>3)blocked.length=3;
 return blocked.sort((a,b)=>a-b);
}
function safeRow(index,seed=0){return {index,safe:true,dir:0,speed:0,speedClass:'safe',length:0,period:0,phase:0,color:0,family:'safe',pattern:[],gapSeconds:[],minGapSeconds:Infinity,maxGapSeconds:Infinity,occupancy:0,blocked:safeBlockedFor(seed,index)};}
function chooseFamily(random,tier,segmentIndex,laneIndex,roads,denseUsed){
 const r=random();
 // The opening teaches reading and committing: no dense lanes at all.
 if(segmentIndex<2)return r<.42?'open':r<.67?'regular':r<.82?'heavy':r<.94?'scout':'platoon';
 // Dense traffic is an accent, never the default, and never dominates a block.
 const denseAllowed=tier>.26&&denseUsed<Math.max(1,Math.floor(roads/4));
 if(tier<.25)return r<.25?'open':r<.45?'regular':r<.60?'irregular':r<.75?'platoon':r<.86?'heavy':r<.95?'scout':'convoy';
 if(tier<.60){
  if(r<.15)return 'open';if(r<.31)return 'regular';if(r<.46)return 'irregular';if(r<.62)return 'platoon';if(r<.74)return 'heavy';if(r<.85)return 'scout';if(r<.95)return 'convoy';return denseAllowed?'dense':'open';
 }
 if(r<.12)return 'open';if(r<.24)return 'regular';if(r<.39)return 'irregular';if(r<.56)return 'platoon';if(r<.67)return 'heavy';if(r<.79)return 'scout';if(r<.91)return 'convoy';return denseAllowed?'dense':'irregular';
}
function vehicleTypeFor(random,family,tier,index){
 if(family==='heavy'||family==='convoy'){
  if(index===0||random()<.52)return random()<(.40+tier*.24)?'bus':'van';
  return random()<.55?'van':'car';
 }
 if(family==='platoon')return random()<(.07+tier*.08)?'van':'car';
 if(family==='scout')return 'car';
 if(random()<(.07+tier*.10))return 'van';
 return 'car';
}
function vehicleLength(random,type){const spec=VEHICLE_SPECS[type]||VEHICLE_SPECS.car;return lerp(spec.minLength,spec.maxLength,random());}
function speedForRow(random,family,tier,segmentIndex){
 let speedClass='cruise',speed;
 if(family==='scout'){
  speedClass='fast';speed=lerp(segmentIndex<5?1.55:2.05,segmentIndex<5?2.05:3.10,random());
 }else if(family==='heavy'||family==='convoy'){
  speedClass='slow';speed=lerp(.56,.92+tier*.28,random());
 }else{
  const band=random();
  if(band<.28){speedClass='slow';speed=lerp(.68,.98+tier*.16,random());}
  else if(band<.76){speedClass='cruise';speed=lerp(.98+tier*.16,1.42+tier*.36,random());}
  else{speedClass='fast';speed=lerp(1.48+tier*.18,2.18+tier*.72,random());}
 }
 if(family==='dense')speed*=1.02;
 if(segmentIndex<2)speed=Math.min(speed,1.55);
 return {speed:clamp(speed,.54,3.15),speedClass};
}
function gapProfile(random,family,tier,count,segmentIndex){
 const ease=segmentIndex<2?1.18:segmentIndex<5?1.08:1;
 const jitter=(a,b)=>Math.max(.72,lerp(a,b,random())*ease),g=[];
 if(family==='open'){
  for(let i=0;i<count;i++)g.push(jitter(i===count-1?4.8:3.0,i===count-1?7.4:4.8));return g;
 }
 if(family==='regular'){
  for(let i=0;i<count;i++)g.push(jitter(2.05,3.45));return g;
 }
 if(family==='dense'){
  // Even the densest lane has a release window; it is pressure, not a wall.
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(3.2,4.8):jitter(1.22,1.90));return g;
 }
 if(family==='heavy'){
  for(let i=0;i<count;i++)g.push(jitter(3.0,5.8));return g;
 }
 if(family==='scout'){
  for(let i=0;i<count;i++)g.push(jitter(5.2,8.4));return g;
 }
 if(family==='convoy'){
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(4.5,7.0):jitter(1.25,2.05));return g;
 }
 if(family==='platoon'){
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(4.6,7.2):jitter(.78,1.28));return g;
 }
 // Irregular lanes deliberately tell a little story: short pressure, medium gap,
 // then a generous invitation. Shuffle where that invitation lands.
 const bands=[[1.15,1.70],[2.0,3.0],[3.7,5.8],[1.45,2.20],[4.2,6.5]];
 const order=Array.from({length:count},(_,i)=>i);
 for(let i=order.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
 for(let i=0;i<count;i++){const b=bands[order[i]%bands.length];g.push(jitter(b[0],b[1]));}
 return g;
}
function buildPattern(random,family,tier,speed,segmentIndex){
 let count;
 if(family==='scout')count=1;
 else if(family==='heavy')count=random()<.72?1:2;
 else if(family==='convoy')count=random()<.66?2:3;
 else if(family==='platoon')count=random()<.68?3:4;
 else if(family==='open')count=random()<.74?1:2;
 else if(family==='dense')count=random()<.70?3:4;
 else count=random()<.55?2:3;
 const vehicles=[];for(let i=0;i<count;i++){const type=vehicleTypeFor(random,family,tier,i);vehicles.push({type,length:vehicleLength(random,type),color:Math.floor(random()*7)});}
 const gaps=gapProfile(random,family,tier,count,segmentIndex),pattern=[];let center=0;
 for(let i=0;i<count;i++){
  if(i===0)center=vehicles[i].length/2;
  else center=pattern[i-1].offset+vehicles[i-1].length/2+speed*gaps[i-1]+vehicles[i].length/2;
  pattern.push({offset:center,length:vehicles[i].length,type:vehicles[i].type,color:vehicles[i].color});
 }
 const last=pattern[count-1],period=last.offset+last.length/2+speed*gaps[count-1];
 const occupied=pattern.reduce((sum,v)=>sum+v.length+.40,0),occupancy=clamp(occupied/Math.max(period,.01),0,1);
 return {pattern,period,gapSeconds:gaps,minGapSeconds:Math.min(...gaps),maxGapSeconds:Math.max(...gaps),occupancy};
}
function gapCenterOffset(row,gapIndex){
 const pattern=row.pattern||[],i=clamp(Math.floor(gapIndex||0),0,Math.max(0,pattern.length-1)),v=pattern[i];
 if(!v)return 0;return v.offset+v.length/2+row.speed*(row.gapSeconds?.[i]||0)/2;
}
function applyChainedWindow(rows,random,start,roads){
 if(start<35||roads<3)return null;
 const chance=clamp(.16+(start-35)/190*.36,.16,.52);if(random()>=chance)return null;
 const maxSpan=Math.min(6,roads),span=Math.min(maxSpan,3+Math.floor(random()*Math.max(1,maxSpan-2)));
 const first=1+Math.floor(random()*Math.max(1,roads-span+1));let x=4+(random()<.5?-.5:.5),elapsed=5;const targets=[];
 for(let j=0;j<span;j++){
  const row=rows[first+j];if(!row||row.safe)continue;
  if(j&&random()<.42)x=clamp(x+(random()<.5?-.5:.5),1,7);
  elapsed+=FORWARD_STEP+(j&&Math.abs(x-(targets.at(-1)?.x??x))>.01?LATERAL_STEP:0);
  let gap=0,best=-1;for(let i=0;i<(row.gapSeconds||[]).length;i++)if(row.gapSeconds[i]>best){best=row.gapSeconds[i];gap=i;}
  const center=gapCenterOffset(row,gap);row.phase=mod(x-row.dir*row.speed*elapsed/HZ-center,row.period);row.chainTarget={tick:elapsed,x,gap};targets.push({row:row.index,tick:elapsed,x,gap});
 }
 return targets.length>=3?{firstRow:rows[first]?.index||start+1,span:targets.length,targets}:null;
}
function cars(row,tick){
 if(!row||row.safe)return [];
 const pattern=Array.isArray(row.pattern)&&row.pattern.length?row.pattern:[{offset:0,length:row.length||1,type:'car',color:row.color||0}];
 const period=Math.max(.01,row.period||4),shift=row.phase+row.dir*row.speed*tick/HZ;
 const maxWidth=Math.max(...pattern.map(v=>v.length||1),1),first=Math.floor((-maxWidth-period-shift)/period),last=Math.ceil((COLS+maxWidth+period-shift)/period),out=[];
 for(let k=first;k<=last;k++)for(let pi=0;pi<pattern.length;pi++){const v=pattern[pi],x=shift+k*period+v.offset;if(x<-maxWidth*1.5||x>COLS+maxWidth*1.5)continue;out.push({id:`${k}:${pi}`,x,width:v.length||1,type:v.type||'car',color:Number.isInteger(v.color)?v.color:(row.color||0)});}
 return out;
}
function segmentForRow(s,index){ensureSegmentsThrough(s,index);return s.segments.find(seg=>index>=seg.start&&index<=seg.end)||null;}
function crosswalkAt(s,index){
 const seg=segmentForRow(s,index);if(!seg?.crosswalk)return null;const cw=seg.crosswalk,cs=s.crosswalk;
 return {...cw,golden:cs.goldenSegmentIndex===seg.index,active:cs.gate?.segmentIndex===seg.index&&(cs.gate.releaseTick==null||s.tick<=cs.gate.releaseTick)};
}
function gateHolding(s,segmentIndex,tick=s.tick){const gate=s.crosswalk?.gate;return Boolean(gate&&gate.segmentIndex===segmentIndex&&(gate.releaseTick==null||tick<=gate.releaseTick));}
function trafficRowSnapshot(row,cw,segmentIndex,tick){
 const left=cw.center-cw.width/2,right=cw.center+cw.width/2,dir=row.dir||1,vehicles={};
 for(const car of cars(row,tick)){
  const inside=car.x+car.width/2>=left&&car.x-car.width/2<=right;
  const passed=dir>0?(car.x-car.width/2>right):(car.x+car.width/2<left);
  vehicles[car.id]={...car,x:car.x,free:inside||passed,stopped:false};
 }
 return {rowIndex:row.index,segmentIndex,lastTick:tick,crosswalk:{center:cw.center,width:cw.width},vehicles};
}
function cloneTrafficRowState(rs){const vehicles={};for(const [id,car] of Object.entries(rs.vehicles||{}))vehicles[id]={...car};return {...rs,crosswalk:{...rs.crosswalk},vehicles};}
function advanceTrafficRowState(s,source,row,targetTick,mutate=true){
 const rs=mutate?source:cloneTrafficRowState(source),tick=Math.max(rs.lastTick,Math.floor(targetTick)),dt=tick-rs.lastTick,dir=row.dir||1,speed=Math.max(0,row.speed||0),cw=rs.crosswalk,left=cw.center-cw.width/2,right=cw.center+cw.width/2;
 if(dt>0){const dx=dir*speed*dt/HZ;for(const car of Object.values(rs.vehicles)) {car.x+=dx;car.stopped=false;}}
 // Only admit traffic from the upstream edge. This prevents the cyclic base
 // pattern from materialising a vehicle beyond a closed crosswalk.
 for(const car of cars(row,tick)){
  if(rs.vehicles[car.id])continue;const upstream=dir>0?(car.x+car.width/2<left):(car.x-car.width/2>right);
  if(upstream)rs.vehicles[car.id]={...car,x:car.x,free:false,stopped:false};
 }
 const active=gateHolding(s,rs.segmentIndex,tick),ordered=Object.values(rs.vehicles).sort((a,b)=>dir>0?b.x-a.x:a.x-b.x);
 if(active){
  let frontier=dir>0?left-CROSSWALK_STOP_GAP:right+CROSSWALK_STOP_GAP;
  for(const car of ordered){
   if(car.free)continue;
   const target=dir>0?frontier-car.width/2:frontier+car.width/2;
   if((dir>0&&car.x>target)||(dir<0&&car.x<target)){car.x=target;car.stopped=true;}
   frontier=dir>0?car.x-car.width/2-CROSSWALK_QUEUE_GAP:car.x+car.width/2+CROSSWALK_QUEUE_GAP;
  }
 }else{
  // Once released, vehicles resume from their held coordinates. Keep the
  // physical spacing while the delayed stream clears instead of snapping
  // back onto the underlying cyclic traffic timeline.
  let previous=null;
  for(const car of ordered){
   if(previous){
    const target=dir>0?previous.x-previous.width/2-CROSSWALK_QUEUE_GAP-car.width/2:previous.x+previous.width/2+CROSSWALK_QUEUE_GAP+car.width/2;
    if((dir>0&&car.x>target)||(dir<0&&car.x<target))car.x=target;
   }
   car.stopped=false;previous=car;
  }
 }
 const margin=Math.max(2.5,Math.max(...Object.values(rs.vehicles).map(v=>v.width||1),1)*1.8);
 for(const [id,car] of Object.entries(rs.vehicles)){if((dir>0&&car.x>COLS+margin)||(dir<0&&car.x<-margin))delete rs.vehicles[id];}
 rs.lastTick=tick;return rs;
}
function updateCrosswalkTraffic(s){
 const rows=s.crosswalk?.trafficRows;if(!rows)return;
 for(const rs of Object.values(rows)){const row=rowAt(s,rs.rowIndex);if(!row||row.safe||isFireLane(row))continue;advanceTrafficRowState(s,rs,row,s.tick,true);}
}
function carsForState(s,row,tick=s.tick){
 if(!s||row?.safe)return cars(row,tick);
 if(isFireLane(row)){const localTick=fireLaneTickForState(s,row,tick);return localTick==null?[]:cars(row,localTick);}
 const base=cars(row,tick),rs=s.crosswalk?.trafficRows?.[row.index];if(!rs)return base;
 const view=tick===rs.lastTick?rs:advanceTrafficRowState(s,rs,row,tick,false);
 return Object.values(view.vehicles).map(car=>({...car}));
}
function candidateSegment(seed,segmentIndex,start,attempt){
 const random=rng(hashSeed(`${seed}:segment:${segmentIndex}:attempt:${attempt}`)),tier=tierForRow(start),roads=roadCountForSegment(seed,segmentIndex),rows=[safeRow(start,seed)],fireLaneIndex=fireLaneIndexForSegment(seed,segmentIndex,roads);
 let previousDir=random()<.5?-1:1,previousSpeed=null,denseUsed=0,openish=0;
 for(let i=1;i<=roads;i++){
  let family=i===fireLaneIndex?'scout':chooseFamily(random,tier,segmentIndex,i,roads,denseUsed);if(family==='dense')denseUsed++;if(['open','heavy','scout','platoon','convoy'].includes(family))openish++;
  const speedInfo=speedForRow(random,family,tier,segmentIndex);let speed=speedInfo.speed;
  // Adjacent lanes should ask different timing questions rather than move on one belt.
  if(previousSpeed!=null&&Math.abs(speed-previousSpeed)<.18&&random()<.78){speed=clamp(speed+(random()<.5?-.34:.38),.54,3.15);}
  previousSpeed=speed;
  let dir;if(i===1)dir=previousDir;else{const r=random();dir=r<.52?previousDir:r<.92?-previousDir:(random()<.5?-1:1);}previousDir=dir;
  const built=buildPattern(random,family,tier,speed,segmentIndex),representative=Math.max(...built.pattern.map(v=>v.length));
  rows.push(tuneEmergencyRow({index:start+i,safe:false,dir,speed,speedClass:speedInfo.speedClass,length:representative,period:built.period,phase:random()*built.period,color:built.pattern[0]?.color||0,family,pattern:built.pattern,gapSeconds:built.gapSeconds,minGapSeconds:built.minGapSeconds,maxGapSeconds:built.maxGapSeconds,occupancy:built.occupancy,blocked:[],segmentIndex,laneIndex:i,emergencyType:i===fireLaneIndex?'fire':null}));
 }
 // A long block must contain several lanes that visibly breathe. If randomness
 // failed to do so, reject it before the expensive solver.
 const requiredOpenish=segmentIndex<2?roads:Math.max(1,Math.ceil(roads*.42));
 const end=start+roads+1;rows.push(safeRow(end,seed));
 const chainWindow=applyChainedWindow(rows,random,start,roads);
 for(const row of rows)if(isFireLane(row))primeEmergencyPhase(row);
 return reserveCrosswalkAccess({seed,index:segmentIndex,start,end,roads,tier,attempt,rows,fallback:false,openish,requiredOpenish,chainWindow});
}
function fallbackSegment(seed,segmentIndex,start){
 const tier=tierForRow(start),roads=roadCountForSegment(seed,segmentIndex),rows=[safeRow(start,seed)],base=hashSeed(`${seed}:segment:${segmentIndex}:fallback`)%2?-1:1;
 for(let i=1;i<=roads;i++){
  const speed=clamp(.82+tier*.42+(i%3)*.18,.72,1.65),dir=i%3===0?-base:base,length=1.0,gaps=i%2?[2.3,4.8]:[3.0,5.5],period=(length+speed*gaps[0])+(length+speed*gaps[1]);
  const pattern=[{offset:length/2,length,type:'car',color:(segmentIndex+i)%7},{offset:length/2+length+speed*gaps[0],length,type:'car',color:(segmentIndex+i+2)%7}];
  const occupancy=(pattern.reduce((sum,v)=>sum+v.length+.40,0))/period;
  rows.push({index:start+i,safe:false,dir,speed,speedClass:i%3?'cruise':'slow',length,period,phase:(period*.19*i)%period,color:pattern[0].color,family:'fallback',pattern,gapSeconds:gaps,minGapSeconds:Math.min(...gaps),maxGapSeconds:Math.max(...gaps),occupancy,blocked:[]});
 }
 const end=start+roads+1;rows.push(safeRow(end,seed));return reserveCrosswalkAccess({seed,index:segmentIndex,start,end,roads,tier,attempt:-1,rows,fallback:true,openish:roads,requiredOpenish:1,chainWindow:null});
}
function rowFromSegment(segment,index){return segment.rows[index-segment.start]||null;}
function safeObstacleAtSegment(segment,x,y){
 for(let ry=Math.max(segment.start,Math.floor(y)-1);ry<=Math.min(segment.end,Math.ceil(y)+1);ry++){
  if(Math.abs(y-ry)>=.43)continue;const row=rowFromSegment(segment,ry);if(!row||!row.safe)continue;
  for(const c of row.blocked||[])if(Math.abs(x-c)<.56)return true;
 }return false;
}
function collisionAtSegment(segment,x,y,tick){
 for(let ry=Math.max(segment.start,Math.floor(y)-1);ry<=Math.min(segment.end,Math.ceil(y)+1);ry++){
  if(Math.abs(y-ry)>=.49)continue;const row=rowFromSegment(segment,ry);if(!row||row.safe)continue;
  for(const car of cars(row,tick))if(Math.abs(x-car.x)<car.width/2+.20)return true;
 }return false;
}
function intervalSafe(segment,x0,y0,x1,y1,startTick,duration){
 for(let dt=1;dt<=duration;dt++){const p=dt/duration,x=x0+(x1-x0)*p,y=y0+(y1-y0)*p;if(safeObstacleAtSegment(segment,x,y)||collisionAtSegment(segment,x,y,startTick+dt))return false;}return true;
}
function durationFor(dir){return dir==='left'||dir==='right'?LATERAL_STEP:FORWARD_STEP;}
function xKey(x){return Math.round(x/LATERAL_DISTANCE);}
function traverseTicks(segment,startTick=0){
 const horizon=SOLVER_HORIZON_TICKS,queue=[],seen=new Set();
 for(let xi=0;xi<=Math.round((COLS-1)/LATERAL_DISTANCE);xi++){const x=xi*LATERAL_DISTANCE;if(safeObstacleAtSegment(segment,x,segment.start))continue;queue.push({x,y:segment.start,t:0});seen.add(`0:${xi}:${segment.start}`);}
 let head=0;const push=(node)=>{if(node.t>horizon)return;const key=`${Math.floor(node.t/SOLVER_TIME_BUCKET)}:${xKey(node.x)}:${node.y}`;if(seen.has(key))return;seen.add(key);queue.push(node);};
 while(head<queue.length){const n=queue[head++];if(n.y>=segment.end)return n.t;
  if(intervalSafe(segment,n.x,n.y,n.x,n.y,startTick+n.t,WAIT_TICKS))push({x:n.x,y:n.y,t:n.t+WAIT_TICKS});
  for(const d of ['forward','left','right']){const [dx,dy]=DIR[d],nx=n.x+dx,ny=n.y+dy,duration=durationFor(d);if(nx<0||nx>COLS-1||ny<segment.start||ny>segment.end)continue;if(intervalSafe(segment,n.x,n.y,nx,ny,startTick+n.t,duration))push({x:nx,y:ny,t:n.t+duration});}
 }
 return Infinity;
}
function canTraverseSegment(segment,startTick=0){return Number.isFinite(traverseTicks(segment,startTick));}
function humanReadableSegment(segment){
 const roads=segment.rows.filter(r=>!r.safe);if(!roads.length)return false;
 if(segment.openish<segment.requiredOpenish)return false;
 const tier=segment.tier,maxOccupancy=tier<.15?.38:tier<.55?.45:.50,minBigGap=tier<.15?3.3:tier<.55?2.75:2.45;
 let generous=0;
 for(const row of roads){
  if((row.occupancy||0)>maxOccupancy)return false;
  if((row.maxGapSeconds||0)<minBigGap)return false;
  if((row.maxGapSeconds||0)>=4.0)generous++;
 }
 if(generous<Math.max(1,Math.ceil(roads.length*.34)))return false;
 const offsets=[0,Math.floor(HZ*1.83),Math.floor(HZ*4.17)],times=offsets.map(t=>traverseTicks(segment,t));
 if(times.some(t=>!Number.isFinite(t)))return false;
 // A mathematically valid segment that takes forever to unlock is not fun.
 const maxSeconds=segment.index<2?6.2:segment.roads<=4?8.2:segment.roads<=6?10.8:13.8;
 return Math.max(...times)/HZ<=maxSeconds;
}
function segmentValid(segment){return humanReadableSegment(segment);}
function buildSegment(seed,segmentIndex,start){
 for(let attempt=0;attempt<SEGMENT_ATTEMPTS;attempt++){const seg=candidateSegment(seed,segmentIndex,start,attempt);if(segmentValid(seg))return seg;}
 const fallback=fallbackSegment(seed,segmentIndex,start);if(!segmentValid(fallback))throw Error('No se pudo construir un tramo jugable');return fallback;
}
function storeSegmentRows(s,segment){for(const row of segment.rows){const existing=s.rows.get(row.index);if(existing?.safe&&row.safe){const keep=new Set(row.blocked||[]);existing.blocked=(existing.blocked||[]).filter(c=>keep.has(c));s.rows.set(row.index,existing);}else s.rows.set(row.index,row);}}
function ensureSegmentsThrough(s,index){
 if(!s.segments.length){const first=buildSegment(s.seed,0,0);s.segments.push(first);storeSegmentRows(s,first);maybeAssignGoldenSegment(s,first);}
 while(s.segments[s.segments.length-1].end<index){const prev=s.segments[s.segments.length-1],next=buildSegment(s.seed,s.segments.length,prev.end);s.segments.push(next);storeSegmentRows(s,next);maybeAssignGoldenSegment(s,next);}
}
function activeSegmentForState(s){
 ensureSegmentsThrough(s,Math.max(1,Math.floor(s.y)+1));
 return s.segments.find(seg=>s.y>=seg.start&&s.y<seg.end)||s.segments[s.segments.length-1]||null;
}
function fireLaneTickForState(s,row,tick=s.tick){
 if(!s||!isFireLane(row))return null;const seg=activeSegmentForState(s);if(!seg||row.segmentIndex!==seg.index)return null;
 if(s.fireSegments[seg.index]==null)s.fireSegments[seg.index]=tick;
 return Math.max(0,tick-s.fireSegments[seg.index]);
}
function isFireLaneActive(s,row){return fireLaneTickForState(s,row,s?.tick??0)!=null;}
function rowAt(s,index){index=Math.max(0,Math.floor(Number(index)||0));if(!s.rows.has(index)){ensureSegmentsThrough(s,index);if(!s.rows.has(index)){const seg=s.segments.find(item=>index>=item.start&&index<=item.end);const row=seg?rowFromSegment(seg,index):null;if(row)s.rows.set(index,row);}}return s.rows.get(index)||safeRow(index,s.seed);}
function create(seed=302026){
 const s={seed:seed>>>0,tick:0,x:4,y:0,maxRow:0,move:null,queued:null,rows:new Map(),segments:[],events:[],over:false,reason:'',started:false,
  police:{active:false,distance:POLICE_INITIAL_DISTANCE,lastProgressTick:0,lastMaxRow:0,streak:0,lastStreakTick:-999999,band:'hidden',startedTick:null},
  crosswalk:{goodCrossings:0,rewardReady:false,goldenSegmentIndex:null,goldenAfterSegmentIndex:null,progress:null,completedSegments:new Set(),gate:null,trafficRows:{},eventSeq:0,lastEvent:null},fireSegments:{}};
 ensureSegmentsThrough(s,1);return s;
}
function derivePoliceBand(s){
 const p=s.police;if(s.maxRow<POLICE_WARNING_ROW)return 'hidden';if(!p.active)return 'signal';
 if(p.band==='danger'&&p.distance<=2.85)return 'danger';
 if(p.band==='pressure'&&p.distance<=5.75&&p.distance>2.25)return 'pressure';
 if(p.distance<=2.30)return 'danger';if(p.distance<=5.10)return 'pressure';return 'safe';
}
function policeSnapshot(s){
 const p=s.police,t=policeTuningForRow(s.maxRow),idle=Math.max(0,(s.tick-p.lastProgressTick)/HZ),grace=Math.max(0,t.graceSeconds-idle);
 return {warning:s.maxRow>=POLICE_WARNING_ROW,active:p.active,distance:p.distance,maxDistance:POLICE_MAX_DISTANCE,band:derivePoliceBand(s),streak:p.streak,graceSeconds:t.graceSeconds,graceRemaining:grace,approachRowsPerSecond:t.approachRowsPerSecond,recoveryPerRow:t.recoveryPerRow};
}
function updatePolice(s){
 const p=s.police;if(s.maxRow>=POLICE_ACTIVE_ROW&&!p.active){p.active=true;p.distance=POLICE_INITIAL_DISTANCE;p.lastProgressTick=s.tick;p.lastMaxRow=s.maxRow;p.streak=0;p.lastStreakTick=s.tick;p.startedTick=s.tick;}
 if(s.maxRow>p.lastMaxRow){
  const delta=s.maxRow-p.lastMaxRow;p.lastMaxRow=s.maxRow;
  if(p.active){const tuning=policeTuningForRow(s.maxRow),chained=s.tick-p.lastStreakTick<=POLICE_STREAK_TICKS;p.streak=chained?p.streak+delta:delta;p.lastStreakTick=s.tick;
   const chainBonus=Math.min(.55,Math.max(0,p.streak-1)*.12);p.distance=clamp(p.distance+delta*(tuning.recoveryPerRow+chainBonus),POLICE_CAPTURE_DISTANCE,POLICE_MAX_DISTANCE);p.lastProgressTick=s.tick;}
 }
 if(!p.active){p.band=derivePoliceBand(s);return;}
 const tuning=policeTuningForRow(s.maxRow),idleTicks=s.tick-p.lastProgressTick;if(idleTicks>Math.round(tuning.graceSeconds*HZ))p.distance=Math.max(POLICE_CAPTURE_DISTANCE,p.distance-tuning.approachRowsPerSecond/HZ);
 if(s.tick-p.lastStreakTick>POLICE_STREAK_TICKS)p.streak=0;p.band=derivePoliceBand(s);
 if(p.distance<=POLICE_CAPTURE_DISTANCE){s.over=true;s.reason='police';s.queued=null;}
}
function emitCrosswalkEvent(s,type,extra={}){const cs=s.crosswalk;cs.eventSeq++;cs.lastEvent={seq:cs.eventSeq,type,...extra};}
function maybeAssignGoldenSegment(s,seg){
 const cs=s.crosswalk;if(!cs?.rewardReady||cs.goldenSegmentIndex!=null||!seg?.crosswalk)return null;
 if(seg.index<=Number(cs.goldenAfterSegmentIndex??-1))return null;cs.goldenSegmentIndex=seg.index;return seg.crosswalk;
}
function assignNextGoldenCrosswalk(s,afterSegmentIndex){
 const cs=s.crosswalk;cs.rewardReady=true;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=afterSegmentIndex;
 for(const seg of s.segments)if(seg.index>afterSegmentIndex&&seg.crosswalk){cs.goldenSegmentIndex=seg.index;return seg.crosswalk;}
 return null;
}
function activateGoldenCrosswalk(s,seg){
 const cs=s.crosswalk,cw=seg.crosswalk,allowedByRow={};
 for(const row of seg.rows){
  if(row.safe)continue;const left=cw.center-cw.width/2,right=cw.center+cw.width/2;
  allowedByRow[row.index]=cars(row,s.tick).filter(car=>car.x+car.width/2>=left&&car.x-car.width/2<=right).map(car=>car.id);
  if(!isFireLane(row))cs.trafficRows[row.index]=trafficRowSnapshot(row,cw,seg.index,s.tick);
 }
 cs.gate={segmentIndex:seg.index,activatedTick:s.tick,releaseTick:null,allowedByRow};emitCrosswalkEvent(s,'priority',{segmentIndex:seg.index});
}
function releaseGoldenGate(s,immediate=false){const gate=s.crosswalk.gate;if(!gate)return;gate.releaseTick=immediate?s.tick:s.tick+CROSSWALK_RELEASE_TICKS;}
function loseGoldenCrosswalk(s){const cs=s.crosswalk;if(!cs.rewardReady&&!cs.goldenSegmentIndex)return;releaseGoldenGate(s,true);cs.goodCrossings=0;cs.rewardReady=false;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=null;cs.progress=null;emitCrosswalkEvent(s,'lost',{count:0});}
function beginCrosswalkIfNeeded(s,dir,targetX,targetY){
 if(dir!=='forward')return;const seg=segmentForRow(s,targetY);if(!seg?.crosswalk||Math.abs(s.y-seg.start)>.001)return;const cs=s.crosswalk,cw=seg.crosswalk;
 if(!xInsideCrosswalk(cw,targetX)){if(cs.goldenSegmentIndex===seg.index)cs.progress={segmentIndex:seg.index,valid:false,golden:true};return;}
 cs.progress={segmentIndex:seg.index,valid:true,golden:cs.goldenSegmentIndex===seg.index};
 if(cs.progress.golden&&cs.rewardReady)activateGoldenCrosswalk(s,seg);
}
function updateCrosswalkProgress(s){
 const cs=s.crosswalk,p=position(s),progress=cs.progress;if(!progress)return;const seg=s.segments.find(item=>item.index===progress.segmentIndex);if(!seg?.crosswalk){cs.progress=null;return;}
 if(!xInsideCrosswalk(seg.crosswalk,p.x)){if(progress.valid&&progress.golden)releaseGoldenGate(s,true);progress.valid=false;}
 if(s.move?.dir==='backward'){if(progress.valid&&progress.golden)releaseGoldenGate(s,true);progress.valid=false;}
}
function finishCrosswalkIfNeeded(s){
 const cs=s.crosswalk,progress=cs.progress;if(!progress)return;const seg=s.segments.find(item=>item.index===progress.segmentIndex);if(!seg?.crosswalk)return;
 if(Math.abs(s.y-seg.end)>.001)return;
 const valid=progress.valid&&xInsideCrosswalk(seg.crosswalk,s.x),golden=progress.golden;cs.progress=null;
 if(golden){
  if(valid&&cs.rewardReady){releaseGoldenGate(s,false);cs.goodCrossings=0;cs.rewardReady=false;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=null;cs.completedSegments.add(seg.index);emitCrosswalkEvent(s,'consumed',{count:0,segmentIndex:seg.index});}
  else loseGoldenCrosswalk(s);
  return;
 }
 if(valid&&!cs.completedSegments.has(seg.index)){
  cs.completedSegments.add(seg.index);cs.goodCrossings=Math.min(CROSSWALK_GOAL,cs.goodCrossings+1);
  if(cs.goodCrossings>=CROSSWALK_GOAL){assignNextGoldenCrosswalk(s,seg.index);emitCrosswalkEvent(s,'unlock',{count:CROSSWALK_GOAL,goldenSegmentIndex:cs.goldenSegmentIndex});}
  else emitCrosswalkEvent(s,'good',{count:cs.goodCrossings});
 }
}
function checkGoldenSkipped(s){const cs=s.crosswalk;if(!cs.rewardReady||cs.goldenSegmentIndex==null)return;const seg=s.segments.find(item=>item.index===cs.goldenSegmentIndex);if(seg&&s.maxRow>=seg.end&&!cs.completedSegments.has(seg.index)&&(!cs.progress||cs.progress.segmentIndex!==seg.index))loseGoldenCrosswalk(s);}
function updateCrosswalkGate(s){const gate=s.crosswalk.gate;if(gate?.releaseTick!=null&&s.tick>gate.releaseTick)s.crosswalk.gate=null;}
function crosswalkSnapshot(s){const cs=s.crosswalk;return {goodCrossings:cs.goodCrossings,goal:CROSSWALK_GOAL,rewardReady:cs.rewardReady,goldenSegmentIndex:cs.goldenSegmentIndex,activeSegmentIndex:gateHolding(s,cs.gate?.segmentIndex??-1)?cs.gate.segmentIndex:null,eventSeq:cs.eventSeq,lastEvent:cs.lastEvent?{...cs.lastEvent}:null};}
function position(s){if(!s.move)return {x:s.x,y:s.y,lift:0};const p=Math.min(1,(s.tick-s.move.at)/s.move.duration);return {x:s.x+s.move.dx*p,y:s.y+s.move.dy*p,lift:Math.sin(p*Math.PI)};}
function safeObstacleAtState(s,x,y){
 for(let ry=Math.max(0,Math.floor(y)-1);ry<=Math.ceil(y)+1;ry++){
  if(Math.abs(y-ry)>=.43)continue;const row=rowAt(s,ry);if(!row.safe)continue;
  for(const c of row.blocked||[])if(Math.abs(x-c)<.56)return true;
 }return false;
}
function movementHitsSafeObstacle(s,x0,y0,x1,y1,duration){
 for(let dt=1;dt<=duration;dt++){const p=dt/duration;if(safeObstacleAtState(s,x0+(x1-x0)*p,y0+(y1-y0)*p))return true;}return false;
}
function begin(s,dir){const [dx,dy]=DIR[dir],x=s.x+dx,y=s.y+dy,duration=durationFor(dir);if(x<0||x>COLS-1||y<Math.max(0,s.maxRow-3)||movementHitsSafeObstacle(s,s.x,s.y,x,y,duration))return false;beginCrosswalkIfNeeded(s,dir,x,y);s.move={at:s.tick,dx,dy,duration,dir};s.started=true;return true;}
function input(s,dir,record=true){if(s.over||!DIR[dir]||s.events.length>=MAX_EVENTS)return false;if(s.move){if(s.queued)return false;s.queued=dir;}else if(!begin(s,dir))return false;if(record)s.events.push({t:s.tick,d:dir});return true;}
function collision(s){const p=position(s);for(let y=Math.max(0,Math.floor(p.y)-1);y<=Math.ceil(p.y)+1;y++){if(Math.abs(p.y-y)>=.49)continue;for(const car of carsForState(s,rowAt(s,y),s.tick))if(Math.abs(p.x-car.x)<car.width/2+.20)return true;}return false;}
function step(s){
 if(s.over)return s;s.tick++;updateCrosswalkProgress(s);updateCrosswalkGate(s);updateCrosswalkTraffic(s);
 if(collision(s)){s.over=true;s.reason='traffic';s.queued=null;return s;}
 if(s.move&&s.tick-s.move.at>=s.move.duration){s.x+=s.move.dx;s.y+=s.move.dy;s.x=Math.round(s.x/LATERAL_DISTANCE)*LATERAL_DISTANCE;s.move=null;if(s.y>s.maxRow)s.maxRow=s.y;finishCrosswalkIfNeeded(s);checkGoldenSkipped(s);if(s.queued){const d=s.queued;s.queued=null;begin(s,d);}}
 updatePolice(s);if(s.over)return s;
 if(s.tick>=MAX_TICKS){s.over=true;s.reason='extraction';s.queued=null;}
 if(s.tick%HZ===0){for(const y of s.rows.keys())if(y<s.maxRow-12)s.rows.delete(y);for(const key of Object.keys(s.crosswalk.trafficRows||{}))if(Number(key)<s.maxRow-14)delete s.crosswalk.trafficRows[key];for(const [segIndex] of Object.entries(s.fireSegments||{})){const seg=s.segments[Number(segIndex)];if(seg&&seg.end<s.maxRow-14)delete s.fireSegments[segIndex];}}
 return s;
}
function replay(seed,events,ticks){
 if(!Array.isArray(events)||events.length>MAX_EVENTS||!Number.isInteger(ticks)||ticks<1||ticks>MAX_TICKS)throw Error('Registro de partida inválido');let prev=-1;
 for(const e of events){if(!e||!Number.isInteger(e.t)||e.t<prev||e.t<0||e.t>=ticks||!DIR[e.d])throw Error('Movimiento inválido');prev=e.t;}
 const s=create(seed);let i=0;while(s.tick<ticks){while(i<events.length&&events[i].t===s.tick){if(!input(s,events[i++].d,false))throw Error('Movimiento no permitido');}step(s);if(s.over&&s.tick!==ticks)throw Error('La partida ya había terminado');}
 if(!s.over||i!==events.length)throw Error('Partida incompleta');return {score:s.maxRow,reason:s.reason,ticks:s.tick,police:policeSnapshot(s),crosswalk:crosswalkSnapshot(s)};
}
function segmentDiagnostics(s,index){ensureSegmentsThrough(s,Math.max(1,index));const seg=s.segments.find(x=>index>=x.start&&index<=x.end)||s.segments[s.segments.length-1];return seg?{index:seg.index,start:seg.start,end:seg.end,roads:seg.roads,tier:seg.tier,attempt:seg.attempt,fallback:seg.fallback,chainWindow:seg.chainWindow||null,crosswalk:seg.crosswalk?{...seg.crosswalk}:null,families:seg.rows.filter(r=>!r.safe).map(r=>r.family),speeds:seg.rows.filter(r=>!r.safe).map(r=>r.speed),gaps:seg.rows.filter(r=>!r.safe).map(r=>r.gapSeconds),occupancies:seg.rows.filter(r=>!r.safe).map(r=>r.occupancy),safeBlocks:seg.rows.filter(r=>r.safe).map(r=>({row:r.index,blocked:[...(r.blocked||[])]})),fireLane:seg.rows.find(r=>isFireLane(r))?.index??null,valid:segmentValid(seg)}:null;}
const api={VERSION,HZ,STEP,FORWARD_STEP,LATERAL_STEP,LATERAL_DISTANCE,COLS,MAX_TICKS,MAX_EVENTS,WAIT_TICKS,SOLVER_HORIZON_TICKS,SOLVER_TIME_BUCKET,POLICE_WARNING_ROW,POLICE_ACTIVE_ROW,POLICE_MAX_DISTANCE,POLICE_INITIAL_DISTANCE,POLICE_STREAK_TICKS,CROSSWALK_GOAL,DIR,VEHICLE_SPECS,TRAFFIC_FAMILIES,hashSeed,tierForRow,pursuitTierForRow,policeTuningForRow,crosswalkForSegment,fireLaneIndexForSegment,isFireLane,isFireLaneActive,fireLaneTickForState,safeBlockedFor,roadCountFor,cars,carsForState,crosswalkAt,crosswalkSnapshot,buildSegment,canTraverseSegment,traverseTicks,humanReadableSegment,segmentValid,rowAt,create,position,input,collision,policeSnapshot,step,replay,segmentDiagnostics};
root.DANI_ARCADE_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
// END SHARED CROSSING ENGINE
// BEGIN SHARED SAFE ENGINE
/* BOTÍN 30 · precision bar rules V10.
 * Five timing attempts on a visible horizontal bar. The marker bounces left/right;
 * every round uses the exact same center target, and difficulty comes only from speed.
 * There is no gameplay timeout: a player may wait as long as needed before tapping.
 * Ranking: highest average precision, then highest worst attempt, then most perfects.
 */
(function(root){'use strict';
const VERSION=10;
const READY_MS=900;
const ROUNDS=5;
const FEEDBACK_MS=900;
const FINISH_MS=1000;
const ROUND_TIMEOUT_MS=0; // Compatibility export: V9 never auto-locks a round.
const MAX_EVENTS=5;
const MAX_DURATION_MS=60*60*1000; // Technical anti-abuse ceiling only; never awards 0 or advances a round.
const TARGETS=Object.freeze([0.50,0.50,0.50,0.50,0.50]);
const TRAVEL_MS=Object.freeze([1700,1300,950,700,520]);
const PERFECT_SNAP=0; // V10: 100.00% exists only at the mathematical center.
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function hashSeed(value){const s=String(value||'');let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}h^=h>>>16;h=Math.imul(h,2246822507)>>>0;h^=h>>>13;h=Math.imul(h,3266489909)>>>0;h^=h>>>16;return h>>>0;}
function startPhaseFor(runId,round){const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),h=hashSeed(`BOTIN30:V${VERSION}:${String(runId||'preview')}:${idx}`);return(h/4294967296)*2;}
function markerX(round,elapsedMs,runId='preview'){
  const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),travel=TRAVEL_MS[idx],t=Math.max(0,Number(elapsedMs)||0),phase=(startPhaseFor(runId,idx)+t/travel)%2;
  return clamp(phase<=1?phase:2-phase,0,1);
}
function elapsedForX(runId,round,x){const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),desired=clamp(Number(x)||0,0,1),phase=startPhaseFor(runId,idx),a=(desired-phase+2)%2,b=((2-desired)-phase+2)%2;return Math.min(a,b)*TRAVEL_MS[idx];}
function centerElapsedFor(runId,round){return elapsedForX(runId,round,.5);}
function targetFor(){return 0.5;}
function precisionFor(round,x){
  const dist=Math.abs(clamp(Number(x)||0,0,1)-0.5),raw=clamp(1-dist/.5,0,1);
  if(dist<9.999e-7)return 10000;
  return Math.min(9999,Math.floor(raw*10000+1e-9));
}
function qualityLabel(bps){const p=Math.max(0,Number(bps)||0);if(p>=9500)return'PERFECTO';if(p>=8500)return'LIMPIO';if(p>=7000)return'AJUSTADO';return'FORZADO';}
function outcomeFor(avgBps){const p=Math.max(0,Number(avgBps)||0);if(p>=10000)return'perfect';if(p>=8500)return'clean';if(p>=7000)return'forced';return'locked';}
function create(runId='preview'){
 return {version:VERSION,runId:String(runId||'preview'),timeMs:0,round:0,roundStartMs:READY_MS,roundLocked:false,feedbackUntil:0,finishAt:0,over:false,reason:'',attempts:[],events:[],fx:[]};
}
function phase(s){if(!s)return'ended';if(s.over)return'ended';if(s.finishAt>0)return'finishing';if(s.timeMs<READY_MS)return'ready';if(s.roundLocked||s.timeMs<s.roundStartMs)return'feedback';return'active';}
function currentMarker(s,atMs=s?.timeMs||0){if(!s||s.round>=ROUNDS)return 0.5;return markerX(s.round,Math.max(0,Number(atMs)-Number(s.roundStartMs||0)),s.runId);}
function averageBps(s){if(!s?.attempts?.length)return 0;return Math.round(s.attempts.reduce((a,b)=>a+Math.max(0,Number(b.precisionBps)||0),0)/s.attempts.length);}
function worstBps(s){if(!s?.attempts?.length)return 0;return Math.min(...s.attempts.map(a=>Math.max(0,Number(a.precisionBps)||0)));}
function perfects(s){return(s?.attempts||[]).filter(a=>Number(a.precisionBps)>=9500).length;}
function exactHundreds(s){return(s?.attempts||[]).filter(a=>Number(a.precisionBps)>=10000).length;}
function pushEvent(s,e){if(s.events.length>=MAX_EVENTS)return false;s.events.push(e);return true;}
function lockAttempt(s,t,{record=true}={}){
 if(s.over||s.finishAt>0||s.round>=ROUNDS)return{accepted:false,reason:'over'};
 const x=currentMarker(s,t),precisionBps=precisionFor(s.round,x),eventTime=Math.round(Number(t)*1000000)/1000000,attempt={round:s.round+1,t:eventTime,x:Math.round(x*10000000)/10000000,target:0.5,precisionBps,label:qualityLabel(precisionBps),timeout:false};
 if(record&&!pushEvent(s,{t:eventTime,type:'tap'}))return{accepted:false,reason:'event-limit'};
 s.attempts.push(attempt);s.fx.push({type:'attempt',...attempt,averageBps:averageBps(s)});s.roundLocked=true;s.feedbackUntil=t+FEEDBACK_MS;s.round+=1;
 if(s.round>=ROUNDS){s.finishAt=t+FINISH_MS;s.feedbackUntil=s.finishAt;}
 else s.roundStartMs=s.feedbackUntil;
 return{accepted:true,attempt,averageBps:averageBps(s),round:s.round};
}
function advance(s,toMs){
 if(!s||s.over)return s;
 const target=clamp(Number(toMs)||0,s.timeMs,MAX_DURATION_MS);s.timeMs=target;
 if(s.finishAt>0&&s.timeMs>=s.finishAt){s.timeMs=s.finishAt;s.over=true;s.reason='complete';return s;}
 if(s.roundLocked&&s.timeMs>=s.feedbackUntil)s.roundLocked=false;
 return s;
}
function tap(s,timeMs,{record=true}={}){
 if(!s||s.over)return{accepted:false,reason:'over'};advance(s,timeMs);if(s.over)return{accepted:false,reason:'over'};
 if(phase(s)!=='active')return{accepted:false,reason:phase(s)};
 return lockAttempt(s,s.timeMs,{record});
}
function result(s){
 const avg=averageBps(s),worst=worstBps(s),done=s.attempts.length>=ROUNDS;
 return {scoreBps:avg,averageBps:avg,worstBps:worst,perfects:perfects(s),exactHundreds:exactHundreds(s),attempts:s.attempts.map(a=>({...a})),outcome:done?outcomeFor(avg):'pending',durationMs:Math.ceil(s.timeMs||0),complete:Boolean(s.over&&s.reason==='complete'&&done)};
}
function replay(runId,events,durationMs){
 if(!Array.isArray(events)||events.length>MAX_EVENTS)throw Error('Registro de BOTÍN inválido');
 const duration=Number(durationMs);if(!Number.isFinite(duration)||duration<READY_MS||duration>MAX_DURATION_MS)throw Error('Duración de BOTÍN inválida');
 const s=create(runId);let prev=-1;
 for(const raw of events){const t=Number(raw?.t);if(!Number.isFinite(t)||t<0||t<prev||t>MAX_DURATION_MS)throw Error('Tiempo de intento inválido');prev=t;if(String(raw?.type||'tap')!=='tap')throw Error('Intento inválido');const out=tap(s,t,{record:false});if(!out.accepted)throw Error('Intento fuera de ronda');}
 advance(s,duration);const r=result(s);if(!r.complete)throw Error('BOTÍN incompleto');return r;
}
function drain(s){return s?.fx?.splice(0)||[];}
const api={VERSION,READY_MS,ROUNDS,FEEDBACK_MS,FINISH_MS,ROUND_TIMEOUT_MS,MAX_EVENTS,MAX_DURATION_MS,TARGETS,TRAVEL_MS,PERFECT_SNAP,hashSeed,startPhaseFor,elapsedForX,centerElapsedFor,markerX,targetFor,precisionFor,qualityLabel,outcomeFor,phase,currentMarker,averageBps,worstBps,perfects,create,advance,tap,result,replay,drain};
root.DANI_SAFE_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
// END SHARED SAFE ENGINE
// BEGIN SHARED INFILTRATION ENGINE
/* BRECHA 30: patrón de seguridad determinista, idéntico en navegador y Worker. */
(function(root){'use strict';
const VERSION=7,SEED=30122026,MAX_EVENTS=32768,MAX_ROUNDS=512,MAX_GRID_SIZE=8;
const ZONES=[
  {from:1,name:'ACCESO EXTERNO',subtitle:'Intercepta el patrón de entrada'},
  {from:4,name:'CONTROL DE IDENTIDAD',subtitle:'La seguridad empieza a endurecerse'},
  {from:7,name:'CÁMARAS',subtitle:'Reconstruye la firma antes de ser detectado'},
  {from:10,name:'RED INTERNA',subtitle:'Cada clave expone una capa más profunda'},
  {from:13,name:'CONTROL DE BÓVEDA',subtitle:'Estás entrando en el sistema de la caja'},
  {from:16,name:'CIFRADO',subtitle:'Los patrones ya no perdonan una duda'},
  {from:20,name:'NÚCLEO DE SEGURIDAD',subtitle:'A partir de aquí no existe margen de error'}
];
function zoneFor(round){let z=ZONES[0],index=0;for(let i=0;i<ZONES.length;i++)if(round>=ZONES[i].from){z=ZONES[i];index=i;}return {...z,index,depth:round>=20?round-19:0};}
function difficulty(round){
  const actualRound=Math.max(1,Math.floor(round||1)),curveRound=Math.min(MAX_ROUNDS,actualRound);
  // V7: la dificultad crece por carga de memoria + distractores, nunca por llenar casi toda la matriz.
  // Mantener el patrón alrededor del 50% evita el atajo cognitivo de memorizar solo las pocas casillas vacías.
  const desiredCount=Math.min(Math.ceil((MAX_GRID_SIZE*MAX_GRID_SIZE)/2),curveRound+2);
  let size=3;
  while(size<MAX_GRID_SIZE&&desiredCount>Math.ceil((size*size)/2))size++;
  const capacity=size*size,maxActive=Math.ceil(capacity/2);
  const count=Math.max(3,Math.min(maxActive,desiredCount));
  const previewMs=3200;
  return {round:actualRound,size,count,length:count,previewMs,density:count/capacity,zone:zoneFor(actualRound)};
}
function hashSeed(value){let h=2166136261;for(const c of String(value)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function runSeed(runId){return hashSeed(`INFILTRACION30:V${VERSION}:${String(runId||'')}`)||SEED;}
function mix(seed,round,attempt=0){let x=(seed^(round*0x9e3779b9)^(attempt*0x85ebca6b))>>>0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return x>>>0;}
function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return x/4294967296;};}
function shuffle(list,random){for(let i=list.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[list[i],list[j]]=[list[j],list[i]];}return list;}
function patternSpread(pattern,size){const rows=new Set(),cols=new Set();for(const slot of pattern){rows.add(Math.floor(slot/size));cols.add(slot%size);}return rows.size+cols.size;}
function patternTransitions(pattern,size){
  const active=new Set(pattern);let transitions=0;
  for(let row=0;row<size;row++)for(let col=0;col<size;col++){
    const slot=row*size+col,on=active.has(slot);
    if(col+1<size&&on!==active.has(slot+1))transitions++;
    if(row+1<size&&on!==active.has(slot+size))transitions++;
  }
  return transitions;
}
function buildRound(round,seed=SEED){
  const d=difficulty(round),all=Array.from({length:d.size*d.size},(_,i)=>i);let best=null;
  // Elegimos entre varios patrones aleatorios el más repartido y fragmentado: menos bloques visuales fáciles de memorizar.
  for(let attempt=0;attempt<32;attempt++){
    const random=rng(mix(seed,round,attempt)),pattern=shuffle(all.slice(),random).slice(0,d.count).sort((a,b)=>a-b);
    const spread=patternSpread(pattern,d.size),transitions=patternTransitions(pattern,d.size),quality=spread*100+transitions;
    const candidate={...d,pattern,spread,transitions,quality};
    if(!best||candidate.quality>best.quality)best=candidate;
  }
  return best;
}
/* Se puede cortar la memorización antes de tiempo, por eso la validación temporal es conservadora. */
function minimumRunMs(failedRound,score=0,roundsCompleted=0){return 350+Math.max(1,failedRound||1)*120+Math.max(0,score||0)*45+Math.max(0,roundsCompleted||0)*90;}
function create(seed=SEED){return {seed,round:1,route:buildRound(1,seed),selected:[],score:0,roundsCompleted:0,over:false,failedRound:0,failedAt:0,wrongSlot:null,events:[],fx:[]};}
function validateEvent(e){if(!e||e.kind!=='tap'||!Number.isInteger(e.slot)||e.slot<0||e.slot>=MAX_GRID_SIZE*MAX_GRID_SIZE)throw Error('Evento de infiltración inválido');return {kind:'tap',slot:e.slot};}
function act(s,event,{record=true}={}){
  if(s.over)throw Error('La partida ya había terminado');const e=validateEvent(event);
  if(record){if(s.events.length>=MAX_EVENTS)throw Error('Demasiados eventos');s.events.push(e);}
  const pattern=s.route.pattern;
  if(s.selected.includes(e.slot)){s.fx.push({type:'repeat',slot:e.slot,score:s.score});return s;}
  if(!pattern.includes(e.slot)){
    s.over=true;s.failedRound=s.round;s.failedAt=s.selected.length;s.wrongSlot=e.slot;
    s.fx.push({type:'fail',slot:e.slot,round:s.round,remembered:s.selected.length});return s;
  }
  s.selected.push(e.slot);s.score++;s.fx.push({type:'key',slot:e.slot,score:s.score,selected:s.selected.length,total:pattern.length});
  if(s.selected.length>=pattern.length){
    s.roundsCompleted++;s.fx.push({type:'round',round:s.round,score:s.score});s.round++;
    s.route=buildRound(s.round,s.seed);s.selected=[];
  }
  return s;
}
function result(s){const zone=zoneFor(s.failedRound||s.round);return {score:s.score,roundsCompleted:s.roundsCompleted,failedRound:s.failedRound||s.round,failedStep:(s.failedAt||0)+1,rememberedInFailed:s.failedAt||0,wrongSlot:s.wrongSlot,zone:zone.name,depth:zone.depth||0,gameOver:s.over,minDurationMs:minimumRunMs(s.failedRound||s.round,s.score,s.roundsCompleted)};}
function replay(events,seed=SEED){if(!Array.isArray(events)||events.length>MAX_EVENTS)throw Error('Registro de partida inválido');const s=create(seed);for(const raw of events)act(s,validateEvent(raw),{record:false});return result(s);}
function drain(s){return s.fx.splice(0);}
const api={VERSION,SEED,MAX_EVENTS,MAX_ROUNDS,MAX_GRID_SIZE,ZONES,zoneFor,difficulty,hashSeed,runSeed,buildRound,minimumRunMs,create,act,result,replay,drain};root.DANI_INFILTRATION_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
// END SHARED INFILTRATION ENGINE
// BEGIN SHARED POINT BLIND ENGINE
/* PUNTO CIEGO 30 · timing / temporal perception engine V1.
 * Three deterministic random patrol windows. Ranking: lowest total absolute error.
 */
(function(root,factory){
  const api=factory();
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.DANI_POINTBLIND_ENGINE=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const VERSION=1;
  const ROUNDS=3;
  const READY_MS=900;
  const BETWEEN_MS=1500;
  const MIN_TARGET_MS=1750;
  const MAX_TARGET_MS=5650;
  const MIN_VARIATION_MS=650;
  const MAX_LATE_MS=4000;
  const MAX_DURATION_MS=36000;
  const FADE_START=.42;
  const FADE_END=.59;

  function hashSeed(value){
    const text=String(value||'');let h=2166136261>>>0;
    for(let i=0;i<text.length;i+=1){h^=text.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}
    h^=h>>>16;h=Math.imul(h,2246822507)>>>0;h^=h>>>13;h=Math.imul(h,3266489909)>>>0;h^=h>>>16;
    return h>>>0||0x6d2b79f5;
  }
  function seedForRun(runId){return hashSeed(`PUNTOCIEGO30:V${VERSION}:${String(runId||'')}`);}
  function rng(seed){let x=(Number(seed)>>>0)||0x6d2b79f5;return()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
  function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
  function makeDurations(seed){
    // One fast, one medium and one slow patrol per run. Their exact timings and
    // order vary deterministically, so nobody learns a fixed round pattern
    // while every player faces a comparable overall difficulty curve.
    const random=rng(seed);
    const bands=[[1750,2450],[3000,3900],[4650,5650]];
    const out=bands.map(([min,max])=>Math.round((min+random()*(max-min))/10)*10);
    for(let i=out.length-1;i>0;i-=1){const j=Math.floor(random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
    return out;
  }
  function plan(runId){const seed=seedForRun(runId);return{seed,durations:makeDurations(seed)};}
  function replay(runId,events,durationMs){
    if(!Array.isArray(events)||events.length!==ROUNDS)throw Error('PUNTO CIEGO requiere exactamente 3 pulsaciones');
    const duration=Math.round(Number(durationMs));if(!Number.isInteger(duration)||duration<READY_MS||duration>MAX_DURATION_MS)throw Error('Duración de PUNTO CIEGO inválida');
    const p=plan(runId);let start=READY_MS;const attempts=[];
    for(let i=0;i<ROUNDS;i+=1){
      const raw=events[i]||{};if(raw.type!=='tap')throw Error('Evento de PUNTO CIEGO inválido');
      const t=Math.round(Number(raw.t));if(!Number.isInteger(t))throw Error('Tiempo de pulsación inválido');
      const target=start+p.durations[i];
      if(t<start-80)throw Error('Pulsación anterior al inicio de la ronda');
      if(t>target+MAX_LATE_MS)throw Error('Pulsación demasiado tardía');
      const signedError=t-target,absoluteError=Math.abs(signedError);
      attempts.push({round:i+1,startMs:start,targetDurationMs:p.durations[i],targetAtMs:target,tapAtMs:t,signedErrorMs:signedError,absoluteErrorMs:absoluteError});
      start=t+BETWEEN_MS;
    }
    const lastTap=attempts[attempts.length-1].tapAtMs;if(duration+100<lastTap)throw Error('Duración inferior a la última pulsación');
    const totalErrorMs=attempts.reduce((sum,item)=>sum+item.absoluteErrorMs,0);
    const worstErrorMs=Math.max(...attempts.map(item=>item.absoluteErrorMs));
    const bestErrorMs=Math.min(...attempts.map(item=>item.absoluteErrorMs));
    return{complete:true,rulesVersion:VERSION,seed:p.seed,durations:p.durations,attempts,totalErrorMs,worstErrorMs,bestErrorMs,averageErrorMs:Math.round(totalErrorMs/ROUNDS),durationMs:duration};
  }
  return{VERSION,ROUNDS,READY_MS,BETWEEN_MS,MIN_TARGET_MS,MAX_TARGET_MS,MIN_VARIATION_MS,MAX_LATE_MS,MAX_DURATION_MS,FADE_START,FADE_END,hashSeed,seedForRun,makeDurations,plan,replay};
});
// END SHARED POINT BLIND ENGINE
const INFILTRATION_ENGINE=globalThis.DANI_INFILTRATION_ENGINE;
const POINTBLIND_ENGINE=globalThis.DANI_POINTBLIND_ENGINE;
const SECURE_LOCATION = {
  location: {
    name: 'MI BAJO · ALFAFAR',
    address: 'C. Benito Pérez Galdós, 32, 46910 Alfafar, Valencia',
    mapsUrl: 'https://www.google.com/maps/search/?api=1&query=39.424352%2C-0.388552'
  },
  parking: {
    name: 'PARKING MERCADONA ALFAFAR',
    address: 'Carrer la Tauleta, 27, 46910 Alfafar, Valencia',
    mapsUrl: 'https://www.google.com/maps/search/?api=1&query=39.420951%2C-0.386150'
  }
};

let schemaReady = false;
let schemaPromise = null;
const encoder = new TextEncoder();

const ARCADE_CONTEST = Object.freeze({
  id:'FUGA30-PURSUIT-V7-2026',
  closesAt:'2026-12-12T13:00:00+01:00',
  closesAtMs:Date.parse('2026-12-12T13:00:00+01:00'),
  rewards:Object.freeze([]),
  maxRunMs:globalThis.DANI_ARCADE_ENGINE.MAX_TICKS/globalThis.DANI_ARCADE_ENGINE.HZ*1000+60000
});

const SAFE_CONTEST = Object.freeze({
  id:'SAQUEO30-2026-PRECISION-V10',
  closesAt:'2026-12-12T13:00:00+01:00',
  closesAtMs:Date.parse('2026-12-12T13:00:00+01:00'),
  rulesVersion:10,
  rewards:Object.freeze([]),
    maxRunMs:globalThis.DANI_SAFE_ENGINE.MAX_DURATION_MS+30000
});

const INFILTRATION_CONTEST = Object.freeze({
  id:'INFILTRACION30-V6-2026',
  closesAt:'2026-12-12T13:00:00+01:00',
  closesAtMs:Date.parse('2026-12-12T13:00:00+01:00'),
  rewards:Object.freeze([]),
  maxRunMs:7200000
});

const POINTBLIND_CONTEST = Object.freeze({
  id:'PUNTOCIEGO30-V1-2026',
  closesAt:'2026-12-12T13:00:00+01:00',
  closesAtMs:Date.parse('2026-12-12T13:00:00+01:00'),
  rulesVersion:1,
  rewards:Object.freeze([]),
  maxRunMs:POINTBLIND_ENGINE.MAX_DURATION_MS+30000
});


// v22.79 · One championship, four disciplines. Individual rankings remain informative,
// but only the combined leaderboard pays cash/respect.
const CLANDESTINE_CONTEST = Object.freeze({
  id:'OPERACION30-GENERAL-V1-2026',
  closesAt:'2026-12-12T13:00:00+01:00',
  closesAtMs:Date.parse('2026-12-12T13:00:00+01:00'),
  scoreVersion:1,
  rewards:Object.freeze([
    Object.freeze({ rank:1, cash:1000, respect:10 }),
    Object.freeze({ rank:2, cash:500, respect:6 }),
    Object.freeze({ rank:3, cash:250, respect:3 })
  ])
});

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    }
  });
}

function cleanString(value, max = 120) {
  return String(value ?? '').trim().slice(0, max);
}

function bytesToHex(buffer) {
  return Array.from(new Uint8Array(buffer), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function hexToBytes(hex) {
  const pairs = String(hex || '').match(/.{1,2}/g) || [];
  return new Uint8Array(pairs.map((pair) => Number.parseInt(pair, 16)));
}

function randomHex(bytes = 24) {
  const data = new Uint8Array(bytes);
  crypto.getRandomValues(data);
  return bytesToHex(data);
}

function randomPin() {
  const data = new Uint32Array(1);
  crypto.getRandomValues(data);
  return String(1000 + (data[0] % 9000));
}

async function sha256(value) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', encoder.encode(String(value))));
}

async function hashPin(pin, saltHex) {
  // PIN corto + salt aleatorio + bloqueo tras 5 intentos. Usamos WebCrypto SHA-256
  // para mantener cada petición muy ligera en Workers Free.
  return sha256(`${saltHex}:${String(pin)}`);
}

function secureEqualHex(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  const left = hexToBytes(a);
  const right = hexToBytes(b);
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}

function normalizeUiPrefs(value) {
  const prefs = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const normalized = {};
  if (typeof prefs.crewOpen === 'boolean') normalized.crewOpen = prefs.crewOpen;
  if (typeof prefs.arcadeDiscovered === 'boolean') normalized.arcadeDiscovered = prefs.arcadeDiscovered;
  if (typeof prefs.partyPrepReviewed === 'boolean') normalized.partyPrepReviewed = prefs.partyPrepReviewed;
  return normalized;
}

function parseUiPrefs(value) {
  try { return normalizeUiPrefs(JSON.parse(value || '{}')); } catch { return {}; }
}

function normalizeCompletedMissions(value) {
  if (!Array.isArray(value)) return [];
  return Array.from(new Set(value.map((item) => cleanString(item, 24)).filter(Boolean))).slice(0, 24);
}

function parseCompletedMissions(value) {
  try { return normalizeCompletedMissions(JSON.parse(value || '[]')); } catch { return []; }
}

function normalizeDiscoveredMissions(value) {
  return normalizeCompletedMissions(value);
}

function parseDiscoveredMissions(value) {
  try { return normalizeDiscoveredMissions(JSON.parse(value || '[]')); } catch { return []; }
}

function mergedDiscoveredMissions(row) {
  return normalizeDiscoveredMissions([
    ...parseDiscoveredMissions(row?.discovered_missions_json),
    ...parseCompletedMissions(row?.completed_missions_json)
  ]);
}

function normalizeWantedLevel(value) {
  const level = Number.parseInt(value, 10);
  return Number.isFinite(level) ? Math.max(0, Math.min(5, level)) : 0;
}

function normalizeGameStars(value) {
  const stars = Number.parseInt(value, 10);
  return Number.isFinite(stars) ? Math.max(0, Math.min(999, stars)) : 0;
}

function normalizeWallet(value) {
  const balance = Number.parseInt(value, 10);
  return Number.isFinite(balance) ? Math.max(0, balance) : 0;
}

function economyEventId(playerId, sourceType, sourceId, actionId, eventId = '') {
  const supplied = cleanString(eventId, 96).replace(/[^a-zA-Z0-9:_-]/g, '');
  if (supplied) return `${playerId}:${supplied}`;
  return `${playerId}:${cleanString(sourceType, 20)}:${cleanString(sourceId, 40)}:${cleanString(actionId, 40)}`;
}

const MISSION_ECONOMY = Object.freeze({
  // Las tarjetas pueden mostrar la recompensa en config.js, pero D1 es la fuente
  // de verdad de los premios persistentes y evita que completar dos veces duplique saldo.
  SAVE30: { cash:100, respect:1, stars:0, label:'PARTIDA GUARDADA', directComplete:true },
  STAR30: { cash:0, respect:0, stars:0, label:'FOTO POLICIAL DEL MÁS BUSCADO', directComplete:false },
  CAR30: { cash:0, respect:0, stars:0, label:'OBJETIVO: APARCAMIENTO COMPLETADO', directComplete:false }
});


const RECORD_CLEAN_COSTS = Object.freeze([200, 300, 500, 800, 1200]);
function recordCleanCost(cleanCount = 0) {
  const count = Math.max(0, Number.parseInt(cleanCount, 10) || 0);
  if (count < RECORD_CLEAN_COSTS.length) return RECORD_CLEAN_COSTS[count];
  return RECORD_CLEAN_COSTS[RECORD_CLEAN_COSTS.length - 1] + ((count - RECORD_CLEAN_COSTS.length + 1) * 500);
}

function resolveEconomyAction(sourceType, sourceId, actionId, body, player) {
  const completed = parseCompletedMissions(player?.completed_missions_json);
  if (sourceType === 'game' && sourceId === 'STAR30' && actionId === 'settlement') {
    if (completed.includes('STAR30')) return { error:'GAME_ALREADY_COMPLETED', message:'STAR30 ya consta en tu expediente.' };
    const rawStars = Number.parseInt(body?.meta?.rawStars, 10);
    if (!Number.isFinite(rawStars) || rawStars < 0 || rawStars > 30) {
      return { error:'INVALID_GAME_RESULT', message:'El resultado de STAR30 debe estar entre 0 y 30 estrellas.' };
    }
    return {
      cashDelta:0, respectDelta:0, starsDelta:rawStars, markCompleted:true, repeatable:false,
      meta:{ rawStars, label:'STAR30 · RESULTADO REGISTRADO' }
    };
  }
  if (sourceType === 'game' && sourceId === 'CAR30' && actionId === 'success') {
    if (completed.includes('CAR30')) return { error:'GAME_ALREADY_COMPLETED', message:'CAR30 ya consta en tu expediente.' };
    return {
      cashDelta:0, respectDelta:0, starsDelta:0, markCompleted:true, repeatable:false,
      meta:{ outcome:'success', label:'CAR30 · APARCAMIENTO COMPLETADO' }
    };
  }
  if (sourceType === 'game' && sourceId === 'CAR30' && actionId === 'loss') {
    if (completed.includes('CAR30')) return { error:'GAME_ALREADY_COMPLETED', message:'CAR30 ya consta en tu expediente.' };
    return {
      cashDelta:0, respectDelta:0, starsDelta:1, markCompleted:true, repeatable:false,
      meta:{ outcome:'loss', label:'CAR30 · +1 ESTRELLA' }
    };
  }
  if (sourceType === 'game' && sourceId === 'CAR30' && actionId === 'retry') {
    if (completed.includes('CAR30')) return { error:'GAME_ALREADY_COMPLETED', message:'CAR30 ya consta en tu expediente.' };
    return {
      cashDelta:-100, respectDelta:0, starsDelta:0, markCompleted:false, repeatable:true,
      meta:{ outcome:'retry', cost:100, label:'CAR30 · REINTENTO' }
    };
  }
  if (sourceType === 'system' && sourceId === 'EXPEDIENTE' && actionId === 'clean-star') {
    const cleanCount = Math.max(0, Number(player?.record_clean_count || 0));
    const cost = recordCleanCost(cleanCount);
    return {
      cashDelta:-cost, respectDelta:0, starsDelta:-1, markCompleted:false, repeatable:true,
      cleanRecord:true, expectedCleanCount:cleanCount,
      meta:{ cost, cleanNumber:cleanCount + 1, label:'LIMPIEZA DE EXPEDIENTE' }
    };
  }
  return { error:'ECONOMY_ACTION_NOT_ALLOWED', message:'Esa acción económica no está habilitada.' };
}

function normalizeSpecialties(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 3).map((item, index) => ({
    key: cleanString(item?.key || `specialty-${index + 1}`, 40),
    label: cleanString(item?.label, 40).toUpperCase(),
    emoji: cleanString(item?.emoji || '•', 16)
  })).filter((item) => item.label);
}

function parseSpecialties(value) {
  try { return normalizeSpecialties(JSON.parse(value || '[]')); } catch { return []; }
}

function playerPhotoUrl(row) {
  if (!row?.id || !row?.photo_data) return '';
  const version = encodeURIComponent(String(row.updated_at || '1'));
  return `/api/player-photo/${encodeURIComponent(String(row.id))}?v=${version}`;
}

function playerHasHeistAccess(row) {
  return Boolean(row && row.attendance === 'yes' && row.briefing_completed && row.location_unlocked);
}

function publicPlayer(row) {
  if (!row) return null;
  const publicPrefs = parseUiPrefs(row.ui_prefs_json);
  return {
    id: row.id,
    crewNumber: row.crew_number,
    name: row.name,
    avatar: row.avatar || '🎮',
    photoData: '',
    photoUrl: playerPhotoUrl(row),
    bio: row.bio || '',
    specialties: parseSpecialties(row.specialties_json),
    specialAbility: row.special_ability || '',
    // Aliases legacy (wantedScore/cash) se conservan durante la transición visual.
    gameStars: normalizeGameStars(row.game_stars ?? row.wanted_score),
    wantedScore: normalizeGameStars(row.game_stars ?? row.wanted_score),
    wantedLevel: normalizeWantedLevel(row.wanted_level),
    walletBalance: normalizeWallet(row.wallet_balance ?? row.cash),
    cash: normalizeWallet(row.wallet_balance ?? row.cash),
    completedMissions: parseCompletedMissions(row.completed_missions_json),
    briefingCompleted: Boolean(row.briefing_completed),
    locationUnlocked: Boolean(row.location_unlocked),
    partyPrepReviewed: Boolean(publicPrefs.partyPrepReviewed),
    missionRespect: Math.max(0, Number(row.mission_respect || 0)),
    socialRespect: Math.max(0, Number(row.respect_count || 0)),
    respect: Math.max(0, Number(row.respect_count || 0)) + Math.max(0, Number(row.mission_respect || 0)),
    respectBreakdown: {
      social: Math.max(0, Number(row.respect_count || 0)),
      missions: Math.max(0, Number(row.mission_respect || 0))
    },
    respectedByViewer: Boolean(row.respected_by_viewer),
    updatedAt: row.updated_at
  };
}

function privatePlayer(row) {
  if (!row) return null;
  return {
    ...publicPlayer(row),
    photoData: row.photo_data || '',
    photoUrl: '',
    attendance: row.attendance,
    dietary: row.dietary || '',
    locationUnlocked: Boolean(row.location_unlocked),
    briefingCompleted: Boolean(row.briefing_completed),
    completedMissions: parseCompletedMissions(row.completed_missions_json),
    discoveredMissions: mergedDiscoveredMissions(row),
    wantedLevel: normalizeWantedLevel(row.wanted_level),
    gameStars: normalizeGameStars(row.game_stars ?? row.wanted_score),
    walletBalance: normalizeWallet(row.wallet_balance ?? row.cash),
    cash: normalizeWallet(row.wallet_balance ?? row.cash),
    cashCollectedCount: Math.max(0, Math.min(5, Number(row.cash_collected_count || 0))),
    recordCleanCount: Math.max(0, Number(row.record_clean_count || 0)),
    nextRecordCleanCost: recordCleanCost(row.record_clean_count || 0),
    hasPin: Boolean(row.pin_hash),
    uiPrefs: parseUiPrefs(row.ui_prefs_json)
  };
}

async function ensureColumn(DB, table, column, definition) {
  const result = await DB.prepare(`PRAGMA table_info(${table})`).all();
  const exists = (result.results || []).some((item) => item.name === column);
  if (!exists) await DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
}

async function ensureSchema(DB) {
  if (schemaReady) return;
  if (schemaPromise) return schemaPromise;

  schemaPromise = (async () => {
    await DB.prepare(`CREATE TABLE IF NOT EXISTS players (
      crew_number INTEGER PRIMARY KEY AUTOINCREMENT,
      id TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      attendance TEXT NOT NULL DEFAULT 'yes',
      dietary TEXT NOT NULL DEFAULT '',
      avatar TEXT NOT NULL DEFAULT '🎮',
      photo_data TEXT NOT NULL DEFAULT '',
      bio TEXT NOT NULL DEFAULT '',
      stats_json TEXT NOT NULL DEFAULT '[]',
      specialties_json TEXT NOT NULL DEFAULT '[]',
      special_ability TEXT NOT NULL DEFAULT '',
      pin_hash TEXT,
      pin_salt TEXT,
      session_hash TEXT NOT NULL,
      location_unlocked INTEGER NOT NULL DEFAULT 0,
      briefing_completed INTEGER NOT NULL DEFAULT 0,
      completed_missions_json TEXT NOT NULL DEFAULT '[]',
      discovered_missions_json TEXT NOT NULL DEFAULT '[]',
      wanted_level INTEGER NOT NULL DEFAULT 0,
      wanted_score INTEGER NOT NULL DEFAULT 0,
      game_stars INTEGER NOT NULL DEFAULT 0,
      cash INTEGER NOT NULL DEFAULT 0,
      wallet_balance INTEGER NOT NULL DEFAULT 0,
      cash_collected_count INTEGER NOT NULL DEFAULT 0,
      mission_respect INTEGER NOT NULL DEFAULT 0,
      record_clean_count INTEGER NOT NULL DEFAULT 0,
      failed_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      ui_prefs_json TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`).run();

    // CREATE TABLE IF NOT EXISTS no añade columnas a una D1 ya existente.
    // Estas migraciones son deliberadamente aditivas para poder desplegar sobre la BD actual.
    await ensureColumn(DB, 'players', 'decline_message', "TEXT NOT NULL DEFAULT ''");
    await ensureColumn(DB, 'players', 'photo_data', "TEXT NOT NULL DEFAULT ''");
    await ensureColumn(DB, 'players', 'specialties_json', "TEXT NOT NULL DEFAULT '[]'");
    await ensureColumn(DB, 'players', 'special_ability', "TEXT NOT NULL DEFAULT ''");
    await ensureColumn(DB, 'players', 'failed_attempts', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'locked_until', 'TEXT');
    await ensureColumn(DB, 'players', 'ui_prefs_json', "TEXT NOT NULL DEFAULT '{}'");
    await ensureColumn(DB, 'players', 'briefing_completed', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'completed_missions_json', "TEXT NOT NULL DEFAULT '[]'");
    await ensureColumn(DB, 'players', 'discovered_missions_json', "TEXT NOT NULL DEFAULT '[]'");
    await ensureColumn(DB, 'players', 'wanted_level', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'cash', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'wallet_balance', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'cash_collected_count', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'mission_respect', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'game_stars', 'INTEGER NOT NULL DEFAULT 0');
    await ensureColumn(DB, 'players', 'record_clean_count', 'INTEGER NOT NULL DEFAULT 0');

    // V21.47 · migración económica aditiva. cash/wanted_score quedan como aliases
    // legacy sincronizados para que una versión anterior del frontend no rompa perfiles.
    await DB.prepare(`UPDATE players SET wallet_balance = cash WHERE wallet_balance = 0 AND cash > 0`).run();
    await DB.prepare(`UPDATE players SET game_stars = wanted_score WHERE game_stars = 0 AND wanted_score > 0`).run();

    // Migra el progreso del antiguo easter egg: antes cada estrella temporal equivalía a un billete recogido.
    await DB.prepare(`UPDATE players SET cash_collected_count = wanted_level, cash = wanted_level * 100, wallet_balance = wanted_level * 100
      WHERE cash_collected_count = 0 AND cash = 0 AND wallet_balance = 0 AND wanted_level BETWEEN 1 AND 5`).run();

    // V21.83 · completar los cinco billetes es un hito permanente. Versiones
    // anteriores ponían wanted_level a 0 al terminar WANTED; restauramos ★★★★★
    // a cualquier personaje que ya tenga los cinco billetes guardados.
    await DB.prepare('UPDATE players SET wanted_level = 5 WHERE cash_collected_count >= 5 AND wanted_level < 5').run();

    // Todo jugador ya existente tuvo que pasar por el briefing para responder.
    // Esta migración convierte el progreso histórico al nuevo modelo sin depender del navegador.
    await DB.prepare('UPDATE players SET briefing_completed = 1 WHERE briefing_completed = 0').run();

    await DB.batch([
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_players_attendance ON players(attendance)'),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_players_session ON players(session_hash)'),
      DB.prepare('CREATE TABLE IF NOT EXISTS player_sessions (session_hash TEXT PRIMARY KEY, player_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)'),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_session_player ON player_sessions(player_id)'),
      DB.prepare('CREATE TABLE IF NOT EXISTS player_respect (giver_id TEXT NOT NULL, receiver_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (giver_id, receiver_id))'),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_respect_receiver ON player_respect(receiver_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS economy_events (
        id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        source_type TEXT NOT NULL,
        source_id TEXT NOT NULL,
        action_id TEXT NOT NULL,
        cash_delta INTEGER NOT NULL DEFAULT 0,
        respect_delta INTEGER NOT NULL DEFAULT 0,
        stars_delta INTEGER NOT NULL DEFAULT 0,
        balance_after INTEGER NOT NULL DEFAULT 0,
        mission_respect_after INTEGER NOT NULL DEFAULT 0,
        game_stars_after INTEGER NOT NULL DEFAULT 0,
        meta_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_economy_player_created ON economy_events(player_id, created_at DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v5_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v5_scores_rank ON crossing_v5_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v5_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v5_runs_player ON crossing_v5_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v5_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v5_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v5_podium_player ON crossing_v5_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v6_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v6_scores_rank ON crossing_v6_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v6_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v6_runs_player ON crossing_v6_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v6_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v6_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v6_podium_player ON crossing_v6_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v7_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v7_scores_rank ON crossing_v7_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v7_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v7_runs_player ON crossing_v7_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v7_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v7_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v7_podium_player ON crossing_v7_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v8_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v8_scores_rank ON crossing_v8_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v8_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v8_runs_player ON crossing_v8_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v8_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v8_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v8_podium_player ON crossing_v8_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v10_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v10_scores_rank ON crossing_v10_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v10_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v10_runs_player ON crossing_v10_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v10_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v10_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v10_podium_player ON crossing_v10_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v11_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v11_scores_rank ON crossing_v11_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v11_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v11_runs_player ON crossing_v11_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v11_awards (
        contest_id TEXT PRIMARY KEY,
        winner_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS crossing_v11_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_crossing_v11_podium_player ON crossing_v11_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_skill_scores (
        player_id TEXT PRIMARY KEY,
        best_score_ms INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score_ms INTEGER NOT NULL DEFAULT 0,
        best_elapsed_ms INTEGER NOT NULL DEFAULT 0,
        best_mistakes INTEGER NOT NULL DEFAULT 0,
        best_perfects INTEGER NOT NULL DEFAULT 0,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_skill_scores_rank ON safe_skill_scores(best_score_ms ASC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_skill_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        elapsed_ms INTEGER,
        mistakes INTEGER,
        perfects INTEGER NOT NULL DEFAULT 0,
        score_ms INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_skill_runs_player ON safe_skill_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_skill_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score_ms INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_skill_podium_player ON safe_skill_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_sequence_scores (
        player_id TEXT PRIMARY KEY,
        best_score_ms INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score_ms INTEGER NOT NULL DEFAULT 0,
        best_elapsed_ms INTEGER NOT NULL DEFAULT 0,
        best_mistakes INTEGER NOT NULL DEFAULT 0,
        best_perfects INTEGER NOT NULL DEFAULT 0,
        best_bonus_ms INTEGER NOT NULL DEFAULT 0,
        best_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_worst_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_precision_json TEXT NOT NULL DEFAULT '[]',
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_sequence_scores_rank ON safe_sequence_scores(best_score_ms ASC, best_precision_bps DESC, best_worst_precision_bps DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_sequence_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        elapsed_ms INTEGER,
        mistakes INTEGER,
        perfects INTEGER NOT NULL DEFAULT 0,
        bonus_ms INTEGER NOT NULL DEFAULT 0,
        precision_bps INTEGER NOT NULL DEFAULT 0,
        worst_precision_bps INTEGER NOT NULL DEFAULT 0,
        precision_json TEXT NOT NULL DEFAULT '[]',
        perfect_flags_json TEXT NOT NULL DEFAULT '[]',
        score_ms INTEGER,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_sequence_runs_player ON safe_sequence_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_sequence_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score_ms INTEGER NOT NULL DEFAULT 0,
        winning_precision_bps INTEGER NOT NULL DEFAULT 0,
        winning_worst_precision_bps INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_sequence_podium_player ON safe_sequence_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v5_scores (
        player_id TEXT PRIMARY KEY,
        best_score_tenths INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score_tenths INTEGER NOT NULL DEFAULT 0,
        best_mistakes INTEGER NOT NULL DEFAULT 0,
        best_perfects INTEGER NOT NULL DEFAULT 0,
        best_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_hit_precision_json TEXT NOT NULL DEFAULT '[]',
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_scores_rank ON safe_loot_v5_scores(best_score_tenths DESC, best_mistakes ASC, best_perfects DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v5_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        rules_version INTEGER NOT NULL DEFAULT 5,
        duration_ms INTEGER,
        score_tenths INTEGER,
        mistakes INTEGER NOT NULL DEFAULT 0,
        perfects INTEGER NOT NULL DEFAULT 0,
        precision_bps INTEGER NOT NULL DEFAULT 0,
        hit_precision_json TEXT NOT NULL DEFAULT '[]',
        event_log_json TEXT NOT NULL DEFAULT '[]',
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_runs_player ON safe_loot_v5_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v5_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score_tenths INTEGER NOT NULL DEFAULT 0,
        winning_mistakes INTEGER NOT NULL DEFAULT 0,
        winning_perfects INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_podium_player ON safe_loot_v5_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v6_scores (
        player_id TEXT PRIMARY KEY,
        best_loops INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_loops INTEGER NOT NULL DEFAULT 0,
        best_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_last_lap_ms INTEGER NOT NULL DEFAULT 999999,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_scores_rank ON safe_loot_v6_scores(best_loops DESC, best_precision_bps DESC, best_last_lap_ms ASC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v6_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        rules_version INTEGER NOT NULL DEFAULT 6,
        duration_ms INTEGER,
        loops INTEGER,
        precision_bps INTEGER NOT NULL DEFAULT 0,
        last_lap_ms INTEGER NOT NULL DEFAULT 0,
        track_breaks INTEGER NOT NULL DEFAULT 0,
        event_log_json TEXT NOT NULL DEFAULT '[]',
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_runs_player ON safe_loot_v6_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v6_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_loops INTEGER NOT NULL DEFAULT 0,
        winning_precision_bps INTEGER NOT NULL DEFAULT 0,
        winning_last_lap_ms INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_podium_player ON safe_loot_v6_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v7_scores (
        player_id TEXT PRIMARY KEY,
        best_precision_bps INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_worst_bps INTEGER NOT NULL DEFAULT 0,
        best_perfects INTEGER NOT NULL DEFAULT 0,
        best_duration_ms INTEGER NOT NULL DEFAULT 999999,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_scores_rank ON safe_loot_v7_scores(best_precision_bps DESC, best_worst_bps DESC, best_perfects DESC, best_duration_ms ASC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v7_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        rules_version INTEGER NOT NULL DEFAULT 7,
        duration_ms INTEGER,
        average_bps INTEGER,
        worst_bps INTEGER NOT NULL DEFAULT 0,
        perfects INTEGER NOT NULL DEFAULT 0,
        outcome TEXT NOT NULL DEFAULT '',
        attempts_json TEXT NOT NULL DEFAULT '[]',
        event_log_json TEXT NOT NULL DEFAULT '[]',
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_runs_player ON safe_loot_v7_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v7_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_precision_bps INTEGER NOT NULL DEFAULT 0,
        winning_worst_bps INTEGER NOT NULL DEFAULT 0,
        winning_perfects INTEGER NOT NULL DEFAULT 0,
        winning_duration_ms INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_podium_player ON safe_loot_v7_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v8_scores (
        player_id TEXT PRIMARY KEY,
        best_precision_bps INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_precision_bps INTEGER NOT NULL DEFAULT 0,
        best_worst_bps INTEGER NOT NULL DEFAULT 0,
        best_perfects INTEGER NOT NULL DEFAULT 0,
        best_duration_ms INTEGER NOT NULL DEFAULT 999999,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_scores_rank ON safe_loot_v8_scores(best_precision_bps DESC, best_worst_bps DESC, best_perfects DESC, best_duration_ms ASC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v8_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        rules_version INTEGER NOT NULL DEFAULT 8,
        duration_ms INTEGER,
        average_bps INTEGER,
        worst_bps INTEGER NOT NULL DEFAULT 0,
        perfects INTEGER NOT NULL DEFAULT 0,
        outcome TEXT NOT NULL DEFAULT '',
        attempts_json TEXT NOT NULL DEFAULT '[]',
        event_log_json TEXT NOT NULL DEFAULT '[]',
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_runs_player ON safe_loot_v8_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS safe_loot_v8_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_precision_bps INTEGER NOT NULL DEFAULT 0,
        winning_worst_bps INTEGER NOT NULL DEFAULT 0,
        winning_perfects INTEGER NOT NULL DEFAULT 0,
        winning_duration_ms INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_podium_player ON safe_loot_v8_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS operation_infiltration_v6_scores (
        player_id TEXT PRIMARY KEY,
        high_score INTEGER NOT NULL DEFAULT 0,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_score INTEGER NOT NULL DEFAULT 0,
        best_rounds_completed INTEGER NOT NULL DEFAULT 0,
        best_failed_round INTEGER NOT NULL DEFAULT 1,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_operation_infiltration_v6_scores_rank ON operation_infiltration_v6_scores(high_score DESC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS operation_infiltration_v6_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        score INTEGER,
        rounds_completed INTEGER NOT NULL DEFAULT 0,
        failed_round INTEGER NOT NULL DEFAULT 1,
        result_json TEXT,
        event_log_json TEXT,
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_operation_infiltration_v6_runs_player ON operation_infiltration_v6_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS operation_infiltration_v6_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_operation_infiltration_podium_player ON operation_infiltration_v6_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS pointblind_v1_scores (
        player_id TEXT PRIMARY KEY,
        best_total_error_ms INTEGER NOT NULL,
        games_played INTEGER NOT NULL DEFAULT 0,
        last_total_error_ms INTEGER NOT NULL DEFAULT 0,
        best_worst_error_ms INTEGER NOT NULL DEFAULT 999999,
        best_single_error_ms INTEGER NOT NULL DEFAULT 999999,
        achieved_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_pointblind_v1_scores_rank ON pointblind_v1_scores(best_total_error_ms ASC, best_worst_error_ms ASC, best_single_error_ms ASC, achieved_at ASC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS pointblind_v1_runs (
        run_id TEXT PRIMARY KEY,
        player_id TEXT NOT NULL,
        started_at_ms INTEGER NOT NULL,
        rules_version INTEGER NOT NULL DEFAULT 1,
        duration_ms INTEGER,
        total_error_ms INTEGER,
        worst_error_ms INTEGER NOT NULL DEFAULT 0,
        best_single_error_ms INTEGER NOT NULL DEFAULT 0,
        attempts_json TEXT NOT NULL DEFAULT '[]',
        event_log_json TEXT NOT NULL DEFAULT '[]',
        finished_at TEXT
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_pointblind_v1_runs_player ON pointblind_v1_runs(player_id, started_at_ms DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS pointblind_v1_podium_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_total_error_ms INTEGER NOT NULL DEFAULT 0,
        winning_worst_error_ms INTEGER NOT NULL DEFAULT 0,
        winning_best_single_error_ms INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_pointblind_v1_podium_player ON pointblind_v1_podium_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS clandestine_championship_awards (
        contest_id TEXT NOT NULL,
        rank INTEGER NOT NULL,
        player_id TEXT NOT NULL,
        winning_score_bps INTEGER NOT NULL DEFAULT 0,
        tiebreak_worst_bps INTEGER NOT NULL DEFAULT 0,
        tiebreak_second_bps INTEGER NOT NULL DEFAULT 0,
        cash_reward INTEGER NOT NULL DEFAULT 0,
        respect_reward INTEGER NOT NULL DEFAULT 0,
        awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (contest_id, rank),
        UNIQUE (contest_id, player_id)
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_clandestine_championship_player ON clandestine_championship_awards(player_id)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS admin_activity (
        id TEXT PRIMARY KEY,
        event_type TEXT NOT NULL,
        severity TEXT NOT NULL DEFAULT 'info',
        actor_id TEXT NOT NULL DEFAULT '',
        actor_name TEXT NOT NULL DEFAULT '',
        title TEXT NOT NULL,
        detail TEXT NOT NULL DEFAULT '',
        meta_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_admin_activity_created ON admin_activity(created_at DESC)'),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_admin_activity_type ON admin_activity(event_type, created_at DESC)'),
      DB.prepare(`CREATE TABLE IF NOT EXISTS admin_notification_settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        enabled INTEGER NOT NULL DEFAULT 0,
        mode TEXT NOT NULL DEFAULT 'hybrid',
        recipient_email TEXT NOT NULL DEFAULT '',
        immediate_rsvp INTEGER NOT NULL DEFAULT 0,
        immediate_decline INTEGER NOT NULL DEFAULT 1,
        immediate_games INTEGER NOT NULL DEFAULT 0,
        daily_digest INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare(`INSERT OR IGNORE INTO admin_notification_settings
        (id, enabled, mode, recipient_email, immediate_rsvp, immediate_decline, immediate_games, daily_digest)
        VALUES (1,0,'hybrid','',0,1,0,1)`),
      DB.prepare(`CREATE TABLE IF NOT EXISTS admin_notification_log (
        id TEXT PRIMARY KEY,
        event_type TEXT NOT NULL DEFAULT '',
        recipient_email TEXT NOT NULL DEFAULT '',
        subject TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT '',
        provider_id TEXT NOT NULL DEFAULT '',
        error TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`),
      DB.prepare('CREATE INDEX IF NOT EXISTS idx_admin_notification_log_created ON admin_notification_log(created_at DESC)'),
    ]);
    schemaReady = true;
  })();

  try {
    await schemaPromise;
  } finally {
    schemaPromise = null;
  }
}

async function requestBody(request) {
  try { return await request.json(); } catch { return {}; }
}

function bearerToken(request) {
  const auth = request.headers.get('authorization') || '';
  return auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
}

async function authenticatedPlayer(request, DB) {
  const token = bearerToken(request);
  if (!token) return null;
  const sessionHash = await sha256(token);
  return DB.prepare('SELECT * FROM players WHERE session_hash = ? OR id IN (SELECT player_id FROM player_sessions WHERE session_hash = ?) LIMIT 1').bind(sessionHash, sessionHash).first();
}

async function requirePlayer(request, DB) {
  const player = await authenticatedPlayer(request, DB);
  if (!player) return { error: json({ error: 'UNAUTHORIZED', message: 'Sesión de jugador no válida.' }, 401) };
  return { player };
}

function adminAllowed(request, env) {
  const supplied = request.headers.get('x-admin-pin') || '';
  return Boolean(env.ADMIN_PIN && supplied && supplied === String(env.ADMIN_PIN));
}

function htmlEscape(value='') {
  return String(value).replace(/[&<>"']/g,(ch)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[ch]));
}

async function readAdminNotificationSettings(DB) {
  const row = await DB.prepare('SELECT * FROM admin_notification_settings WHERE id = 1').first();
  return {
    enabled:Boolean(row?.enabled), mode:['off','daily','hybrid','immediate'].includes(String(row?.mode||''))?String(row.mode):'hybrid',
    recipientEmail:String(row?.recipient_email||''), immediateRsvp:Boolean(row?.immediate_rsvp), immediateDecline:Boolean(row?.immediate_decline),
    immediateGames:Boolean(row?.immediate_games), dailyDigest:Boolean(row?.daily_digest), updatedAt:row?.updated_at||null
  };
}

function maskAdminEmail(value='') {
  const email=String(value||'').trim();
  const at=email.indexOf('@');
  if(at<=0)return email?'CONFIGURADO':'NO CONFIGURADO';
  const local=email.slice(0,at),domain=email.slice(at+1);
  const visible=local.length<=2?local.slice(0,1):local.slice(0,2);
  return `${visible}${'*'.repeat(Math.max(2,Math.min(6,local.length-visible.length)))}@${domain}`;
}

function resolveAdminRecipient(env, settings={}) {
  return cleanString(env.ADMIN_TO_EMAIL || settings.recipientEmail || '',160);
}

function resolveAdminFromEmail(env) {
  return cleanString(env.ADMIN_FROM_EMAIL || '',200) || 'Operación 30 <onboarding@resend.dev>';
}

function adminEmailProvider(env, settings={}) {
  const recipient=resolveAdminRecipient(env,settings),sender=resolveAdminFromEmail(env);
  return {
    configured:Boolean(env.RESEND_API_KEY&&recipient),
    apiKeyConfigured:Boolean(env.RESEND_API_KEY),
    recipientConfigured:Boolean(recipient),
    recipientHint:maskAdminEmail(recipient),
    recipientSource:env.ADMIN_TO_EMAIL?'cloudflare':(settings.recipientEmail?'database':'none'),
    sender,
    senderMode:env.ADMIN_FROM_EMAIL?'custom':'resend-test',
    provider:'Resend',
    name:'Resend'
  };
}

async function sendAdminEmail(DB, env, { eventType='admin', to='', subject='', html='' }={}) {
  const logId=crypto.randomUUID(),from=resolveAdminFromEmail(env);
  if(!to || !env.RESEND_API_KEY){
    const missing=!env.RESEND_API_KEY?'Falta RESEND_API_KEY':'Falta ADMIN_TO_EMAIL';
    await DB.prepare(`INSERT INTO admin_notification_log (id,event_type,recipient_email,subject,status,error) VALUES(?,?,?,?,?,?)`)
      .bind(logId,eventType,to,subject,'not_configured',missing).run();
    return {ok:false,status:'not_configured',error:missing};
  }
  try{
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${env.RESEND_API_KEY}`,'idempotency-key':`dani30/${eventType}/${logId}`},body:JSON.stringify({from,to:[to],subject,html})});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok){
      const detail=String(payload?.message||payload?.error||payload?.name||`Resend ${response.status}`);
      const error=new Error(detail);error.statusCode=response.status;throw error;
    }
    await DB.prepare(`INSERT INTO admin_notification_log (id,event_type,recipient_email,subject,status,provider_id) VALUES(?,?,?,?,?,?)`)
      .bind(logId,eventType,to,subject,'sent',String(payload?.id||'')).run();
    return {ok:true,status:'sent',id:payload?.id||''};
  }catch(error){
    const detail=String(error?.message||error);
    await DB.prepare(`INSERT INTO admin_notification_log (id,event_type,recipient_email,subject,status,error) VALUES(?,?,?,?,?,?)`)
      .bind(logId,eventType,to,subject,'error',detail).run();
    return {ok:false,status:'error',error:detail,statusCode:Number(error?.statusCode||0)};
  }
}

async function recordAdminActivity(DB, env, event={}) {
  const row={ id:crypto.randomUUID(), eventType:String(event.eventType||'event'), severity:String(event.severity||'info'), actorId:String(event.actorId||''), actorName:String(event.actorName||''), title:String(event.title||'Actividad'), detail:String(event.detail||''), meta:event.meta||{} };
  await DB.prepare(`INSERT INTO admin_activity (id,event_type,severity,actor_id,actor_name,title,detail,meta_json) VALUES(?,?,?,?,?,?,?,?)`)
    .bind(row.id,row.eventType,row.severity,row.actorId,row.actorName,row.title,row.detail,JSON.stringify(row.meta)).run();
  const settings=await readAdminNotificationSettings(DB),recipient=resolveAdminRecipient(env,settings);
  const immediate=settings.enabled && recipient && settings.mode!=='off' && (
    settings.mode==='immediate' ||
    (settings.mode==='hybrid' && ((event.category==='decline'&&settings.immediateDecline&&Boolean(event.meta?.hasMessage))||(event.category==='rsvp'&&settings.immediateRsvp)||(event.category==='game'&&settings.immediateGames)))
  );
  if(immediate){
    const subject=`Operación 30 · ${row.title}`;
    const html=`<div style="font-family:Arial,sans-serif;max-width:620px"><p style="font-size:12px;color:#777">OPERACIÓN 30 · AVISO</p><h2>${htmlEscape(row.title)}</h2><p>${htmlEscape(row.detail||row.actorName)}</p><p style="font-size:12px;color:#777">${new Date().toISOString()}</p></div>`;
    await sendAdminEmail(DB,env,{eventType:row.eventType,to:recipient,subject,html});
  }
  return row;
}

async function adminActivityFeed(DB, limit=40) {
  const safeLimit=Math.max(1,Math.min(100,Number(limit)||40));
  const result=await DB.prepare(`SELECT id,event_type,severity,actor_id,actor_name,title,detail,meta_json,created_at FROM admin_activity ORDER BY created_at DESC LIMIT ?`).bind(safeLimit).all();
  return (result.results||[]).map(row=>({id:row.id,eventType:row.event_type,severity:row.severity,actorId:row.actor_id,actorName:row.actor_name,title:row.title,detail:row.detail,meta:(()=>{try{return JSON.parse(row.meta_json||'{}')}catch{return {}}})(),createdAt:row.created_at}));
}

async function adminDashboard(DB) {
  const [people,sessions,activity24,notifications]=await Promise.all([
    DB.prepare(`SELECT COUNT(*) total, SUM(CASE WHEN attendance='yes' THEN 1 ELSE 0 END) confirmed, SUM(CASE WHEN attendance='no' THEN 1 ELSE 0 END) declined,
      SUM(CASE WHEN attendance='yes' AND TRIM(dietary)<>'' THEN 1 ELSE 0 END) dietary, SUM(CASE WHEN attendance='no' AND TRIM(decline_message)<>'' THEN 1 ELSE 0 END) messages,
      MAX(updated_at) last_update FROM players`).first(),
    DB.prepare(`SELECT COUNT(*) active_sessions FROM player_sessions`).first(),
    DB.prepare(`SELECT COUNT(*) activity_24h FROM admin_activity WHERE created_at >= datetime('now','-1 day')`).first(),
    readAdminNotificationSettings(DB)
  ]);
  return {total:Number(people?.total||0),confirmed:Number(people?.confirmed||0),declined:Number(people?.declined||0),dietary:Number(people?.dietary||0),messages:Number(people?.messages||0),activeSessions:Number(sessions?.active_sessions||0),activity24h:Number(activity24?.activity_24h||0),lastUpdate:people?.last_update||null,notifications};
}

async function buildAdminDigest(DB) {
  const dashboard=await adminDashboard(DB), activity=await adminActivityFeed(DB,60);
  const day=activity.filter(item=>{const t=Date.parse(String(item.createdAt||'').replace(' ','T')+'Z');return Number.isFinite(t)&&t>=Date.now()-86400000;});
  const items=day.slice(0,24).map(item=>`<li><b>${htmlEscape(item.title)}</b>${item.detail?` — ${htmlEscape(item.detail)}`:''}</li>`).join('');
  return {dashboard,activity:day,subject:`Operación 30 · Resumen diario · ${dashboard.confirmed} confirmados`,html:`<div style="font-family:Arial,sans-serif;max-width:680px"><p style="font-size:12px;color:#777">OPERACIÓN 30 · RESUMEN</p><h2>${dashboard.confirmed} confirmados · ${dashboard.declined} bajas</h2><p>${dashboard.messages} mensajes · ${dashboard.dietary} avisos de dieta/alergias · ${dashboard.activity24h} movimientos en 24 h</p>${items?`<h3>Últimos movimientos</h3><ul>${items}</ul>`:'<p>Sin movimientos durante las últimas 24 horas.</p>'}</div>`};
}


function clampScoreBps(value) {
  return Math.max(0, Math.min(10000, Math.round(Number(value) || 0)));
}

function clandestineComponentScores(row) {
  // Hidden common scale. Constants calibrate very different raw metrics onto 0..100
  // without changing the rules of any game. All four disciplines then weigh exactly 25%.
  const infiltrationRaw=Math.max(0,Number(row?.infiltration_score||0));
  const blindError=Math.max(0,Number(row?.blind_error_ms||0));
  const safePrecision=Math.max(0,Number(row?.safe_precision_bps||0));
  const fugaRaw=Math.max(0,Number(row?.fuga_score||0));
  const infiltration=clampScoreBps(10000*(1-Math.exp(-infiltrationRaw/50)));
  const blind=clampScoreBps(10000*Math.exp(-blindError/4000));
  const safe=clampScoreBps(safePrecision);
  const fuga=clampScoreBps(10000*(1-Math.exp(-fugaRaw/75)));
  return {infiltration,blind,safe,fuga};
}

function compareClandestineEntries(a,b) {
  if(b.scoreBps!==a.scoreBps)return b.scoreBps-a.scoreBps;
  // Tie-break: reward balance. Compare the weakest discipline first, then the next weakest.
  for(let i=0;i<4;i+=1){const d=(b.balanceVector?.[i]||0)-(a.balanceVector?.[i]||0);if(d)return d;}
  const ta=Date.parse(a.completedAt||'')||Number.MAX_SAFE_INTEGER,tb=Date.parse(b.completedAt||'')||Number.MAX_SAFE_INTEGER;
  if(ta!==tb)return ta-tb;
  return Number(a.crewNumber||0)-Number(b.crewNumber||0);
}

async function clandestineRawPlayers(DB) {
  const result=await DB.prepare(`SELECT p.id AS player_id,p.crew_number,p.name,p.avatar,p.photo_data,p.updated_at,
      i.high_score AS infiltration_score,i.achieved_at AS infiltration_at,
      b.best_total_error_ms AS blind_error_ms,b.achieved_at AS blind_at,
      s.best_precision_bps AS safe_precision_bps,s.achieved_at AS safe_at,
      f.high_score AS fuga_score,f.achieved_at AS fuga_at
    FROM players p
    LEFT JOIN operation_infiltration_v6_scores i ON i.player_id=p.id
    LEFT JOIN pointblind_v1_scores b ON b.player_id=p.id
    LEFT JOIN safe_loot_v8_scores s ON s.player_id=p.id
    LEFT JOIN crossing_v11_scores f ON f.player_id=p.id
    WHERE p.attendance='yes'
    ORDER BY p.crew_number ASC`).all();
  return result.results||[];
}

function clandestineEntryFromRow(row,viewerId='') {
  const completedGames=[row.infiltration_score!=null,row.blind_error_ms!=null,row.safe_precision_bps!=null,row.fuga_score!=null];
  const completedCount=completedGames.filter(Boolean).length;
  const missing=[];if(!completedGames[0])missing.push('BRECHA');if(!completedGames[1])missing.push('PUNTO CIEGO');if(!completedGames[2])missing.push('BOTÍN');if(!completedGames[3])missing.push('FUGA');
  const base={playerId:row.player_id,crewNumber:Number(row.crew_number||0),name:row.name||'PLAYER',avatar:row.avatar||'🎮',photoUrl:playerPhotoUrl(row),isViewer:Boolean(viewerId&&viewerId===row.player_id),completedCount,missing};
  if(completedCount!==4)return {...base,eligible:false};
  const components=clandestineComponentScores(row),values=Object.values(components),scoreBps=Math.round(values.reduce((sum,v)=>sum+v,0)/4),balanceVector=values.slice().sort((a,b)=>a-b);
  const dates=[row.infiltration_at,row.blind_at,row.safe_at,row.fuga_at].map(v=>Date.parse(v||'')).filter(Number.isFinite);
  const completedAt=dates.length?new Date(Math.max(...dates)).toISOString():null;
  return {...base,eligible:true,scoreBps,balanceVector,completedAt,components,raw:{infiltration:Number(row.infiltration_score||0),blind:Number(row.blind_error_ms||0),safe:Number(row.safe_precision_bps||0),fuga:Number(row.fuga_score||0)}};
}

async function clandestineLeaderboard(DB,viewerId='') {
  const rows=await clandestineRawPlayers(DB),all=rows.map(row=>clandestineEntryFromRow(row,viewerId)),eligible=all.filter(x=>x.eligible).sort(compareClandestineEntries);
  eligible.forEach((entry,index)=>{entry.rank=index+1;entry.prize=CLANDESTINE_CONTEST.rewards[index]?{...CLANDESTINE_CONTEST.rewards[index]}:null;});
  const viewer=all.find(x=>x.isViewer)||null;
  if(viewer?.eligible){const ranked=eligible.find(x=>x.playerId===viewer.playerId);if(ranked)Object.assign(viewer,{rank:ranked.rank,scoreBps:ranked.scoreBps,balanceVector:ranked.balanceVector,components:ranked.components,completedAt:ranked.completedAt,prize:ranked.prize});}
  return {leaderboard:eligible,viewer,confirmed:all.length,eligiblePlayers:eligible.length};
}

async function clandestineAwards(DB) {
  const result=await DB.prepare(`SELECT a.contest_id,a.rank,a.player_id,a.winning_score_bps,a.tiebreak_worst_bps,a.tiebreak_second_bps,a.cash_reward,a.respect_reward,a.awarded_at,
      p.name,p.avatar,p.photo_data,p.updated_at FROM clandestine_championship_awards a LEFT JOIN players p ON p.id=a.player_id
      WHERE a.contest_id=? ORDER BY a.rank ASC`).bind(CLANDESTINE_CONTEST.id).all();
  return (result.results||[]).map(row=>({rank:Number(row.rank||0),playerId:row.player_id,name:row.name||'PLAYER',avatar:row.avatar||'🎮',photoUrl:playerPhotoUrl(row),scoreBps:Number(row.winning_score_bps||0),cash:Number(row.cash_reward||0),respect:Number(row.respect_reward||0),awardedAt:row.awarded_at}));
}

async function settleClandestineChampionship(DB,nowMs=Date.now()) {
  const existing=await clandestineAwards(DB);
  if(!Number.isFinite(CLANDESTINE_CONTEST.closesAtMs)||nowMs<CLANDESTINE_CONTEST.closesAtMs)return existing;
  const {leaderboard}=await clandestineLeaderboard(DB);
  for(let index=0;index<Math.min(3,leaderboard.length);index+=1){
    const leader=leaderboard[index],reward=CLANDESTINE_CONTEST.rewards[index];if(!reward)continue;
    const inserted=await DB.prepare(`INSERT OR IGNORE INTO clandestine_championship_awards
      (contest_id,rank,player_id,winning_score_bps,tiebreak_worst_bps,tiebreak_second_bps,cash_reward,respect_reward)
      VALUES(?,?,?,?,?,?,?,?)`).bind(CLANDESTINE_CONTEST.id,reward.rank,leader.playerId,leader.scoreBps,leader.balanceVector[0]||0,leader.balanceVector[1]||0,reward.cash,reward.respect).run();
    if(Number(inserted?.meta?.changes||0)<=0)continue;
    await DB.prepare(`UPDATE players SET wallet_balance=wallet_balance+?,cash=cash+?,mission_respect=mission_respect+?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
      .bind(reward.cash,reward.cash,reward.respect,leader.playerId).run();
    const balance=await DB.prepare('SELECT wallet_balance,mission_respect,game_stars FROM players WHERE id=? LIMIT 1').bind(leader.playerId).first();
    await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id,player_id,source_type,source_id,action_id,cash_delta,respect_delta,stars_delta,balance_after,mission_respect_after,game_stars_after,meta_json)
      VALUES(?,?,'arcade','OPERACION30',?,?,?,0,?,?,?,?)`)
      .bind(`${leader.playerId}:arcade:OPERACION30:general:${reward.rank}`,leader.playerId,`general-podium-${reward.rank}`,reward.cash,reward.respect,
        Math.max(0,Number(balance?.wallet_balance||0)),Math.max(0,Number(balance?.mission_respect||0)),Math.max(0,Number(balance?.game_stars||0)),
        JSON.stringify({label:`OPERACIÓN 30 · PODIO GENERAL #${reward.rank}`,rank:reward.rank,cash:reward.cash,respect:reward.respect,scoreBps:leader.scoreBps})).run();
  }
  return clandestineAwards(DB);
}

async function clandestineStatus(DB,viewerId='') {
  const awards=await settleClandestineChampionship(DB),board=await clandestineLeaderboard(DB,viewerId),closed=Date.now()>=CLANDESTINE_CONTEST.closesAtMs;
  return {phase:closed?'closed':'open',closesAt:CLANDESTINE_CONTEST.closesAt,scoreVersion:CLANDESTINE_CONTEST.scoreVersion,rewards:CLANDESTINE_CONTEST.rewards.map(x=>({...x})),totalCash:CLANDESTINE_CONTEST.rewards.reduce((sum,x)=>sum+x.cash,0),awards,winner:awards[0]||null,leaderboard:board.leaderboard.slice(0,20),viewer:board.viewer,eligiblePlayers:board.eligiblePlayers,confirmed:board.confirmed};
}


async function arcadeAwards(DB) {
  const result = await DB.prepare(`SELECT a.contest_id, a.rank, a.player_id, a.winning_score,
      a.cash_reward, a.respect_reward, a.awarded_at, p.name, p.avatar, p.photo_data, p.updated_at
    FROM crossing_v11_podium_awards a LEFT JOIN players p ON p.id = a.player_id
    WHERE a.contest_id = ? ORDER BY a.rank ASC`).bind(ARCADE_CONTEST.id).all();
  return (result.results || []).map((row) => ({
    rank:Math.max(1, Number(row.rank || 1)),
    playerId:row.player_id,
    name:row.name || 'PLAYER',
    avatar:row.avatar || '🎮',
    photoUrl:playerPhotoUrl(row),
    score:Math.max(0, Number(row.winning_score || 0)),
    cash:Math.max(0, Number(row.cash_reward || 0)),
    respect:Math.max(0, Number(row.respect_reward || 0)),
    awardedAt:row.awarded_at
  }));
}

async function settleArcadeContest(DB, nowMs = Date.now()) {
  const existing = await arcadeAwards(DB);
  if (!Number.isFinite(ARCADE_CONTEST.closesAtMs) || nowMs < ARCADE_CONTEST.closesAtMs) return existing;

  const result = await DB.prepare(`SELECT s.player_id, s.high_score, s.achieved_at, p.name, p.avatar
    FROM crossing_v11_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.high_score > 0
    ORDER BY s.high_score DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 3`).all();
  const podium = result.results || [];
  for (let index = 0; index < podium.length; index += 1) {
    const leader = podium[index];
    const reward = ARCADE_CONTEST.rewards[index];
    if (!reward) continue;
    const inserted = await DB.prepare(`INSERT OR IGNORE INTO crossing_v11_podium_awards
      (contest_id, rank, player_id, winning_score, cash_reward, respect_reward)
      VALUES (?, ?, ?, ?, ?, ?)`).bind(
        ARCADE_CONTEST.id, reward.rank, leader.player_id, leader.high_score, reward.cash, reward.respect
      ).run();
    if (Number(inserted?.meta?.changes || 0) <= 0) continue;

    await DB.prepare(`UPDATE players SET wallet_balance = wallet_balance + ?, cash = cash + ?,
      mission_respect = mission_respect + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .bind(reward.cash, reward.cash, reward.respect, leader.player_id).run();
    const balance = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars FROM players WHERE id = ? LIMIT 1').bind(leader.player_id).first();
    await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta,
       balance_after, mission_respect_after, game_stars_after, meta_json)
      VALUES (?, ?, 'arcade', 'FUGA30', ?, ?, ?, 0, ?, ?, ?, ?)`)
      .bind(`${leader.player_id}:arcade:FUGA30:v10:podium:${reward.rank}`, leader.player_id, `v10-podium-${reward.rank}`,
        reward.cash, reward.respect, Math.max(0, Number(balance?.wallet_balance || 0)),
        Math.max(0, Number(balance?.mission_respect || 0)), Math.max(0, Number(balance?.game_stars || 0)),
        JSON.stringify({ label:`FUGA 30 · PODIO #${reward.rank}`, rank:reward.rank, score:Number(leader.high_score || 0), cash:reward.cash, respect:reward.respect })).run();
  }
  return arcadeAwards(DB);
}

async function arcadeLeaderboard(DB, viewerId = '') {
  const result = await DB.prepare(`SELECT s.player_id, s.high_score, s.games_played, s.achieved_at,
      p.crew_number, p.name, p.avatar, p.photo_data, p.updated_at
    FROM crossing_v11_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.high_score > 0
    ORDER BY s.high_score DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 20`).all();
  return (result.results || []).map((row, index) => ({
    rank:index + 1,
    playerId:row.player_id,
    name:row.name,
    avatar:row.avatar || '🎮',
    photoUrl:playerPhotoUrl(row),
    score:Math.max(0, Number(row.high_score || 0)),
    gamesPlayed:Math.max(0, Number(row.games_played || 0)),
    achievedAt:row.achieved_at,
    isViewer:Boolean(viewerId && viewerId === row.player_id),
    prize:ARCADE_CONTEST.rewards[index] ? { ...ARCADE_CONTEST.rewards[index] } : null
  }));
}

async function adminArcadeStatus(DB) {
  const awards = await settleArcadeContest(DB);
  const leaderboard = await arcadeLeaderboard(DB);
  const totals = await DB.prepare(`SELECT COUNT(*) AS players, COALESCE(SUM(games_played),0) AS games,
    COALESCE(MAX(high_score),0) AS best FROM crossing_v11_scores WHERE high_score > 0`).first();
  return {
    phase:Date.now() < ARCADE_CONTEST.closesAtMs ? 'open' : 'closed',
    closesAt:ARCADE_CONTEST.closesAt,
    rewards:ARCADE_CONTEST.rewards.map((item) => ({ ...item })),
    awards,
    leaderboard,
    players:Math.max(0, Number(totals?.players || 0)),
    games:Math.max(0, Number(totals?.games || 0)),
    best:Math.max(0, Number(totals?.best || 0))
  };
}

async function adminOperationsStatus(DB) {
  const [fuga,infiltration,blind,championship]=await Promise.all([adminArcadeStatus(DB),adminInfiltrationStatus(DB),adminPointBlindStatus(DB),clandestineStatus(DB)]);
  const safeTotals=await DB.prepare(`SELECT COUNT(*) AS players,COALESCE(SUM(games_played),0) AS games,
    COALESCE(MAX(best_precision_bps),0) AS best FROM safe_loot_v8_scores WHERE best_precision_bps>0`).first();
  const safeBoard=await DB.prepare(`SELECT s.player_id,s.best_precision_bps AS score,s.games_played,p.name,p.avatar
    FROM safe_loot_v8_scores s JOIN players p ON p.id=s.player_id WHERE p.attendance='yes' AND s.best_precision_bps>0
    ORDER BY s.best_precision_bps DESC,s.best_worst_bps DESC,s.best_perfects DESC,s.achieved_at ASC,p.crew_number ASC LIMIT 3`).all();
  const safe={phase:Date.now()<SAFE_CONTEST.closesAtMs?'open':'closed',players:Math.max(0,Number(safeTotals?.players||0)),games:Math.max(0,Number(safeTotals?.games||0)),best:Math.max(0,Number(safeTotals?.best||0)),leaderboard:(safeBoard.results||[]).map((r,i)=>({rank:i+1,playerId:r.player_id,name:r.name,avatar:r.avatar||'🔐',score:Number(r.score)||0,gamesPlayed:Number(r.games_played)||0}))};
  return{championship,fuga,safe,caja:safe,blind:{...blind,leaderboard:blind.leaderboard.slice(0,3)},infiltration:{...infiltration,leaderboard:infiltration.leaderboard.slice(0,3)}};
}

function pointBlindRunBeats(existing,totalErrorMs,worstErrorMs,bestSingleErrorMs) {
  if (!existing) return true;
  const oldTotal=Math.max(0,Number(existing.best_total_error_ms ?? existing.score ?? 999999)),oldWorst=Math.max(0,Number(existing.best_worst_error_ms ?? existing.worstErrorMs ?? 999999)),oldBest=Math.max(0,Number(existing.best_single_error_ms ?? existing.bestSingleErrorMs ?? 999999));
  const nextTotal=Math.max(0,Number(totalErrorMs||0)),nextWorst=Math.max(0,Number(worstErrorMs||0)),nextBest=Math.max(0,Number(bestSingleErrorMs||0));
  if(nextTotal!==oldTotal)return nextTotal<oldTotal;
  if(nextWorst!==oldWorst)return nextWorst<oldWorst;
  return nextBest<oldBest;
}

async function pointBlindAwards(DB) {
  const result=await DB.prepare(`SELECT a.contest_id,a.rank,a.player_id,a.winning_total_error_ms,a.winning_worst_error_ms,a.winning_best_single_error_ms,a.cash_reward,a.respect_reward,a.awarded_at,
      p.name,p.avatar,p.photo_data,p.updated_at FROM pointblind_v1_podium_awards a LEFT JOIN players p ON p.id=a.player_id
      WHERE a.contest_id=? ORDER BY a.rank ASC`).bind(POINTBLIND_CONTEST.id).all();
  return (result.results||[]).map(row=>({rank:Math.max(1,Number(row.rank||1)),playerId:row.player_id,name:row.name||'PLAYER',avatar:row.avatar||'🕶️',photoUrl:playerPhotoUrl(row),score:Math.max(0,Number(row.winning_total_error_ms||0)),worstErrorMs:Math.max(0,Number(row.winning_worst_error_ms||0)),bestSingleErrorMs:Math.max(0,Number(row.winning_best_single_error_ms||0)),cash:Math.max(0,Number(row.cash_reward||0)),respect:Math.max(0,Number(row.respect_reward||0)),awardedAt:row.awarded_at}));
}

async function settlePointBlindContest(DB,nowMs=Date.now()) {
  const existing=await pointBlindAwards(DB);if(!Number.isFinite(POINTBLIND_CONTEST.closesAtMs)||nowMs<POINTBLIND_CONTEST.closesAtMs)return existing;
  const result=await DB.prepare(`SELECT s.player_id,s.best_total_error_ms,s.best_worst_error_ms,s.best_single_error_ms,s.achieved_at,p.name,p.avatar
    FROM pointblind_v1_scores s JOIN players p ON p.id=s.player_id WHERE p.attendance='yes'
    ORDER BY s.best_total_error_ms ASC,s.best_worst_error_ms ASC,s.best_single_error_ms ASC,s.achieved_at ASC,p.crew_number ASC LIMIT 3`).all();
  const podium=result.results||[];
  for(let index=0;index<podium.length;index+=1){const leader=podium[index],reward=POINTBLIND_CONTEST.rewards[index];if(!reward)continue;
    const inserted=await DB.prepare(`INSERT OR IGNORE INTO pointblind_v1_podium_awards
      (contest_id,rank,player_id,winning_total_error_ms,winning_worst_error_ms,winning_best_single_error_ms,cash_reward,respect_reward)
      VALUES(?,?,?,?,?,?,?,?)`).bind(POINTBLIND_CONTEST.id,reward.rank,leader.player_id,leader.best_total_error_ms,leader.best_worst_error_ms,leader.best_single_error_ms,reward.cash,reward.respect).run();
    if(Number(inserted?.meta?.changes||0)<=0)continue;
    await DB.prepare(`UPDATE players SET wallet_balance=wallet_balance+?,cash=cash+?,mission_respect=mission_respect+?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(reward.cash,reward.cash,reward.respect,leader.player_id).run();
    const balance=await DB.prepare('SELECT wallet_balance,mission_respect,game_stars FROM players WHERE id=? LIMIT 1').bind(leader.player_id).first();
    await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id,player_id,source_type,source_id,action_id,cash_delta,respect_delta,stars_delta,balance_after,mission_respect_after,game_stars_after,meta_json)
      VALUES(?,?,'arcade','PUNTOCIEGO30',?,?,?,0,?,?,?,?)`)
      .bind(`${leader.player_id}:arcade:PUNTOCIEGO30:v1:podium:${reward.rank}`,leader.player_id,`v1-podium-${reward.rank}`,reward.cash,reward.respect,
        Math.max(0,Number(balance?.wallet_balance||0)),Math.max(0,Number(balance?.mission_respect||0)),Math.max(0,Number(balance?.game_stars||0)),
        JSON.stringify({label:`PUNTO CIEGO 30 · PODIO #${reward.rank}`,rank:reward.rank,totalErrorMs:Number(leader.best_total_error_ms||0),cash:reward.cash,respect:reward.respect})).run();
  }
  return pointBlindAwards(DB);
}

async function pointBlindLeaderboard(DB,viewerId='') {
  const result=await DB.prepare(`SELECT s.player_id,s.best_total_error_ms,s.games_played,s.best_worst_error_ms,s.best_single_error_ms,s.achieved_at,
      p.crew_number,p.name,p.avatar,p.photo_data,p.updated_at FROM pointblind_v1_scores s JOIN players p ON p.id=s.player_id
      WHERE p.attendance='yes' ORDER BY s.best_total_error_ms ASC,s.best_worst_error_ms ASC,s.best_single_error_ms ASC,s.achieved_at ASC,p.crew_number ASC LIMIT 20`).all();
  return (result.results||[]).map((row,index)=>({rank:index+1,playerId:row.player_id,name:row.name,avatar:row.avatar||'🕶️',photoUrl:playerPhotoUrl(row),score:Math.max(0,Number(row.best_total_error_ms||0)),worstErrorMs:Math.max(0,Number(row.best_worst_error_ms||0)),bestSingleErrorMs:Math.max(0,Number(row.best_single_error_ms||0)),gamesPlayed:Math.max(0,Number(row.games_played||0)),achievedAt:row.achieved_at,isViewer:Boolean(viewerId&&viewerId===row.player_id),prize:POINTBLIND_CONTEST.rewards[index]?{...POINTBLIND_CONTEST.rewards[index]}:null}));
}

async function adminPointBlindStatus(DB) {
  const awards=await settlePointBlindContest(DB),leaderboard=await pointBlindLeaderboard(DB);
  const totals=await DB.prepare(`SELECT COUNT(*) AS players,COALESCE(SUM(games_played),0) AS games,MIN(best_total_error_ms) AS best FROM pointblind_v1_scores`).first();
  return{phase:Date.now()<POINTBLIND_CONTEST.closesAtMs?'open':'closed',closesAt:POINTBLIND_CONTEST.closesAt,rewards:POINTBLIND_CONTEST.rewards.map(item=>({...item})),awards,leaderboard,players:Math.max(0,Number(totals?.players||0)),games:Math.max(0,Number(totals?.games||0)),best:totals?.best==null?null:Math.max(0,Number(totals.best))};
}

async function safeAwards(DB) {
  const result = await DB.prepare(`SELECT a.contest_id, a.rank, a.player_id, a.winning_precision_bps,
      a.winning_worst_bps, a.winning_perfects, a.winning_duration_ms, a.cash_reward, a.respect_reward, a.awarded_at,
      p.name, p.avatar, p.photo_data, p.updated_at
    FROM safe_loot_v8_podium_awards a LEFT JOIN players p ON p.id = a.player_id
    WHERE a.contest_id = ? ORDER BY a.rank ASC`).bind(SAFE_CONTEST.id).all();
  return (result.results || []).map((row) => ({
    rank:Math.max(1, Number(row.rank || 1)), playerId:row.player_id, name:row.name || 'PLAYER', avatar:row.avatar || '🔐', photoUrl:playerPhotoUrl(row),
    score:Math.max(0, Number(row.winning_precision_bps || 0)), worstBps:Math.max(0, Number(row.winning_worst_bps || 0)), perfects:Math.max(0, Number(row.winning_perfects || 0)), durationMs:Math.max(0, Number(row.winning_duration_ms || 0)),
    cash:Math.max(0, Number(row.cash_reward || 0)), respect:Math.max(0, Number(row.respect_reward || 0)), awardedAt:row.awarded_at
  }));
}

async function settleSafeContest(DB, nowMs = Date.now()) {
  const existing = await safeAwards(DB);
  if (!Number.isFinite(SAFE_CONTEST.closesAtMs) || nowMs < SAFE_CONTEST.closesAtMs) return existing;
  const result = await DB.prepare(`SELECT s.player_id, s.best_precision_bps, s.best_worst_bps, s.best_perfects, s.best_duration_ms, s.achieved_at, p.name, p.avatar
    FROM safe_loot_v8_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.best_precision_bps > 0
    ORDER BY s.best_precision_bps DESC, s.best_worst_bps DESC, s.best_perfects DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 3`).all();
  const podium = result.results || [];
  for (let index = 0; index < podium.length; index += 1) {
    const leader = podium[index], reward = SAFE_CONTEST.rewards[index]; if (!reward) continue;
    const inserted = await DB.prepare(`INSERT OR IGNORE INTO safe_loot_v8_podium_awards
      (contest_id, rank, player_id, winning_precision_bps, winning_worst_bps, winning_perfects, winning_duration_ms, cash_reward, respect_reward)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(SAFE_CONTEST.id, reward.rank, leader.player_id, leader.best_precision_bps, leader.best_worst_bps, leader.best_perfects, leader.best_duration_ms, reward.cash, reward.respect).run();
    if (Number(inserted?.meta?.changes || 0) <= 0) continue;
    await DB.prepare(`UPDATE players SET wallet_balance = wallet_balance + ?, cash = cash + ?, mission_respect = mission_respect + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(reward.cash, reward.cash, reward.respect, leader.player_id).run();
    const balance = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars FROM players WHERE id = ? LIMIT 1').bind(leader.player_id).first();
    await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta, balance_after, mission_respect_after, game_stars_after, meta_json)
      VALUES (?, ?, 'arcade', 'SAQUEO30', ?, ?, ?, 0, ?, ?, ?, ?)`)
      .bind(`${leader.player_id}:arcade:SAQUEO30:precision-v9-podium:${reward.rank}`, leader.player_id, `precision-v9-podium-${reward.rank}`, reward.cash, reward.respect,
        Math.max(0, Number(balance?.wallet_balance || 0)), Math.max(0, Number(balance?.mission_respect || 0)), Math.max(0, Number(balance?.game_stars || 0)),
        JSON.stringify({ label:`BOTÍN 30 · PODIO #${reward.rank}`, rank:reward.rank, precisionBps:Number(leader.best_precision_bps || 0), cash:reward.cash, respect:reward.respect })).run();
  }
  return safeAwards(DB);
}

async function safeLeaderboard(DB, viewerId = '') {
  const result = await DB.prepare(`SELECT s.player_id, s.best_precision_bps, s.games_played, s.best_worst_bps, s.best_perfects, s.best_duration_ms, s.achieved_at,
      p.crew_number, p.name, p.avatar, p.photo_data, p.updated_at
    FROM safe_loot_v8_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.best_precision_bps > 0
    ORDER BY s.best_precision_bps DESC, s.best_worst_bps DESC, s.best_perfects DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 20`).all();
  return (result.results || []).map((row, index) => ({
    rank:index + 1, playerId:row.player_id, name:row.name, avatar:row.avatar || '🔐', photoUrl:playerPhotoUrl(row),
    score:Math.max(0, Number(row.best_precision_bps || 0)), worstBps:Math.max(0, Number(row.best_worst_bps || 0)), perfects:Math.max(0, Number(row.best_perfects || 0)), durationMs:Math.max(0, Number(row.best_duration_ms || 0)),
    gamesPlayed:Math.max(0, Number(row.games_played || 0)), achievedAt:row.achieved_at, isViewer:Boolean(viewerId && viewerId === row.player_id), prize:SAFE_CONTEST.rewards[index] ? { ...SAFE_CONTEST.rewards[index] } : null
  }));
}

async function infiltrationAwards(DB) {
  const result = await DB.prepare(`SELECT a.contest_id, a.rank, a.player_id, a.winning_score,
      a.cash_reward, a.respect_reward, a.awarded_at,
      p.name, p.avatar, p.photo_data, p.updated_at
    FROM operation_infiltration_v6_podium_awards a LEFT JOIN players p ON p.id = a.player_id
    WHERE a.contest_id = ? ORDER BY a.rank ASC`).bind(INFILTRATION_CONTEST.id).all();
  return (result.results || []).map((row) => ({
    rank:Math.max(1, Number(row.rank || 1)),
    playerId:row.player_id,
    name:row.name || 'PLAYER',
    avatar:row.avatar || '🕶️',
    photoUrl:playerPhotoUrl(row),
    score:Math.max(0, Number(row.winning_score || 0)),
    cash:Math.max(0, Number(row.cash_reward || 0)),
    respect:Math.max(0, Number(row.respect_reward || 0)),
    awardedAt:row.awarded_at
  }));
}

async function settleInfiltrationContest(DB, nowMs = Date.now()) {
  const existing = await infiltrationAwards(DB);
  if (!Number.isFinite(INFILTRATION_CONTEST.closesAtMs) || nowMs < INFILTRATION_CONTEST.closesAtMs) return existing;
  const result = await DB.prepare(`SELECT s.player_id, s.high_score, s.achieved_at, p.name, p.avatar
    FROM operation_infiltration_v6_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.high_score > 0
    ORDER BY s.high_score DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 3`).all();
  const podium = result.results || [];
  for (let index = 0; index < podium.length; index += 1) {
    const leader = podium[index];
    const reward = INFILTRATION_CONTEST.rewards[index];
    if (!reward) continue;
    const inserted = await DB.prepare(`INSERT OR IGNORE INTO operation_infiltration_v6_podium_awards
      (contest_id, rank, player_id, winning_score, cash_reward, respect_reward)
      VALUES (?, ?, ?, ?, ?, ?)`).bind(
        INFILTRATION_CONTEST.id, reward.rank, leader.player_id, leader.high_score, reward.cash, reward.respect
      ).run();
    if (Number(inserted?.meta?.changes || 0) <= 0) continue;
    await DB.prepare(`UPDATE players SET wallet_balance = wallet_balance + ?, cash = cash + ?,
      mission_respect = mission_respect + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .bind(reward.cash, reward.cash, reward.respect, leader.player_id).run();
    const balance = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars FROM players WHERE id = ? LIMIT 1').bind(leader.player_id).first();
    await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta,
       balance_after, mission_respect_after, game_stars_after, meta_json)
      VALUES (?, ?, 'arcade', 'INFILTRACION30', ?, ?, ?, 0, ?, ?, ?, ?)`)
      .bind(`${leader.player_id}:arcade:INFILTRACION30:podium:${reward.rank}`, leader.player_id, `podium-${reward.rank}`,
        reward.cash, reward.respect, Math.max(0, Number(balance?.wallet_balance || 0)),
        Math.max(0, Number(balance?.mission_respect || 0)), Math.max(0, Number(balance?.game_stars || 0)),
        JSON.stringify({ label:`BRECHA 30 · PODIO #${reward.rank}`, rank:reward.rank, score:Number(leader.high_score || 0), cash:reward.cash, respect:reward.respect })).run();
  }
  return infiltrationAwards(DB);
}

async function infiltrationLeaderboard(DB, viewerId = '') {
  const result = await DB.prepare(`SELECT s.player_id, s.high_score, s.games_played, s.best_rounds_completed, s.best_failed_round, s.achieved_at,
      p.crew_number, p.name, p.avatar, p.photo_data, p.updated_at
    FROM operation_infiltration_v6_scores s JOIN players p ON p.id = s.player_id
    WHERE p.attendance = 'yes' AND s.high_score > 0
    ORDER BY s.high_score DESC, s.achieved_at ASC, p.crew_number ASC LIMIT 20`).all();
  return (result.results || []).map((row, index) => {
    const zone = INFILTRATION_ENGINE.zoneFor(Math.max(1, Number(row.best_failed_round || 1)));
    return {
      rank:index + 1,
      playerId:row.player_id,
      name:row.name,
      avatar:row.avatar || '🕶️',
      photoUrl:playerPhotoUrl(row),
      score:Math.max(0, Number(row.high_score || 0)),
      roundsCompleted:Math.max(0, Number(row.best_rounds_completed || 0)),
      failedRound:Math.max(1, Number(row.best_failed_round || 1)),
      zone:zone.name,
      depth:Math.max(0, Number(zone.depth || 0)),
      gamesPlayed:Math.max(0, Number(row.games_played || 0)),
      achievedAt:row.achieved_at,
      isViewer:Boolean(viewerId && viewerId === row.player_id),
      prize:INFILTRATION_CONTEST.rewards[index] ? { ...INFILTRATION_CONTEST.rewards[index] } : null
    };
  });
}

async function adminInfiltrationStatus(DB) {
  const awards = await settleInfiltrationContest(DB);
  const leaderboard = await infiltrationLeaderboard(DB);
  const totals = await DB.prepare(`SELECT COUNT(*) AS players, COALESCE(SUM(games_played),0) AS games,
    COALESCE(MAX(high_score),0) AS best FROM operation_infiltration_v6_scores WHERE high_score > 0`).first();
  return {
    phase:Date.now() < INFILTRATION_CONTEST.closesAtMs ? 'open' : 'closed',
    closesAt:INFILTRATION_CONTEST.closesAt,
    rewards:INFILTRATION_CONTEST.rewards.map((item) => ({ ...item })),
    awards,
    leaderboard,
    players:Math.max(0, Number(totals?.players || 0)),
    games:Math.max(0, Number(totals?.games || 0)),
    best:Math.max(0, Number(totals?.best || 0))
  };
}

function safeJsonArray(value, length = 5, min = 0, max = 10000) {
  try {
    const parsed = JSON.parse(String(value || '[]'));
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, length).map((item) => Math.max(min, Math.min(max, Math.round(Number(item) || 0))));
  } catch { return []; }
}

function safeRunBeats(existing, precisionBps, worstBps, perfects, durationMs) {
  if (!existing) return true;
  const oldPrecision=Math.max(0,Number(existing.best_precision_bps ?? existing.score ?? 0)),oldWorst=Math.max(0,Number(existing.best_worst_bps ?? existing.worstBps ?? 0));
  const oldPerfects=Math.max(0,Number(existing.best_perfects ?? existing.perfects ?? 0));
  const nextPrecision=Math.max(0,Number(precisionBps||0)),nextWorst=Math.max(0,Number(worstBps||0)),nextPerfects=Math.max(0,Number(perfects||0));
  if(nextPrecision!==oldPrecision)return nextPrecision>oldPrecision;
  if(nextWorst!==oldWorst)return nextWorst>oldWorst;
  if(nextPerfects!==oldPerfects)return nextPerfects>oldPerfects;
  return false;
}

async function clearApplicationData(DB) {
  await clearAdminGameData(DB);
  await DB.batch([
    DB.prepare('DELETE FROM clandestine_championship_awards'),
    DB.prepare('DELETE FROM pointblind_v1_podium_awards'),
    DB.prepare('DELETE FROM pointblind_v1_runs'),
    DB.prepare('DELETE FROM pointblind_v1_scores'),
    DB.prepare('DELETE FROM operation_infiltration_v6_podium_awards'),
    DB.prepare('DELETE FROM operation_infiltration_v6_runs'),
    DB.prepare('DELETE FROM operation_infiltration_v6_scores'),
    DB.prepare('DELETE FROM safe_loot_v8_podium_awards'),
    DB.prepare('DELETE FROM safe_loot_v8_runs'),
    DB.prepare('DELETE FROM safe_loot_v8_scores'),
    DB.prepare('DELETE FROM safe_loot_v7_podium_awards'),
    DB.prepare('DELETE FROM safe_loot_v7_runs'),
    DB.prepare('DELETE FROM safe_loot_v7_scores'),
    DB.prepare('DELETE FROM safe_loot_v6_podium_awards'),
    DB.prepare('DELETE FROM safe_loot_v6_runs'),
    DB.prepare('DELETE FROM safe_loot_v6_scores'),
    DB.prepare('DELETE FROM safe_loot_v5_podium_awards'),
    DB.prepare('DELETE FROM safe_loot_v5_runs'),
    DB.prepare('DELETE FROM safe_loot_v5_scores'),
    DB.prepare('DELETE FROM safe_sequence_podium_awards'),
    DB.prepare('DELETE FROM safe_sequence_runs'),
    DB.prepare('DELETE FROM safe_sequence_scores'),
    DB.prepare('DELETE FROM safe_skill_podium_awards'),
    DB.prepare('DELETE FROM safe_skill_runs'),
    DB.prepare('DELETE FROM safe_skill_scores'),
    DB.prepare('DELETE FROM crossing_v11_podium_awards'),
    DB.prepare('DELETE FROM crossing_v11_awards'),
    DB.prepare('DELETE FROM crossing_v11_runs'),
    DB.prepare('DELETE FROM crossing_v11_scores'),
    DB.prepare('DELETE FROM crossing_v7_podium_awards'),
    DB.prepare('DELETE FROM crossing_v7_awards'),
    DB.prepare('DELETE FROM crossing_v7_runs'),
    DB.prepare('DELETE FROM crossing_v7_scores'),
    DB.prepare('DELETE FROM crossing_v5_podium_awards'),
    DB.prepare('DELETE FROM crossing_v5_awards'),
    DB.prepare('DELETE FROM crossing_v5_runs'),
    DB.prepare('DELETE FROM crossing_v5_scores'),
    DB.prepare('DELETE FROM economy_events'),
    DB.prepare('DELETE FROM player_respect'),
    DB.prepare('DELETE FROM player_sessions'),
    DB.prepare('DELETE FROM players')
  ]);
  try { await DB.prepare("DELETE FROM sqlite_sequence WHERE name = 'players'").run(); } catch {}
}

const ADMIN_GAME_TABLES = Object.freeze([
  'arcade_podium_awards','arcade_awards','arcade_runs','arcade_scores',
  'clandestine_championship_awards','pointblind_v1_podium_awards','pointblind_v1_runs','pointblind_v1_scores',
  'safe_skill_podium_awards','safe_skill_runs','safe_skill_scores','safe_sequence_podium_awards','safe_sequence_runs','safe_sequence_scores','safe_precision_podium_awards','safe_precision_runs','safe_precision_scores',
  'safe_loot_v5_podium_awards','safe_loot_v5_runs','safe_loot_v5_scores','safe_loot_v6_podium_awards','safe_loot_v6_runs','safe_loot_v6_scores','safe_loot_v7_podium_awards','safe_loot_v7_runs','safe_loot_v7_scores','safe_loot_v8_podium_awards','safe_loot_v8_runs','safe_loot_v8_scores',
  'operation_infiltration_podium_awards','operation_infiltration_runs','operation_infiltration_scores','operation_infiltration_v6_podium_awards','operation_infiltration_v6_runs','operation_infiltration_v6_scores',
  'crossing_v3_podium_awards','crossing_v3_awards','crossing_v3_runs','crossing_v3_scores','crossing_v4_podium_awards','crossing_v4_awards','crossing_v4_runs','crossing_v4_scores',
  'crossing_v5_podium_awards','crossing_v5_awards','crossing_v5_runs','crossing_v5_scores','crossing_v6_podium_awards','crossing_v6_awards','crossing_v6_runs','crossing_v6_scores',
  'crossing_v7_podium_awards','crossing_v7_awards','crossing_v7_runs','crossing_v7_scores','crossing_v8_podium_awards','crossing_v8_awards','crossing_v8_runs','crossing_v8_scores',
  'crossing_v9_podium_awards','crossing_v9_awards','crossing_v9_runs','crossing_v9_scores','crossing_v10_podium_awards','crossing_v10_awards','crossing_v10_runs','crossing_v10_scores',
  'crossing_v11_podium_awards','crossing_v11_awards','crossing_v11_runs','crossing_v11_scores'
]);

async function clearAdminGameData(DB){
  const existing=await DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  const names=new Set((existing.results||[]).map(row=>String(row.name||'')));
  const statements=ADMIN_GAME_TABLES.filter(name=>names.has(name)).map(name=>DB.prepare(`DELETE FROM ${name}`));
  if(statements.length)await DB.batch(statements);
}

async function resetAdminGuestProgress(DB){
  await clearAdminGameData(DB);
  await DB.batch([
    DB.prepare('DELETE FROM economy_events'), DB.prepare('DELETE FROM player_respect'),
    DB.prepare(`UPDATE players SET location_unlocked=0, completed_missions_json='[]', discovered_missions_json='[]', wanted_level=0, wanted_score=0, game_stars=0,
      cash=0, wallet_balance=0, cash_collected_count=0, mission_respect=0, record_clean_count=0, updated_at=CURRENT_TIMESTAMP`)
  ]);
}

async function clearAdminActivity(DB){
  await DB.batch([DB.prepare('DELETE FROM admin_activity'),DB.prepare('DELETE FROM admin_notification_log')]);
}

async function prepareAdminProduction(DB){
  await clearApplicationData(DB);
  await clearAdminActivity(DB);
}

const ADMIN_TEST_PLAYERS = [
  { name:'Alex', avatar:'🕶️', dietary:'', stars:4, cash:700, bills:5, location:1, completed:['STAR30','CAR30'], discovered:['STAR30','CAR30','SAVE30'], respect:2, specialties:['Informática','Gaming'] },
  { name:'Andrea', avatar:'🌴', dietary:'Intolerancia a la lactosa', stars:1, cash:1200, bills:2, location:1, completed:['SAVE30'], discovered:['SAVE30','CAR30'], respect:4, specialties:['Nutrición','Viajes'] },
  { name:'Carlos', avatar:'🚗', dietary:'Alergia a frutos secos', stars:6, cash:300, bills:5, location:1, completed:['STAR30','CAR30','SAVE30'], discovered:['STAR30','CAR30','SAVE30'], respect:1, specialties:['Mecánica','Coches'] },
  { name:'Claudia', avatar:'✨', dietary:'Vegetariana', stars:0, cash:900, bills:4, location:1, completed:['STAR30','CAR30','SAVE30'], discovered:['STAR30','CAR30','SAVE30'], respect:5, specialties:['Diseño','Fotografía'] },
  { name:'David', avatar:'🏋️', dietary:'', stars:3, cash:500, bills:1, location:1, completed:['STAR30'], discovered:['STAR30','CAR30'], respect:0, specialties:['CrossFit','Deporte'] },
  { name:'Elena', avatar:'🌸', dietary:'Sin gluten', stars:2, cash:650, bills:3, location:1, completed:['CAR30'], discovered:['CAR30','SAVE30'], respect:3, specialties:['Educación','Música'] },
  { name:'Fran', avatar:'🎧', dietary:'', stars:5, cash:200, bills:5, location:1, completed:['STAR30','CAR30'], discovered:['STAR30','CAR30'], respect:2, specialties:['Música','Fiesta'] },
  { name:'Irene', avatar:'🦩', dietary:'No marisco', stars:1, cash:800, bills:0, location:1, completed:[], discovered:['SAVE30'], respect:1, specialties:['Sanidad','Viajes'] },
  { name:'Javi', avatar:'🛹', dietary:'', stars:7, cash:100, bills:5, location:1, completed:['STAR30'], discovered:['STAR30','CAR30','SAVE30'], respect:0, specialties:['Deporte','Gaming'] },
  { name:'Laura', avatar:'💖', dietary:'Alergia al kiwi', stars:0, cash:1400, bills:5, location:1, completed:['STAR30','CAR30','SAVE30'], discovered:['STAR30','CAR30','SAVE30'], respect:6, specialties:['Contabilidad','Viajes'] },
  { name:'Lucía', avatar:'🪩', dietary:'Vegana', stars:2, cash:450, bills:2, location:1, completed:['SAVE30'], discovered:['SAVE30'], respect:2, specialties:['Fiesta','Diseño'] },
  { name:'Marta', avatar:'🎀', dietary:'', stars:3, cash:600, bills:4, location:1, completed:['CAR30'], discovered:['STAR30','CAR30'], respect:3, specialties:['Educación','Fallera'] },
  { name:'Miguel', avatar:'🏎️', dietary:'', stars:8, cash:50, bills:5, location:1, completed:['STAR30','CAR30'], discovered:['STAR30','CAR30','SAVE30'], respect:1, specialties:['Coches','Informática'] },
  { name:'Nerea', avatar:'🌺', dietary:'Intolerancia a la lactosa', stars:1, cash:1050, bills:3, location:1, completed:['SAVE30'], discovered:['SAVE30','STAR30'], respect:5, specialties:['Sanidad','Nutrición'] },
  { name:'Pablo', avatar:'🎮', dietary:'', stars:4, cash:350, bills:1, location:0, completed:[], discovered:['STAR30'], respect:0, specialties:['Gaming','Informática'] },
  { name:'Raquel', avatar:'🍒', dietary:'Celíaca · sin gluten', stars:0, cash:1100, bills:5, location:1, completed:['STAR30','CAR30','SAVE30'], discovered:['STAR30','CAR30','SAVE30'], respect:4, specialties:['Nutrición','Fotografía'] },
  { name:'Sergio', avatar:'⚡', dietary:'', stars:2, cash:750, bills:0, location:0, completed:[], discovered:[], respect:1, specialties:['CrossFit','Mecánica'] },
  { name:'Álvaro', avatar:'🛫', attendance:'no', dietary:'', decline:'No puedo ir, pero quiero fotos del golpe 😭', specialties:['Viajes'] },
  { name:'Bea', avatar:'🌙', attendance:'no', dietary:'', decline:'Me coincide con otro compromiso. Pasadlo increíble ❤️', specialties:['Diseño'] },
  { name:'Marcos', avatar:'🧢', attendance:'no', dietary:'', decline:'Esta vez me toca perderme la misión. A la próxima estoy dentro.', specialties:['Deporte'] }
];

async function seedAdminTestData(DB) {
  await clearApplicationData(DB);
  const statements = [];
  for (let index = 0; index < ADMIN_TEST_PLAYERS.length; index += 1) {
    const item = ADMIN_TEST_PLAYERS[index];
    const attendance = item.attendance === 'no' ? 'no' : 'yes';
    let pinSalt = null;
    let pinHash = null;
    if (attendance === 'yes') {
      pinSalt = randomHex(16);
      pinHash = await hashPin('1234', pinSalt);
    }
    const sessionHash = await sha256(`admin-test-${index}-${randomHex(12)}`);
    const stars = Math.max(0, Number(item.stars || 0));
    const cash = Math.max(0, Number(item.cash || 0));
    const bills = Math.max(0, Math.min(5, Number(item.bills || 0)));
    const completed = Array.isArray(item.completed) ? item.completed : [];
    const discovered = Array.isArray(item.discovered) ? item.discovered : completed;
    statements.push(DB.prepare(`INSERT INTO players
      (id, name, attendance, dietary, decline_message, avatar, bio, specialties_json, special_ability,
       pin_hash, pin_salt, session_hash, location_unlocked, briefing_completed,
       completed_missions_json, discovered_missions_json, wanted_level, wanted_score, game_stars,
       cash, wallet_balance, cash_collected_count, mission_respect, record_clean_count)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(
        `admin-test-${String(index + 1).padStart(2,'0')}`, item.name, attendance, item.dietary || '', item.decline || '', item.avatar || '🎮',
        attendance === 'yes' ? 'Perfil de prueba para Operación 30.' : '', JSON.stringify((item.specialties || []).map((label, specialtyIndex) => ({ key:`test-${specialtyIndex + 1}`, label, emoji:'•' }))), '',
        pinHash, pinSalt, sessionHash, item.location ? 1 : 0, attendance === 'yes' ? 1 : 0,
        JSON.stringify(completed), JSON.stringify(discovered), bills >= 5 ? 5 : bills, stars, stars,
        cash, cash, bills, Math.max(0, Number(item.respect || 0)), 0
      ));
  }
  if (statements.length) await DB.batch(statements);
  const arcadeStatements = ADMIN_TEST_PLAYERS.map((item, index) => {
    if (item.attendance === 'no') return null;
    const playerId = `admin-test-${String(index + 1).padStart(2,'0')}`;
    const score = 15 + ((index * 17) % 130);
    return DB.prepare(`INSERT INTO crossing_v11_scores (player_id, high_score, games_played, last_score, achieved_at)
      VALUES (?, ?, ?, ?, datetime('now', ?))`)
      .bind(playerId, score, 1 + (index % 9), score, `-${18 - index} minutes`);
  }).filter(Boolean);
  if (arcadeStatements.length) await DB.batch(arcadeStatements);

  const safeStatements = ADMIN_TEST_PLAYERS.map((item, index) => {
    if (item.attendance === 'no') return null;
    const playerId = `admin-test-${String(index + 1).padStart(2,'0')}`;
    const precision = Math.min(9950, 7050 + ((index * 191) % 2850));
    const worst = Math.max(0, precision - (350 + ((index * 79) % 900)));
    const perfects = Math.max(0, Math.min(5, Math.floor((precision - 7000) / 600)));
    const duration = 6500 + ((index * 227) % 4200);
    return DB.prepare(`INSERT INTO safe_loot_v8_scores
      (player_id,best_precision_bps,games_played,last_precision_bps,best_worst_bps,best_perfects,best_duration_ms,achieved_at)
      VALUES (?,?,?,?,?,?,?,datetime('now', ?))`)
      .bind(playerId,precision,1+(index%6),precision,worst,perfects,duration,`-${32-index} minutes`);
  }).filter(Boolean);
  if (safeStatements.length) await DB.batch(safeStatements);

  const blindStatements = ADMIN_TEST_PLAYERS.map((item,index)=>{
    if(item.attendance==='no')return null;
    const playerId=`admin-test-${String(index+1).padStart(2,'0')}`;
    const total=70+((index*137)%1150),worst=Math.max(18,Math.round(total*.54)),best=Math.max(4,Math.round(total*.12));
    return DB.prepare(`INSERT INTO pointblind_v1_scores
      (player_id,best_total_error_ms,games_played,last_total_error_ms,best_worst_error_ms,best_single_error_ms,achieved_at)
      VALUES(?,?,?,?,?,?,datetime('now', ?))`)
      .bind(playerId,total,1+(index%7),total,worst,best,`-${26-index} minutes`);
  }).filter(Boolean);
  if(blindStatements.length)await DB.batch(blindStatements);

  const infiltrationScoreStatements = [];
  const infiltrationRunStatements = [];
  ADMIN_TEST_PLAYERS.forEach((item,index)=>{
    if(item.attendance==='no')return;
    const playerId=`admin-test-${String(index+1).padStart(2,'0')}`;
    const score=8+((index*7)%58),rounds=Math.max(1,Math.floor(score/6)),failedRound=rounds+1,games=1+(index%5);
    const achievedAt=new Date(Date.now()-index*45000).toISOString();
    infiltrationScoreStatements.push(DB.prepare(`INSERT INTO operation_infiltration_v6_scores
      (player_id,high_score,games_played,last_score,best_rounds_completed,best_failed_round,achieved_at)
      VALUES(?,?,?,?,?,?,?)`).bind(playerId,score,games,score,rounds,failedRound,achievedAt));
    const result={score,roundsCompleted:rounds,failedRound,failedStep:2,gameOver:true,freePlay:false};
    infiltrationRunStatements.push(DB.prepare(`INSERT INTO operation_infiltration_v6_runs
      (run_id,player_id,started_at_ms,finished_at,score,rounds_completed,failed_round,result_json,event_log_json)
      VALUES(?,?,?,?,?,?,?,?,?)`).bind(`admin-infiltration-${String(index+1).padStart(2,'0')}`,playerId,Date.now()-((index+1)*60000),achievedAt,score,rounds,failedRound,JSON.stringify(result),'[]'));
  });
  if(infiltrationScoreStatements.length)await DB.batch(infiltrationScoreStatements);
  if(infiltrationRunStatements.length)await DB.batch(infiltrationRunStatements);
}

async function readAdminPlayers(DB) {
  const result = await DB.prepare(`SELECT id, crew_number, name, attendance, dietary, avatar, photo_data, bio, specialties_json, special_ability, wanted_score, game_stars, wallet_balance, mission_respect,
    location_unlocked, briefing_completed, completed_missions_json, discovered_missions_json, wanted_level, cash, cash_collected_count, decline_message, updated_at
    FROM players ORDER BY crew_number ASC`).all();
  return (result.results || []).map((row) => ({
    ...privatePlayer(row),
    wantedScore: Number(row.wanted_score || 0),
    declineMessage: row.decline_message || '',
    updatedAt: row.updated_at
  }));
}

async function handleApi(request, env) {
  if (!env.DB) {
    return json({ error: 'DB_NOT_CONFIGURED', message: 'Falta enlazar una base D1 con el nombre DB.' }, 503);
  }

  await ensureSchema(env.DB);
  const DB = env.DB;
  const url = new URL(request.url);
  const parts = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const route = parts.join('/');
  const method = request.method.toUpperCase();

  if (route === 'health' && method === 'GET') {
    return json({ ok: true, database: true });
  }

  if (parts[0] === 'player-photo' && parts[1] && method === 'GET') {
    const playerId = decodeURIComponent(parts[1]);
    const row = await DB.prepare(`SELECT photo_data, updated_at FROM players WHERE id = ? AND attendance = 'yes' LIMIT 1`).bind(playerId).first();
    const match = String(row?.photo_data || '').match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/i);
    if (!match) return new Response(null, { status:404, headers:{ 'cache-control':'no-store' } });
    let bytes;
    try {
      const binary = atob(match[2]);
      bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
    } catch {
      return new Response(null, { status:404, headers:{ 'cache-control':'no-store' } });
    }
    return new Response(bytes, {
      status:200,
      headers:{
        'content-type':match[1].toLowerCase(),
        'cache-control':'public, max-age=31536000, immutable',
        'x-content-type-options':'nosniff'
      }
    });
  }

  if (route === 'rsvp' && method === 'POST') {
    const body = await requestBody(request);
    const name = cleanString(body.name, 40);
    const attendance = body.attendance === 'no' ? 'no' : 'yes';
    const dietary = cleanString(body.dietary, 120);
    const pin = cleanString(body.pin, 4);
    const briefingCompleted = body.briefingCompleted !== false;

    if (!name) return json({ error: 'NAME_REQUIRED', message: 'Introduce tu nombre.' }, 400);
    if (attendance === 'yes' && !/^\d{4}$/.test(pin)) {
      return json({ error: 'PIN_REQUIRED', message: 'Elige un PIN de 4 cifras.' }, 400);
    }

    // A random client retry key makes an uncertain RSVP submission idempotent.
    const retryKey = request.headers.get('x-rsvp-key') || '';
    const sessionToken = /^[a-f0-9]{48}$/.test(retryKey) ? retryKey : randomHex(24);
    const sessionHash = await sha256(sessionToken);
    const id = /^[a-f0-9]{48}$/.test(retryKey) ? `rsvp-${sessionHash.slice(0,32)}` : crypto.randomUUID();
    const existing = await DB.prepare('SELECT * FROM players WHERE id = ?').bind(id).first();
    if (existing) return json({ok:true, sessionToken, player:privatePlayer(existing)});
    let pinSalt = null;
    let pinHash = null;
    if (attendance === 'yes') {
      pinSalt = randomHex(16);
      pinHash = await hashPin(pin, pinSalt);
    }

    await DB.prepare(`INSERT OR IGNORE INTO players
      (id, name, attendance, dietary, pin_hash, pin_salt, session_hash, briefing_completed, decline_message)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, name, attendance, dietary, pinHash, pinSalt, sessionHash, briefingCompleted ? 1 : 0, cleanString(body.declineMessage, 500)).run();

    const row = await DB.prepare('SELECT * FROM players WHERE id = ?').bind(id).first();
    const declineMessage=cleanString(body.declineMessage,500);
    await recordAdminActivity(DB,env,{eventType:attendance==='yes'?'rsvp_confirmed':'rsvp_declined',category:attendance==='yes'?'rsvp':'decline',severity:attendance==='no'&&declineMessage?'attention':'info',actorId:id,actorName:name,
      title:attendance==='yes'?`${name} se ha apuntado`:`${name} no puede venir`,detail:attendance==='yes'?(dietary?`Confirmado · ${dietary}`:'Confirmado'):(declineMessage||'Ha indicado que no puede asistir'),meta:{attendance,dietary,hasMessage:Boolean(declineMessage)}});
    return json({ ok: true, sessionToken, player: privatePlayer(row) }, 201);
  }

  if (route === 'me' && method === 'GET') {
    await settleArcadeContest(DB);
    await settleSafeContest(DB);
    try { await settleInfiltrationContest(DB); } catch {}
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    return json({ ok: true, player: privatePlayer(row) });
  }


  if (route === 'me' && method === 'PATCH') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    const current = auth.player;
    const body = await requestBody(request);

    const fields = [];
    const values = [];
    const set = (column, value) => { fields.push(`${column} = ?`); values.push(value); };

    if (body.name !== undefined) {
      const name = cleanString(body.name, 40);
      if (!name) return json({ error: 'NAME_REQUIRED', message: 'Introduce tu nombre.' }, 400);
      set('name', name);
    }
    if (body.declineMessage !== undefined) set('decline_message', cleanString(body.declineMessage, 500));
    if (body.dietary !== undefined) set('dietary', cleanString(body.dietary, 120));
    if (body.avatar !== undefined) set('avatar', cleanString(body.avatar || '🎮', 16));
    if (body.photoData !== undefined) {
      const photoData = String(body.photoData || '');
      if (photoData && (!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(photoData) || photoData.length > 250000)) {
        return json({ error:'INVALID_PHOTO', message:'La foto no tiene un formato válido o es demasiado grande.' }, 400);
      }
      set('photo_data', photoData);
    }
    if (body.bio !== undefined) set('bio', cleanString(body.bio, 90));
    if (body.specialties !== undefined) set('specialties_json', JSON.stringify(normalizeSpecialties(body.specialties)));
    if (body.specialAbility !== undefined) set('special_ability', cleanString(body.specialAbility, 90));
    if (body.uiPrefs !== undefined) set('ui_prefs_json', JSON.stringify(normalizeUiPrefs(body.uiPrefs)));
    if (body.briefingCompleted !== undefined) set('briefing_completed', body.briefingCompleted ? 1 : 0);

    if (body.attendance !== undefined) {
      const attendance = body.attendance === 'no' ? 'no' : 'yes';
      if (attendance === 'yes' && !current.pin_hash) {
        const pin = cleanString(body.pin, 4);
        if (!/^\d{4}$/.test(pin)) return json({ error: 'PIN_REQUIRED', message: 'Elige un PIN de 4 cifras.' }, 400);
        const pinSalt = randomHex(16);
        const pinHash = await hashPin(pin, pinSalt);
        set('pin_hash', pinHash);
        set('pin_salt', pinSalt);
      }
      set('attendance', attendance);
      if (attendance === 'no') {
        set('location_unlocked', 0);
        set('completed_missions_json', '[]');
        set('discovered_missions_json', '[]');
      }
    }

    if (body.pin !== undefined && current.pin_hash && /^\d{4}$/.test(cleanString(body.pin, 4))) {
      const pinSalt = randomHex(16);
      const pinHash = await hashPin(cleanString(body.pin, 4), pinSalt);
      set('pin_hash', pinHash);
      set('pin_salt', pinSalt);
    }

    if (fields.length) {
      fields.push('updated_at = CURRENT_TIMESTAMP');
      values.push(current.id);
      await DB.prepare(`UPDATE players SET ${fields.join(', ')} WHERE id = ?`).bind(...values).run();
    }

    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(current.id).first();
    if(body.attendance!==undefined||body.declineMessage!==undefined||body.dietary!==undefined){
      const nextAttendance=String(row?.attendance||current.attendance||'yes'),decline=String(row?.decline_message||'').trim(),diet=String(row?.dietary||'').trim();
      await recordAdminActivity(DB,env,{eventType:'guest_updated',category:nextAttendance==='no'?'decline':'rsvp',severity:nextAttendance==='no'&&decline?'attention':'info',actorId:current.id,actorName:String(row?.name||current.name||''),
        title:nextAttendance==='no'?`${row?.name||current.name} actualizó su baja`:`${row?.name||current.name} actualizó su respuesta`,detail:nextAttendance==='no'?(decline||'No puede asistir'):(diet?`Confirmado · ${diet}`:'Respuesta actualizada'),meta:{attendance:nextAttendance,dietary:diet,hasMessage:Boolean(decline)}});
    }
    return json({ ok: true, player: privatePlayer(row) });
  }

  if (route === 'crew' && method === 'GET') {
    const viewer = await authenticatedPlayer(request, DB);
    const viewerId = viewer?.id || '';
    const result = await DB.prepare(`SELECT p.id, p.crew_number, p.name, p.avatar, p.photo_data, p.bio, p.specialties_json, p.special_ability, p.wanted_score, p.game_stars, p.wanted_level, p.cash, p.wallet_balance, p.mission_respect, p.completed_missions_json,
        p.briefing_completed, p.location_unlocked, p.ui_prefs_json, p.updated_at,
        (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count,
        (SELECT COUNT(*) FROM player_respect g WHERE g.giver_id = ? AND g.receiver_id = p.id) AS respected_by_viewer
      FROM players p WHERE p.attendance = 'yes' ORDER BY p.crew_number ASC`).bind(viewerId).all();
    const rows = result.results || [];
    if (viewer?.attendance !== 'yes') {
      return json({ ok:true, players:rows.map((row) => ({
        id:row.id,
        crewNumber:row.crew_number,
        name:row.name,
        avatar:row.avatar || '🎮',
        photoData:'',
        photoUrl:playerPhotoUrl(row),
        bio:'',
        specialties:[],
        specialAbility:'',
        briefingCompleted:Boolean(row.briefing_completed),
        locationUnlocked:Boolean(row.location_unlocked),
        wantedScore:0,
        gameStars:0,
        wantedLevel:0,
        cash:0,
        walletBalance:0,
        completedMissions:[],
        missionRespect:0,
        socialRespect:0,
        respect:0,
        respectedByViewer:false
      })) });
    }
    return json({ ok: true, players: rows.map(publicPlayer) });
  }

  if (route === 'crew/respect' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda antes de dar respeto.' }, 403);
    const body = await requestBody(request);
    const receiverId = cleanString(body.playerId, 80);
    if (!receiverId || receiverId === auth.player.id) return json({ error:'INVALID_RESPECT', message:'No puedes darte respeto a ti mismo.' }, 400);
    const receiver = await DB.prepare('SELECT id FROM players WHERE id = ? AND attendance = ? LIMIT 1').bind(receiverId, 'yes').first();
    if (!receiver) return json({ error:'PLAYER_NOT_FOUND', message:'Ese miembro ya no está disponible.' }, 404);
    await DB.prepare('INSERT OR IGNORE INTO player_respect (giver_id, receiver_id) VALUES (?, ?)').bind(auth.player.id, receiverId).run();
    const countRow = await DB.prepare(`SELECT
      (SELECT COUNT(*) FROM player_respect WHERE receiver_id = ?) AS social_total,
      (SELECT mission_respect FROM players WHERE id = ? LIMIT 1) AS mission_total`).bind(receiverId, receiverId).first();
    const socialRespect = Math.max(0, Number(countRow?.social_total || 0));
    const missionRespect = Math.max(0, Number(countRow?.mission_total || 0));
    return json({ ok:true, playerId:receiverId, respect:socialRespect + missionRespect, socialRespect, missionRespect, respected:true });
  }

  if (route === 'money/collect' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda antes de recoger fondos.' }, 403);
    const body = await requestBody(request);
    const requestedIndex = Number.parseInt(body.index, 10);
    if (!Number.isFinite(requestedIndex) || requestedIndex < 1 || requestedIndex > 5) return json({ error:'INVALID_BILL' }, 400);
    const currentCount = Math.max(0, Math.min(5, Number(auth.player.cash_collected_count || 0)));
    if (requestedIndex > currentCount + 1) return json({ error:'BILL_LOCKED', message:'Ese billete todavía no está disponible.' }, 409);
    if (requestedIndex >= 4 && !auth.player.location_unlocked) {
      return json({ error:'BILL_PHASE_LOCKED', message:'Los últimos billetes se desbloquean después de localizar el punto.' }, 409);
    }
    let amount = 0;
    if (requestedIndex === currentCount + 1 && currentCount < 5) {
      const update = await DB.prepare(`UPDATE players SET cash = cash + 100, wallet_balance = wallet_balance + 100,
        cash_collected_count = cash_collected_count + 1, wanted_level = MIN(5, wanted_level + 1), updated_at = CURRENT_TIMESTAMP
        WHERE id = ? AND cash_collected_count = ?`).bind(auth.player.id, currentCount).run();
      if (Number(update?.meta?.changes || 0) > 0) {
        amount = 100;
        const after = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars FROM players WHERE id = ? LIMIT 1').bind(auth.player.id).first();
        await DB.prepare(`INSERT OR IGNORE INTO economy_events
          (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta, balance_after, mission_respect_after, game_stars_after, meta_json)
          VALUES (?, ?, 'loot', 'hidden-cash', ?, 100, 0, 0, ?, ?, ?, ?)`)
          .bind(`${auth.player.id}:loot:bill:${requestedIndex}`, auth.player.id, `bill-${requestedIndex}`,
            normalizeWallet(after?.wallet_balance), Math.max(0, Number(after?.mission_respect || 0)), normalizeGameStars(after?.game_stars),
            JSON.stringify({ billIndex:requestedIndex, wantedLevel:Math.min(5, currentCount + 1) })).run();
      }
    }
    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    return json({ ok:true, amount, player:privatePlayer(row) });
  }

  if (route === 'money/escape' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (Number(auth.player.cash_collected_count || 0) < 5) return json({ error:'CHASE_NOT_READY' }, 409);
    // El final de WANTED ya no borra el progreso: ★★★★★ queda como marca
    // permanente de haber completado la búsqueda de los cinco billetes.
    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    return json({ ok:true, player:privatePlayer(row) });
  }


  if (route === 'missions/discover' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda antes de desbloquear objetivos.' }, 403);
    if (!auth.player.location_unlocked) return json({ error:'HEIST_LOCKED', message:'Completa el acceso al golpe antes de desbloquear objetivos.' }, 403);
    const body = await requestBody(request);
    const code = cleanString(body.code, 24).toUpperCase();
    if (!MISSION_ECONOMY[code]) return json({ error:'MISSION_UNKNOWN', message:'Ese código no está activo.' }, 404);

    const current = mergedDiscoveredMissions(auth.player);
    const alreadyDiscovered = current.includes(code);
    if (!alreadyDiscovered) {
      const next = normalizeDiscoveredMissions([...current, code]);
      await DB.prepare('UPDATE players SET discovered_missions_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
        .bind(JSON.stringify(next), auth.player.id).run();
    }
    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    return json({ ok:true, alreadyDiscovered, code, player:privatePlayer(row) });
  }

  if (route === 'missions/complete' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda antes de completar actividades.' }, 403);
    if (!auth.player.location_unlocked) return json({ error:'HEIST_LOCKED', message:'Completa el acceso al golpe antes de registrar objetivos.' }, 403);
    const body = await requestBody(request);
    const code = cleanString(body.code, 24).toUpperCase();
    const reward = MISSION_ECONOMY[code];
    if (!reward) return json({ error:'MISSION_UNKNOWN', message:'Ese código de misión no está activo.' }, 404);
    if (!reward.directComplete) return json({ error:'MISSION_RESULT_REQUIRED', message:'Ese juego debe registrar su resultado desde la propia tarjeta.' }, 409);

    const completed = parseCompletedMissions(auth.player.completed_missions_json);
    const alreadyCompleted = completed.includes(code);
    const eventId = economyEventId(auth.player.id, 'mission', code, 'complete');

    let applied = false;
    if (!alreadyCompleted) {
      const nextCompleted = normalizeCompletedMissions([...completed, code]);
      const nextDiscovered = normalizeDiscoveredMissions([...mergedDiscoveredMissions(auth.player), code]);
      const cashDelta = Math.max(0, Number(reward.cash || 0));
      const respectDelta = Math.max(0, Number(reward.respect || 0));
      const starsDelta = Math.max(0, Number(reward.stars || 0));

      // Reservamos el id del movimiento antes de tocar saldos. Dos peticiones iguales
      // no pueden cobrar dos veces aunque lleguen prácticamente a la vez.
      const reservation = await DB.prepare(`INSERT OR IGNORE INTO economy_events
        (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta, balance_after, mission_respect_after, game_stars_after, meta_json)
        VALUES (?, ?, 'mission', ?, 'complete', 0, 0, 0, 0, 0, 0, ?)`)
        .bind(eventId, auth.player.id, code, JSON.stringify({ pending:true, label:reward.label || code })).run();
      applied = Number(reservation?.meta?.changes || 0) > 0;

      if (applied) {
        await DB.prepare(`UPDATE players SET completed_missions_json = ?, discovered_missions_json = ?,
          wallet_balance = wallet_balance + ?, cash = cash + ?,
          mission_respect = mission_respect + ?,
          game_stars = game_stars + ?, wanted_score = wanted_score + ?,
          updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
          .bind(JSON.stringify(nextCompleted), JSON.stringify(nextDiscovered), cashDelta, cashDelta, respectDelta, starsDelta, starsDelta, auth.player.id).run();
        const after = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars FROM players WHERE id = ? LIMIT 1').bind(auth.player.id).first();
        await DB.prepare(`UPDATE economy_events SET cash_delta = ?, respect_delta = ?, stars_delta = ?,
          balance_after = ?, mission_respect_after = ?, game_stars_after = ?, meta_json = ? WHERE id = ?`)
          .bind(cashDelta, respectDelta, starsDelta, normalizeWallet(after?.wallet_balance),
            Math.max(0, Number(after?.mission_respect || 0)), normalizeGameStars(after?.game_stars),
            JSON.stringify({ label:reward.label || code }), eventId).run();
      }
    }

    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    const duplicate = alreadyCompleted || !applied;
    return json({ ok:true, alreadyCompleted:duplicate, reward:duplicate ? { cash:0, respect:0, stars:0 } : { cash:Number(reward.cash || 0), respect:Number(reward.respect || 0), stars:Number(reward.stars || 0) }, player:privatePlayer(row) });
  }

  if (route === 'economy/apply' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda antes de registrar resultados.' }, 403);
    if (!auth.player.location_unlocked) return json({ error:'HEIST_LOCKED', message:'Completa el acceso al golpe antes de registrar resultados.' }, 403);
    const body = await requestBody(request);
    const sourceType = cleanString(body.sourceType, 20).toLowerCase();
    const sourceId = cleanString(body.sourceId, 40).toUpperCase();
    const actionId = cleanString(body.actionId, 40).toLowerCase();
    if (!['game','mission','system'].includes(sourceType) || !/^[A-Z0-9_-]{2,40}$/.test(sourceId) || !/^[a-z0-9_-]{2,40}$/.test(actionId)) {
      return json({ error:'INVALID_ECONOMY_EVENT', message:'El movimiento no tiene un origen válido.' }, 400);
    }

    // El cliente solo declara QUÉ ha ocurrido. Los importes, estrellas y reglas
    // se resuelven aquí para que DevTools no pueda fabricar dinero o borrar penalizaciones.
    const rule = resolveEconomyAction(sourceType, sourceId, actionId, body, auth.player);
    if (rule.error) return json({ error:rule.error, message:rule.message }, 400);

    const currentCompleted = parseCompletedMissions(auth.player.completed_missions_json);
    const completedJson = JSON.stringify(rule.markCompleted ? normalizeCompletedMissions([...currentCompleted, sourceId]) : currentCompleted);
    const discoveredJson = JSON.stringify(normalizeDiscoveredMissions([
      ...mergedDiscoveredMissions(auth.player),
      ...(rule.markCompleted ? [sourceId] : [])
    ]));
    const suppliedEventId = cleanString(body.eventId, 96).replace(/[^a-zA-Z0-9:_-]/g, '');
    const eventId = rule.repeatable
      ? economyEventId(auth.player.id, sourceType, sourceId, actionId, suppliedEventId || `req-${crypto.randomUUID()}`)
      : economyEventId(auth.player.id, sourceType, sourceId, actionId);

    const reservation = await DB.prepare(`INSERT OR IGNORE INTO economy_events
      (id, player_id, source_type, source_id, action_id, cash_delta, respect_delta, stars_delta, balance_after, mission_respect_after, game_stars_after, meta_json)
      VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, ?)`)
      .bind(eventId, auth.player.id, sourceType, sourceId, actionId, JSON.stringify({ pending:true })).run();
    const duplicate = Number(reservation?.meta?.changes || 0) === 0;

    if (!duplicate) {
      const cashDelta = Number(rule.cashDelta || 0);
      const respectDelta = Number(rule.respectDelta || 0);
      const starsDelta = Number(rule.starsDelta || 0);
      const wallet = normalizeWallet(auth.player.wallet_balance ?? auth.player.cash);
      const currentStars = normalizeGameStars(auth.player.game_stars ?? auth.player.wanted_score);

      if (wallet + cashDelta < 0) {
        await DB.prepare('DELETE FROM economy_events WHERE id = ?').bind(eventId).run();
        return json({ error:'INSUFFICIENT_FUNDS', message:'No tienes suficiente dinero para esa acción.' }, 409);
      }
      if (starsDelta < 0 && currentStars < Math.abs(starsDelta)) {
        await DB.prepare('DELETE FROM economy_events WHERE id = ?').bind(eventId).run();
        return json({ error:'NO_STARS_TO_CLEAN', message:'Tu expediente ya está limpio.' }, 409);
      }

      let update;
      if (rule.cleanRecord) {
        update = await DB.prepare(`UPDATE players SET
          wallet_balance = wallet_balance + ?, cash = cash + ?,
          game_stars = game_stars - 1, wanted_score = MAX(0, wanted_score - 1),
          record_clean_count = record_clean_count + 1, updated_at = CURRENT_TIMESTAMP
          WHERE id = ? AND wallet_balance >= ? AND game_stars > 0 AND record_clean_count = ?`)
          .bind(cashDelta, cashDelta, auth.player.id, Math.abs(cashDelta), rule.expectedCleanCount).run();
      } else {
        const nextStars = Math.max(0, currentStars + starsDelta);
        const effectiveStarsDelta = nextStars - currentStars;
        update = await DB.prepare(`UPDATE players SET
          completed_missions_json = ?, discovered_missions_json = ?,
          wallet_balance = wallet_balance + ?, cash = cash + ?,
          mission_respect = mission_respect + ?,
          game_stars = MAX(0, game_stars + ?), wanted_score = MAX(0, wanted_score + ?), updated_at = CURRENT_TIMESTAMP
          WHERE id = ? AND wallet_balance + ? >= 0`)
          .bind(completedJson, discoveredJson, cashDelta, cashDelta, respectDelta, effectiveStarsDelta, effectiveStarsDelta, auth.player.id, cashDelta).run();
      }

      if (Number(update?.meta?.changes || 0) === 0) {
        await DB.prepare('DELETE FROM economy_events WHERE id = ?').bind(eventId).run();
        if (rule.cleanRecord) return json({ error:'ECONOMY_STATE_CHANGED', message:'Tu expediente ha cambiado. Vuelve a intentarlo.' }, 409);
        return json({ error:'ECONOMY_NOT_APPLIED', message:'No se ha podido aplicar ese resultado.' }, 409);
      }

      const after = await DB.prepare('SELECT wallet_balance, mission_respect, game_stars, record_clean_count FROM players WHERE id = ? LIMIT 1').bind(auth.player.id).first();
      const appliedStarsDelta = normalizeGameStars(after?.game_stars) - currentStars;
      const meta = { ...(rule.meta || {}), ...(body.meta && typeof body.meta === 'object' ? body.meta : {}) };
      // Los campos de seguridad vuelven a imponerse después del meta del cliente.
      if (rule.cleanRecord) {
        meta.cost = Math.abs(cashDelta);
        meta.cleanNumber = Number(after?.record_clean_count || 0);
        meta.label = 'LIMPIEZA DE EXPEDIENTE';
      }
      await DB.prepare(`UPDATE economy_events SET cash_delta = ?, respect_delta = ?, stars_delta = ?,
        balance_after = ?, mission_respect_after = ?, game_stars_after = ?, meta_json = ? WHERE id = ?`)
        .bind(cashDelta, respectDelta, appliedStarsDelta, normalizeWallet(after?.wallet_balance),
          Math.max(0, Number(after?.mission_respect || 0)), normalizeGameStars(after?.game_stars), JSON.stringify(meta), eventId).run();
    }

    const row = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(auth.player.id).first();
    return json({ ok:true, duplicate, eventId, player:privatePlayer(row) });
  }

  if (route === 'economy/activity' && method === 'GET') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    const limit = Math.max(1, Math.min(30, Number.parseInt(url.searchParams.get('limit'), 10) || 12));
    const result = await DB.prepare(`SELECT source_type, source_id, action_id, cash_delta, respect_delta, stars_delta,
      balance_after, mission_respect_after, game_stars_after, meta_json, created_at
      FROM economy_events WHERE player_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?`).bind(auth.player.id, limit).all();
    const events = (result.results || []).map((item) => ({
      sourceType:item.source_type, sourceId:item.source_id, actionId:item.action_id,
      cashDelta:Number(item.cash_delta || 0), respectDelta:Number(item.respect_delta || 0), starsDelta:Number(item.stars_delta || 0),
      balanceAfter:Number(item.balance_after || 0), respectAfter:Number(item.mission_respect_after || 0), starsAfter:Number(item.game_stars_after || 0),
      meta:(() => { try { return JSON.parse(item.meta_json || '{}'); } catch { return {}; } })(), createdAt:item.created_at
    }));
    return json({ ok:true, events });
  }

  if (route === 'login' && method === 'POST') {
    const body = await requestBody(request);
    const playerId = cleanString(body.playerId, 80);
    const pin = cleanString(body.pin, 4);
    const requireHeistAccess = body.requireHeistAccess === true;
    if (!playerId || !/^\d{4}$/.test(pin)) return json({ error: 'INVALID_LOGIN', message: 'Jugador o PIN incorrecto.' }, 400);

    const row = await DB.prepare('SELECT * FROM players WHERE id = ? AND attendance = ? LIMIT 1').bind(playerId, 'yes').first();
    if (!row?.pin_hash || !row?.pin_salt) return json({ error: 'INVALID_LOGIN', message: 'Jugador o PIN incorrecto.' }, 401);
    if (requireHeistAccess && !playerHasHeistAccess(row)) {
      return json({ error:'HEIST_ACCESS_REQUIRED', message:'Ese personaje todavía no ha completado la Operación 30.' }, 403);
    }

    if (row.locked_until && Date.parse(row.locked_until) > Date.now()) {
      return json({ error: 'LOGIN_LOCKED', message: 'DEMASIADOS INTENTOS · Espera unos minutos o pide a Dani que restablezca tu PIN.' }, 429);
    }

    const candidate = await hashPin(pin, row.pin_salt);
    if (!secureEqualHex(candidate, row.pin_hash)) {
      const attempts = Number(row.failed_attempts || 0) + 1;
      if (attempts >= 5) {
        const lockedUntil = new Date(Date.now() + 10 * 60 * 1000).toISOString();
        await DB.prepare('UPDATE players SET failed_attempts = 0, locked_until = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(lockedUntil, row.id).run();
        return json({ error: 'LOGIN_LOCKED', message: 'ACCESO BLOQUEADO · 5 intentos fallidos. Espera 10 minutos o pide a Dani un nuevo PIN.' }, 429);
      }
      await DB.prepare('UPDATE players SET failed_attempts = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(attempts, row.id).run();
      return json({ error: 'INVALID_LOGIN', message: `ACCESO DENEGADO · PIN incorrecto (${attempts}/5).` }, 401);
    }

    const sessionToken = randomHex(24);
    const sessionHash = await sha256(sessionToken);
    await DB.batch([
      DB.prepare('INSERT INTO player_sessions (session_hash, player_id) VALUES (?, ?)').bind(sessionHash, row.id),
      DB.prepare('UPDATE players SET failed_attempts = 0, locked_until = NULL WHERE id = ?').bind(row.id)
    ]);
    const updated = await DB.prepare(`SELECT p.*, (SELECT COUNT(*) FROM player_respect r WHERE r.receiver_id = p.id) AS respect_count
      FROM players p WHERE p.id = ? LIMIT 1`).bind(row.id).first();
    return json({ ok: true, sessionToken, player: privatePlayer(updated) });
  }

  if (route === 'location/unlock' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error: 'NOT_CONFIRMED' }, 403);
    await DB.prepare('UPDATE players SET location_unlocked = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(auth.player.id).run();
    return json({ ok: true, ...SECURE_LOCATION });
  }

  if (route === 'location' && method === 'GET') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes' || !auth.player.location_unlocked) {
      return json({ error: 'LOCATION_LOCKED', message: 'Completa el hack para desbloquear la ubicación.' }, 403);
    }
    return json({ ok: true, ...SECURE_LOCATION });
  }

  if (route === 'clandestine/leaderboard' && method === 'GET') {
    const auth=await requirePlayer(request,DB);if(auth.error)return auth.error;
    if(auth.player.attendance!=='yes')return json({error:'NOT_CONFIRMED',message:'Únete a la banda para entrar en Operaciones Clandestinas.'},403);
    return json({ok:true,...await clandestineStatus(DB,auth.player.id)});
  }

  if (route === 'arcade/leaderboard' && method === 'GET') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en el arcade.' }, 403);
    const awards = await settleArcadeContest(DB);
    const leaderboard = await arcadeLeaderboard(DB, auth.player.id);
    const mine = leaderboard.find((entry) => entry.playerId === auth.player.id) || null;
    return json({
      ok:true,
      phase:Date.now() < ARCADE_CONTEST.closesAtMs ? 'open' : 'closed',
      closesAt:ARCADE_CONTEST.closesAt,
      rewards:ARCADE_CONTEST.rewards.map((item) => ({ ...item })),
      totalCash:ARCADE_CONTEST.rewards.reduce((sum,item) => sum + item.cash, 0),
      playerBest:mine?.score || 0,
      playerRank:mine?.rank || null,
      awards,
      winner:awards[0] || null,
      leaderboard
    });
  }

  if (route === 'arcade/start' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en el arcade.' }, 403);
    const body = await requestBody(request);
    const requestedRulesVersion = Number(body.rulesVersion || 0);
    const nowMs = Date.now();
    const freePlay = nowMs >= ARCADE_CONTEST.closesAtMs;
    if (freePlay) await settleArcadeContest(DB, nowMs);
    const runId = crypto.randomUUID();
    await DB.prepare('INSERT INTO crossing_v11_runs (run_id, player_id, started_at_ms) VALUES (?, ?, ?)')
      .bind(runId, auth.player.id, nowMs).run();
    return json({ ok:true, runId, rulesVersion:globalThis.DANI_ARCADE_ENGINE.VERSION, seed:globalThis.DANI_ARCADE_ENGINE.hashSeed(runId), startedAt:nowMs, freePlay, phase:freePlay?'closed':'open', closesAt:ARCADE_CONTEST.closesAt, rewards:ARCADE_CONTEST.rewards.map((item) => ({ ...item })) });
  }

  if (route === 'arcade/finish' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    const body = await requestBody(request);
    const runId = cleanString(body.runId, 80);
    const run = await DB.prepare('SELECT * FROM crossing_v11_runs WHERE run_id = ? AND player_id = ? LIMIT 1').bind(runId, auth.player.id).first();
    if (!run) return json({ error:'RUN_NOT_FOUND', message:'Esa partida ya no está disponible.' }, 404);
    const runStartedMs = Number(run.started_at_ms || 0);
    const freePlay = runStartedMs >= ARCADE_CONTEST.closesAtMs;
    const firstFinish = run.score == null;
    let score = run.score == null ? NaN : Number(run.score);
    let newRecord = false;
    if (!Number.isFinite(score)) {
      const endMs = freePlay ? Date.now() : Math.min(Date.now(), ARCADE_CONTEST.closesAtMs);
      const elapsedMs = Math.max(0, Math.min(ARCADE_CONTEST.maxRunMs, endMs - Number(run.started_at_ms || endMs)));
      let verified;
      try {
        if(body.rulesVersion !== globalThis.DANI_ARCADE_ENGINE.VERSION)throw Error('Actualiza la página para jugar a la nueva FUGA 30.');
        if(!Number.isInteger(body.ticks)||body.ticks > Math.floor(elapsedMs*globalThis.DANI_ARCADE_ENGINE.HZ/1000)+globalThis.DANI_ARCADE_ENGINE.HZ)throw Error('Duración de partida inválida');
        verified=globalThis.DANI_ARCADE_ENGINE.replay(globalThis.DANI_ARCADE_ENGINE.hashSeed(runId),body.events,body.ticks);
      } catch(error){return json({error:'INVALID_RUN',message:error.message||'No se pudo validar la partida.'},400);}
      score=verified.score;
      const writes=[];
      if(!freePlay){
        const existing=await DB.prepare('SELECT high_score FROM crossing_v11_scores WHERE player_id = ? LIMIT 1').bind(auth.player.id).first();
        newRecord=score>Math.max(0,Number(existing?.high_score||0));
        writes.push(DB.prepare(`INSERT INTO crossing_v11_scores (player_id,high_score,games_played,last_score,achieved_at)
          SELECT ?,?,1,?,CURRENT_TIMESTAMP WHERE EXISTS (SELECT 1 FROM crossing_v11_runs WHERE run_id=? AND score IS NULL)
          ON CONFLICT(player_id) DO UPDATE SET
          achieved_at=CASE WHEN excluded.high_score>crossing_v11_scores.high_score THEN CURRENT_TIMESTAMP ELSE crossing_v11_scores.achieved_at END,
          high_score=MAX(crossing_v11_scores.high_score,excluded.high_score),
          games_played=crossing_v11_scores.games_played+1,last_score=excluded.last_score,updated_at=CURRENT_TIMESTAMP`)
          .bind(auth.player.id,score,score,runId));
      }
      writes.push(DB.prepare('UPDATE crossing_v11_runs SET score = ?, finished_at = CURRENT_TIMESTAMP WHERE run_id = ? AND score IS NULL').bind(score,runId));
      await DB.batch(writes);
    }

    if(firstFinish)await recordAdminActivity(DB,env,{eventType:'game_fuga',category:'game',actorId:auth.player.id,actorName:String(auth.player.name||''),title:`${auth.player.name} terminó FUGA 30`,detail:`${Math.max(0,Number(score||0)).toLocaleString('es-ES')} pasos${newRecord?' · nuevo récord':''}`,meta:{game:'fuga',score,newRecord,freePlay}});
    const awards = await settleArcadeContest(DB);
    const leaderboard = await arcadeLeaderboard(DB, auth.player.id);
    const mine = leaderboard.find((entry) => entry.playerId === auth.player.id) || null;
    const officialBest = Math.max(0, Number(mine?.score || 0));
    return json({
      ok:true,
      score,
      newRecord:freePlay ? false : newRecord,
      freePlay,
      beatOfficialBest:Boolean(freePlay && officialBest > 0 && score > officialBest),
      phase:Date.now() < ARCADE_CONTEST.closesAtMs ? 'open' : 'closed',
      closesAt:ARCADE_CONTEST.closesAt,
      rewards:ARCADE_CONTEST.rewards.map((item) => ({ ...item })),
      totalCash:ARCADE_CONTEST.rewards.reduce((sum,item) => sum + item.cash, 0),
      playerBest:officialBest,
      playerRank:mine?.rank || null,
      awards,
      winner:awards[0] || null,
      leaderboard
    });
  }

  if (route === 'infiltration/leaderboard' && method === 'GET') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en BRECHA 30.' }, 403);
    const awards = await settleInfiltrationContest(DB);
    const leaderboard = await infiltrationLeaderboard(DB, auth.player.id);
    const mine = leaderboard.find((entry) => entry.playerId === auth.player.id) || null;
    return json({
      ok:true,
      phase:Date.now() < INFILTRATION_CONTEST.closesAtMs ? 'open' : 'closed',
      closesAt:INFILTRATION_CONTEST.closesAt,
      rewards:INFILTRATION_CONTEST.rewards.map((item) => ({ ...item })),
      totalCash:INFILTRATION_CONTEST.rewards.reduce((sum,item) => sum + item.cash, 0),
      playerBest:mine?.score || 0,
      playerRank:mine?.rank || null,
      awards,
      winner:awards[0] || null,
      leaderboard
    });
  }

  if (route === 'infiltration/start' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en BRECHA 30.' }, 403);
    const nowMs = Date.now();
    const freePlay = nowMs >= INFILTRATION_CONTEST.closesAtMs;
    if (freePlay) await settleInfiltrationContest(DB, nowMs);
    const runId = crypto.randomUUID();
    await DB.prepare('INSERT INTO operation_infiltration_v6_runs (run_id, player_id, started_at_ms) VALUES (?, ?, ?)')
      .bind(runId, auth.player.id, nowMs).run();
    return json({
      ok:true, runId, startedAt:nowMs, freePlay, phase:freePlay?'closed':'open', closesAt:INFILTRATION_CONTEST.closesAt,
      seed:INFILTRATION_ENGINE.runSeed(runId), rulesVersion:INFILTRATION_ENGINE.VERSION,
      rewards:INFILTRATION_CONTEST.rewards.map((item) => ({ ...item }))
    });
  }

  if (route === 'infiltration/finish' && method === 'POST') {
    const auth = await requirePlayer(request, DB);
    if (auth.error) return auth.error;
    const body = await requestBody(request);
    const runId = cleanString(body.runId, 80);
    const run = await DB.prepare('SELECT * FROM operation_infiltration_v6_runs WHERE run_id = ? AND player_id = ? LIMIT 1').bind(runId, auth.player.id).first();
    if (!run) return json({ error:'RUN_NOT_FOUND', message:'Esa brecha ya no está disponible.' }, 404);
    const runStartedMs = Number(run.started_at_ms || 0);
    const freePlay = runStartedMs >= INFILTRATION_CONTEST.closesAtMs;
    const firstFinish = run.score == null;

    let score = run.score == null ? NaN : Number(run.score);
    let roundsCompleted = Math.max(0, Number(run.rounds_completed || 0));
    let failedRound = Math.max(1, Number(run.failed_round || 1));
    let resultData = null;
    let newRecord = false;

    if (!Number.isFinite(score)) {
      try {
        resultData = INFILTRATION_ENGINE.replay(body.events, INFILTRATION_ENGINE.runSeed(runId));
      } catch (error) {
        return json({ error:'INVALID_RUN', message:error.message || 'La partida no es válida.' }, 409);
      }
      if (!resultData.gameOver) return json({ error:'RUN_NOT_FINISHED', message:'La brecha todavía no ha terminado.' }, 409);
      const endMs = freePlay ? Date.now() : Math.min(Date.now(), INFILTRATION_CONTEST.closesAtMs);
      const elapsedMs = Math.max(0, Math.min(INFILTRATION_CONTEST.maxRunMs, endMs - runStartedMs));
      if (elapsedMs < Math.max(250, Number(resultData.minDurationMs || 0) - 650)) {
        return json({ error:'RUN_TOO_FAST', message:'La duración de la partida no es válida.' }, 409);
      }
      score = Math.max(0, Number(resultData.score || 0));
      roundsCompleted = Math.max(0, Number(resultData.roundsCompleted || 0));
      failedRound = Math.max(1, Number(resultData.failedRound || 1));
      await DB.prepare(`UPDATE operation_infiltration_v6_runs SET score = ?, rounds_completed = ?, failed_round = ?,
        result_json = ?, event_log_json = ?, finished_at = CURRENT_TIMESTAMP WHERE run_id = ? AND score IS NULL`)
        .bind(score, roundsCompleted, failedRound, JSON.stringify(resultData), JSON.stringify(Array.isArray(body.events) ? body.events : []), runId).run();

      if (!freePlay) {
        const existing = await DB.prepare('SELECT high_score FROM operation_infiltration_v6_scores WHERE player_id = ? LIMIT 1').bind(auth.player.id).first();
        const previousBest = Math.max(0, Number(existing?.high_score || 0));
        if (!existing) {
          newRecord = score > 0;
          await DB.prepare(`INSERT INTO operation_infiltration_v6_scores
            (player_id, high_score, games_played, last_score, best_rounds_completed, best_failed_round, achieved_at)
            VALUES (?, ?, 1, ?, ?, ?, CURRENT_TIMESTAMP)`)
            .bind(auth.player.id, score, score, roundsCompleted, failedRound).run();
        } else if (score > previousBest) {
          newRecord = true;
          await DB.prepare(`UPDATE operation_infiltration_v6_scores SET high_score = ?, games_played = games_played + 1,
            last_score = ?, best_rounds_completed = ?, best_failed_round = ?, achieved_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP WHERE player_id = ?`)
            .bind(score, score, roundsCompleted, failedRound, auth.player.id).run();
        } else {
          await DB.prepare(`UPDATE operation_infiltration_v6_scores SET games_played = games_played + 1,
            last_score = ?, updated_at = CURRENT_TIMESTAMP WHERE player_id = ?`)
            .bind(score, auth.player.id).run();
        }
      }
    } else if (run.result_json) {
      try { resultData = JSON.parse(run.result_json); } catch { resultData = null; }
    }

    if(firstFinish)await recordAdminActivity(DB,env,{eventType:'game_infiltration',category:'game',actorId:auth.player.id,actorName:String(auth.player.name||''),title:`${auth.player.name} terminó BRECHA 30`,detail:`${Math.max(0,Number(score||0))} teclas${newRecord?' · nuevo récord':''}`,meta:{game:'infiltration',score,newRecord,freePlay}});
    const awards = await settleInfiltrationContest(DB);
    const leaderboard = await infiltrationLeaderboard(DB, auth.player.id);
    const mine = leaderboard.find((entry) => entry.playerId === auth.player.id) || null;
    const officialBest = Math.max(0, Number(mine?.score || 0));
    const zone = INFILTRATION_ENGINE.zoneFor(failedRound);
    return json({
      ok:true,
      ...(resultData || {}),
      score,
      roundsCompleted,
      failedRound,
      zone:resultData?.zone || zone.name,
      depth:Math.max(0, Number(resultData?.depth ?? zone.depth ?? 0)),
      newRecord:freePlay ? false : newRecord,
      freePlay,
      beatOfficialBest:Boolean(freePlay && officialBest > 0 && score > officialBest),
      phase:Date.now() < INFILTRATION_CONTEST.closesAtMs ? 'open' : 'closed',
      closesAt:INFILTRATION_CONTEST.closesAt,
      rewards:INFILTRATION_CONTEST.rewards.map((item) => ({ ...item })),
      totalCash:INFILTRATION_CONTEST.rewards.reduce((sum,item) => sum + item.cash, 0),
      playerBest:officialBest,
      playerRank:mine?.rank || null,
      awards,
      winner:awards[0] || null,
      leaderboard
    });
  }

  if (route === 'pointblind/leaderboard' && method === 'GET') {
    const auth=await requirePlayer(request,DB);if(auth.error)return auth.error;
    if(auth.player.attendance!=='yes')return json({error:'NOT_CONFIRMED',message:'Únete a la banda para entrar en PUNTO CIEGO 30.'},403);
    const awards=await settlePointBlindContest(DB),leaderboard=await pointBlindLeaderboard(DB,auth.player.id),mine=leaderboard.find(entry=>entry.playerId===auth.player.id)||null;
    return json({ok:true,rulesVersion:POINTBLIND_CONTEST.rulesVersion,phase:Date.now()<POINTBLIND_CONTEST.closesAtMs?'open':'closed',closesAt:POINTBLIND_CONTEST.closesAt,
      rewards:POINTBLIND_CONTEST.rewards.map(item=>({...item})),totalCash:POINTBLIND_CONTEST.rewards.reduce((sum,item)=>sum+item.cash,0),
      playerBest:mine?mine.score:null,playerRank:mine?.rank||null,awards,winner:awards[0]||null,leaderboard});
  }

  if (route === 'pointblind/start' && method === 'POST') {
    const auth=await requirePlayer(request,DB);if(auth.error)return auth.error;
    if(auth.player.attendance!=='yes')return json({error:'NOT_CONFIRMED',message:'Únete a la banda para entrar en PUNTO CIEGO 30.'},403);
    const body=await requestBody(request);if(Number(body.rulesVersion)!==POINTBLIND_CONTEST.rulesVersion)return json({error:'UPDATE_REQUIRED',message:'Actualiza la página para cargar PUNTO CIEGO 30.'},409);
    const nowMs=Date.now(),freePlay=nowMs>=POINTBLIND_CONTEST.closesAtMs;if(freePlay)await settlePointBlindContest(DB,nowMs);const runId=crypto.randomUUID();
    await DB.prepare('INSERT INTO pointblind_v1_runs (run_id,player_id,started_at_ms,rules_version) VALUES(?,?,?,?)').bind(runId,auth.player.id,nowMs,POINTBLIND_CONTEST.rulesVersion).run();
    return json({ok:true,runId,rulesVersion:POINTBLIND_CONTEST.rulesVersion,seed:POINTBLIND_ENGINE.seedForRun(runId),startedAt:nowMs,freePlay,phase:freePlay?'closed':'open',closesAt:POINTBLIND_CONTEST.closesAt,rewards:POINTBLIND_CONTEST.rewards.map(item=>({...item}))});
  }

  if (route === 'pointblind/finish' && method === 'POST') {
    const auth=await requirePlayer(request,DB);if(auth.error)return auth.error;const body=await requestBody(request),runId=cleanString(body.runId,80);
    const run=await DB.prepare('SELECT * FROM pointblind_v1_runs WHERE run_id=? AND player_id=? LIMIT 1').bind(runId,auth.player.id).first();
    if(!run)return json({error:'RUN_NOT_FOUND',message:'Ese punto ciego ya no está disponible.'},404);
    const runStartedMs=Number(run.started_at_ms||0),freePlay=runStartedMs>=POINTBLIND_CONTEST.closesAtMs;
    let totalErrorMs=run.total_error_ms==null?NaN:Number(run.total_error_ms),worstErrorMs=Math.max(0,Number(run.worst_error_ms||0)),bestSingleErrorMs=Math.max(0,Number(run.best_single_error_ms||0)),durationMs=Math.max(0,Number(run.duration_ms||0)),attempts=[],newRecord=false,firstFinish=false;
    if(!Number.isFinite(totalErrorMs)){
      if(Number(body.rulesVersion)!==POINTBLIND_CONTEST.rulesVersion||Number(run.rules_version)!==POINTBLIND_CONTEST.rulesVersion)return json({error:'UPDATE_REQUIRED',message:'Actualiza la página para cargar PUNTO CIEGO 30.'},409);
      const reportedDuration=Math.max(0,Math.floor(Number(body.durationMs)||0)),endMs=freePlay?Date.now():Math.min(Date.now(),POINTBLIND_CONTEST.closesAtMs),serverElapsed=Math.max(0,Math.min(POINTBLIND_CONTEST.maxRunMs,endMs-runStartedMs));
      if(reportedDuration<POINTBLIND_ENGINE.READY_MS||reportedDuration>POINTBLIND_ENGINE.MAX_DURATION_MS||reportedDuration>serverElapsed+1800)return json({error:'INVALID_POINTBLIND_TIME',message:'La duración registrada no es válida.'},409);
      let verified;try{verified=POINTBLIND_ENGINE.replay(runId,Array.isArray(body.events)?body.events:[],reportedDuration);}catch(error){return json({error:'INVALID_POINTBLIND_RUN',message:error.message||'No se pudo validar PUNTO CIEGO 30.'},400);}
      totalErrorMs=Math.max(0,Number(verified.totalErrorMs||0));worstErrorMs=Math.max(0,Number(verified.worstErrorMs||0));bestSingleErrorMs=Math.max(0,Number(verified.bestErrorMs||0));durationMs=reportedDuration;attempts=verified.attempts||[];
      const stored=await DB.prepare(`UPDATE pointblind_v1_runs SET duration_ms=?,total_error_ms=?,worst_error_ms=?,best_single_error_ms=?,attempts_json=?,event_log_json=?,finished_at=CURRENT_TIMESTAMP WHERE run_id=? AND total_error_ms IS NULL`)
        .bind(durationMs,totalErrorMs,worstErrorMs,bestSingleErrorMs,JSON.stringify(attempts),JSON.stringify(body.events||[]),runId).run();
      firstFinish=Number(stored?.meta?.changes||0)>0;
      if(firstFinish&&!freePlay){
        const existing=await DB.prepare('SELECT best_total_error_ms,best_worst_error_ms,best_single_error_ms FROM pointblind_v1_scores WHERE player_id=? LIMIT 1').bind(auth.player.id).first(),better=pointBlindRunBeats(existing,totalErrorMs,worstErrorMs,bestSingleErrorMs);
        if(!existing){newRecord=true;await DB.prepare(`INSERT INTO pointblind_v1_scores (player_id,best_total_error_ms,games_played,last_total_error_ms,best_worst_error_ms,best_single_error_ms,achieved_at) VALUES(?,?,1,?,?,?,strftime('%Y-%m-%d %H:%M:%f','now'))`).bind(auth.player.id,totalErrorMs,totalErrorMs,worstErrorMs,bestSingleErrorMs).run();}
        else if(better){newRecord=true;await DB.prepare(`UPDATE pointblind_v1_scores SET best_total_error_ms=?,games_played=games_played+1,last_total_error_ms=?,best_worst_error_ms=?,best_single_error_ms=?,achieved_at=strftime('%Y-%m-%d %H:%M:%f','now'),updated_at=CURRENT_TIMESTAMP WHERE player_id=?`).bind(totalErrorMs,totalErrorMs,worstErrorMs,bestSingleErrorMs,auth.player.id).run();}
        else await DB.prepare('UPDATE pointblind_v1_scores SET games_played=games_played+1,last_total_error_ms=?,updated_at=CURRENT_TIMESTAMP WHERE player_id=?').bind(totalErrorMs,auth.player.id).run();
      }
    }else{try{attempts=JSON.parse(String(run.attempts_json||'[]'))||[]}catch{attempts=[]}}
    if(firstFinish)await recordAdminActivity(DB,env,{eventType:'game_pointblind',category:'game',actorId:auth.player.id,actorName:String(auth.player.name||''),title:`${auth.player.name} terminó PUNTO CIEGO 30`,detail:`${(totalErrorMs/1000).toFixed(3)} s de error${newRecord?' · nuevo récord':''}`,meta:{game:'blind',totalErrorMs,newRecord,freePlay}});
    const awards=await settlePointBlindContest(DB),leaderboard=await pointBlindLeaderboard(DB,auth.player.id),mine=leaderboard.find(entry=>entry.playerId===auth.player.id)||null,officialBest=mine?Math.max(0,Number(mine.score||0)):null;
    const beatsOfficial=Boolean(freePlay&&mine&&pointBlindRunBeats({best_total_error_ms:mine.score,best_worst_error_ms:mine.worstErrorMs,best_single_error_ms:mine.bestSingleErrorMs},totalErrorMs,worstErrorMs,bestSingleErrorMs));
    return json({ok:true,rulesVersion:POINTBLIND_CONTEST.rulesVersion,score:totalErrorMs,totalErrorMs,worstErrorMs,bestSingleErrorMs,durationMs,attempts,newRecord:freePlay?false:newRecord,freePlay,beatOfficialBest:beatsOfficial,
      phase:Date.now()<POINTBLIND_CONTEST.closesAtMs?'open':'closed',closesAt:POINTBLIND_CONTEST.closesAt,rewards:POINTBLIND_CONTEST.rewards.map(item=>({...item})),totalCash:POINTBLIND_CONTEST.rewards.reduce((sum,item)=>sum+item.cash,0),
      playerBest:officialBest,playerRank:mine?.rank||null,awards,winner:awards[0]||null,leaderboard});
  }

  if (route === 'safe/leaderboard' && method === 'GET') {
    const auth = await requirePlayer(request, DB); if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en BOTÍN 30.' }, 403);
    const awards = await settleSafeContest(DB), leaderboard = await safeLeaderboard(DB, auth.player.id), mine = leaderboard.find((entry) => entry.playerId === auth.player.id) || null;
    return json({ ok:true, rulesVersion:SAFE_CONTEST.rulesVersion, phase:Date.now() < SAFE_CONTEST.closesAtMs ? 'open' : 'closed', closesAt:SAFE_CONTEST.closesAt,
      rewards:SAFE_CONTEST.rewards.map((item) => ({ ...item })), totalCash:SAFE_CONTEST.rewards.reduce((sum,item) => sum + item.cash, 0),
      playerBest:mine?.score || 0, playerRank:mine?.rank || null, awards, winner:awards[0] || null, leaderboard });
  }

  if (route === 'safe/start' && method === 'POST') {
    const auth = await requirePlayer(request, DB); if (auth.error) return auth.error;
    if (auth.player.attendance !== 'yes') return json({ error:'NOT_CONFIRMED', message:'Únete a la banda para entrar en BOTÍN 30.' }, 403);
    const body = await requestBody(request);
    if (Number(body.rulesVersion) !== SAFE_CONTEST.rulesVersion) return json({ error:'UPDATE_REQUIRED', message:'Actualiza la página para cargar el nuevo BOTÍN 30.' }, 409);
    const nowMs=Date.now(), freePlay=nowMs>=SAFE_CONTEST.closesAtMs; if(freePlay)await settleSafeContest(DB,nowMs); const runId=crypto.randomUUID();
    await DB.prepare('INSERT INTO safe_loot_v8_runs (run_id, player_id, started_at_ms, rules_version) VALUES (?, ?, ?, ?)').bind(runId,auth.player.id,nowMs,SAFE_CONTEST.rulesVersion).run();
    return json({ok:true,runId,rulesVersion:SAFE_CONTEST.rulesVersion,startedAt:nowMs,freePlay,phase:freePlay?'closed':'open',closesAt:SAFE_CONTEST.closesAt,rewards:SAFE_CONTEST.rewards.map((item)=>({...item}))});
  }

  if (route === 'safe/finish' && method === 'POST') {
    const auth=await requirePlayer(request,DB); if(auth.error)return auth.error; const body=await requestBody(request),runId=cleanString(body.runId,80);
    const run=await DB.prepare('SELECT * FROM safe_loot_v8_runs WHERE run_id = ? AND player_id = ? LIMIT 1').bind(runId,auth.player.id).first();
    if(!run)return json({error:'RUN_NOT_FOUND',message:'Ese intento de BOTÍN 30 ya no está disponible.'},404);
    const runStartedMs=Number(run.started_at_ms||0),freePlay=runStartedMs>=SAFE_CONTEST.closesAtMs;
    let precisionBps=run.average_bps==null?NaN:Number(run.average_bps),worstBps=Math.max(0,Number(run.worst_bps||0)),perfects=Math.max(0,Number(run.perfects||0)),durationMs=Math.max(0,Number(run.duration_ms||0)),outcome=String(run.outcome||''),attempts=[],newRecord=false,firstFinish=false;
    if(!Number.isFinite(precisionBps)){
      if(Number(body.rulesVersion)!==SAFE_CONTEST.rulesVersion||Number(run.rules_version)!==SAFE_CONTEST.rulesVersion)return json({error:'UPDATE_REQUIRED',message:'Actualiza la página para cargar el nuevo BOTÍN 30.'},409);
      const reportedDuration=Math.max(0,Math.floor(Number(body.durationMs)||0)),endMs=freePlay?Date.now():Math.min(Date.now(),SAFE_CONTEST.closesAtMs),serverElapsed=Math.max(0,Math.min(SAFE_CONTEST.maxRunMs,endMs-runStartedMs));
      if(reportedDuration<globalThis.DANI_SAFE_ENGINE.READY_MS||reportedDuration>globalThis.DANI_SAFE_ENGINE.MAX_DURATION_MS||reportedDuration>serverElapsed+1500)return json({error:'INVALID_SAFE_TIME',message:'La duración registrada no es válida.'},409);
      let verified;try{verified=globalThis.DANI_SAFE_ENGINE.replay(runId,Array.isArray(body.events)?body.events:[],reportedDuration);}catch(error){return json({error:'INVALID_SAFE_RUN',message:error.message||'No se pudo validar BOTÍN 30.'},400);}
      precisionBps=Math.max(0,Number(verified.averageBps||0));worstBps=Math.max(0,Number(verified.worstBps||0));perfects=Math.max(0,Number(verified.perfects||0));durationMs=reportedDuration;outcome=String(verified.outcome||'locked');attempts=verified.attempts||[];
      const stored=await DB.prepare(`UPDATE safe_loot_v8_runs SET duration_ms=?, average_bps=?, worst_bps=?, perfects=?, outcome=?, attempts_json=?, event_log_json=?, finished_at=CURRENT_TIMESTAMP WHERE run_id=? AND average_bps IS NULL`)
        .bind(durationMs,precisionBps,worstBps,perfects,outcome,JSON.stringify(attempts),JSON.stringify(body.events||[]),runId).run();
      firstFinish=Number(stored?.meta?.changes||0)>0;
      if(firstFinish&&!freePlay){
        const existing=await DB.prepare('SELECT best_precision_bps,best_worst_bps,best_perfects,best_duration_ms FROM safe_loot_v8_scores WHERE player_id=? LIMIT 1').bind(auth.player.id).first(),better=safeRunBeats(existing,precisionBps,worstBps,perfects,durationMs);
        if(!existing){newRecord=precisionBps>0;await DB.prepare(`INSERT INTO safe_loot_v8_scores (player_id,best_precision_bps,games_played,last_precision_bps,best_worst_bps,best_perfects,best_duration_ms,achieved_at) VALUES(?,?,1,?,?,?,?,strftime('%Y-%m-%d %H:%M:%f','now'))`).bind(auth.player.id,precisionBps,precisionBps,worstBps,perfects,durationMs).run();}
        else if(better){newRecord=true;await DB.prepare(`UPDATE safe_loot_v8_scores SET best_precision_bps=?,games_played=games_played+1,last_precision_bps=?,best_worst_bps=?,best_perfects=?,best_duration_ms=?,achieved_at=strftime('%Y-%m-%d %H:%M:%f','now'),updated_at=CURRENT_TIMESTAMP WHERE player_id=?`).bind(precisionBps,precisionBps,worstBps,perfects,durationMs,auth.player.id).run();}
        else await DB.prepare('UPDATE safe_loot_v8_scores SET games_played=games_played+1,last_precision_bps=?,updated_at=CURRENT_TIMESTAMP WHERE player_id=?').bind(precisionBps,auth.player.id).run();
      }
    } else {try{attempts=JSON.parse(String(run.attempts_json||'[]'))||[]}catch{attempts=[]}}
    if(firstFinish)await recordAdminActivity(DB,env,{eventType:'game_safe',category:'game',actorId:auth.player.id,actorName:String(auth.player.name||''),title:`${auth.player.name} terminó BOTÍN 30`,detail:`${(Math.max(0,Number(precisionBps||0))/100).toFixed(1)}% precisión${newRecord?' · nuevo récord':''}`,meta:{game:'safe',precisionBps,newRecord,freePlay,outcome}});
    const awards=await settleSafeContest(DB),leaderboard=await safeLeaderboard(DB,auth.player.id),mine=leaderboard.find((entry)=>entry.playerId===auth.player.id)||null,officialBest=Math.max(0,Number(mine?.score||0));
    const beatsOfficial=Boolean(freePlay&&mine&&safeRunBeats({best_precision_bps:mine.score,best_worst_bps:mine.worstBps,best_perfects:mine.perfects,best_duration_ms:mine.durationMs},precisionBps,worstBps,perfects,durationMs));
    return json({ok:true,rulesVersion:SAFE_CONTEST.rulesVersion,score:precisionBps,precisionBps,worstBps,perfects,durationMs,outcome,attempts,newRecord:freePlay?false:newRecord,freePlay,beatOfficialBest:beatsOfficial,
      phase:Date.now()<SAFE_CONTEST.closesAtMs?'open':'closed',closesAt:SAFE_CONTEST.closesAt,rewards:SAFE_CONTEST.rewards.map((item)=>({...item})),totalCash:SAFE_CONTEST.rewards.reduce((sum,item)=>sum+item.cash,0),
      playerBest:officialBest,playerRank:mine?.rank||null,awards,winner:awards[0]||null,leaderboard});
  }

  if (route === 'score/wanted' && method === 'GET') {
    const result = await DB.prepare(`SELECT id, crew_number, name, avatar, bio, specialties_json, special_ability, wanted_score, game_stars, mission_respect, wallet_balance, updated_at
      FROM players WHERE attendance = 'yes'
      ORDER BY game_stars DESC, updated_at ASC, crew_number ASC`).all();
    return json({ ok: true, players: (result.results || []).map(publicPlayer) });
  }

  if (route === 'score/wanted' && method === 'POST') {
    return json({ error:'RESULTS_FROM_GAMES', message:'Las estrellas se registran desde la ficha de cada juego.' }, 410);
  }

  if (route === 'admin/dashboard' && method === 'GET') {
    if (!env.ADMIN_PIN) return json({ error:'ADMIN_NOT_CONFIGURED', message:'Falta configurar ADMIN_PIN.' },503);
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const [dashboard,activity,operations]=await Promise.all([adminDashboard(DB),adminActivityFeed(DB,40),adminOperationsStatus(DB)]);
    return json({ok:true,dashboard,activity,operations,emailProvider:adminEmailProvider(env,dashboard.notifications||{})});
  }

  if (route === 'admin/activity' && method === 'GET') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    return json({ok:true,activity:await adminActivityFeed(DB,80)});
  }

  if (route === 'admin/notifications' && method === 'GET') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const settings=await readAdminNotificationSettings(DB);
    return json({ok:true,settings,provider:adminEmailProvider(env,settings)});
  }

  if (route === 'admin/notifications' && method === 'PATCH') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const body=await requestBody(request),mode=['off','daily','hybrid','immediate'].includes(String(body.mode||''))?String(body.mode):'hybrid';
    await DB.prepare(`UPDATE admin_notification_settings SET enabled=?,mode=?,immediate_rsvp=?,immediate_decline=?,immediate_games=?,daily_digest=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
      .bind(body.enabled?1:0,mode,body.immediateRsvp?1:0,body.immediateDecline!==false?1:0,body.immediateGames?1:0,body.dailyDigest!==false?1:0).run();
    const settings=await readAdminNotificationSettings(DB);
    return json({ok:true,settings,provider:adminEmailProvider(env,settings)});
  }

  if (route === 'admin/notifications/test' && method === 'POST') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const settings=await readAdminNotificationSettings(DB),recipient=resolveAdminRecipient(env,settings); if(!recipient)return json({error:'NO_RECIPIENT',message:'Falta ADMIN_TO_EMAIL en Cloudflare.'},400);
    const result=await sendAdminEmail(DB,env,{eventType:'test',to:recipient,subject:'Operación 30 · Email de prueba',html:'<div style="font-family:Arial,sans-serif"><h2>Operación 30</h2><p>Las notificaciones del panel de control están conectadas correctamente.</p></div>'});
    if(!result.ok)return json({error:'EMAIL_NOT_SENT',message:result.status==='not_configured'?(result.error||'Falta configurar el email en Cloudflare.'):(result.error||'No se pudo enviar el email.'),providerStatus:result.statusCode||0},503);
    return json({ok:true,to:maskAdminEmail(recipient),from:resolveAdminFromEmail(env)});
  }

  if (route === 'admin/notifications/digest' && method === 'POST') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const settings=await readAdminNotificationSettings(DB),recipient=resolveAdminRecipient(env,settings); if(!recipient)return json({error:'NO_RECIPIENT',message:'Falta ADMIN_TO_EMAIL en Cloudflare.'},400);
    const digest=await buildAdminDigest(DB),result=await sendAdminEmail(DB,env,{eventType:'daily_digest',to:recipient,subject:digest.subject,html:digest.html});
    if(!result.ok)return json({error:'EMAIL_NOT_SENT',message:result.status==='not_configured'?(result.error||'Falta configurar el email en Cloudflare.'):(result.error||'No se pudo enviar el resumen.'),providerStatus:result.statusCode||0},503);
    return json({ok:true,count:digest.activity.length,to:maskAdminEmail(recipient)});
  }

  if (route === 'admin/export' && method === 'GET') {
    if (!adminAllowed(request,env)) return json({ error:'ADMIN_DENIED', message:'PIN de administrador incorrecto.' },401);
    const [players,operations,activity,dashboard,settings]=await Promise.all([readAdminPlayers(DB),adminOperationsStatus(DB),adminActivityFeed(DB,100),adminDashboard(DB),readAdminNotificationSettings(DB)]);
    return json({ok:true,exportedAt:new Date().toISOString(),dashboard,players,operations,activity,notificationSettings:settings});
  }

  if (route === 'admin/crew' && method === 'GET') {
    if (!env.ADMIN_PIN) return json({ error: 'ADMIN_NOT_CONFIGURED', message: 'Falta configurar el secreto ADMIN_PIN en Cloudflare.' }, 503);
    if (!adminAllowed(request, env)) return json({ error: 'ADMIN_DENIED', message: 'PIN de administrador incorrecto.' }, 401);
    const players = await readAdminPlayers(DB);
    return json({ ok: true, players });
  }

  if (route === 'admin/arcade' && method === 'GET') {
    if (!env.ADMIN_PIN) return json({ error: 'ADMIN_NOT_CONFIGURED', message: 'Falta configurar el secreto ADMIN_PIN en Cloudflare.' }, 503);
    if (!adminAllowed(request, env)) return json({ error: 'ADMIN_DENIED', message: 'PIN de administrador incorrecto.' }, 401);
    const operations = await adminOperationsStatus(DB);
    return json({ ok:true, ...operations.fuga, operations });
  }

  if (route === 'admin/database/reset' && method === 'POST') {
    if (!env.ADMIN_PIN) return json({ error: 'ADMIN_NOT_CONFIGURED', message: 'Falta configurar el secreto ADMIN_PIN en Cloudflare.' }, 503);
    if (!adminAllowed(request, env)) return json({ error: 'ADMIN_DENIED', message: 'PIN de administrador incorrecto.' }, 401);
    const body = await requestBody(request);
    const allowed=new Set(['seed','empty','games','progress','activity','production']);
    const mode=allowed.has(String(body.mode||''))?String(body.mode):'empty';
    if(mode==='seed')await seedAdminTestData(DB);
    else if(mode==='games')await clearAdminGameData(DB);
    else if(mode==='progress')await resetAdminGuestProgress(DB);
    else if(mode==='activity')await clearAdminActivity(DB);
    else if(mode==='production')await prepareAdminProduction(DB);
    else await clearApplicationData(DB);
    const players=await readAdminPlayers(DB);
    if(!['activity','production'].includes(mode))await recordAdminActivity(DB,env,{eventType:'admin_reset',severity:'admin',title:'Operación de datos ejecutada',detail:`Modo: ${mode}`,meta:{mode,count:players.length}});
    return json({ok:true,mode,count:players.length,testPin:mode==='seed'?'1234':null,players,dashboard:await adminDashboard(DB)});
  }

  if (route === 'admin/delete-player' && method === 'POST') {
    if (!env.ADMIN_PIN) return json({ error: 'ADMIN_NOT_CONFIGURED', message: 'Falta configurar el secreto ADMIN_PIN en Cloudflare.' }, 503);
    if (!adminAllowed(request, env)) return json({ error: 'ADMIN_DENIED', message: 'PIN de administrador incorrecto.' }, 401);
    const body = await requestBody(request);
    const playerId = cleanString(body.playerId, 80);
    const row = await DB.prepare('SELECT id, name FROM players WHERE id = ? LIMIT 1').bind(playerId).first();
    if (!row) return json({ error: 'NOT_FOUND', message: 'El jugador ya no existe.' }, 404);
    await DB.batch([
      DB.prepare('DELETE FROM player_sessions WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM player_respect WHERE giver_id = ? OR receiver_id = ?').bind(playerId, playerId),
      DB.prepare('DELETE FROM clandestine_championship_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM pointblind_v1_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM pointblind_v1_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM pointblind_v1_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM operation_infiltration_v6_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM operation_infiltration_v6_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM operation_infiltration_v6_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v8_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v8_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v8_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v7_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v7_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v7_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v6_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v6_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v6_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v5_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v5_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_loot_v5_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_sequence_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_sequence_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_sequence_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_skill_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_skill_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM safe_skill_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v11_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v11_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v11_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v7_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v7_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v7_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v5_podium_awards WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v5_runs WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM crossing_v5_scores WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM economy_events WHERE player_id = ?').bind(playerId),
      DB.prepare('DELETE FROM players WHERE id = ?').bind(playerId)
    ]);
    await recordAdminActivity(DB,env,{eventType:'admin_delete_player',severity:'admin',actorId:playerId,actorName:String(row.name||''),title:'Invitado eliminado',detail:String(row.name||'')});
    return json({ ok: true, deletedPlayerId: playerId });
  }

  if (route === 'admin/reset-pin' && method === 'POST') {
    if (!env.ADMIN_PIN) return json({ error: 'ADMIN_NOT_CONFIGURED', message: 'Falta configurar el secreto ADMIN_PIN en Cloudflare.' }, 503);
    if (!adminAllowed(request, env)) return json({ error: 'ADMIN_DENIED', message: 'PIN de administrador incorrecto.' }, 401);
    const body = await requestBody(request);
    const playerId = cleanString(body.playerId, 80);
    const requested = cleanString(body.newPin, 4);
    const newPin = /^\d{4}$/.test(requested) ? requested : randomPin();
    const row = await DB.prepare('SELECT id FROM players WHERE id = ? LIMIT 1').bind(playerId).first();
    if (!row) return json({ error: 'NOT_FOUND' }, 404);
    const pinSalt = randomHex(16);
    const pinHash = await hashPin(newPin, pinSalt);
    await DB.batch([
      DB.prepare('UPDATE players SET pin_hash = ?, pin_salt = ?, session_hash = ?, failed_attempts = 0, locked_until = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?').bind(pinHash, pinSalt, await sha256(randomHex()), playerId),
      DB.prepare('DELETE FROM player_sessions WHERE player_id = ?').bind(playerId)
    ]);
    await recordAdminActivity(DB,env,{eventType:'admin_reset_pin',severity:'admin',actorId:playerId,title:'PIN restablecido',detail:'Se generó un PIN temporal para un invitado.'});
    return json({ ok: true, temporaryPin: newPin });
  }

  return json({ error: 'NOT_FOUND' }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
      try {
        return await handleApi(request, env);
      } catch (error) {
        console.error('Birthday API error', error);
        return json({ error: 'SERVER_ERROR', message: 'Error temporal en Mission Control.' }, 500);
      }
    }
    const assetResponse = await env.ASSETS.fetch(request);
    // Los despliegues de la web cambian con mucha frecuencia durante las pruebas.
    // Evitamos que Safari/Chrome mantengan un index.html anterior (que podría
    // apuntar a una estructura de interfaz ya obsoleta). JS/CSS se revalidan.
    if (request.method === 'GET' && assetResponse) {
      const headers = new Headers(assetResponse.headers);
      const path = url.pathname.toLowerCase();
      if (path === '/' || path.endsWith('.html')) {
        headers.set('cache-control', 'no-store, max-age=0, must-revalidate');
        headers.set('pragma', 'no-cache');
        headers.set('expires', '0');
      } else if (path.endsWith('.js') || path.endsWith('.css')) {
        headers.set('cache-control', 'no-cache, max-age=0, must-revalidate');
      }
      return new Response(assetResponse.body, {
        status: assetResponse.status,
        statusText: assetResponse.statusText,
        headers
      });
    }
    return assetResponse;
  }
};
