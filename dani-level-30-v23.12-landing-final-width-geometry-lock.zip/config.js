window.BIRTHDAY_CONFIG = {
  host: "Dani",
  level: 30,
  dateLabel: "Sábado 12 de diciembre de 2026",
  officialBirthdayLabel: "Miércoles 9 de diciembre de 2026",
  timeLabel: "13:00 h",
  eventStart: "2026-12-12T13:00:00+01:00",
  eventTimeZone: "Europe/Madrid",
  developmentMode: false,
  // Longitud visual del PIN de administración. El secreto real sigue viviendo sólo en Cloudflare.
  adminPinLength: 4,
  // Acceso temporal para probar El Golpe antes de la fecha oficial.
  // Cambiar a false cuando terminen las pruebas.
  heistTestAccess: true,
  partyModeWindow: {
    start: "2026-12-12T13:00:00+01:00",
    end: "2026-12-13T08:00:00+01:00"
  },
  venueLabel: "Mi Bajo · Alfafar",

  // La dirección exacta ya no vive en el frontend. Se entrega desde Cloudflare
  // solo a jugadores confirmados que hayan completado el hack.
  location: {
    name: "MI BAJO · ALFAFAR",
    parking: { name: "PARKING MERCADONA ALFAFAR" }
  },

  // Códigos provisionales solo para pruebas. En producción se pueden cambiar
  // sin tocar el resto de la web.
  missions: {
    "STAR30": {
      type: "JUEGO · LOS 30 MÁS BUSCADOS",
      title: "Pasa las estrellas. Que no te pille la sirena.",
      intro: "Cada participante entra en juego con dos estrellas de pinza. Durante 20–30 minutos tendrás que intentar quitártelas de encima sin levantar sospechas.",
      rules: [
        "Coloca discretamente tus estrellas en la ropa exterior de otros jugadores: mangas, bajos o bolsillos exteriores.",
        "Si descubres que te han puesto una estrella, puedes intentar pasársela a otra persona.",
        "No vale esconderlas, tirarlas ni guardarlas en bolsillos para sacarlas del juego.",
        "Si te pillan mientras intentas colocar una estrella, te la quedas y tendrás que buscar otra oportunidad.",
        "Cuando suene una única sirena: manos arriba y nadie puede mover ninguna estrella."
      ],
      end: "Pierde quien tenga más estrellas cuando suene la sirena. También cuentan las que todavía tengas en la mano. Si hay empate, se comparte la derrota.",
      reward: "FOTO POLICIAL DEL MÁS BUSCADO",
      countsForCompetition: true,
      economy: { mode: "pin-stars", maxStars: 30, resultDriven: true }
    },
    "CAR30": {
      type: "MINIJUEGO · APARCA COMO PUEDAS",
      title: "Misión: aparcar sin tocar el coche",
      intro: "Tendrás un coche de juguete unido a una cuerda que se enrolla en un lápiz. Parece sencillo hasta que empiezas.",
      rules: [
        "Enrolla la cuerda usando el lápiz para mover el coche.",
        "Lleva el vehículo hasta la plaza marcada sobre la mesa.",
        "No puedes coger ni recolocar el coche directamente con la mano.",
        "Dani anunciará cuándo termina el turno."
      ],
      end: "La misión termina cuando el coche queda correctamente dentro de la plaza o cuando se agota tu turno.",
      reward: "OBJETIVO: APARCAMIENTO COMPLETADO",
      countsForCompetition: true,
      economy: { mode: "car-retry", retryCost: 100, resultDriven: true }
    },
    "SAVE30": {
      type: "ENCARGO · PUNTO DE GUARDADO",
      title: "Un recuerdo para el nivel 31",
      intro: "Deja un recuerdo y un plan para antes de los 31.",
      rules: [
        "Escribe una anécdota que compartamos o un recuerdo que merezca la pena guardar.",
        "Añade una propuesta de plan realista para hacer antes de que llegue el nivel 31.",
        "Deposita la tarjeta en el punto de guardado."
      ],
      end: "La partida se guarda cuando la tarjeta entra en la caja. Se recuperará más adelante.",
      reward: "+$100 · +1 RESPETO",
      countsForCompetition: false,
      economy: { complete: { cash: 100, respect: 1, stars: 0 } }
    }
  }
};
