/* BOTÍN 30 · precision bar rules V10.
 * Five timing attempts on a visible horizontal bar. The marker bounces left/right;
 * every round uses the exact same center target, and difficulty comes only from speed.
 * There is no gameplay timeout: a player may wait as long as needed before tapping.
 * Ranking: highest average precision, then highest worst attempt, then most perfects.
 */
(function(root){'use strict';
const VERSION=10;
const READY_MS=900;
const ROUNDS=5;
const FEEDBACK_MS=900;
const FINISH_MS=1000;
const ROUND_TIMEOUT_MS=0; // Compatibility export: V9 never auto-locks a round.
const MAX_EVENTS=5;
const MAX_DURATION_MS=60*60*1000; // Technical anti-abuse ceiling only; never awards 0 or advances a round.
const TARGETS=Object.freeze([0.50,0.50,0.50,0.50,0.50]);
const TRAVEL_MS=Object.freeze([1700,1300,950,700,520]);
const PERFECT_SNAP=0; // V10: 100.00% exists only at the mathematical center.
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function hashSeed(value){const s=String(value||'');let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}h^=h>>>16;h=Math.imul(h,2246822507)>>>0;h^=h>>>13;h=Math.imul(h,3266489909)>>>0;h^=h>>>16;return h>>>0;}
function startPhaseFor(runId,round){const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),h=hashSeed(`BOTIN30:V${VERSION}:${String(runId||'preview')}:${idx}`);return(h/4294967296)*2;}
function markerX(round,elapsedMs,runId='preview'){
  const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),travel=TRAVEL_MS[idx],t=Math.max(0,Number(elapsedMs)||0),phase=(startPhaseFor(runId,idx)+t/travel)%2;
  return clamp(phase<=1?phase:2-phase,0,1);
}
function elapsedForX(runId,round,x){const idx=clamp(Math.floor(Number(round)||0),0,ROUNDS-1),desired=clamp(Number(x)||0,0,1),phase=startPhaseFor(runId,idx),a=(desired-phase+2)%2,b=((2-desired)-phase+2)%2;return Math.min(a,b)*TRAVEL_MS[idx];}
function centerElapsedFor(runId,round){return elapsedForX(runId,round,.5);}
function targetFor(){return 0.5;}
function precisionFor(round,x){
  const dist=Math.abs(clamp(Number(x)||0,0,1)-0.5),raw=clamp(1-dist/.5,0,1);
  if(dist<9.999e-7)return 10000;
  return Math.min(9999,Math.floor(raw*10000+1e-9));
}
function qualityLabel(bps){const p=Math.max(0,Number(bps)||0);if(p>=9500)return'PERFECTO';if(p>=8500)return'LIMPIO';if(p>=7000)return'AJUSTADO';return'FORZADO';}
function outcomeFor(avgBps){const p=Math.max(0,Number(avgBps)||0);if(p>=10000)return'perfect';if(p>=8500)return'clean';if(p>=7000)return'forced';return'locked';}
function create(runId='preview'){
 return {version:VERSION,runId:String(runId||'preview'),timeMs:0,round:0,roundStartMs:READY_MS,roundLocked:false,feedbackUntil:0,finishAt:0,over:false,reason:'',attempts:[],events:[],fx:[]};
}
function phase(s){if(!s)return'ended';if(s.over)return'ended';if(s.finishAt>0)return'finishing';if(s.timeMs<READY_MS)return'ready';if(s.roundLocked||s.timeMs<s.roundStartMs)return'feedback';return'active';}
function currentMarker(s,atMs=s?.timeMs||0){if(!s||s.round>=ROUNDS)return 0.5;return markerX(s.round,Math.max(0,Number(atMs)-Number(s.roundStartMs||0)),s.runId);}
function averageBps(s){if(!s?.attempts?.length)return 0;return Math.round(s.attempts.reduce((a,b)=>a+Math.max(0,Number(b.precisionBps)||0),0)/s.attempts.length);}
function worstBps(s){if(!s?.attempts?.length)return 0;return Math.min(...s.attempts.map(a=>Math.max(0,Number(a.precisionBps)||0)));}
function perfects(s){return(s?.attempts||[]).filter(a=>Number(a.precisionBps)>=9500).length;}
function exactHundreds(s){return(s?.attempts||[]).filter(a=>Number(a.precisionBps)>=10000).length;}
function pushEvent(s,e){if(s.events.length>=MAX_EVENTS)return false;s.events.push(e);return true;}
function lockAttempt(s,t,{record=true}={}){
 if(s.over||s.finishAt>0||s.round>=ROUNDS)return{accepted:false,reason:'over'};
 const x=currentMarker(s,t),precisionBps=precisionFor(s.round,x),eventTime=Math.round(Number(t)*1000000)/1000000,attempt={round:s.round+1,t:eventTime,x:Math.round(x*10000000)/10000000,target:0.5,precisionBps,label:qualityLabel(precisionBps),timeout:false};
 if(record&&!pushEvent(s,{t:eventTime,type:'tap'}))return{accepted:false,reason:'event-limit'};
 s.attempts.push(attempt);s.fx.push({type:'attempt',...attempt,averageBps:averageBps(s)});s.roundLocked=true;s.feedbackUntil=t+FEEDBACK_MS;s.round+=1;
 if(s.round>=ROUNDS){s.finishAt=t+FINISH_MS;s.feedbackUntil=s.finishAt;}
 else s.roundStartMs=s.feedbackUntil;
 return{accepted:true,attempt,averageBps:averageBps(s),round:s.round};
}
function advance(s,toMs){
 if(!s||s.over)return s;
 const target=clamp(Number(toMs)||0,s.timeMs,MAX_DURATION_MS);s.timeMs=target;
 if(s.finishAt>0&&s.timeMs>=s.finishAt){s.timeMs=s.finishAt;s.over=true;s.reason='complete';return s;}
 if(s.roundLocked&&s.timeMs>=s.feedbackUntil)s.roundLocked=false;
 return s;
}
function tap(s,timeMs,{record=true}={}){
 if(!s||s.over)return{accepted:false,reason:'over'};advance(s,timeMs);if(s.over)return{accepted:false,reason:'over'};
 if(phase(s)!=='active')return{accepted:false,reason:phase(s)};
 return lockAttempt(s,s.timeMs,{record});
}
function result(s){
 const avg=averageBps(s),worst=worstBps(s),done=s.attempts.length>=ROUNDS;
 return {scoreBps:avg,averageBps:avg,worstBps:worst,perfects:perfects(s),exactHundreds:exactHundreds(s),attempts:s.attempts.map(a=>({...a})),outcome:done?outcomeFor(avg):'pending',durationMs:Math.ceil(s.timeMs||0),complete:Boolean(s.over&&s.reason==='complete'&&done)};
}
function replay(runId,events,durationMs){
 if(!Array.isArray(events)||events.length>MAX_EVENTS)throw Error('Registro de BOTÍN inválido');
 const duration=Number(durationMs);if(!Number.isFinite(duration)||duration<READY_MS||duration>MAX_DURATION_MS)throw Error('Duración de BOTÍN inválida');
 const s=create(runId);let prev=-1;
 for(const raw of events){const t=Number(raw?.t);if(!Number.isFinite(t)||t<0||t<prev||t>MAX_DURATION_MS)throw Error('Tiempo de intento inválido');prev=t;if(String(raw?.type||'tap')!=='tap')throw Error('Intento inválido');const out=tap(s,t,{record:false});if(!out.accepted)throw Error('Intento fuera de ronda');}
 advance(s,duration);const r=result(s);if(!r.complete)throw Error('BOTÍN incompleto');return r;
}
function drain(s){return s?.fx?.splice(0)||[];}
const api={VERSION,READY_MS,ROUNDS,FEEDBACK_MS,FINISH_MS,ROUND_TIMEOUT_MS,MAX_EVENTS,MAX_DURATION_MS,TARGETS,TRAVEL_MS,PERFECT_SNAP,hashSeed,startPhaseFor,elapsedForX,centerElapsedFor,markerX,targetFor,precisionFor,qualityLabel,outcomeFor,phase,currentMarker,averageBps,worstBps,perfects,create,advance,tap,result,replay,drain};
root.DANI_SAFE_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
