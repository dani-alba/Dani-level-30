(() => {
  'use strict';
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
  const $ = (selector, root=document) => root.querySelector(selector);
  const body = document.body;
  if (!body) return;
  body.classList.add('motion-system');

  // A brief layered entrance once per browser session. This is atmosphere only.
  try {
    const key = 'dani30-motion-entry-v2311';
    if (!reduced && !sessionStorage.getItem(key)) {
      body.classList.add('motion-first-entry');
      sessionStorage.setItem(key, '1');
      window.setTimeout(() => body.classList.remove('motion-first-entry'), 1500);
    }
  } catch {}

  const retrigger = (node, className, duration=650) => {
    if (!node || reduced) return;
    node.classList.remove(className);
    void node.offsetWidth;
    node.classList.add(className);
    window.setTimeout(() => node.classList.remove(className), duration);
  };

  // Operation accordion: animate only the newly opened phase.
  document.addEventListener('dani:disclosure-change', (event) => {
    const id = event.detail?.openId;
    if (!event.detail?.group || !id) return;
    retrigger(document.getElementById(`operationStage${id}`), 'motion-stage-open', 620);
  });

  // Dialogs get one short entrance choreography each time they actually open.
  const watchDialog = (id) => {
    const dialog = document.getElementById(id);
    if (!dialog) return;
    let wasOpen = Boolean(dialog.open);
    new MutationObserver(() => {
      const open = Boolean(dialog.open);
      if (open && !wasOpen) retrigger(dialog, 'motion-dialog-enter', 760);
      wasOpen = open;
    }).observe(dialog, { attributes:true, attributeFilter:['open'] });
  };
  watchDialog('crewDirectoryDialog');
  watchDialog('clandestineDialog');

  // Profile already slides in on mobile; this adds only the content/identity settle.
  const profilePanel = document.getElementById('crewProfilePanel');
  if (profilePanel) {
    let wasHidden = profilePanel.hidden;
    new MutationObserver(() => {
      const hidden = profilePanel.hidden;
      if (!hidden && wasHidden) retrigger(profilePanel, 'motion-profile-enter', 760);
      wasHidden = hidden;
    }).observe(profilePanel, { attributes:true, attributeFilter:['hidden'] });
  }

  // Identity changes should feel deliberate rather than text abruptly swapping.
  const hudLabel = document.getElementById('hudMenuLabel');
  const hudToggle = document.getElementById('hudMenuToggle');
  if (hudLabel && hudToggle) {
    let initial = true;
    new MutationObserver(() => {
      if (initial) { initial = false; return; }
      retrigger(hudToggle, 'motion-identity-swap', 560);
    }).observe(hudLabel, { childList:true, characterData:true, subtree:true });
    window.setTimeout(() => { initial = false; }, 0);
  }

  // Game cards answer the tap before the loader takes over.
  document.addEventListener('click', (event) => {
    const play = event.target.closest?.('.clandestine-play');
    if (!play) return;
    retrigger(play.closest('.clandestine-game'), 'motion-launch', 340);
  }, true);

  // Results reveal in a short hierarchy whenever any game unhides its shared result shell.
  document.querySelectorAll('.operation-result').forEach((result) => {
    let wasHidden = result.hidden;
    new MutationObserver(() => {
      const hidden = result.hidden;
      if (!hidden && wasHidden) retrigger(result, 'motion-result-enter', 900);
      wasHidden = hidden;
    }).observe(result, { attributes:true, attributeFilter:['hidden'] });
  });

  let inviteTransitionCleanup = null;
  const inviteTimers = new Set();

  const laterInvite = (fn, delay) => {
    const id = window.setTimeout(() => { inviteTimers.delete(id); fn(); }, delay);
    inviteTimers.add(id);
    return id;
  };
  const clearInviteTimers = () => {
    inviteTimers.forEach((id) => window.clearTimeout(id));
    inviteTimers.clear();
  };

  const prepareInviteTransition = () => {
    if (reduced) return null;
    window.clearTimeout(inviteTransitionCleanup);
    clearInviteTimers();
    body.classList.remove(
      'motion-first-entry','motion-invite-sun-focus','motion-invite-shell-final',
      'motion-invite-content-ready','motion-invite-split-ready','motion-invite-settled'
    );
    const hero = document.getElementById('home');
    if (!hero) return null;
    body.classList.add('motion-invite-entering');
    void hero.offsetWidth;
    return hero;
  };

  const playInviteTransition = ({ readiness = Promise.resolve() } = {}) => {
    if (reduced) return Promise.resolve();
    const hero = document.getElementById('home');
    if (!hero) return Promise.resolve();

    // Poster out -> sun hand-off -> final shell. The sun intentionally owns a longer beat
    // while the invitation surface hydrates behind it.
    laterInvite(() => body.classList.add('motion-invite-sun-focus'), 220);
    laterInvite(() => body.classList.add('motion-invite-shell-final'), 420);

    const minimumCinematicBeat = new Promise((resolve) => laterInvite(resolve, 1080));
    const ready = Promise.resolve(readiness).catch(() => undefined);
    const reveal = Promise.all([minimumCinematicBeat, ready]).then(() => {
      if (!body.classList.contains('motion-invite-entering')) return;
      body.classList.add('motion-invite-content-ready');
      // One frame lets the invitation copy establish its final layout before the two shells peel away.
      return new Promise((resolve) => window.requestAnimationFrame(() => {
        body.classList.add('motion-invite-split-ready');
        resolve();
      }));
    });
    return reveal;
  };

  const finishInviteTransition = () => {
    if (reduced) return;
    clearInviteTimers();
    body.classList.add('motion-invite-settled');
    inviteTransitionCleanup = window.setTimeout(() => {
      body.classList.remove(
        'motion-invite-entering','motion-invite-sun-focus','motion-invite-shell-final',
        'motion-invite-content-ready','motion-invite-split-ready','motion-invite-settled'
      );
    }, 240);
  };

  window.DANI_MOTION = Object.freeze({
    pulseCash() { retrigger(hudToggle, 'moment-cash', 620); },
    pulseProgress() { retrigger(document.getElementById('operationProgress'), 'moment-progress', 680); },
    prepareInviteTransition,
    playInviteTransition,
    finishInviteTransition
  });
})();
