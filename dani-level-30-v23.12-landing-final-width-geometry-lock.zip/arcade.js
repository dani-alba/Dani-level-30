(() => {
'use strict';
const core=window.DANI_CORE,crew=window.DANI_CREW,engine=window.DANI_ARCADE_ENGINE;
if(!core||!crew||!engine)return;
const {$,reducedMotion}=core;
const dialog=$('#arcadeDialog'),canvas=$('#arcadeCanvas'),ctx=canvas?.getContext('2d');
const state={status:null,championship:null,runId:'',running:false,preparing:false,finishing:false,generation:0,raf:0,eventTimer:0,impactTimer:0,debug:{enabled:false,seed:302026},game:null,paused:false,camera:0,accumulator:0,pendingFinish:null,audioCtx:null,audioMaster:null,noiseBuffer:null,audioPriorityUntil:0,lastNearMissSfxAt:-Infinity,lastArrestPulseAt:-Infinity,fireCueRows:new Set(),lastPoliceBand:'hidden',policeCueTimes:{signal:-Infinity,pressure:-Infinity,danger:-Infinity},pursuitVisual:{frontY:null,intensity:0},deathFx:null,nearMiss:null,lastNearMissTick:-999999,lastMaxRow:0,lastChainAnnounced:0,lastCrosswalkEventSeq:0,blockedUntil:0,blockedDir:null};
function profile(){return crew.getLocalProfile?.();}
function syncOperationLoadingViewport(){document.documentElement?.style?.setProperty?.('--operation-loading-height',`${Math.round(window.visualViewport?.height||window.innerHeight||700)}px`);}
function fmt(score){return `${Math.max(0,Number(score||0)).toLocaleString('es-ES')} ${Number(score)===1?'paso':'pasos'}`;}
function fmtResultValue(score){return Math.max(0,Number(score||0)).toLocaleString('es-ES');}
function setResultMessage(text=''){const node=$('#arcadeResultText');if(!node)return;node.textContent=text;node.hidden=!text;}
function escapeHtml(value=''){const span=document.createElement('span');span.textContent=String(value);return span.innerHTML;}
function rewardForRank(rank,data=state.status){return (data?.rewards||[]).find(item=>Number(item.rank)===Number(rank))||null;}
function ensureAudio(){const C=window.AudioContext||window.webkitAudioContext;if(!C)return null;try{if(!state.audioCtx)state.audioCtx=new C();if(!state.audioMaster){state.audioMaster=state.audioCtx.createGain();state.audioMaster.gain.value=1.9;state.audioMaster.connect(state.audioCtx.destination);}if(state.audioCtx.state==='suspended')state.audioCtx.resume?.().catch?.(()=>{});return state.audioCtx;}catch{return null;}}
function tone(freq,duration=.04,{gain=.018,type='sine',delay=0,endFreq=null}={}){const a=ensureAudio();if(!a)return;try{const o=a.createOscillator(),g=a.createGain(),at=a.currentTime+delay;o.type=type;o.frequency.setValueAtTime(freq,at);if(endFreq)o.frequency.exponentialRampToValueAtTime(Math.max(40,endFreq),at+duration);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),at+.006);g.gain.exponentialRampToValueAtTime(.0001,at+duration);o.connect(g);g.connect(state.audioMaster||a.destination);o.start(at);o.stop(at+duration+.01);}catch{}}
function noiseBurst(duration=.08,{gain=.006,center=700,startCenter=null,delay=0}={}){const a=ensureAudio();if(!a)return;try{if(!state.noiseBuffer||state.noiseBuffer.sampleRate!==a.sampleRate){const len=Math.max(1,Math.floor(a.sampleRate*.32)),buf=a.createBuffer(1,len,a.sampleRate),data=buf.getChannelData(0);for(let i=0;i<len;i++)data[i]=Math.random()*2-1;state.noiseBuffer=buf;}const src=a.createBufferSource(),filter=a.createBiquadFilter(),g=a.createGain(),at=a.currentTime+delay;src.buffer=state.noiseBuffer;filter.type='bandpass';filter.Q.value=.75;filter.frequency.setValueAtTime(Math.max(90,startCenter??center),at);if(startCenter!=null)filter.frequency.exponentialRampToValueAtTime(Math.max(90,center),at+duration);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),at+.012);g.gain.exponentialRampToValueAtTime(.0001,at+duration);src.connect(filter);filter.connect(g);g.connect(state.audioMaster||a.destination);src.start(at);src.stop(at+duration+.015);}catch{}}
function playMoveSfx(dir){tone(dir==='forward'?205:dir==='backward'?155:178,.036,{gain:.008,type:'triangle',endFreq:dir==='forward'?150:132});}
function playPoliceCue(kind){const now=performance.now(),last=state.policeCueTimes?.[kind]??-Infinity;if(now-last<15000)return;state.policeCueTimes[kind]=now;if(kind==='signal'){tone(510,.055,{gain:.014,type:'triangle',endFreq:390});tone(680,.045,{gain:.010,type:'triangle',delay:.085,endFreq:520});}else if(kind==='pressure'){tone(590,.06,{gain:.016,type:'triangle',endFreq:455});tone(760,.055,{gain:.013,type:'triangle',delay:.10,endFreq:570});}else if(kind==='danger'){tone(720,.07,{gain:.020,type:'square',endFreq:520});tone(510,.07,{gain:.015,type:'triangle',delay:.12,endFreq:390});}}
function playArrestProximityPulse(intensity=0){const now=performance.now();if(now<state.audioPriorityUntil)return;const t=clamp01(intensity),interval=1250-t*650;if(now-state.lastArrestPulseAt<interval)return;state.lastArrestPulseAt=now;const gain=.0042+t*.0038;tone(86+t*10,.07,{gain,type:'sine',endFreq:68});tone(118+t*14,.05,{gain:gain*.62,type:'triangle',delay:.115,endFreq:88});}
function playEndSfx(reason){state.audioPriorityUntil=performance.now()+1150;if(reason==='police'){tone(180,.14,{gain:.024,type:'sawtooth',endFreq:82});tone(420,.07,{gain:.012,type:'triangle',delay:.03,endFreq:310});}else if(reason==='traffic'){tone(120,.12,{gain:.022,type:'square',endFreq:58});tone(86,.16,{gain:.016,type:'sawtooth',delay:.035,endFreq:48});noiseBurst(.10,{gain:.008,center:180,startCenter:520});}}
function playNearMissSfx(){const now=performance.now();if(now<state.audioPriorityUntil||now-state.lastNearMissSfxAt<2800)return;state.lastNearMissSfxAt=now;noiseBurst(.085,{gain:.0055,center:520,startCenter:1250});}
function playFireWarningSfx(){const now=performance.now();state.audioPriorityUntil=Math.max(state.audioPriorityUntil,now+760);/* Two fixed European-style emergency pulses: less synthetic than the old swept sawtooth. */tone(515,.16,{gain:.014,type:'triangle'});tone(1030,.13,{gain:.0032,type:'sine',delay:.008});tone(675,.17,{gain:.014,type:'triangle',delay:.19});tone(1350,.13,{gain:.0030,type:'sine',delay:.198});}
function visualHash(a,b=0){let x=(Math.imul((Number(a)||0)+1013904223,1664525)^Math.imul((Number(b)||0)+374761393,668265263))>>>0;x^=x>>>13;x=Math.imul(x,1274126177)>>>0;return (x>>>0)/4294967296;}
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function resetImpactFx(){}
function controlsSeen(){try{return localStorage.getItem('dani30:fuga-controls-v4')==='1';}catch{return false;}}
function showControlsTutorial(){const el=$('#crossingTutorial');if(el)el.hidden=controlsSeen();}
function hideControlsTutorial(){const el=$('#crossingTutorial');if(el)el.hidden=true;try{localStorage.setItem('dani30:fuga-controls-v4','1');}catch{}}
  function contestSnapshotKey() { return `dani30:contest:fuga-crossing-v11:${profile()?.id || 'anon'}`; }
  function readContestSnapshot() {
    try { const raw=localStorage.getItem(contestSnapshotKey()); return raw?JSON.parse(raw):null; } catch { return null; }
  }
  function writeContestSnapshot(data) {
    if(!profile()?.id || data?.previewFreePlay)return;
    try {
      localStorage.setItem(contestSnapshotKey(),JSON.stringify({
        rank:Number(data?.playerRank||0),best:Number(data?.playerBest||0),phase:data?.phase||'open',savedAt:Date.now()
      }));
    } catch {}
  }
  function notifyContestMovement(data,{announce=true}={}) { writeContestSnapshot(data); }

  function decorateContestStatus(data) {
    if (!data) return data;
    const serverPhase = data._serverPhase || data.phase || 'open';
    const timeline = window.DANI_APP?.getEventSnapshot?.();
    const previewClosed = serverPhase !== 'closed' && Boolean(timeline?.previewMode) && (timeline.previewMode === 'eventday' || timeline.phase !== 'before');
    return { ...data, _serverPhase:serverPhase, phase:(serverPhase === 'closed' || previewClosed) ? 'closed' : serverPhase, previewFreePlay:previewClosed };
  }
  function activeOperationCount(){return Math.max(1,document.querySelectorAll('.clandestine-game[data-game-id]').length||4);}
  function formatArcadeCash(value){return `$${Math.max(0,Number(value||0)).toLocaleString('es-ES')}`;}
  function formatStageCompetitionRank(rank){const n=Number(rank||0);return n===1?'🥇':n===2?'🥈':n===3?'🥉':n?`#${n}`:'';}
  function renderArcadeIdentity(p=profile()){
    const wrap=$('#clandestineActivePlayer'),avatar=$('#clandestineActivePlayerAvatar'),name=$('#clandestineActivePlayerName'),cash=$('#clandestineActivePlayerCash'),sub=$('#clandestineHubSub');
    if(sub)sub.textContent=`${activeOperationCount()} OPERACIONES · 1 CLASIFICACIÓN`;
    if(!wrap)return;
    wrap.hidden=!p;
    if(!p)return;
    renderAvatar(avatar,p);
    if(name)name.textContent=String(p.name||'PLAYER').toUpperCase();
    if(cash)cash.textContent=formatArcadeCash(p.walletBalance??p.cash);
  }
  function syncAccess() {
    const p = profile();
    const confirmed = p?.attendance === 'yes';
    const prepared = confirmed && Boolean(p?.locationUnlocked) && Boolean(p?.uiPrefs?.partyPrepReviewed);
    state.discovered = Boolean(p?.uiPrefs?.arcadeDiscovered);
    const egg = $('#arcadeEasterEgg');
    if (egg) egg.hidden = !prepared;
    renderArcadeIdentity(p);
  }

  function renderAvatar(root, entry) {
    root.replaceChildren();
    if (entry.photoUrl) { const img=document.createElement('img'); img.src=entry.photoUrl; img.alt=''; root.appendChild(img); }
    else root.textContent=entry.avatar || '🎮';
  }

  function podiumCopy(entry) {
    const prize = entry?.prize || rewardForRank(entry?.rank);
    return prize ? `$${prize.cash} · +${prize.respect} RESPETO` : '';
  }

  function championshipSnapshotKey(){return `dani30:contest:general-v1:${profile()?.id||'anon'}`;}
  function readChampionshipSnapshot(){try{const raw=localStorage.getItem(championshipSnapshotKey());return raw?JSON.parse(raw):null;}catch{return null;}}
  function writeChampionshipSnapshot(data){if(!profile()?.id||!data)return;try{localStorage.setItem(championshipSnapshotKey(),JSON.stringify({rank:Number(data?.viewer?.rank||0),completed:Number(data?.viewer?.completedCount||0),eligible:Boolean(data?.viewer?.eligible),phase:data?.phase||'open',savedAt:Date.now()}));}catch{}}
  function notifyChampionshipMovement(data,{announce=true}={}){
    if(!data||!profile()?.id)return;const previous=state.championship?{rank:+(state.championship?.viewer?.rank||0),completed:+(state.championship?.viewer?.completedCount||0),eligible:Boolean(state.championship?.viewer?.eligible),phase:state.championship?.phase||'open'}:readChampionshipSnapshot();
    const viewer=data.viewer||{},rank=+(viewer.rank||0),completed=+(viewer.completedCount||0),hud=window.DANI_APP?.announceHud;
    if(announce&&previous){
      if(completed>Number(previous.completed||0)&&completed<activeOperationCount())hud?.(`OPERACIÓN ${completed}/${activeOperationCount()} COMPLETADA`,{detail:'SIGUE SUMANDO PARA LA CLASIFICACIÓN GENERAL',tone:'success',duration:2400,priority:2});
      else if(!previous.eligible&&viewer.eligible)hud?.('ENTRAS EN LA CLASIFICACIÓN GENERAL',{detail:rank?`POSICIÓN PROVISIONAL · #${rank}`:`LAS ${activeOperationCount()} OPERACIONES COMPLETADAS`,tone:'success',duration:3000,priority:3});
      else if(viewer.eligible&&data.phase!=='closed'&&previous.phase!=='closed'&&rank&&Number(previous.rank||0)&&rank<Number(previous.rank||0))hud?.('SUBES EN LA GENERAL',{detail:`AHORA VAS #${rank}`,tone:'success',duration:2600,priority:3});
    }
    writeChampionshipSnapshot(data);
  }
  function renderChampionshipStatus(data,options={}){
    if(!data)return;notifyChampionshipMovement(data,options);state.championship=data;const viewer=data.viewer||{},closed=data.phase==='closed',total=activeOperationCount(),completed=Math.max(0,Math.min(total,Number(viewer.completedCount||0)));
    const lead=$('#clandestineLead'),kicker=$('#clandestinePrizeKicker'),title=$('#clandestinePrizeTitle'),text=$('#clandestinePrizeText'),note=$('#clandestineNote');
    if(kicker)kicker.textContent=closed?'GENERAL · FINAL':'GENERAL';
    if(title){if(viewer.eligible&&viewer.rank)title.textContent=`#${viewer.rank}`;else title.textContent=`${completed} / ${total}`;}
    if(text){text.hidden=true;text.textContent=closed?'Clasificación final':viewer.eligible?'Clasificación general activa':`${completed} de ${total} operaciones completadas`;}
    if(lead)lead.textContent=closed?'La operación está cerrada.':`${total} operaciones. Un único podio.`;
    if(note){note.hidden=true;note.textContent='';}
    const stageLabel=$('#operationStage5CompetitionLabel'),stageValue=$('#operationStage5CompetitionValue'),stageText=$('#operationStage5CompetitionText'),stageState=$('#operationStage5CompetitionState'),stageNote=$('#operationStage5CompetitionNote'),inviteButton=$('#arcadeEasterEgg');
    const rank=Number(viewer.rank||0),prize=rank?rewardForRank(rank,data):null;
    if(stageLabel)stageLabel.textContent=closed?'CLASIFICACIÓN FINAL':'CLASIFICACIÓN GENERAL';
    if(closed){
      if(stageValue)stageValue.textContent=viewer.eligible&&rank?`${formatStageCompetitionRank(rank)}${prize?` · ${formatArcadeCash(prize.cash)}`:''}`:`${completed}/${total}`;
      if(stageText)stageText.textContent=viewer.eligible?'La clasificación ya está cerrada.':'La preparación terminó antes de que completaras todas las operaciones.';
      if(stageState)stageState.textContent='CERRADA';
      if(stageNote)stageNote.textContent='El resultado definitivo de la preparación ya está sellado.';
      if(inviteButton)inviteButton.textContent='ABRIR OPERACIONES · JUEGO LIBRE →';
    }else if(!viewer.eligible){
      if(stageValue)stageValue.textContent=`${completed}/${total} OPERACIONES`;
      if(stageText)stageText.textContent=`Completa todas las operaciones para entrar en la clasificación general.`;
      if(stageState)stageState.textContent='EN CURSO';
      if(stageNote)stageNote.textContent='La clasificación sigue abierta. Cuando completes todas, tu posición provisional aparecerá aquí.';
      if(inviteButton)inviteButton.textContent='ENTRAR EN OPERACIONES CLANDESTINAS →';
    }else if(rank&&prize){
      if(stageValue)stageValue.textContent=`${formatStageCompetitionRank(rank)} · ${formatArcadeCash(prize.cash)} PROVISIONALES`;
      if(stageText)stageText.textContent='Si la clasificación cerrase ahora, este sería tu botín.';
      if(stageState)stageState.textContent='PUESTO DE BOTÍN';
      if(stageNote)stageNote.textContent='La clasificación sigue abierta. Tu posición y el botín provisional pueden cambiar hasta El Golpe.';
      if(inviteButton)inviteButton.textContent='MEJORAR MIS MARCAS →';
    }else{
      if(stageValue)stageValue.textContent=rank?formatStageCompetitionRank(rank):'CLASIFICADO';
      if(stageText)stageText.textContent='Fuera del botín por ahora. Mejora tus marcas para subir en la clasificación.';
      if(stageState)stageState.textContent='SIGUE COMPITIENDO';
      if(stageNote)stageNote.textContent='La clasificación sigue abierta. El botín definitivo se decidirá cuando termine la preparación para El Golpe.';
      if(inviteButton)inviteButton.textContent='MEJORAR MIS MARCAS →';
    }
    $('#clandestineDialog')?.classList.toggle('is-archive',closed);syncAccess();
  }
  async function refreshChampionship(options={announce:true}){if(!profile()?.id){syncAccess();return null;}try{const data=await crew.clandestineLeaderboard();renderChampionshipStatus(data,options);return data;}catch(error){const msg=$('#clandestineMessage'),stageText=$('#operationStage5CompetitionText'),stageValue=$('#operationStage5CompetitionValue');if(msg)msg.textContent=error.message||'No se ha podido cargar la clasificación general.';if(stageValue)stageValue.textContent='—';if(stageText)stageText.textContent='No se ha podido actualizar tu posición. Puedes entrar igualmente en las operaciones.';syncAccess();return null;}}
  function renderOverallRanking(body){
    const data=state.championship;if(!data){body.innerHTML='<p class="arcade-leaderboard-empty">No se ha podido cargar la clasificación general.</p>';return;}
    const viewer=data.viewer||{},closed=data.phase==='closed',rows=Array.isArray(data.leaderboard)?data.leaderboard:[];
    const section=document.createElement('section');section.className='arcade-ranking operation-ranking overall-ranking arcade-ranking--sheet';
    const head=document.createElement('div');head.className='arcade-ranking__head';head.innerHTML=`<div><small>${closed?'CLASIFICACIÓN FINAL':'CLASIFICACIÓN GENERAL'}</small><h3>Operación 30</h3></div><span class="${closed?'is-closed':''}">${closed?'FINAL':'ABIERTO'}</span>`;section.appendChild(head);
    const copy=document.createElement('p');copy.className='arcade-ranking__deadline';copy.textContent=viewer.eligible?'Tus mejores marcas de todas las operaciones ya están contando.':`Completa las ${activeOperationCount()} operaciones para entrar en la general.`;section.appendChild(copy);
    const prizes=document.createElement('div');prizes.className='arcade-prize-strip arcade-prize-strip--ranking arcade-prize-strip--general';prizes.innerHTML='<span>🥇 <b>$1.000</b> · +10 RESPETO</span><span>🥈 <b>$500</b> · +6</span><span>🥉 <b>$250</b> · +3</span>';section.appendChild(prizes);
    const list=document.createElement('div');list.className='arcade-leaderboard';if(!rows.length){const empty=document.createElement('p');empty.className='arcade-leaderboard-empty';empty.textContent='Todavía nadie ha completado todas las operaciones.';list.appendChild(empty);}else rows.slice(0,20).forEach(entry=>{const row=document.createElement('div');row.className=`arcade-rank-row${entry.isViewer?' is-me':''}${entry.rank<=3?` is-podium is-rank-${entry.rank}`:''}`;const rank=document.createElement('span');rank.className='arcade-rank-row__rank';rank.textContent=entry.rank===1?'🥇':entry.rank===2?'🥈':entry.rank===3?'🥉':String(entry.rank);const avatar=document.createElement('span');avatar.className='arcade-rank-row__avatar';renderAvatar(avatar,entry);const name=document.createElement('span');name.className='arcade-rank-row__name';const sub=entry.rank<=3&&entry.prize?`$${entry.prize.cash.toLocaleString('es-ES')} · +${entry.prize.respect} RESPETO`:entry.isViewer?'TÚ':'';name.innerHTML=`<b>${escapeHtml(entry.name)}</b><small>${escapeHtml(sub)}</small>`;row.append(rank,avatar,name);list.appendChild(row);});section.appendChild(list);
    const rules=document.createElement('details');rules.className='overall-ranking-rules';rules.innerHTML='<summary>¿CÓMO SE ORDENA?</summary><p>Tu mejor marca de cada operación se compara en la misma escala y las cuatro pesan igual. Si hay empate, va delante quien tenga el rendimiento más equilibrado; si continúa, quien logró antes esas marcas.</p>';section.appendChild(rules);body.replaceChildren(section);
  }

  function renderStatus(data, options={}) {
    data = decorateContestStatus(data);
    notifyContestMovement(data, options);
    state.status = data;
    const record=$('#clandestineFugaRecord');if(record)record.textContent=data.playerBest?`${fmt(data.playerBest)} · #${data.playerRank||'—'}`:'SIN MARCA';
    $('#arcadePersonalBest').textContent = data.playerBest ? fmt(data.playerBest) : '—';
    const badge=$('#arcadePhaseBadge');
    badge.textContent = data.phase === 'closed' ? 'FINAL' : 'ABIERTO';
    badge.classList.toggle('is-closed', data.phase === 'closed');
    const start=$('#arcadeStart'), retry=$('#arcadeRetry');
    const closed=data.phase === 'closed';
    const cardState=$('#clandestineFugaState');if(cardState){cardState.hidden=!closed;cardState.textContent='FINAL';}
    const areaPlay=$('#clandestinePlayFuga');if(areaPlay)areaPlay.textContent=closed?'JUGAR POR DIVERSIÓN':'JUGAR';
    if (start) { start.disabled=false; start.textContent=closed ? 'JUGAR POR DIVERSIÓN' : 'INICIAR FUGA'; }
    if (retry) { retry.disabled=false; retry.textContent=closed ? 'OTRA PARTIDA' : 'OTRA FUGA'; }
    const rankingKicker=$('#arcadeRankingKicker');if(rankingKicker)rankingKicker.textContent=closed?'CLASIFICACIÓN FINAL':'CLASIFICACIÓN';
    const deadline=$('#arcadeRankingDeadline');if(deadline)deadline.textContent='Clasificación propia de FUGA 30.';

    const list=$('#arcadeLeaderboard'); list.replaceChildren();
    const rows=Array.isArray(data.leaderboard) ? data.leaderboard : [];
    if (!rows.length) {
      const empty=document.createElement('p'); empty.className='arcade-leaderboard-empty'; empty.textContent='Todavía nadie ha dejado marca en la huida. La primera referencia puede ser tuya.'; list.appendChild(empty);
    } else rows.slice(0,10).forEach((entry) => {
      const row=document.createElement('div');
      row.className=`arcade-rank-row${entry.isViewer?' is-me':''}${entry.rank<=3?` is-podium is-rank-${entry.rank}`:''}`;
      const rank=document.createElement('span'); rank.className='arcade-rank-row__rank'; rank.textContent=entry.rank===1?'🥇':entry.rank===2?'🥈':entry.rank===3?'🥉':String(entry.rank);
      const avatar=document.createElement('span'); avatar.className='arcade-rank-row__avatar'; renderAvatar(avatar,entry);
      const name=document.createElement('span'); name.className='arcade-rank-row__name';
      const sub = entry.isViewer?'TU RÉCORD':`${entry.gamesPlayed || 1} PARTIDAS`;
      name.innerHTML=`<b>${escapeHtml(entry.name)}</b><small>${escapeHtml(sub)}</small>`;
      const score=document.createElement('strong'); score.className='arcade-rank-row__score'; score.textContent=fmt(entry.score);
      row.append(rank,avatar,name,score); list.appendChild(row);
    });

    const awards=Array.isArray(data.awards) ? data.awards : [];
    $('#arcadeMessage').textContent = '';
    syncAccess();
  }

  async function refresh(options={announce:true}) {
    if (!profile()?.id) { syncAccess(); return null; }
    try { const data=await crew.arcadeLeaderboard(); renderStatus(data,options); return data; }
    catch (error) { $('#arcadeMessage').textContent=error.message || 'No se ha podido cargar FUGA 30.'; return null; }
  }

  let hubSheetController=null;
  const ui=window.DANI_UI;
  const hubInfo={
    infiltration:{kicker:'BRECHA 30 · MEMORIA',title:'CÓMO SE JUEGA',html:'<div class="arcade-hub-info"><div><small>OBJETIVO</small><strong>Memoriza las teclas iluminadas y reconstruye el patrón para abrir la brecha.</strong></div><div><small>REGLA CLAVE</small><p>El orden no importa. Una tecla que no pertenezca al patrón activa la alarma.</p></div><div><small>PUNTUACIÓN</small><p>Cada tecla memorizada correctamente aumenta tu marca.</p></div></div>'},
    blind:{kicker:'PUNTO CIEGO 30 · PERCEPCIÓN',title:'CÓMO SE JUEGA',html:'<div class="arcade-hub-info"><div><small>OBJETIVO</small><strong>Calcula cuándo la patrulla completa su recorrido aunque ya no puedas verla.</strong></div><div><small>CONTROL</small><p>Observa su velocidad. Cuando desaparezca, toca cualquier parte cuando creas que ha llegado al final.</p></div><div><small>CLASIFICACIÓN</small><p>Son 3 patrullas con velocidades aleatorias. Se suma el valor absoluto de cada error: adelantarte y retrasarte nunca se compensan. Gana quien quede más cerca de 0,000 s.</p></div></div>'},
    safe:{kicker:'BOTÍN 30 · PRECISIÓN',title:'CÓMO SE JUEGA',html:'<div class="arcade-hub-info"><div><small>OBJETIVO</small><strong>Abre la cámara clavando el centro en los 5 cierres.</strong></div><div><small>CONTROL</small><p>Toca para parar la aguja. Cada cierre va más rápido.</p></div><div><small>CLASIFICACIÓN</small><p>Gana la mejor precisión media.</p></div></div>'},
    fuga:{kicker:'FUGA 30 · REFLEJOS',title:'CÓMO SE JUEGA',html:'<div class="arcade-hub-info"><div><small>OBJETIVO</small><strong>Escapa lo más lejos posible.</strong></div><div><small>CONTROL</small><p>Toca para avanzar y desliza para moverte. Lee el tráfico antes de entrar.</p></div><div><small>PELIGRO</small><p>La policía recorta terreno si esperas demasiado. BOMBEROS no respeta la prioridad peatonal.</p></div></div>'},
    prizes:{kicker:'OPERACIÓN 30',title:'UN SOLO PODIO',html:'<div class="arcade-hub-info arcade-hub-info--prizes"><div><small>PREMIOS GENERALES</small><strong>COMPLETA LAS 4 OPERACIONES</strong></div><div class="arcade-hub-prizes"><span>🥇 <b>$1.000</b> · +10 RESPETO</span><span>🥈 <b>$500</b> · +6 RESPETO</span><span>🥉 <b>$250</b> · +3 RESPETO</span></div><p>Hay un único podio para toda Operación 30. La explicación del orden y los desempates está dentro de la clasificación general.</p></div>'}
  };
  function clearClonedIds(root){root?.querySelectorAll?.('[id]').forEach(node=>node.removeAttribute('id'));root?.removeAttribute?.('id');}
  function bindHubSheetSwipe(){
    const panel=$('#arcadeHubSheetPanel');
    if(!panel||hubSheetController||!ui?.createMobileBottomSheetController)return;
    hubSheetController=ui.createMobileBottomSheetController({
      sheet:panel,
      isMobile:()=>window.matchMedia?.('(max-width:720px)').matches ?? true,
      getScrollRoot:(target)=>target?.closest?.('.app-surface__scroll')||$('#arcadeHubSheetBody'),
      onClose:(detail)=>closeHubSheet(detail?.source==='swipe')
    });
  }
  async function openHubSheet(type='info',game='fuga'){
    const sheet=$('#arcadeHubSheet'),body=$('#arcadeHubSheetBody'),panel=$('#arcadeHubSheetPanel');if(!sheet||!body||!panel)return;
    hubSheetController?.reset?.();
    body.scrollTop=0;
    panel.dataset.sheetType=type;
    panel.dataset.game=game;
    if(type==='ranking'){
      if(game==='overall'){await refreshChampionship({announce:false});$('#arcadeHubSheetKicker').textContent='OPERACIÓN 30';$('#arcadeHubSheetTitle').textContent='CLASIFICACIÓN GENERAL';renderOverallRanking(body);}
      else {if(game==='safe')await window.DANI_SAFE?.refresh?.();else if(game==='infiltration')await window.DANI_INFILTRATION?.refresh?.();else if(game==='blind')await window.DANI_POINTBLIND?.refresh?.();else await refresh({announce:false});
        const source=game==='safe'?$('#safeRanking'):game==='infiltration'?$('#infRanking'):game==='blind'?$('#blindRanking'):$('#arcadeRanking');
        const title=game==='safe'?'BOTÍN 30':game==='infiltration'?'BRECHA 30':game==='blind'?'PUNTO CIEGO 30':'FUGA 30';
        $('#arcadeHubSheetKicker').textContent=`${title} · MARCAS`;$('#arcadeHubSheetTitle').textContent='RANKING DEL JUEGO';body.replaceChildren();
        if(source){const clone=source.cloneNode(true);clearClonedIds(clone);clone.classList.add('arcade-ranking--sheet');body.appendChild(clone);}}
    }else{
      const info=hubInfo[game]||hubInfo.fuga;$('#arcadeHubSheetKicker').textContent=info.kicker;$('#arcadeHubSheetTitle').textContent=info.title;body.innerHTML=info.html;
    }
    sheet.hidden=false;sheet.setAttribute('aria-hidden','false');
    requestAnimationFrame(()=>{sheet.classList.add('is-open');panel.focus?.({preventScroll:true});});
  }
  function closeHubSheet(fromSwipe=false){
    const sheet=$('#arcadeHubSheet');if(!sheet)return;
    sheet.classList.remove('is-open');sheet.setAttribute('aria-hidden','true');
    if(!fromSwipe)hubSheetController?.reset?.();
    window.setTimeout(()=>{
      if(!sheet.classList.contains('is-open')){
        sheet.hidden=true;
        // A swipe-close keeps the panel below the viewport until it is actually hidden.
        // Only then reset it for the next open, avoiding the reopen/close flash.
        if(fromSwipe)hubSheetController?.reset?.();
      }
    },180);
  }

  let areaOpening=false;
  async function openArea(){
    const p=profile();if(!p||p.attendance!=='yes'||!p.locationUnlocked||!p.uiPrefs?.partyPrepReviewed||areaOpening)return;
    window.DANI_APP?.setHudMenuOpen?.(false);
    const area=$('#clandestineDialog');
    const chapterEntry=!area.open&&!document.body.classList.contains('arcade-open');
    areaOpening=true;
    try{
      if(chapterEntry&&!reducedMotion){
        document.body.classList.add('motion-clandestine-entering');
        await new Promise(resolve=>setTimeout(resolve,260));
      }
      if(!area.open)area.showModal();
      refreshChampionship();
      refresh();
      window.DANI_SAFE?.refresh?.();
      window.DANI_INFILTRATION?.refresh?.();
      window.DANI_POINTBLIND?.refresh?.();
      document.body.classList.add('arcade-open');
      if(chapterEntry&&!reducedMotion)window.setTimeout(()=>document.body.classList.remove('motion-clandestine-entering'),300);
      if(!p.uiPrefs?.arcadeDiscovered){try{await crew.discoverArcade();state.discovered=true;syncAccess();}catch{$('#clandestineMessage').textContent='Puedes jugar. No hemos podido guardar el acceso en tu expediente; vuelve a entrar desde la Fase 05.';}}
    }finally{
      areaOpening=false;
      if(!chapterEntry||reducedMotion)document.body.classList.remove('motion-clandestine-entering');
    }
  }
  async function discoverAndOpen(){await openArea();}

  function scrollGameHome(){
    const shell=dialog?.querySelector('.arcade-shell');
    if(shell) shell.scrollTop=0;
    if(dialog) dialog.scrollTop=0;
  }

  async function open(options={}) {
    $('#clandestineDialog')?.close();
    state.debug.enabled=false;state.debug.forcedKind='';
    const p=profile();
    if (!p || p.attendance !== 'yes') return;
    window.DANI_APP?.setHudMenuOpen?.(false);
    // A new launch must invalidate every previous async lifecycle BEFORE the first await.
    // This prevents an old finish/death/save continuation from revealing the result over a fresh run.
    stopActiveGame();
    if (!dialog.open) dialog.showModal();
    document.body.classList.add('arcade-open');
    scrollGameHome();
    if(options.play){
      // Direct play deliberately skips the leaderboard refresh. The Hub already loaded it and
      // arcade/start returns the authoritative phase/run data. One tap -> one loader -> one run.
      requestAnimationFrame(scrollGameHome);
      await startGame();
      return;
    }
    await refresh();
    requestAnimationFrame(scrollGameHome);
  }

  function stopActiveGame() {
    state.gesture=null; state.paused=false;
    state.generation+=1;
    state.running=false;state.preparing=false;state.finishing=false;state.runId='';state.pendingFinish=null;state.deathFx=null;state.nearMiss=null;state.blockedUntil=0;state.blockedDir=null;
    state.game=null;state.camera=0;state.accumulator=0;
    cancelAnimationFrame(state.raf);state.raf=0;
    clearTimeout(state.eventTimer);state.eventTimer=0;
    clearTimeout(state.impactTimer);state.impactTimer=0;
    const countdownRoot=$('#arcadeCountdown');if(countdownRoot)countdownRoot.hidden=true;
    const pauseMenu=$('#arcadePauseMenu');if(pauseMenu)pauseMenu.hidden=true;
    $('#arcadeTouchSurface')?.classList.remove('is-tutorial','is-left','is-right');
    resetGameView();
  }

  function close() {
    stopActiveGame();
    if (dialog?.open) dialog.close();
    document.body.classList.remove('arcade-open','arcade-playing','arcade-crash','operation-result-open');
    if(state.debug.enabled) exitDebug();
  }

  function returnToArea(){
    close();
    openArea();
  }

  function showOperationLoading(message='Preparando la huida…',error=false){const root=$('#arcadeLoading');if(!root)return;syncOperationLoadingViewport();document.body.classList.add('operation-loading-open');root.hidden=false;root.classList.toggle('is-error',Boolean(error));const copy=$('#arcadeLoadingText');if(copy)copy.textContent=message;$('#arcadeIntro').hidden=true;$('#arcadeGame').hidden=true;$('#arcadeResult').hidden=true;}
  function hideOperationLoading(){const root=$('#arcadeLoading');document.body.classList.remove('operation-loading-open');if(root){root.hidden=true;root.classList.remove('is-error');}}

  function resetGameView() {
    $('#arcadeIntro').hidden=true; hideOperationLoading(); $('#arcadeGame').hidden=true; $('#arcadeResult').hidden=true;
    $('#arcadeMessage').textContent='';const tutorial=$('#crossingTutorial');if(tutorial)tutorial.hidden=true;
    document.body.classList.remove('arcade-playing','arcade-crash','operation-result-open');
    resetImpactFx();
  }

  function syncGameViewport() {
    const height = Math.round(window.visualViewport?.height || window.innerHeight || 700);
    document.documentElement.style.setProperty('--arcade-game-height', `${height}px`);
    if (!$('#arcadeGame')?.hidden) resizeCanvas();
  }

function resizeCanvas(){
 if(!canvas||!ctx)return;const r=canvas.getBoundingClientRect(),dpr=Math.min(2,devicePixelRatio||1);
 canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
 state.w=r.width;state.h=r.height;if(state.game)draw();
}
function isFireLane(row){return Boolean(engine.isFireLane?.(row));}
function fireTruckETA(row,tick){
 if(!isFireLane(row)||!Array.isArray(row.pattern)||!row.pattern.length)return Infinity;
 const v=row.pattern[0],period=Math.max(.01,row.period||4),speed=Math.max(.01,row.speed||1),shift=(row.phase||0)+row.dir*speed*tick/engine.HZ,base=shift+(v.offset||0),half=(v.length||1)/2;
 if(row.dir>0){const k=Math.floor((-half-base)/period),x=base+k*period;return Math.max(0,(-half-x)/speed);}
 const k=Math.ceil((engine.COLS+half-base)/period),x=base+k*period;return Math.max(0,(x-(engine.COLS+half))/speed);
}
function drawFireLaneWarning(row,cy,w,rowH){
 const localTick=engine.fireLaneTickForState?.(state.game,row,state.game?.tick||0),cueKey=row.index;if(localTick==null){state.fireCueRows.delete(cueKey);return;}
 const eta=fireTruckETA(row,localTick);if(!Number.isFinite(eta)||eta<=.05||eta>1.45){state.fireCueRows.delete(cueKey);return;}
 if(!state.fireCueRows.has(cueKey)){state.fireCueRows.add(cueKey);playFireWarningSfx();}
 const urgency=clamp01(1-eta/1.45),edgeX=row.dir>0?0:w,t=state.game.tick/engine.HZ,pulse=.55+.45*Math.sin(t*Math.PI*5.2);
 ctx.save();ctx.globalCompositeOperation='screen';
 for(let i=0;i<2;i++){
  const gx=edgeX+(row.dir>0?1:-1)*(10+i*12),gy=cy+(i?8:-8),r=rowH*(.38+i*.06);
  const g=ctx.createRadialGradient?.(gx,gy,2,gx,gy,r);
  if(g?.addColorStop){g.addColorStop(0,`rgba(95,166,255,${(.20+urgency*.38)*pulse})`);g.addColorStop(.35,`rgba(95,166,255,${.10+urgency*.18})`);g.addColorStop(1,'rgba(95,166,255,0)');ctx.fillStyle=g;}else ctx.fillStyle=`rgba(95,166,255,${.08+urgency*.12})`;ctx.fillRect(gx-r,gy-r,r*2,r*2);
 }
 ctx.globalCompositeOperation='source-over';
 ctx.fillStyle=`rgba(235,244,255,${.25+urgency*.45})`;ctx.beginPath();ctx.arc(edgeX+(row.dir>0?1:-1)*8,cy,2.4+urgency*1.8,0,Math.PI*2);ctx.fill();
 const labelPulse=.35+.65*Math.abs(Math.sin(t*Math.PI*4.4)),tx=edgeX+(row.dir>0?1:-1)*Math.max(34,w*.095);
 ctx.globalAlpha=(.35+urgency*.55)*labelPulse;ctx.fillStyle='#f2f5f7';ctx.font=`900 ${Math.max(10,Math.min(14,rowH*.26))}px system-ui`;ctx.textAlign=row.dir>0?'left':'right';ctx.textBaseline='middle';ctx.fillText('BOMBEROS',tx,cy);
 ctx.restore();
}

function drawVehicle(car,x,cy,cell,rowH,dir,speed=1,row=null,stopped=false){
 const palette=['#e7bb61','#87b6ca','#cc786d','#afa1cc','#c6cfd2','#7fc69f','#d991b6','#e6e1d7','#8c9fae','#db504a','#4fb4c9'];
 const style=(car.color||0)%6,fast=Math.max(0,Math.min(1,(Number(speed)||1)-1.35));
 const isMotorcycle=car.type==='car'&&row?.family!=='scout'&&((car.color||0)%7===0)&&((row?.index||0)%2===0);
 const isFireTruck=Boolean(row&&isFireLane(row));
 const body=isFireTruck?'#cf3f37':palette[(car.color||0)%palette.length];
 const drawW=(isMotorcycle?car.width*.60:isFireTruck?car.width*1.10:car.width)*cell;
 const drawH=rowH*(isMotorcycle?.44:car.type==='bus'?.68:car.type==='van'?.64:.60);
 const left=x-drawW/2,top=cy-drawH/2;
 ctx.save();
 if(fast>.18&&!reducedMotion){ctx.fillStyle=`rgba(200,225,235,${fast*.055})`;ctx.fillRect(left-dir*drawW*.18,top+drawH*.16,drawW*1.18,drawH*.68);}
 if(isMotorcycle){
  ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.ellipse(x+1,cy+5,drawW*.42,5,0,0,Math.PI*2);ctx.fill();
  const wheelR=Math.max(4,drawH*.18);
  for(const wx of [left+drawW*.23,left+drawW*.77]){
   ctx.fillStyle='#12171b';ctx.beginPath();ctx.arc(wx,cy+drawH*.14,wheelR,0,Math.PI*2);ctx.fill();
   ctx.strokeStyle='rgba(180,190,198,.45)';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(wx,cy+drawH*.14,wheelR*.54,0,Math.PI*2);ctx.stroke();
  }
  ctx.strokeStyle='#2d3b45';ctx.lineWidth=Math.max(2,drawH*.10);ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(left+drawW*.23,cy+drawH*.10);ctx.lineTo(left+drawW*.46,cy-drawH*.02);ctx.lineTo(left+drawW*.74,cy+drawH*.06);ctx.stroke();
  ctx.strokeStyle=body;ctx.lineWidth=Math.max(4,drawH*.16);
  ctx.beginPath();ctx.moveTo(left+drawW*.28,cy+drawH*.03);ctx.lineTo(left+drawW*.47,cy-drawH*.08);ctx.lineTo(left+drawW*.65,cy-drawH*.02);ctx.stroke();
  ctx.fillStyle=body;ctx.beginPath();ctx.roundRect(left+drawW*.44,cy-drawH*.16,drawW*.17,drawH*.14,4);ctx.fill();
  ctx.fillStyle='#f1d1aa';ctx.beginPath();ctx.arc(left+drawW*.49,cy-drawH*.18,drawH*.11,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#202a31';ctx.beginPath();ctx.arc(left+drawW*.51,cy-drawH*.19,drawH*.07,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#29363f';ctx.lineWidth=Math.max(2,drawH*.08);ctx.beginPath();ctx.moveTo(left+drawW*.56,cy-drawH*.12);ctx.lineTo(left+drawW*.72,cy-drawH*.18);ctx.stroke();
  const nose=x+dir*drawW*.45;
  ctx.fillStyle='#fff3bc';ctx.beginPath();ctx.arc(nose,cy,3.5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=stopped?'#ff5b61':'#d94c51';ctx.beginPath();ctx.arc(x-dir*drawW*.42,cy+1,stopped?4:2.8,0,Math.PI*2);ctx.fill();if(stopped){ctx.fillStyle='rgba(255,72,80,.16)';ctx.beginPath();ctx.arc(x-dir*drawW*.42,cy+1,8,0,Math.PI*2);ctx.fill();}
  ctx.restore();return;
 }
 ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.roundRect(left+2,top+4,drawW,drawH,car.type==='bus'?4:7);ctx.fill();
 ctx.fillStyle='#11181c';const wheelW=Math.max(4,drawW*.075),wheelH=Math.max(4,drawH*.18);
 ctx.fillRect(left+drawW*.18-wheelW/2,top-wheelH*.14,wheelW,wheelH);ctx.fillRect(left+drawW*.18-wheelW/2,top+drawH-wheelH*.86,wheelW,wheelH);
 ctx.fillRect(left+drawW*.78-wheelW/2,top-wheelH*.14,wheelW,wheelH);ctx.fillRect(left+drawW*.78-wheelW/2,top+drawH-wheelH*.86,wheelW,wheelH);
 ctx.fillStyle=body;ctx.beginPath();ctx.roundRect(left,top,drawW,drawH,car.type==='bus'?4:7);ctx.fill();
 ctx.fillStyle='rgba(255,255,255,.08)';ctx.fillRect(left+drawW*.08,top+drawH*.08,drawW*.84,drawH*.10);
 if(isFireTruck){
  // Camión de bomberos reconocible: cabina, módulo trasero, escalera y equipos.
  ctx.fillStyle='#f3f3ef';ctx.beginPath();ctx.roundRect(left+drawW*.09,top+drawH*.16,drawW*.28,drawH*.38,4);ctx.fill();
  ctx.fillStyle='#26404e';ctx.fillRect(left+drawW*.13,top+drawH*.20,drawW*.19,drawH*.20);
  ctx.fillStyle=body;ctx.beginPath();ctx.roundRect(left+drawW*.34,top+drawH*.12,drawW*.53,drawH*.46,4);ctx.fill();
  ctx.fillStyle='#bcc5ca';for(let i=0;i<4;i++)ctx.fillRect(left+drawW*(.40+i*.10),top+drawH*.63,drawW*.06,3);
  ctx.fillStyle='#f7df83';ctx.fillRect(left+drawW*.38,top+drawH*.22,drawW*.45,drawH*.05);
  ctx.fillStyle='#b0b8bf';ctx.fillRect(left+drawW*.36,top+drawH*.05,drawW*.44,drawH*.08); // ladder
  ctx.strokeStyle='#8f979d';ctx.lineWidth=1.5;for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(left+drawW*(.39+i*.09),top+drawH*.05);ctx.lineTo(left+drawW*(.39+i*.09),top+drawH*.13);ctx.stroke();}
  ctx.fillStyle='#314b57';ctx.fillRect(left+drawW*.73,top+drawH*.19,drawW*.10,drawH*.28); // rear window/equipment panel
  const blink=(Math.sin(state.game.tick/engine.HZ*Math.PI*4)+1)/2;
  ctx.fillStyle=`rgba(82,154,255,${.25+.55*blink})`;ctx.beginPath();ctx.arc(left+drawW*.20,top+drawH*.08,drawH*.06,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=`rgba(255,85,85,${.25+.55*(1-blink*.35)})`;ctx.beginPath();ctx.arc(left+drawW*.31,top+drawH*.08,drawH*.06,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.24)';ctx.fillRect(left+drawW*.11,top+drawH*.56,drawW*.73,2);
  if(fast>.22&&!reducedMotion){ctx.fillStyle=`rgba(255,242,178,${.05+fast*.10})`;ctx.fillRect(left+drawW*(dir>0?.93:-.05),top+drawH*.30,dir*(10+fast*8),2.5);}
 }else if(car.type==='bus'){
  ctx.fillStyle='#213740';const count=Math.max(3,Math.min(7,Math.floor(drawW/(cell*.34)))),pad=drawW*.08,usable=drawW-pad*2,gap=3,ww=(usable-gap*(count-1))/count;
  for(let i=0;i<count;i++){ctx.fillStyle=i%2?'#253d47':'#1f343e';ctx.fillRect(left+pad+i*(ww+gap),top+drawH*.18,ww,drawH*.34);}ctx.fillStyle='#131d22';ctx.fillRect(left+drawW*.07,top+drawH*.70,drawW*.86,drawH*.11);ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(left+drawW*.06,top+drawH*.10,drawW*.88,2);
 }else if(car.type==='van'){
  ctx.fillStyle='#243a44';ctx.beginPath();ctx.roundRect(left+drawW*.16,top+drawH*.16,drawW*.52,drawH*.42,3);ctx.fill();ctx.fillStyle='rgba(190,226,236,.22)';ctx.fillRect(left+drawW*.71,top+drawH*.19,drawW*.16,drawH*.36);if(style===3){ctx.fillStyle='rgba(255,255,255,.32)';ctx.fillRect(left+drawW*.08,top+drawH*.76,drawW*.84,3);}
 }else{
  const cabinX=style===0?.29:style===1?.24:style===2?.27:style===3?.25:style===4?.33:.21;
  const cabinW=style===4?.34:style===2?.38:style===5?.50:.43;
  ctx.fillStyle='#203541';ctx.beginPath();ctx.roundRect(left+drawW*cabinX,top+drawH*.15,drawW*cabinW,drawH*.48,3);ctx.fill();
  ctx.fillStyle='rgba(190,226,236,.20)';ctx.fillRect(left+drawW*(cabinX+.04),top+drawH*.20,drawW*(cabinW*.33),drawH*.34);ctx.fillRect(left+drawW*(cabinX+cabinW*.58),top+drawH*.20,drawW*(cabinW*.30),drawH*.34);
  if(style===2){ctx.fillStyle='rgba(28,31,34,.34)';ctx.fillRect(left+drawW*.10,top+drawH*.45,drawW*.78,3);} // muscle
  if(style===3){ctx.fillStyle='#f4d65e';ctx.beginPath();ctx.roundRect(left+drawW*.45,top-drawH*.04,drawW*.13,drawH*.18,2);ctx.fill();ctx.fillStyle='#222';ctx.font=`700 ${Math.max(6,drawH*.16)}px system-ui`;ctx.textAlign='center';ctx.fillText('TAXI',left+drawW*.515,top+drawH*.075);} // taxi
  if(style===4){ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(left+drawW*.12,top+drawH*.72,drawW*.72,2);} // coupe
  if(style===5){ctx.fillStyle='rgba(255,255,255,.20)';ctx.fillRect(left+drawW*.08,top+drawH*.66,drawW*.84,2);ctx.fillStyle='#2f2f34';ctx.fillRect(left+drawW*.22,top+drawH*.11,drawW*.08,drawH*.12);} // suv-ish
 }
 const nose=x+dir*drawW*.43,tail=x-dir*drawW*.43;
 ctx.fillStyle='#fff0b4';ctx.fillRect(nose-2,top+drawH*.13,4,5);ctx.fillRect(nose-2,top+drawH*.82,4,5);
 ctx.fillStyle=stopped?'#ff5b61':'#d94c51';ctx.fillRect(tail-(stopped?3:2),top+drawH*.15,stopped?6:4,stopped?6:4);ctx.fillRect(tail-(stopped?3:2),top+drawH*.79,stopped?6:4,stopped?6:4);if(stopped){ctx.fillStyle='rgba(255,65,72,.12)';ctx.fillRect(tail-dir*2,top+drawH*.10,dir*10,drawH*.78);}
 if(fast>.35){ctx.fillStyle=`rgba(255,240,180,${.08+fast*.10})`;ctx.fillRect(nose-dir*2,top+drawH*.20,dir*12,2);}
 if(state.debug.showHitboxes){ctx.strokeStyle='#ff5b91';ctx.lineWidth=1;ctx.strokeRect(x-car.width*cell/2,top,car.width*cell,drawH);}
 ctx.restore();
}

function drawRoadDecor(row,cy,w,rowH,cell){
 const seed=row.index*97+(row.dir>0?13:29),r1=visualHash(seed,1),r2=visualHash(seed,2),r3=visualHash(seed,3),r4=visualHash(seed,4),r5=visualHash(seed,5);
 ctx.save();
 // Fine asphalt grain.
 ctx.fillStyle='rgba(255,255,255,.022)';
 for(let i=0;i<9;i++){const rx=visualHash(seed,i+10)*w,ry=cy-rowH*.42+visualHash(seed,i+30)*rowH*.84;ctx.fillRect(rx,ry,1.2,1.2);}
 // Repair patch.
 if(r1>.52){const pw=Math.max(cell*.75,cell*(.9+r2*1.6)),ph=rowH*(.26+r3*.18),px=(.08+r4*.76)*w;ctx.fillStyle='rgba(58,63,66,.34)';ctx.fillRect(px-pw/2,cy-ph/2,pw,ph);ctx.strokeStyle='rgba(23,26,29,.26)';ctx.lineWidth=1;ctx.strokeRect(px-pw/2,cy-ph/2,pw,ph);}
 // Broken asphalt / branching cracks / pothole edge.
 if(r3>.30){
  const cx=(.10+r2*.80)*w;
  ctx.strokeStyle='rgba(18,22,26,.40)';ctx.lineWidth=1.8;
  ctx.beginPath();ctx.moveTo(cx-cell*.65,cy-rowH*.06);ctx.lineTo(cx-cell*.22,cy-rowH*.18);ctx.lineTo(cx+cell*.02,cy-rowH*.03);ctx.lineTo(cx+cell*.28,cy+rowH*.16);ctx.lineTo(cx+cell*.62,cy+rowH*.04);ctx.stroke();
  ctx.beginPath();ctx.moveTo(cx-cell*.08,cy-rowH*.05);ctx.lineTo(cx+cell*.08,cy-rowH*.28);ctx.lineTo(cx+cell*.22,cy-rowH*.18);ctx.stroke();
  if(r5>.60){ctx.fillStyle='rgba(14,17,19,.18)';ctx.beginPath();ctx.ellipse(cx+cell*.10,cy+rowH*.02,cell*.18,rowH*.09,-.12,0,Math.PI*2);ctx.fill();}
 }
 // Alcantarilla / drainage grid.
 if(r1<.24){const dx=(r2>.5?w*.10:w*.90);ctx.fillStyle='rgba(16,22,26,.35)';for(let i=0;i<4;i++)ctx.fillRect(dx-7+i*4,cy-rowH*.27,2,rowH*.54);}else if(r1>.84){const mx=(1+Math.floor(r2*7))*cell;ctx.strokeStyle='rgba(12,18,22,.34)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(mx,cy,rowH*.16,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(mx,cy,rowH*.10,0,Math.PI*2);ctx.stroke();}
 ctx.restore();
}

function drawCrosswalkSegments(s,from,to,screenY,w,rowH,cell){
 const visited=new Set(),scanFrom=Math.max(1,from-2),scanTo=to+2;
 for(let y=scanFrom;y<=scanTo;y++){
  const row=engine.rowAt(s,y);if(row.safe)continue;
  let start=y;while(start>0&&!engine.rowAt(s,start-1).safe)start--;
  if(visited.has(start))continue;visited.add(start);
  const cw=engine.crosswalkAt(s,start+1);if(!cw)continue;
  const centerX=(cw.center+.5)*cell,zebraW=cw.width*cell;
  const top=screenY(cw.end)+rowH/2,bottom=screenY(cw.start)-rowH/2;
  if(bottom<0||top>state.h)continue;
  const golden=Boolean(cw.golden),active=Boolean(cw.active),stripeH=Math.max(5,rowH*.13),gap=Math.max(5,rowH*.105),period=stripeH+gap;
  ctx.save();
  if(golden){
   const glow=ctx.createLinearGradient?.(centerX-zebraW*.82,0,centerX+zebraW*.82,0);if(glow?.addColorStop){glow.addColorStop(0,'rgba(245,196,70,0)');glow.addColorStop(.5,`rgba(245,196,70,${active?.16:.09})`);glow.addColorStop(1,'rgba(245,196,70,0)');ctx.fillStyle=glow;}else ctx.fillStyle=`rgba(245,196,70,${active?.09:.05})`;ctx.fillRect(centerX-zebraW*.82,top,zebraW*1.64,bottom-top);
  }else{ctx.fillStyle='rgba(222,225,219,.035)';ctx.fillRect(centerX-zebraW*.56,top,zebraW*1.12,bottom-top);}
  ctx.fillStyle=golden?`rgba(240,190,62,${active?.78:.60})`:'rgba(245,246,239,.30)';
  let sy=top+Math.max(2,rowH*.05);while(sy<bottom-Math.max(2,rowH*.05)){const hStripe=Math.min(stripeH,bottom-sy-Math.max(2,rowH*.05));if(hStripe>2)ctx.fillRect(centerX-zebraW/2,sy,zebraW,hStripe);sy+=period;}
  // Road-edge caps: paint terminates exactly at the curb, never on the sidewalk.
  ctx.fillStyle=golden?'rgba(247,211,108,.34)':'rgba(210,214,207,.15)';ctx.fillRect(centerX-zebraW*.58,top,zebraW*1.16,2);ctx.fillRect(centerX-zebraW*.58,bottom-2,zebraW*1.16,2);
  if(golden){
   ctx.strokeStyle=active?'rgba(255,224,118,.78)':'rgba(237,190,72,.48)';ctx.lineWidth=2;ctx.setLineDash([7,7]);ctx.strokeRect(centerX-zebraW*.60,top,zebraW*1.20,bottom-top);ctx.setLineDash([]);
  }
  ctx.restore();
 }
}

function drawRefugeObstacle(row,c,cy,cell,rowH){
 const x=(c+.5)*cell,variant=Math.abs((row.index*11+c*5))%6,w=cell*1.02,h=rowH*.64,left=x-w/2,top=cy-h/2;
 ctx.save();
 ctx.fillStyle='rgba(0,0,0,.26)';ctx.beginPath();ctx.ellipse(x+2,cy+h*.26,w*.48,h*.18,0,0,Math.PI*2);ctx.fill();
 if(variant===0){
  // Obra real: valla + hueco/alcantarilla + conos.
  ctx.fillStyle='#4b5458';ctx.beginPath();ctx.ellipse(x,top+h*.68,w*.34,h*.13,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#2a2f32';ctx.beginPath();ctx.ellipse(x,top+h*.66,w*.28,h*.09,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#84755f';ctx.fillRect(left+w*.18,top+h*.58,w*.64,h*.06);
  ctx.fillStyle='#e1842f';ctx.beginPath();ctx.roundRect(left,top+h*.22,w,h*.34,4);ctx.fill();
  ctx.fillStyle='#fff1d7';for(let i=0;i<4;i++){ctx.save();ctx.translate(left+w*(.12+i*.25),top+h*.39);ctx.rotate(-.52);ctx.fillRect(-w*.055,-h*.15,w*.11,h*.30);ctx.restore();}
  ctx.fillStyle='#3b4245';ctx.fillRect(left+w*.10,top+h*.56,w*.10,h*.30);ctx.fillRect(left+w*.80,top+h*.56,w*.10,h*.30);
  for(const ox of [left+w*.12,left+w*.88]){ctx.fillStyle='#f29c2b';ctx.beginPath();ctx.moveTo(ox,top+h*.54);ctx.lineTo(ox-w*.06,top+h*.74);ctx.lineTo(ox+w*.06,top+h*.74);ctx.closePath();ctx.fill();ctx.fillStyle='#fff2cc';ctx.fillRect(ox-w*.03,top+h*.64,w*.06,h*.03);}
 }else if(variant===1){
  ctx.fillStyle='#8a7a65';ctx.beginPath();ctx.roundRect(left+w*.05,top+h*.56,w*.90,h*.30,5);ctx.fill();ctx.fillStyle='#4a3a2c';ctx.fillRect(x-w*.045,top+h*.24,w*.09,h*.40);ctx.fillStyle='#3f6c4a';ctx.beginPath();ctx.arc(x,top+h*.22,w*.25,0,Math.PI*2);ctx.arc(x-w*.18,top+h*.32,w*.18,0,Math.PI*2);ctx.arc(x+w*.18,top+h*.32,w*.19,0,Math.PI*2);ctx.fill();ctx.fillStyle='#64865b';ctx.beginPath();ctx.arc(x-w*.07,top+h*.16,w*.11,0,Math.PI*2);ctx.fill();
 }else if(variant===2){
  ctx.fillStyle='#5b4434';ctx.beginPath();ctx.roundRect(left+w*.12,top+h*.46,w*.76,h*.17,4);ctx.fill();ctx.fillStyle='#403027';ctx.fillRect(left+w*.20,top+h*.61,w*.08,h*.20);ctx.fillRect(left+w*.72,top+h*.61,w*.08,h*.20);ctx.strokeStyle='#5b4434';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(left+w*.18,top+h*.45);ctx.lineTo(left+w*.18,top+h*.24);ctx.lineTo(left+w*.82,top+h*.24);ctx.lineTo(left+w*.82,top+h*.45);ctx.stroke();for(const sx of [left+w*.06,left+w*.94]){ctx.fillStyle='#877461';ctx.beginPath();ctx.arc(sx,top+h*.64,w*.10,0,Math.PI*2);ctx.fill();ctx.fillStyle='#4f7550';ctx.beginPath();ctx.arc(sx,top+h*.50,w*.11,0,Math.PI*2);ctx.fill();}
 }else if(variant===3){
  ctx.fillStyle='#364048';ctx.beginPath();ctx.arc(x,top+h*.76,w*.18,0,Math.PI*2);ctx.fill();ctx.fillRect(x-w*.035,top+h*.18,w*.07,h*.60);ctx.fillStyle='#f4dd9d';ctx.beginPath();ctx.arc(x,top+h*.16,w*.09,0,Math.PI*2);ctx.fill();for(const dx of [-w*.31,w*.31]){ctx.fillStyle='#525b5f';ctx.beginPath();ctx.roundRect(x+dx-w*.055,top+h*.54,w*.11,h*.26,3);ctx.fill();ctx.fillStyle='#d9c25c';ctx.fillRect(x+dx-w*.055,top+h*.60,w*.11,h*.06);}
 }else if(variant===4){
  ctx.fillStyle='#958575';ctx.beginPath();ctx.roundRect(left+w*.04,top+h*.48,w*.92,h*.35,5);ctx.fill();ctx.fillStyle='#476e4b';for(const dx of [-.23,0,.22]){ctx.beginPath();ctx.ellipse(x+w*dx,top+h*(.34-Math.abs(dx)*.12),w*.17,h*.20,0,0,Math.PI*2);ctx.fill();}ctx.fillStyle='#6f9660';ctx.beginPath();ctx.arc(x+w*.10,top+h*.28,w*.08,0,Math.PI*2);ctx.fill();
 }else{
  // Armario eléctrico / poste urbano.
  ctx.fillStyle='#6d767a';ctx.beginPath();ctx.roundRect(left+w*.18,top+h*.28,w*.40,h*.44,4);ctx.fill();ctx.fillStyle='#505a5f';ctx.fillRect(left+w*.23,top+h*.35,w*.30,h*.06);ctx.fillRect(left+w*.23,top+h*.46,w*.30,h*.06);ctx.fillStyle='#d1b84c';ctx.fillRect(left+w*.32,top+h*.57,w*.12,h*.04);ctx.fillStyle='#4a5357';ctx.fillRect(left+w*.72,top+h*.20,w*.06,h*.62);ctx.fillStyle='#b0b8bf';ctx.beginPath();ctx.arc(left+w*.75,top+h*.18,w*.07,0,Math.PI*2);ctx.fill();
 }
 ctx.restore();
}

function drawSafeSurface(row,cy,w,rowH,cell){
 const paverW=cell/2,paverCols=engine.COLS*2,style=Math.abs(row.index*7)%4;
 const styles=[
  {base:'#666d70',curb:'#8e979b',curbBottom:'#4f5659',line:'rgba(116,126,130,.95)',fillA:'rgba(188,196,199,.14)',fillB:'rgba(90,99,103,.10)',hline:'rgba(142,150,154,.40)'},
  {base:'#75706a',curb:'#b3aaa1',curbBottom:'#5a554f',line:'rgba(149,141,132,.90)',fillA:'rgba(214,204,191,.15)',fillB:'rgba(128,118,109,.12)',hline:'rgba(172,161,151,.34)'},
  {base:'#70767a',curb:'#9ea6aa',curbBottom:'#545b60',line:'rgba(116,125,130,.92)',fillA:'rgba(164,171,175,.12)',fillB:'rgba(78,84,88,.12)',hline:'rgba(156,164,168,.28)'},
  {base:'#6c726d',curb:'#a8aea8',curbBottom:'#565b57',line:'rgba(127,135,128,.92)',fillA:'rgba(196,201,191,.14)',fillB:'rgba(94,100,92,.12)',hline:'rgba(154,160,150,.32)'}
 ][style];
 ctx.fillStyle=styles.base;ctx.fillRect(0,cy-rowH/2,w,rowH);
 ctx.fillStyle=styles.curb;ctx.fillRect(0,cy-rowH/2,w,3);
 ctx.fillStyle=styles.curbBottom;ctx.fillRect(0,cy+rowH/2-3,w,3);
 for(let c=0;c<paverCols;c++){
  if(style===0){ctx.fillStyle=(c+row.index)%2===0?styles.fillA:styles.fillB;ctx.fillRect(c*paverW,cy-rowH/2,paverW,rowH);}
  else if(style===1){ctx.fillStyle=(Math.floor(c/2)+row.index)%2===0?styles.fillA:styles.fillB;ctx.fillRect(c*paverW,cy-rowH/2,paverW,rowH);} 
  else if(style===2){ctx.fillStyle=(c%3===0)?styles.fillA:styles.fillB;ctx.fillRect(c*paverW,cy-rowH/2,paverW,rowH);} 
  else {ctx.fillStyle=(c%4<2)?styles.fillA:styles.fillB;ctx.fillRect(c*paverW,cy-rowH/2,paverW,rowH);} 
 }
 ctx.strokeStyle=styles.line;ctx.lineWidth=1;
 for(let c=0;c<=paverCols;c++){ctx.beginPath();ctx.moveTo(c*paverW,cy-rowH/2);ctx.lineTo(c*paverW,cy+rowH/2);ctx.stroke();}
 ctx.strokeStyle=styles.hline;ctx.lineWidth=1;
 if(style===0||style===3){for(let y=-1;y<=1;y+=2){ctx.beginPath();ctx.moveTo(0,cy+y*rowH*.18);ctx.lineTo(w,cy+y*rowH*.18);ctx.stroke();}}
 else if(style===1){ctx.beginPath();ctx.moveTo(0,cy);ctx.lineTo(w,cy);ctx.stroke();}
 else {for(const y of [-.24,0,.24]){ctx.beginPath();ctx.moveTo(0,cy+y*rowH);ctx.lineTo(w,cy+y*rowH);ctx.stroke();}}
 ctx.strokeStyle='rgba(62,82,73,.24)';ctx.setLineDash([4,7]);ctx.beginPath();ctx.moveTo(0,cy);ctx.lineTo(w,cy);ctx.stroke();ctx.setLineDash([]);
}

function drawPlayerCharacter(p,px,py,cell,rowH,{over=false,reason=null,blockedProgress=0}={}){
 const moveDir=state.game?.move?.dir||null;
 const tilt=moveDir==='left'?-.16:moveDir==='right'?.16:moveDir==='backward'?.05:moveDir==='forward'?-.04:0;
 const lift=reducedMotion?0:(p.lift||0)*7;
 const squash=reducedMotion?0:(p.lift||0)*.08;
 const idle=!state.game?.move&&!over&&!blockedProgress&&!reducedMotion?Math.sin(state.game.tick/engine.HZ*Math.PI*1.45)*1.1:0;
 const blockedShake=blockedProgress&&!reducedMotion?Math.sin((1-blockedProgress)*Math.PI*8)*(cell*.06+1.2)*blockedProgress:0;
 const blockedTilt=blockedProgress&&!reducedMotion?Math.sin((1-blockedProgress)*Math.PI*4)*.13*blockedProgress:0;
 const pursuit=!over&&state.game?engine.policeSnapshot(state.game):null;
 const fear=pursuit?.active?clamp01((3.8-Number(pursuit.distance||0))/2.2):0;
 const fearShake=fear&&!reducedMotion?Math.sin(state.game.tick*.91)*(.16+fear*.42):0;
 const fearTilt=fear&&!reducedMotion?Math.sin(state.game.tick*.63)*.006*fear:0;
 ctx.save();ctx.translate(px+blockedShake+fearShake,py-rowH*.16-lift+idle);ctx.rotate(tilt+blockedTilt+fearTilt);
 if(reason==='traffic'){
  // Flattened top-down pose: clear but playful, not graphic.
  ctx.rotate(Math.PI*.48);ctx.scale(1.08,.72);
  ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.ellipse(3,rowH*.16,cell*.30,7,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#d7b45a';ctx.beginPath();ctx.roundRect(-cell*.30,-rowH*.02,cell*.60,rowH*.26,6);ctx.fill();
  ctx.fillStyle='#334650';ctx.beginPath();ctx.roundRect(-cell*.12,-rowH*.14,cell*.32,rowH*.20,5);ctx.fill();
  ctx.fillStyle='#f1d1aa';ctx.beginPath();ctx.arc(-cell*.28,-rowH*.02,cell*.14,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#6c5236';ctx.beginPath();ctx.roundRect(cell*.12,-rowH*.02,cell*.24,rowH*.24,4);ctx.fill();
  ctx.restore();return;
 }
 if(reason==='police'){
  // Caught pose: hands up / frozen in the arrest zone.
  ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(0,rowH*.25,cell*.27,7,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#ffdf74';ctx.beginPath();ctx.roundRect(-cell*.20,-rowH*.03,cell*.40,rowH*.40,5);ctx.fill();
  ctx.strokeStyle='#f1d1aa';ctx.lineWidth=Math.max(3,cell*.07);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-cell*.13,0);ctx.lineTo(-cell*.28,-rowH*.22);ctx.moveTo(cell*.13,0);ctx.lineTo(cell*.28,-rowH*.22);ctx.stroke();
  ctx.fillStyle='#f1d1aa';ctx.beginPath();ctx.arc(0,-rowH*.12,cell*.15,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#6c5236';ctx.beginPath();ctx.roundRect(-cell*.17,rowH*.09,cell*.34,rowH*.20,4);ctx.fill();
  ctx.restore();return;
 }
 const bodyScale=1-squash,bodyStretch=1+squash*.75;
 ctx.scale(bodyStretch,bodyScale);
 ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.ellipse(0,rowH*.22+lift+5,cell*.26,7,0,0,Math.PI*2);ctx.fill();
 // Backpack full of loot.
 ctx.fillStyle='#6b5135';ctx.beginPath();ctx.roundRect(-cell*.24,rowH*.05,cell*.22,rowH*.30,4);ctx.fill();
 ctx.fillStyle='#8d7148';ctx.fillRect(-cell*.21,rowH*.08,cell*.16,3);
 ctx.fillStyle='#d9c66d';ctx.fillRect(-cell*.19,rowH*.02,cell*.10,4);ctx.fillRect(-cell*.13,rowH*.00,cell*.09,4);
 // Body / arms / head.
 ctx.fillStyle=over?'#fa8a7c':'#ffdf74';ctx.beginPath();ctx.roundRect(-cell*.20,-rowH*.02,cell*.40,rowH*.40,5);ctx.fill();
 ctx.strokeStyle='#d5b760';ctx.lineWidth=Math.max(2,cell*.045);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-cell*.16,rowH*.08);ctx.lineTo(-cell*.26,rowH*.18);ctx.moveTo(cell*.16,rowH*.08);ctx.lineTo(cell*.25,rowH*.16);ctx.stroke();
 ctx.fillStyle='#101d27';ctx.fillRect(-cell*.14,rowH*.08,cell*.28,5);
 ctx.fillStyle='#f1d1aa';ctx.beginPath();ctx.arc(0,-rowH*.10,cell*.15,0,Math.PI*2);ctx.fill();
 if(fear>.12){
  // Continuous sweat replaces the old large fear shake. Drops are staggered so there is always motion near arrest.
  const sweatSpeed=.022+fear*.050,sweatAlpha=.34+fear*.58;
  for(let i=0;i<4;i++){
   const phase=(state.game.tick*sweatSpeed+i*.27)%1;
   const side=i%2===0?1:-1;
   const startX=side*cell*(.17+(i%3)*.018);
   const dropX=startX+Math.sin((phase+i)*Math.PI*1.4)*cell*.025;
   const dropY=-rowH*.18+phase*rowH*.38;
   const fade=Math.sin(Math.PI*Math.min(1,phase*1.06));
   ctx.fillStyle=`rgba(121,210,255,${sweatAlpha*Math.max(.18,fade)})`;
   ctx.beginPath();
   ctx.ellipse(dropX,dropY,Math.max(1.0,cell*.022),Math.max(1.9,rowH*.038),side*.16,0,Math.PI*2);
   ctx.fill();
  }
 }
 if(blockedProgress){ctx.strokeStyle=`rgba(255,245,214,${.18+blockedProgress*.18})`;ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,-rowH*.10,cell*.24,Math.PI*.88,Math.PI*2.12);ctx.stroke();}
 ctx.restore();
}

function drawBill(x,y,angle,scale=1,alpha=1){
 ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.scale(scale,scale);ctx.globalAlpha=alpha;ctx.fillStyle='#7ebc69';ctx.beginPath();ctx.roundRect(-10,-5,20,10,2);ctx.fill();ctx.strokeStyle='rgba(31,74,39,.72)';ctx.lineWidth=1;ctx.strokeRect(-7,-3,14,6);ctx.fillStyle='rgba(29,73,36,.82)';ctx.font='700 7px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('$',0,0);ctx.restore();
}

function findImpactVehicle(){
 const s=state.game;if(!s)return null;const p=engine.position(s);let best=null,bestDist=Infinity;
 for(let y=Math.max(0,Math.floor(p.y)-1);y<=Math.ceil(p.y)+1;y++){
  if(Math.abs(p.y-y)>=.55)continue;const row=engine.rowAt(s,y);if(row.safe)continue;
  for(const car of engine.carsForState(s,row,s.tick)){const d=Math.abs(p.x-car.x);if(d<bestDist){bestDist=d;best={...car,row:y,dir:row.dir,speed:row.speed};}}
 }
 return best;
}

function drawDeathCinematicOverlay(w,h,cell,rowH,playerPx,playerPy){
 const fx=state.deathFx;if(!fx)return;const elapsed=performance.now()-fx.start,duration=fx.duration||1350,p=Math.min(1,elapsed/duration),ease=1-Math.pow(1-p,3);
 const billCount=fx.reason==='traffic'?12:6;
 for(let i=0;i<billCount;i++){
  const seed=visualHash((state.game?.tick||0)+i*41,i+7),a=(-Math.PI*.92)+(Math.PI*1.84)*(i/Math.max(1,billCount-1));
  const dist=(26+seed*62)*Math.min(1,p*1.4),bx=playerPx+Math.cos(a)*dist,by=playerPy-18-Math.sin(a)*dist*.55-Math.sin(Math.min(1,p)*Math.PI)*(14+seed*20);
  drawBill(bx,by,a+p*(2.2+seed*3.6),.70+seed*.42,Math.min(1,p*4)*(1-Math.max(0,p-.78)/.22));
 }
 const titleStart=.18,titleP=clamp((p-titleStart)/(1-titleStart),0,1),fade=Math.min(1,titleP*3.2);
 if(fx.reason==='traffic'){
  const vignette=ctx.createRadialGradient?.(w*.5,h*.5,Math.min(w,h)*.16,w*.5,h*.5,Math.max(w,h)*.74);if(vignette?.addColorStop){vignette.addColorStop(0,'rgba(18,20,22,0)');vignette.addColorStop(1,`rgba(5,6,7,${.36*ease})`);ctx.fillStyle=vignette;}else ctx.fillStyle=`rgba(5,6,7,${.22*ease})`;ctx.fillRect(0,0,w,h);
  ctx.save();ctx.globalAlpha=fade;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='rgba(234,234,229,.93)';ctx.font=`900 ${Math.max(46,Math.min(74,w*.17))}px Impact,Arial Black,system-ui`;ctx.fillText('WASTED',w/2,h*.39);ctx.fillStyle='rgba(238,221,183,.88)';ctx.font=`800 ${Math.max(14,Math.min(19,w*.04))}px system-ui`;ctx.fillText('EL BOTÍN HA SALIDO VOLANDO',w/2,h*.468);ctx.restore();
 }else if(fx.reason==='police'){
  ctx.fillStyle=`rgba(20,10,14,${.12*ease})`;ctx.fillRect(0,0,w,h);
  ctx.save();ctx.globalAlpha=fade;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='rgba(250,226,137,.96)';ctx.font=`900 ${Math.max(44,Math.min(70,w*.16))}px Impact,Arial Black,system-ui`;ctx.fillText('BUSTED',w/2,h*.40);ctx.fillStyle='rgba(245,228,182,.78)';ctx.font=`800 ${Math.max(12,Math.min(17,w*.037))}px system-ui`;ctx.fillText('TE CERRARON EL CERCO',w/2,h*.46);ctx.restore();
 }
}

function updateCosmeticMoments(){
 const s=state.game;if(!s||s.over)return;const p=engine.position(s),now=performance.now();
 // Near miss: a vehicle clears the character by a narrow but safe margin.
 if(s.tick-state.lastNearMissTick>engine.HZ*.8){
  let near=false;
  for(let y=Math.max(0,Math.floor(p.y)-1);y<=Math.ceil(p.y)+1&&!near;y++){
   if(Math.abs(p.y-y)>=.45)continue;const row=engine.rowAt(s,y);if(row.safe)continue;
   for(const car of engine.carsForState(s,row,s.tick)){const dx=Math.abs(p.x-car.x),hit=car.width/2+.20;if(dx>hit+.035&&dx<hit+.145){near=true;break;}}
  }
  if(near){state.lastNearMissTick=s.tick;state.nearMiss={start:now,duration:620,until:now+620,text:'ROZANDO'};playNearMissSfx();}
 }
 const crosswalk=engine.crosswalkSnapshot(s);
 if(crosswalk.eventSeq>state.lastCrosswalkEventSeq&&crosswalk.lastEvent){
  state.lastCrosswalkEventSeq=crosswalk.eventSeq;const ev=crosswalk.lastEvent;
  if(ev.type==='good')state.nearMiss={start:now,duration:1800,until:now+1800,text:'BUEN CIUDADANO'};
  else if(ev.type==='unlock')state.nearMiss={start:now,duration:2400,until:now+2400,text:'BUEN CIUDADANO',detail:'PRIORIDAD PEATONAL CONSEGUIDA'};
  else if(ev.type==='priority')state.nearMiss={start:now,duration:1100,until:now+1100,text:'PRIORIDAD PEATONAL',detail:'TRÁFICO CIVIL DETENIDO'};
  else if(ev.type==='consumed')state.nearMiss={start:now,duration:900,until:now+900,text:'PRIORIDAD CONSUMIDA'};
  else if(ev.type==='lost')state.nearMiss={start:now,duration:900,until:now+900,text:'PRIORIDAD PERDIDA'};
 }
 const police=engine.policeSnapshot(s);
 if(s.maxRow>state.lastMaxRow){
  const reached=engine.rowAt(s,s.maxRow);
  if(reached?.safe&&(police.band==='pressure'||police.band==='danger'))state.nearMiss={start:now,duration:720,until:now+720,text:'RESPIRA'};
  state.lastMaxRow=s.maxRow;
 }
 if(police.streak>=4&&police.streak>state.lastChainAnnounced){state.lastChainAnnounced=police.streak;state.nearMiss={start:now,duration:650,until:now+650,text:police.streak>=6?'BUENA FUGA':'SIGUE'};}
 if(police.streak===0)state.lastChainAnnounced=0;
}

function drawFloatingFeedback(w,h){
 const fx=state.nearMiss,now=performance.now();if(!fx||now>fx.until)return;const duration=Math.max(180,Number(fx.duration)||620),elapsed=Math.max(0,now-(fx.start??(fx.until-duration))),left=Math.max(0,fx.until-now),alpha=Math.min(1,elapsed/120,left/180);ctx.save();ctx.globalAlpha=clamp(alpha,0,1)*.82;ctx.textAlign='center';ctx.fillStyle='#fff0b7';ctx.font=`800 ${Math.max(12,Math.min(16,w*.035))}px system-ui`;ctx.fillText(fx.text,w/2,h*.25);if(fx.detail){ctx.fillStyle='rgba(255,240,183,.80)';ctx.font=`700 ${Math.max(9,Math.min(12,w*.027))}px system-ui`;ctx.fillText(fx.detail,w/2,h*.25+18);}ctx.restore();
}

function runDeathCinematic(reason){
 const generation=state.generation,duration=reducedMotion?420:reason==='traffic'?2300:1550;
 state.deathFx={reason,start:performance.now(),duration,impact:reason==='traffic'?findImpactVehicle():null};
 return new Promise(resolve=>{
  const frame=()=>{if(generation!==state.generation){resolve();return;}draw();if(performance.now()-state.deathFx.start>=duration){resolve();return;}state.raf=requestAnimationFrame(frame);};
  state.raf=requestAnimationFrame(frame);
 });
}

function drawArrestPanicWarning(pursuit,px,py,w,h,rowH){
 if(!pursuit?.active)return;const distance=Number(pursuit.distance||0),fear=clamp01((3.55-distance)/1.95);if(fear<=0)return;
 const alpha=clamp01((fear-.08)/.35),bubbleW=92,bubbleH=30;
 const bx=clamp(px-bubbleW*.5,8,w-bubbleW-8),by=clamp(py+rowH*.48,py+18,h-bubbleH-10);
 ctx.save();ctx.globalAlpha=alpha;ctx.shadowColor='rgba(0,0,0,.28)';ctx.shadowBlur=9;ctx.fillStyle='rgba(17,18,23,.91)';ctx.strokeStyle=`rgba(255,92,92,${.52+fear*.34})`;ctx.lineWidth=1.2;ctx.beginPath();
 const r=9;if(typeof ctx.roundRect==='function')ctx.roundRect(bx,by,bubbleW,bubbleH,r);else{ctx.moveTo(bx+r,by);ctx.lineTo(bx+bubbleW-r,by);ctx.quadraticCurveTo(bx+bubbleW,by,bx+bubbleW,by+r);ctx.lineTo(bx+bubbleW,by+bubbleH-r);ctx.quadraticCurveTo(bx+bubbleW,by+bubbleH,bx+bubbleW-r,by+bubbleH);ctx.lineTo(bx+r,by+bubbleH);ctx.quadraticCurveTo(bx,by+bubbleH,bx,by+bubbleH-r);ctx.lineTo(bx,by+r);ctx.quadraticCurveTo(bx,by,bx+r,by);ctx.closePath();}ctx.fill();ctx.stroke();ctx.shadowBlur=0;
 const pointerX=clamp(px,bx+15,bx+bubbleW-15);ctx.fillStyle='rgba(17,18,23,.91)';ctx.beginPath();ctx.moveTo(pointerX-5,by);ctx.lineTo(pointerX+5,by);ctx.lineTo(pointerX,by-7);ctx.closePath();ctx.fill();
 ctx.fillStyle='rgba(255,235,229,.96)';ctx.font='900 10px system-ui,-apple-system,BlinkMacSystemFont,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('¡DATE PRISA!',bx+bubbleW/2,by+bubbleH/2+.5);ctx.restore();
}

function draw(){
 const s=state.game;if(!s)return;const w=state.w,h=state.h,cell=w/engine.COLS,rowH=Math.min(55,(h-185)/9),anchor=h-150;
 const p=engine.position(s),camera=state.camera;
 ctx.fillStyle='#111920';ctx.fillRect(0,0,w,h);
 const deathElapsed=state.deathFx?performance.now()-state.deathFx.start:0;
 const shakeAmp=state.deathFx&&!reducedMotion?(state.deathFx.reason==='traffic'?4.5:2.4)*Math.max(0,1-deathElapsed/520):0;
 const shakeX=shakeAmp?Math.sin(deathElapsed*.115)*shakeAmp:0,shakeY=shakeAmp?Math.cos(deathElapsed*.093)*shakeAmp*.55:0;
 ctx.save();ctx.translate(shakeX,shakeY);
 const screenY=y=>anchor-(y-camera)*rowH;
 const from=Math.max(0,Math.floor(camera)-5),to=Math.ceil(camera+(h-150)/rowH)+2;
 for(let y=from;y<=to;y++){
  const row=engine.rowAt(s,y),cy=screenY(y);if(cy < -rowH||cy>h+rowH)continue;
  if(row.safe){
   drawSafeSurface(row,cy,w,rowH,cell);for(const c of row.blocked||[])drawRefugeObstacle(row,c,cy,cell,rowH);
  }else{
   const roadTone={open:'#283741',regular:'#24313b',dense:'#222d36',irregular:'#27333c',heavy:'#202b33',scout:'#28343d',convoy:'#222e35',platoon:'#26343d',fallback:'#24313b'}[row.family]||'#24313b';ctx.fillStyle=roadTone;ctx.fillRect(0,cy-rowH/2,w,rowH);
   drawRoadDecor(row,cy,w,rowH,cell);
   ctx.strokeStyle='rgba(164,181,190,.42)';ctx.setLineDash([12,14]);ctx.beginPath();ctx.moveTo(0,cy+rowH/2);ctx.lineTo(w,cy+rowH/2);ctx.stroke();ctx.setLineDash([]);
  }
 }
 // Crosswalks are segment-level geometry: one continuous zebra crossing from safe zone to safe zone.
 drawCrosswalkSegments(s,from,to,screenY,w,rowH,cell);
 // Vehicles render after road markings so they sit naturally on top of the crossing.
 for(let y=from;y<=to;y++){
  const row=engine.rowAt(s,y),cy=screenY(y);if(row.safe||cy < -rowH||cy>h+rowH)continue;
  const cwState=engine.crosswalkAt(s,row.index);drawFireLaneWarning(row,cy,w,rowH);for(const car of engine.carsForState(s,row,s.tick)){const x=(car.x+.5)*cell;drawVehicle(car,x,cy,cell,rowH,row.dir,row.speed,row,Boolean(car.stopped));}
 }
 const pursuit=engine.policeSnapshot(s);
 drawPursuitPressure(pursuit,p,screenY(p.y),w,h,rowH);
 const blockedRemaining=Math.max(0,(state.blockedUntil||0)-performance.now());
 const blockedProgress=blockedRemaining?clamp01(blockedRemaining/165):0;
 const px=(p.x+.5)*cell,py=screenY(p.y);
 const deathReason=state.deathFx?.reason||null;
 drawPlayerCharacter(p,px,py,cell,rowH,{over:Boolean(deathReason),reason:deathReason,blockedProgress:deathReason?0:blockedProgress});
 if(!deathReason)drawArrestPanicWarning(pursuit,px,py,w,h,rowH);
  if(state.debug.showHitboxes){ctx.strokeStyle='#ff5b91';ctx.lineWidth=1;ctx.strokeRect(px-cell*.2,py-rowH*.18,cell*.4,rowH*.36);}
 ctx.restore();
 drawFloatingFeedback(w,h);
 if(state.deathFx)drawDeathCinematicOverlay(w,h,cell,rowH,px+shakeX,py+shakeY);
}
function drawPursuitPressure(pursuit,player,playerY,w,h,rowH){
 const visual=state.pursuitVisual||(state.pursuitVisual={frontY:null,intensity:0});
 const maxDistance=Math.max(1,Number(pursuit?.maxDistance)||1);
 const closeness=pursuit?.active?clamp01(1-(Number(pursuit.distance)||0)/maxDistance):0;
 const targetIntensity=!pursuit?.warning?0:pursuit.active?(.16+.62*Math.pow(closeness,.88)):.07;
 const farY=h+42,nearY=playerY+rowH*.42;
 const targetFront=!pursuit?.warning?h+80:pursuit.active?farY+(nearY-farY)*Math.pow(closeness,1.0):h+40;
 if(!Number.isFinite(visual.frontY))visual.frontY=targetFront;
 const follow=reducedMotion?.22:.11;
 visual.frontY+=(targetFront-visual.frontY)*follow;
 visual.intensity+=(targetIntensity-visual.intensity)*(reducedMotion?.24:.12);
 if(visual.intensity<.003&&visual.frontY>h+45)return;
 const t=state.game.tick/engine.HZ;
 const pulseSlow=reducedMotion?1:(.92+.08*Math.sin(t*Math.PI*.72));
 const pulseFlash=reducedMotion?1:(.64+.36*(.5+.5*Math.sin(t*Math.PI*2.05)));
 const front=visual.frontY,intensity=clamp01(visual.intensity),litIntensity=intensity*pulseSlow;
 const pathPoints=[];const slices=10;
 for(let i=0;i<=slices;i++){
  const x=w*i/slices;
  const y=front+Math.sin(i*1.55+state.game.tick*.012)*4+Math.sin(i*.63+state.game.tick*.005)*2;
  pathPoints.push([x,y]);
 }
 const arrestZonePath=new Path2D();
 arrestZonePath.moveTo(0,h); arrestZonePath.lineTo(pathPoints[0][0],pathPoints[0][1]);
 for(let i=1;i<pathPoints.length;i++)arrestZonePath.lineTo(pathPoints[i][0],pathPoints[i][1]);
 arrestZonePath.lineTo(w,h); arrestZonePath.closePath();
 ctx.save();
 // Frente irregular: una presión del mundo, no una barra de interfaz.
 // Zona tomada: más oscura y velada.
 ctx.fillStyle=`rgba(4,7,10,${.20+intensity*.24})`;
 ctx.fill(arrestZonePath);
 const fog=ctx.createLinearGradient(0,front-24,0,h);
 fog.addColorStop(0,`rgba(14,18,24,${intensity*.05})`);
 fog.addColorStop(.20,`rgba(10,12,16,${intensity*.13})`);
 fog.addColorStop(1,`rgba(4,6,8,${.20+intensity*.16})`);
 ctx.fillStyle=fog;ctx.fillRect(0,Math.max(0,front-26),w,h-Math.max(0,front-26));
 // Reflejos de patrullas fuera de cámara.
 // Luces policiales difuminadas: beacons reales, no una línea.
 ctx.save();ctx.clip(arrestZonePath);ctx.globalCompositeOperation='screen';
 const beaconSpacing=Math.max(74,w/4.6),baseRadius=Math.max(115,Math.min(190,w*.24)),beaconAlpha=.16+litIntensity*.44,shift=(t*22)%beaconSpacing;
 for(let i=-2;i<8;i++){
  const cx=i*beaconSpacing+shift+Math.sin(t*.85+i*.9)*8;
  const cy=h+22+Math.cos(t*1.12+i*.8)*4;
  const isBlue=((i+Math.floor(t*2))%2===0),r=baseRadius+(isBlue?8:-4);
  const grad=ctx.createRadialGradient(cx,cy,8,cx,cy,r);
  if(isBlue){grad.addColorStop(0,`rgba(72,120,255,${beaconAlpha*pulseFlash})`);grad.addColorStop(.18,`rgba(72,120,255,${beaconAlpha*.62})`);grad.addColorStop(.5,`rgba(72,120,255,${beaconAlpha*.22})`);grad.addColorStop(1,'rgba(72,120,255,0)');}
  else{grad.addColorStop(0,`rgba(255,72,88,${beaconAlpha*(1.08-pulseFlash*.2)})`);grad.addColorStop(.18,`rgba(255,72,88,${beaconAlpha*.58})`);grad.addColorStop(.5,`rgba(255,72,88,${beaconAlpha*.21})`);grad.addColorStop(1,'rgba(255,72,88,0)');}
  ctx.fillStyle=grad;ctx.fillRect(cx-r,cy-r,r*2,r*2);
 }
 const haze=ctx.createLinearGradient(0,front-90,0,h);
 haze.addColorStop(0,'rgba(0,0,0,0)');haze.addColorStop(.30,`rgba(104,124,188,${intensity*.08})`);haze.addColorStop(.68,`rgba(255,80,92,${intensity*.08})`);haze.addColorStop(1,`rgba(28,33,40,${intensity*.11})`);
 ctx.fillStyle=haze;ctx.fillRect(0,Math.max(0,front-92),w,h-Math.max(0,front-92));
 // Franjas diagonales de zona tomada.
 ctx.strokeStyle=`rgba(246,214,101,${.16+intensity*.12})`;ctx.lineWidth=10;
 const stripeGap=36,stripeDrift=(t*26)%stripeGap;
 for(let x=-h;x<w+h;x+=stripeGap){ctx.beginPath();ctx.moveTo(x+stripeDrift,front+10);ctx.lineTo(x+stripeDrift+120,h);ctx.stroke();}
 ctx.strokeStyle=`rgba(18,14,8,${.12+intensity*.10})`;ctx.lineWidth=6;
 for(let x=-h+18;x<w+h;x+=stripeGap){ctx.beginPath();ctx.moveTo(x+stripeDrift,front+10);ctx.lineTo(x+stripeDrift+120,h);ctx.stroke();}
 // Texto legible y más espaciado, sin superponerse.
 ctx.save();
 ctx.translate(w*.10,front+58);
 ctx.rotate(-0.18);
 ctx.font=`700 ${Math.max(12,Math.min(18,rowH*.31))}px system-ui,-apple-system,BlinkMacSystemFont,sans-serif`;
 ctx.fillStyle=`rgba(255,223,126,${.20+intensity*.11})`;
 const textGap=Math.max(176,w*.34),rowGap=Math.max(54,rowH*1.15);
 for(let y=0;y<(h-front)+100;y+=rowGap){
  const rowOffset=((y/rowGap)%2)*88;
  for(let x=-30+rowOffset;x<w+180;x+=textGap)ctx.fillText('ZONA DE ARRESTO',x,y);
 }
 ctx.restore();
 ctx.restore();
 // Cinta/frontera integrada: una sola banda amarilla con diagonales internas.
 const bandTop=front-7,bandHeight=Math.max(14,Math.min(20,rowH*.38));
 ctx.save();
 ctx.shadowColor='rgba(0,0,0,.18)';ctx.shadowBlur=4;ctx.shadowOffsetY=1;
 ctx.fillStyle=`rgba(247,209,76,${.84+.12*intensity})`;ctx.fillRect(0,bandTop,w,bandHeight);
 ctx.restore();
 ctx.save();ctx.beginPath();ctx.rect(0,bandTop,w,bandHeight);ctx.clip();
 ctx.strokeStyle=`rgba(84,65,18,${.52+.12*intensity})`;ctx.lineWidth=5;
 const tapeGap=26,tapeDrift=(t*18)%tapeGap;
 for(let x=-bandHeight*4;x<w+bandHeight*6;x+=tapeGap){ctx.beginPath();ctx.moveTo(x+tapeDrift,bandTop+bandHeight);ctx.lineTo(x+tapeDrift+bandHeight,bandTop);ctx.stroke();}
 ctx.restore();
 const edgeGlow=ctx.createLinearGradient(0,bandTop,0,bandTop+bandHeight);
 edgeGlow.addColorStop(0,'rgba(255,241,171,.26)');edgeGlow.addColorStop(.5,'rgba(255,241,171,0)');edgeGlow.addColorStop(1,'rgba(95,72,18,.10)');
 ctx.fillStyle=edgeGlow;ctx.fillRect(0,bandTop,w,bandHeight);
 ctx.restore();
}
function updatePursuitSignals(){
 const s=state.game;if(!s)return;const p=engine.policeSnapshot(s);if(!p.warning){state.lastPoliceBand='hidden';return;}
 const rank={hidden:0,signal:1,safe:1,pressure:2,danger:3},prev=state.lastPoliceBand||'hidden';if(p.band!==prev&&rank[p.band]>rank[prev]){playPoliceCue(p.band==='safe'?'signal':p.band);if(p.band==='danger')window.navigator?.vibrate?.(25);}state.lastPoliceBand=p.band;
 if(p.active&&Number(p.distance)<=3.55)playArrestProximityPulse(clamp01((3.55-Number(p.distance))/2.35));
}
function clamp01(v){return Math.max(0,Math.min(1,Number(v)||0));}
function updateHud(){
 const s=state.game;$('#arcadeLiveScore').textContent=fmt(s.maxRow);const best=Number(state.status?.playerBest||0);$('#arcadeRecordChase').textContent=best?(s.maxRow>best?'NUEVO RÉCORD':`RÉCORD · ${fmt(best)}`):'CADA FILA NUEVA SUMA';updatePursuitSignals();
}
function move(dir){
 if(!state.running||state.paused)return;
 if(!engine.input(state.game,dir)){state.blockedUntil=performance.now()+165;state.blockedDir=dir;return;}
 playMoveSfx(dir);hideControlsTutorial();
}
function pauseGame(){
 state.paused=true;state.gesture=null;
 cancelAnimationFrame(state.raf);const menu=$('#arcadePauseMenu');if(menu)menu.hidden=false;
}
function resumeGame(){
 if(!state.running||!state.paused)return;state.paused=false;const menu=$('#arcadePauseMenu');if(menu)menu.hidden=true;state.lastTs=performance.now();state.accumulator=0;state.raf=requestAnimationFrame(tick);
}
async function startGame(){
 if(state.running||state.preparing||state.finishing)return;
 const generation=++state.generation;state.preparing=true;state.gesture=null;document.body.classList.remove('operation-result-open');showOperationLoading('Preparando la huida…');
 $('#arcadeStart').disabled=true;$('#arcadeRetry').disabled=true;$('#arcadeMessage').textContent='';
 const retry=$('#arcadeRetry');retry.textContent='PREPARANDO…';
 try{
  const data=state.debug.enabled?{runId:'debug',seed:state.debug.seed}:state.status?.previewFreePlay?{runId:'preview-freeplay',seed:engine.hashSeed(String(Date.now()))}:await crew.arcadeStart();
  if(generation!==state.generation)return;
  if(data.rulesVersion!=null&&Number(data.rulesVersion)!==Number(engine.VERSION))throw Error(`FUGA desincronizada (juego V${engine.VERSION} / servidor V${data.rulesVersion}). Recarga una vez la página.`);
  state.runId=data.runId;state.game=engine.create(data.seed??engine.hashSeed(data.runId));state.camera=0;state.accumulator=0;state.paused=false;state.pendingFinish=null;state.audioPriorityUntil=0;state.lastNearMissSfxAt=-Infinity;state.lastArrestPulseAt=-Infinity;state.fireCueRows.clear();state.lastPoliceBand='hidden';state.policeCueTimes={signal:-Infinity,pressure:-Infinity,danger:-Infinity};state.pursuitVisual={frontY:null,intensity:0};state.deathFx=null;state.nearMiss=null;state.lastNearMissTick=-999999;state.lastMaxRow=0;state.lastChainAnnounced=0;state.lastCrosswalkEventSeq=0;state.blockedUntil=0;state.blockedDir=null;
  hideOperationLoading();$('#arcadeIntro').hidden=true;$('#arcadeResult').hidden=true;$('#arcadeGame').hidden=false;const pauseMenu=$('#arcadePauseMenu');if(pauseMenu)pauseMenu.hidden=true;$('#crossingSave').hidden=true;showControlsTutorial();
  document.body.classList.add('arcade-playing');syncGameViewport();updateHud();draw();
  state.preparing=false;state.running=true;state.lastTs=performance.now();state.raf=requestAnimationFrame(tick);
 }catch(e){if(generation!==state.generation)return;state.preparing=false;const message=e.message||'No se ha podido iniciar la fuga.';showOperationLoading(message,true);$('#arcadeMessage').textContent=message;$('#arcadeResultText').textContent=message;}
 finally{if(generation===state.generation){$('#arcadeStart').disabled=false;retry.disabled=false;retry.textContent='OTRA FUGA';}}
}
function tick(ts){
 if(!state.running||state.paused)return;
 state.accumulator+=Math.min(.25,Math.max(0,(ts-state.lastTs)/1000));state.lastTs=ts;
 while(state.accumulator>=1/engine.HZ&&!state.game.over){engine.step(state.game);state.accumulator-=1/engine.HZ;}
 state.camera+=(Math.max(0,state.game.y)-state.camera)*(reducedMotion?1:.23);
 updateCosmeticMoments();updateHud();draw();
 if(state.game.over){finishGame();return;}
 state.raf=requestAnimationFrame(tick);
}
const reasons={traffic:'Te alcanzó un vehículo.',police:'La policía cerró el cerco.',extraction:'Extracción completada.'};
async function saveResult(generation){
 const pending=state.pendingFinish;if(!pending)return;
 $('#crossingSave').hidden=true;state.finishing=true;$('#arcadeRetry').disabled=true;
 try{
  const data=await crew.arcadeFinish(pending.runId,pending.score,pending.proof);
  if(generation!==state.generation)return;
  renderStatus(data,{announce:false});refreshChampionship({announce:true});$('#arcadeResultKicker').textContent=data.freePlay?'PARTIDA LIBRE':'FUGA TERMINADA';
  const rankCopy=data.playerRank?`#${data.playerRank} DE LA BANDA`:'';
  $('#arcadeResultRank').textContent=[data.newRecord&&!data.freePlay?'NUEVO RÉCORD':'',rankCopy].filter(Boolean).join(' · ')||(data.freePlay?'FUERA DE COMPETICIÓN':'MARCA REGISTRADA');
  setResultMessage('');
  state.pendingFinish=null;
 }catch(e){if(generation!==state.generation)return;$('#arcadeResultKicker').textContent='MARCA NO ENVIADA';$('#arcadeResultRank').textContent='REINTENTA EL ENVÍO';setResultMessage(e.message||'No hay conexión.');$('#crossingSave').hidden=false;}
 finally{if(generation===state.generation){state.finishing=false;$('#arcadeRetry').disabled=false;}}
}
async function finishGame(){
 if(!state.running)return;const generation=state.generation,s=state.game;
 state.running=false;state.finishing=true;state.gesture=null;cancelAnimationFrame(state.raf);playEndSfx(s.reason);if(s.reason==='police')window.navigator?.vibrate?.([35,40,70]);else if(s.reason==='traffic')window.navigator?.vibrate?.([55,28,95]);
 await runDeathCinematic(s.reason);if(generation!==state.generation)return;
 document.body.classList.remove('arcade-playing');document.body.classList.add('operation-result-open');$('#arcadeGame').hidden=true;$('#arcadeResult').hidden=false;$('#arcadeResultPrize').hidden=true;
 $('#arcadeResultScore').textContent=fmtResultValue(s.maxRow);$('#arcadeResultRank').textContent='ENVIANDO MARCA…';setResultMessage('');$('#arcadeResultKicker').textContent='FUGA TERMINADA';
 if(state.debug.enabled||state.runId==='preview-freeplay'){$('#arcadeResultKicker').textContent=state.debug.enabled?'PRUEBA · SIN CLASIFICACIÓN':'PARTIDA LIBRE';state.finishing=false;$('#arcadeRetry').disabled=false;return;}
 state.pendingFinish={runId:state.runId,score:s.maxRow,reason:s.reason,proof:{rulesVersion:engine.VERSION,ticks:s.tick,events:s.events}};
 await saveResult(generation);
}
function bindTouchSurface(){
 const surface=$('#arcadeTouchSurface');
 surface.addEventListener('pointerdown',e=>{
  if(!state.running||state.paused||state.gesture||!e.isPrimary||e.button>0)return;
  e.preventDefault();surface.setPointerCapture(e.pointerId);state.gesture={id:e.pointerId,x:e.clientX,y:e.clientY,at:performance.now(),used:false};
 },{passive:false});
 surface.addEventListener('pointermove',e=>{
  const g=state.gesture;if(!g||g.id!==e.pointerId||g.used)return;e.preventDefault();
  const dx=e.clientX-g.x,dy=e.clientY-g.y;if(Math.hypot(dx,dy)<19)return;
  g.used=true;move(Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'backward':'forward');
 },{passive:false});
 surface.addEventListener('pointerup',e=>{const g=state.gesture;if(!g||g.id!==e.pointerId)return;e.preventDefault();state.gesture=null;if(!g.used&&performance.now()-g.at<400)move('forward');},{passive:false});
 surface.addEventListener('pointercancel',()=>{state.gesture=null;});
 surface.addEventListener('lostpointercapture',()=>{state.gesture=null;});
 $('#crossingResume').addEventListener('click',resumeGame);
 $('#crossingSave').addEventListener('click',()=>{if(!state.finishing)saveResult(state.generation);});
 window.addEventListener('keydown',e=>{if(!dialog.open||!state.running||e.repeat)return;const d={ArrowUp:'forward',ArrowDown:'backward',ArrowLeft:'left',ArrowRight:'right',' ':'forward'}[e.key];if(d){e.preventDefault();move(d);}});
}
function configureDebug(options={}){Object.assign(state.debug,options);return {...state.debug};}
function exitDebug(){state.debug.enabled=false;}
async function openDebug(options={}){state.debug.enabled=true;configureDebug(options);$('#clandestineDialog')?.close();if(!dialog.open)dialog.showModal();document.body.classList.add('arcade-open');resetGameView();$('#arcadeMessage').textContent='PRUEBA LOCAL · las marcas no entran en clasificación';}
function getDiagnostics(){return {running:state.running,paused:state.paused,game:state.game?{tick:state.game.tick,x:state.game.x,y:state.game.y,score:state.game.maxRow,over:state.game.over,reason:state.game.reason,queued:state.game.queued,events:state.game.events,seed:state.game.seed,police:engine.policeSnapshot(state.game),crosswalk:engine.crosswalkSnapshot(state.game)}:null};}
  function bind() {
    const games=$('#clandestineGames');
    const slide=(direction)=>{if(!games)return;games.scrollBy({left:direction*((games.firstElementChild?.getBoundingClientRect().width||games.clientWidth)+16),behavior:reducedMotion?'instant':'smooth'});};
    $('#clandestinePrev')?.addEventListener('click',()=>slide(-1));
    $('#clandestineNext')?.addEventListener('click',()=>slide(1));
    games?.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();slide(e.key==='ArrowRight'?1:-1);}});
    games?.addEventListener('scroll',()=>{const step=(games.firstElementChild?.getBoundingClientRect().width||games.clientWidth)+16;const total=Math.max(1,games.children.length);const page=Math.max(1,Math.min(total,Math.round(games.scrollLeft/Math.max(1,step))+1));$('#clandestinePage').textContent=`${String(page).padStart(2,'0')} / ${String(total).padStart(2,'0')}`;$('#clandestinePrev').disabled=page===1;$('#clandestineNext').disabled=page===total;},{passive:true});
    $('#clandestinePlayFuga')?.addEventListener('click',(e)=>{e.stopPropagation();open({play:true});});
    const swipeBack=(surface,back)=>{let start=null;surface?.addEventListener('touchstart',e=>{if(state.running||state.preparing||e.target.closest?.('#clandestineGames')){start=null;return;}const t=e.touches[0];start={x:t.clientX,y:t.clientY};},{passive:true});surface?.addEventListener('touchend',e=>{if(!start)return;const t=e.changedTouches[0],dx=t.clientX-start.x,dy=t.clientY-start.y;start=null;if(dx < -85 && Math.abs(dx)>Math.abs(dy)*1.8)back();},{passive:true});};
    swipeBack(dialog,returnToArea);
    swipeBack($('#clandestineDialog'),()=>$('#clandestineDialog').close());
    $('#clandestineClose')?.addEventListener('click',()=>{$('#clandestineDialog').close();window.DANI_APP?.openPreparation?.({scroll:true,target:'operationStage5'});});
    $('#clandestineOverallRanking')?.addEventListener('click',()=>openHubSheet('ranking','overall'));
    $('#clandestinePrizeInfo')?.addEventListener('click',()=>openHubSheet('info','prizes'));
    $('#clandestineInfoInfiltration')?.addEventListener('click',()=>openHubSheet('info','infiltration'));$('#clandestineRankInfiltration')?.addEventListener('click',()=>openHubSheet('ranking','infiltration'));
    $('#clandestineInfoBlind')?.addEventListener('click',()=>openHubSheet('info','blind'));$('#clandestineRankBlind')?.addEventListener('click',()=>openHubSheet('ranking','blind'));
    $('#clandestineInfoSafe')?.addEventListener('click',()=>openHubSheet('info','safe'));$('#clandestineRankSafe')?.addEventListener('click',()=>openHubSheet('ranking','safe'));
    $('#clandestineInfoFuga')?.addEventListener('click',()=>openHubSheet('info','fuga'));$('#clandestineRankFuga')?.addEventListener('click',()=>openHubSheet('ranking','fuga'));
    bindHubSheetSwipe();$('#arcadeHubSheetBackdrop')?.addEventListener('click',closeHubSheet);
    $('#clandestineDialog')?.addEventListener('close',()=>{if(!dialog.open)document.body.classList.remove('arcade-open');});
    $('#arcadeEasterEgg')?.addEventListener('click',discoverAndOpen);$('#closeArcade')?.addEventListener('click',returnToArea);$('#arcadeExitGame')?.addEventListener('click',()=>{if(state.running&&!state.paused)pauseGame();else if(!state.running)returnToArea();});$('#arcadePauseExit')?.addEventListener('click',returnToArea);$('#arcadeResultBack')?.addEventListener('click',returnToArea);
    dialog?.addEventListener('cancel',(e)=>{e.preventDefault();if(state.running&&!state.paused)pauseGame();else if(!state.running)returnToArea();});
    dialog?.addEventListener('close',()=>{stopActiveGame();if(!$('#clandestineDialog')?.open)document.body.classList.remove('arcade-open');document.body.classList.remove('arcade-playing','operation-result-open');if(state.debug.enabled)exitDebug();});
    $('#arcadeStart')?.addEventListener('click',startGame);$('#arcadeRetry')?.addEventListener('click',startGame);
    const showFugaRanking=async()=>{close();await openArea();await openHubSheet('ranking','fuga');};
    $('#arcadeViewRanking')?.addEventListener('click',showFugaRanking);$('#arcadeIntroRanking')?.addEventListener('click',showFugaRanking);

    bindTouchSurface();
    state.viewportHandler=()=>syncGameViewport();window.addEventListener('resize',state.viewportHandler);window.visualViewport?.addEventListener('resize',state.viewportHandler);
    document.addEventListener('visibilitychange',()=>{if(state.running&&document.hidden)pauseGame();}); window.addEventListener('blur',()=>{if(state.running)pauseGame();});
    // Pausa al cambiar de app/pestaña, pero una navegación real nunca conserva la partida.
    window.addEventListener('pagehide',()=>{if(state.running||state.paused||state.preparing)stopActiveGame();});
    window.addEventListener('pageshow',e=>{if(e.persisted&&(state.running||state.paused||state.preparing||state.game))stopActiveGame();});
  }

document.addEventListener('dani:event-clock',()=>{if(state.status&&!state.running&&!state.preparing&&!state.finishing)renderStatus(state.status);});
bind();syncAccess();if(profile()?.id)refreshChampionship({announce:false});
window.DANI_ARCADE={syncProfile:()=>{syncAccess();if(profile()?.id){refreshChampionship({announce:true});refresh({announce:true});}},syncAccess,open,openArea,openHubSheet,closeHubSheet,refresh,refreshChampionship,openDebug,configureDebug,getDiagnostics,getDebug:()=>({...state.debug})};
})();
