/* FUGA 30 · crossing simulation V11 · Pursuit + pedestrian priority crosswalks.
 * Grid movement / cyclic traffic adapted from GeekBoySupreme/crossy-road,
 * Copyright (c) 2020 Shuvam Manna, MIT. See licenses/crossy-road-MIT.txt.
 * Deterministic fixed-step simulation, continuous collision, one-command input
 * buffer, human-playability validation, breathing traffic, surprise waves,
 * half-cell lateral precision, chained traffic windows, elastic police pursuit
 * and authoritative replay added for Operación 30.
 */
(function(root){'use strict';
const VERSION=11,HZ=120,STEP=17,FORWARD_STEP=17,LATERAL_STEP=12,LATERAL_DISTANCE=.5,COLS=9,MAX_TICKS=HZ*60*20,MAX_EVENTS=12000;
const CROSSWALK_GOAL=1,CROSSWALK_STOP_GAP=.18,CROSSWALK_QUEUE_GAP=.34,CROSSWALK_RELEASE_TICKS=Math.round(HZ*.55);
const WAIT_TICKS=10,SOLVER_HORIZON_TICKS=HZ*16,SEGMENT_ATTEMPTS=16,SOLVER_TIME_BUCKET=8;
const POLICE_WARNING_ROW=25,POLICE_ACTIVE_ROW=40,POLICE_MAX_DISTANCE=10.5,POLICE_INITIAL_DISTANCE=8.6,POLICE_CAPTURE_DISTANCE=0;
const POLICE_STREAK_TICKS=Math.round(HZ*2.15);
const DIR={forward:[0,1],backward:[0,-1],left:[-LATERAL_DISTANCE,0],right:[LATERAL_DISTANCE,0]};
const VEHICLE_SPECS=Object.freeze({
 car:Object.freeze({type:'car',minLength:.90,maxLength:1.08}),
 van:Object.freeze({type:'van',minLength:1.24,maxLength:1.50}),
 bus:Object.freeze({type:'bus',minLength:1.82,maxLength:2.20})
});
const TRAFFIC_FAMILIES=Object.freeze(['open','regular','irregular','platoon','heavy','scout','convoy','dense']);
const ROAD_CADENCES=Object.freeze([
 Object.freeze([2,2,3,2,4,3,2,4,3,5,3,4,6,4,5,3,6,5,7,4,6,5,8,6,5,7,4,8,6,9,5,7,6,8,5,9]),
 Object.freeze([2,3,2,3,2,4,3,2,5,3,4,2,5,4,6,3,5,7,4,6,5,8,4,7,6,5,9,6,8,5,7,9,6,8,5,7]),
 Object.freeze([2,2,3,4,2,3,5,3,2,4,6,3,5,4,7,4,6,5,3,7,5,8,6,4,7,5,9,6,5,8,7,6,9,5,8,6])
]);
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
function lerp(a,b,t){return a+(b-a)*t;}
function hashSeed(v){let h=2166136261;for(const c of String(v)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function rng(seed){let x=seed>>>0;return ()=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return x/4294967296;};}
function tierForRow(row){return clamp(Math.max(0,Number(row)||0)/210,0,1);}
function pursuitTierForRow(row){return clamp((Math.max(0,Number(row)||0)-POLICE_ACTIVE_ROW)/150,0,1);}
function policeTuningForRow(row){
 const t=pursuitTierForRow(row);
 return {tier:t,graceSeconds:lerp(3.05,1.45,t),approachRowsPerSecond:lerp(.62,.98,t),recoveryPerRow:lerp(.54,.40,t)};
}
function mod(v,m){return ((v%m)+m)%m;}
function fireLaneIndexForSegment(seed,segmentIndex,roads){
 if(segmentIndex<2||roads<2)return null;
 const random=rng(hashSeed(`${seed}:fire-segment:${segmentIndex}:${roads}`));
 const chance=segmentIndex<8?.18:.24;if(random()>=chance)return null;
 // Keep the emergency inside the active block and close to its entry, so it is
 // perceived as an immediate hazard instead of distant scenery.
 return 1+Math.floor(random()*Math.min(3,roads));
}
function isFireLane(row){return Boolean(row&&!row.safe&&row.emergencyType==='fire');}
function primeEmergencyPhase(row,leadSeconds=1.18){
 if(!isFireLane(row)||!Array.isArray(row.pattern)||!row.pattern.length)return row;
 const v=row.pattern[0],half=(v.length||1)/2,offset=v.offset||0;
 row.phase=row.dir>0?(-half-row.speed*leadSeconds-offset):(COLS+half+row.speed*leadSeconds-offset);
 return row;
}
function tuneEmergencyRow(row){
 if(!isFireLane(row))return row;
 // Emergency vehicles are intentionally a distinct hazard: large safe gaps,
 // strong pre-warning in presentation, but materially faster traversal.
 row.speed=clamp(Math.max(row.speed*1.78,4.35),4.35,5.35);row.speedClass='emergency';
 if(Array.isArray(row.gapSeconds)&&row.gapSeconds.length){
  const built=buildPattern(rng(hashSeed(`fire-pattern:${row.index}:${row.speed}`)),'scout',tierForRow(row.index),row.speed,Math.max(0,row.index));
  row.pattern=built.pattern;row.period=built.period;row.gapSeconds=built.gapSeconds;row.minGapSeconds=built.minGapSeconds;row.maxGapSeconds=built.maxGapSeconds;row.occupancy=built.occupancy;row.length=Math.max(...row.pattern.map(v=>v.length));
 }
 return primeEmergencyPhase(row);
}
function roadCapForSegment(segmentIndex){if(segmentIndex<2)return 2;if(segmentIndex<5)return 3;if(segmentIndex<9)return 4;if(segmentIndex<14)return 5;if(segmentIndex<20)return 6;if(segmentIndex<27)return 7;if(segmentIndex<34)return 8;return 9;}
function roadCountFor(startRow,sample=.5){
 const tier=tierForRow(startRow),r=clamp(Number(sample)||0,0,.999999);
 const choices=tier<.08?[2,2,3]:tier<.22?[2,3,4,3]:tier<.42?[3,4,5,3,4]:tier<.62?[3,4,5,6,4]:tier<.82?[4,5,6,7,5]:[5,6,7,8,9,6];
 return choices[Math.floor(r*choices.length)];
}
function roadCountForSegment(seed,segmentIndex){
 const cadence=ROAD_CADENCES[hashSeed(`${seed}:road-cadence`)%ROAD_CADENCES.length],offset=hashSeed(`${seed}:road-offset`)%7;
 if(segmentIndex===0)return 2;
 if(segmentIndex===1)return 2;
 // Deep runs deliberately expose 6–9 lane reads, but keep shorter blocks mixed
 // in so difficulty breathes instead of becoming a permanent wall.
 if(segmentIndex>=34){const late=[6,7,5,8,6,9,7,5,8,6,9,7];return late[(segmentIndex+offset)%late.length];}
 const cap=roadCapForSegment(segmentIndex),raw=cadence[(segmentIndex+offset)%cadence.length];
 return clamp(raw,2,cap);
}
function crosswalkForSegment(seed,segmentIndex,start,end){
 const random=rng(hashSeed(`${seed}:crosswalk:${segmentIndex}:${start}:${end}`)),roads=Math.max(1,end-start-1);
 // Crosswalks are deliberately special. They become a little more likely in
 // long road blocks, where pedestrian priority has the most strategic value.
 const chance=roads>=7?.18:roads>=5?.13:roads>=4?.10:.065;
 if(random()>=chance)return null;
 const center=clamp(Math.round((1.5+random()*5)*2)/2,1.5,6.5);
 const width=random()>.56?2:1.5;
 return {segmentIndex,start,end,center,width};
}
function xInsideCrosswalk(cw,x,margin=.16){return Boolean(cw)&&Math.abs(x-cw.center)<=Math.max(.20,cw.width/2-margin);}
function reserveCrosswalkAccess(segment){
 const cw=crosswalkForSegment(segment.seed,segment.index,segment.start,segment.end);segment.crosswalk=cw;if(!cw)return segment;
 const clearance=cw.width/2+.58;
 for(const row of [segment.rows[0],segment.rows[segment.rows.length-1]])if(row?.safe)row.blocked=(row.blocked||[]).filter(c=>Math.abs(c-cw.center)>=clearance);
 return segment;
}
function safeBlockedFor(seed,index){
 index=Math.max(0,Math.floor(Number(index)||0));if(index<34)return [];
 const random=rng(hashSeed(`${seed}:safe-obstacles:${index}`)),tier=tierForRow(index);
 const chance=clamp(.20+tier*.46,.20,.66);if(random()>=chance)return [];
 const early=[[0],[8],[1],[7],[2],[6],[3],[5],[1,2],[6,7]];
 const advanced=[[0,1],[7,8],[1,2],[6,7],[2,3],[5,6],[3,4],[4,5],[0,1,2],[6,7,8],[2,3,4],[4,5,6]];
 const pool=tier<.35?early:advanced,blocked=[...pool[Math.floor(random()*pool.length)]];
 if(blocked.length>3)blocked.length=3;
 return blocked.sort((a,b)=>a-b);
}
function safeRow(index,seed=0){return {index,safe:true,dir:0,speed:0,speedClass:'safe',length:0,period:0,phase:0,color:0,family:'safe',pattern:[],gapSeconds:[],minGapSeconds:Infinity,maxGapSeconds:Infinity,occupancy:0,blocked:safeBlockedFor(seed,index)};}
function chooseFamily(random,tier,segmentIndex,laneIndex,roads,denseUsed){
 const r=random();
 // The opening teaches reading and committing: no dense lanes at all.
 if(segmentIndex<2)return r<.42?'open':r<.67?'regular':r<.82?'heavy':r<.94?'scout':'platoon';
 // Dense traffic is an accent, never the default, and never dominates a block.
 const denseAllowed=tier>.26&&denseUsed<Math.max(1,Math.floor(roads/4));
 if(tier<.25)return r<.25?'open':r<.45?'regular':r<.60?'irregular':r<.75?'platoon':r<.86?'heavy':r<.95?'scout':'convoy';
 if(tier<.60){
  if(r<.15)return 'open';if(r<.31)return 'regular';if(r<.46)return 'irregular';if(r<.62)return 'platoon';if(r<.74)return 'heavy';if(r<.85)return 'scout';if(r<.95)return 'convoy';return denseAllowed?'dense':'open';
 }
 if(r<.12)return 'open';if(r<.24)return 'regular';if(r<.39)return 'irregular';if(r<.56)return 'platoon';if(r<.67)return 'heavy';if(r<.79)return 'scout';if(r<.91)return 'convoy';return denseAllowed?'dense':'irregular';
}
function vehicleTypeFor(random,family,tier,index){
 if(family==='heavy'||family==='convoy'){
  if(index===0||random()<.52)return random()<(.40+tier*.24)?'bus':'van';
  return random()<.55?'van':'car';
 }
 if(family==='platoon')return random()<(.07+tier*.08)?'van':'car';
 if(family==='scout')return 'car';
 if(random()<(.07+tier*.10))return 'van';
 return 'car';
}
function vehicleLength(random,type){const spec=VEHICLE_SPECS[type]||VEHICLE_SPECS.car;return lerp(spec.minLength,spec.maxLength,random());}
function speedForRow(random,family,tier,segmentIndex){
 let speedClass='cruise',speed;
 if(family==='scout'){
  speedClass='fast';speed=lerp(segmentIndex<5?1.55:2.05,segmentIndex<5?2.05:3.10,random());
 }else if(family==='heavy'||family==='convoy'){
  speedClass='slow';speed=lerp(.56,.92+tier*.28,random());
 }else{
  const band=random();
  if(band<.28){speedClass='slow';speed=lerp(.68,.98+tier*.16,random());}
  else if(band<.76){speedClass='cruise';speed=lerp(.98+tier*.16,1.42+tier*.36,random());}
  else{speedClass='fast';speed=lerp(1.48+tier*.18,2.18+tier*.72,random());}
 }
 if(family==='dense')speed*=1.02;
 if(segmentIndex<2)speed=Math.min(speed,1.55);
 return {speed:clamp(speed,.54,3.15),speedClass};
}
function gapProfile(random,family,tier,count,segmentIndex){
 const ease=segmentIndex<2?1.18:segmentIndex<5?1.08:1;
 const jitter=(a,b)=>Math.max(.72,lerp(a,b,random())*ease),g=[];
 if(family==='open'){
  for(let i=0;i<count;i++)g.push(jitter(i===count-1?4.8:3.0,i===count-1?7.4:4.8));return g;
 }
 if(family==='regular'){
  for(let i=0;i<count;i++)g.push(jitter(2.05,3.45));return g;
 }
 if(family==='dense'){
  // Even the densest lane has a release window; it is pressure, not a wall.
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(3.2,4.8):jitter(1.22,1.90));return g;
 }
 if(family==='heavy'){
  for(let i=0;i<count;i++)g.push(jitter(3.0,5.8));return g;
 }
 if(family==='scout'){
  for(let i=0;i<count;i++)g.push(jitter(5.2,8.4));return g;
 }
 if(family==='convoy'){
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(4.5,7.0):jitter(1.25,2.05));return g;
 }
 if(family==='platoon'){
  for(let i=0;i<count;i++)g.push(i===count-1?jitter(4.6,7.2):jitter(.78,1.28));return g;
 }
 // Irregular lanes deliberately tell a little story: short pressure, medium gap,
 // then a generous invitation. Shuffle where that invitation lands.
 const bands=[[1.15,1.70],[2.0,3.0],[3.7,5.8],[1.45,2.20],[4.2,6.5]];
 const order=Array.from({length:count},(_,i)=>i);
 for(let i=order.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
 for(let i=0;i<count;i++){const b=bands[order[i]%bands.length];g.push(jitter(b[0],b[1]));}
 return g;
}
function buildPattern(random,family,tier,speed,segmentIndex){
 let count;
 if(family==='scout')count=1;
 else if(family==='heavy')count=random()<.72?1:2;
 else if(family==='convoy')count=random()<.66?2:3;
 else if(family==='platoon')count=random()<.68?3:4;
 else if(family==='open')count=random()<.74?1:2;
 else if(family==='dense')count=random()<.70?3:4;
 else count=random()<.55?2:3;
 const vehicles=[];for(let i=0;i<count;i++){const type=vehicleTypeFor(random,family,tier,i);vehicles.push({type,length:vehicleLength(random,type),color:Math.floor(random()*7)});}
 const gaps=gapProfile(random,family,tier,count,segmentIndex),pattern=[];let center=0;
 for(let i=0;i<count;i++){
  if(i===0)center=vehicles[i].length/2;
  else center=pattern[i-1].offset+vehicles[i-1].length/2+speed*gaps[i-1]+vehicles[i].length/2;
  pattern.push({offset:center,length:vehicles[i].length,type:vehicles[i].type,color:vehicles[i].color});
 }
 const last=pattern[count-1],period=last.offset+last.length/2+speed*gaps[count-1];
 const occupied=pattern.reduce((sum,v)=>sum+v.length+.40,0),occupancy=clamp(occupied/Math.max(period,.01),0,1);
 return {pattern,period,gapSeconds:gaps,minGapSeconds:Math.min(...gaps),maxGapSeconds:Math.max(...gaps),occupancy};
}
function gapCenterOffset(row,gapIndex){
 const pattern=row.pattern||[],i=clamp(Math.floor(gapIndex||0),0,Math.max(0,pattern.length-1)),v=pattern[i];
 if(!v)return 0;return v.offset+v.length/2+row.speed*(row.gapSeconds?.[i]||0)/2;
}
function applyChainedWindow(rows,random,start,roads){
 if(start<35||roads<3)return null;
 const chance=clamp(.16+(start-35)/190*.36,.16,.52);if(random()>=chance)return null;
 const maxSpan=Math.min(6,roads),span=Math.min(maxSpan,3+Math.floor(random()*Math.max(1,maxSpan-2)));
 const first=1+Math.floor(random()*Math.max(1,roads-span+1));let x=4+(random()<.5?-.5:.5),elapsed=5;const targets=[];
 for(let j=0;j<span;j++){
  const row=rows[first+j];if(!row||row.safe)continue;
  if(j&&random()<.42)x=clamp(x+(random()<.5?-.5:.5),1,7);
  elapsed+=FORWARD_STEP+(j&&Math.abs(x-(targets.at(-1)?.x??x))>.01?LATERAL_STEP:0);
  let gap=0,best=-1;for(let i=0;i<(row.gapSeconds||[]).length;i++)if(row.gapSeconds[i]>best){best=row.gapSeconds[i];gap=i;}
  const center=gapCenterOffset(row,gap);row.phase=mod(x-row.dir*row.speed*elapsed/HZ-center,row.period);row.chainTarget={tick:elapsed,x,gap};targets.push({row:row.index,tick:elapsed,x,gap});
 }
 return targets.length>=3?{firstRow:rows[first]?.index||start+1,span:targets.length,targets}:null;
}
function cars(row,tick){
 if(!row||row.safe)return [];
 const pattern=Array.isArray(row.pattern)&&row.pattern.length?row.pattern:[{offset:0,length:row.length||1,type:'car',color:row.color||0}];
 const period=Math.max(.01,row.period||4),shift=row.phase+row.dir*row.speed*tick/HZ;
 const maxWidth=Math.max(...pattern.map(v=>v.length||1),1),first=Math.floor((-maxWidth-period-shift)/period),last=Math.ceil((COLS+maxWidth+period-shift)/period),out=[];
 for(let k=first;k<=last;k++)for(let pi=0;pi<pattern.length;pi++){const v=pattern[pi],x=shift+k*period+v.offset;if(x<-maxWidth*1.5||x>COLS+maxWidth*1.5)continue;out.push({id:`${k}:${pi}`,x,width:v.length||1,type:v.type||'car',color:Number.isInteger(v.color)?v.color:(row.color||0)});}
 return out;
}
function segmentForRow(s,index){ensureSegmentsThrough(s,index);return s.segments.find(seg=>index>=seg.start&&index<=seg.end)||null;}
function crosswalkAt(s,index){
 const seg=segmentForRow(s,index);if(!seg?.crosswalk)return null;const cw=seg.crosswalk,cs=s.crosswalk;
 return {...cw,golden:cs.goldenSegmentIndex===seg.index,active:cs.gate?.segmentIndex===seg.index&&(cs.gate.releaseTick==null||s.tick<=cs.gate.releaseTick)};
}
function gateHolding(s,segmentIndex,tick=s.tick){const gate=s.crosswalk?.gate;return Boolean(gate&&gate.segmentIndex===segmentIndex&&(gate.releaseTick==null||tick<=gate.releaseTick));}
function trafficRowSnapshot(row,cw,segmentIndex,tick){
 const left=cw.center-cw.width/2,right=cw.center+cw.width/2,dir=row.dir||1,vehicles={};
 for(const car of cars(row,tick)){
  const inside=car.x+car.width/2>=left&&car.x-car.width/2<=right;
  const passed=dir>0?(car.x-car.width/2>right):(car.x+car.width/2<left);
  vehicles[car.id]={...car,x:car.x,free:inside||passed,stopped:false};
 }
 return {rowIndex:row.index,segmentIndex,lastTick:tick,crosswalk:{center:cw.center,width:cw.width},vehicles};
}
function cloneTrafficRowState(rs){const vehicles={};for(const [id,car] of Object.entries(rs.vehicles||{}))vehicles[id]={...car};return {...rs,crosswalk:{...rs.crosswalk},vehicles};}
function advanceTrafficRowState(s,source,row,targetTick,mutate=true){
 const rs=mutate?source:cloneTrafficRowState(source),tick=Math.max(rs.lastTick,Math.floor(targetTick)),dt=tick-rs.lastTick,dir=row.dir||1,speed=Math.max(0,row.speed||0),cw=rs.crosswalk,left=cw.center-cw.width/2,right=cw.center+cw.width/2;
 if(dt>0){const dx=dir*speed*dt/HZ;for(const car of Object.values(rs.vehicles)) {car.x+=dx;car.stopped=false;}}
 // Only admit traffic from the upstream edge. This prevents the cyclic base
 // pattern from materialising a vehicle beyond a closed crosswalk.
 for(const car of cars(row,tick)){
  if(rs.vehicles[car.id])continue;const upstream=dir>0?(car.x+car.width/2<left):(car.x-car.width/2>right);
  if(upstream)rs.vehicles[car.id]={...car,x:car.x,free:false,stopped:false};
 }
 const active=gateHolding(s,rs.segmentIndex,tick),ordered=Object.values(rs.vehicles).sort((a,b)=>dir>0?b.x-a.x:a.x-b.x);
 if(active){
  let frontier=dir>0?left-CROSSWALK_STOP_GAP:right+CROSSWALK_STOP_GAP;
  for(const car of ordered){
   if(car.free)continue;
   const target=dir>0?frontier-car.width/2:frontier+car.width/2;
   if((dir>0&&car.x>target)||(dir<0&&car.x<target)){car.x=target;car.stopped=true;}
   frontier=dir>0?car.x-car.width/2-CROSSWALK_QUEUE_GAP:car.x+car.width/2+CROSSWALK_QUEUE_GAP;
  }
 }else{
  // Once released, vehicles resume from their held coordinates. Keep the
  // physical spacing while the delayed stream clears instead of snapping
  // back onto the underlying cyclic traffic timeline.
  let previous=null;
  for(const car of ordered){
   if(previous){
    const target=dir>0?previous.x-previous.width/2-CROSSWALK_QUEUE_GAP-car.width/2:previous.x+previous.width/2+CROSSWALK_QUEUE_GAP+car.width/2;
    if((dir>0&&car.x>target)||(dir<0&&car.x<target))car.x=target;
   }
   car.stopped=false;previous=car;
  }
 }
 const margin=Math.max(2.5,Math.max(...Object.values(rs.vehicles).map(v=>v.width||1),1)*1.8);
 for(const [id,car] of Object.entries(rs.vehicles)){if((dir>0&&car.x>COLS+margin)||(dir<0&&car.x<-margin))delete rs.vehicles[id];}
 rs.lastTick=tick;return rs;
}
function updateCrosswalkTraffic(s){
 const rows=s.crosswalk?.trafficRows;if(!rows)return;
 for(const rs of Object.values(rows)){const row=rowAt(s,rs.rowIndex);if(!row||row.safe||isFireLane(row))continue;advanceTrafficRowState(s,rs,row,s.tick,true);}
}
function carsForState(s,row,tick=s.tick){
 if(!s||row?.safe)return cars(row,tick);
 if(isFireLane(row)){const localTick=fireLaneTickForState(s,row,tick);return localTick==null?[]:cars(row,localTick);}
 const base=cars(row,tick),rs=s.crosswalk?.trafficRows?.[row.index];if(!rs)return base;
 const view=tick===rs.lastTick?rs:advanceTrafficRowState(s,rs,row,tick,false);
 return Object.values(view.vehicles).map(car=>({...car}));
}
function candidateSegment(seed,segmentIndex,start,attempt){
 const random=rng(hashSeed(`${seed}:segment:${segmentIndex}:attempt:${attempt}`)),tier=tierForRow(start),roads=roadCountForSegment(seed,segmentIndex),rows=[safeRow(start,seed)],fireLaneIndex=fireLaneIndexForSegment(seed,segmentIndex,roads);
 let previousDir=random()<.5?-1:1,previousSpeed=null,denseUsed=0,openish=0;
 for(let i=1;i<=roads;i++){
  let family=i===fireLaneIndex?'scout':chooseFamily(random,tier,segmentIndex,i,roads,denseUsed);if(family==='dense')denseUsed++;if(['open','heavy','scout','platoon','convoy'].includes(family))openish++;
  const speedInfo=speedForRow(random,family,tier,segmentIndex);let speed=speedInfo.speed;
  // Adjacent lanes should ask different timing questions rather than move on one belt.
  if(previousSpeed!=null&&Math.abs(speed-previousSpeed)<.18&&random()<.78){speed=clamp(speed+(random()<.5?-.34:.38),.54,3.15);}
  previousSpeed=speed;
  let dir;if(i===1)dir=previousDir;else{const r=random();dir=r<.52?previousDir:r<.92?-previousDir:(random()<.5?-1:1);}previousDir=dir;
  const built=buildPattern(random,family,tier,speed,segmentIndex),representative=Math.max(...built.pattern.map(v=>v.length));
  rows.push(tuneEmergencyRow({index:start+i,safe:false,dir,speed,speedClass:speedInfo.speedClass,length:representative,period:built.period,phase:random()*built.period,color:built.pattern[0]?.color||0,family,pattern:built.pattern,gapSeconds:built.gapSeconds,minGapSeconds:built.minGapSeconds,maxGapSeconds:built.maxGapSeconds,occupancy:built.occupancy,blocked:[],segmentIndex,laneIndex:i,emergencyType:i===fireLaneIndex?'fire':null}));
 }
 // A long block must contain several lanes that visibly breathe. If randomness
 // failed to do so, reject it before the expensive solver.
 const requiredOpenish=segmentIndex<2?roads:Math.max(1,Math.ceil(roads*.42));
 const end=start+roads+1;rows.push(safeRow(end,seed));
 const chainWindow=applyChainedWindow(rows,random,start,roads);
 for(const row of rows)if(isFireLane(row))primeEmergencyPhase(row);
 return reserveCrosswalkAccess({seed,index:segmentIndex,start,end,roads,tier,attempt,rows,fallback:false,openish,requiredOpenish,chainWindow});
}
function fallbackSegment(seed,segmentIndex,start){
 const tier=tierForRow(start),roads=roadCountForSegment(seed,segmentIndex),rows=[safeRow(start,seed)],base=hashSeed(`${seed}:segment:${segmentIndex}:fallback`)%2?-1:1;
 for(let i=1;i<=roads;i++){
  const speed=clamp(.82+tier*.42+(i%3)*.18,.72,1.65),dir=i%3===0?-base:base,length=1.0,gaps=i%2?[2.3,4.8]:[3.0,5.5],period=(length+speed*gaps[0])+(length+speed*gaps[1]);
  const pattern=[{offset:length/2,length,type:'car',color:(segmentIndex+i)%7},{offset:length/2+length+speed*gaps[0],length,type:'car',color:(segmentIndex+i+2)%7}];
  const occupancy=(pattern.reduce((sum,v)=>sum+v.length+.40,0))/period;
  rows.push({index:start+i,safe:false,dir,speed,speedClass:i%3?'cruise':'slow',length,period,phase:(period*.19*i)%period,color:pattern[0].color,family:'fallback',pattern,gapSeconds:gaps,minGapSeconds:Math.min(...gaps),maxGapSeconds:Math.max(...gaps),occupancy,blocked:[]});
 }
 const end=start+roads+1;rows.push(safeRow(end,seed));return reserveCrosswalkAccess({seed,index:segmentIndex,start,end,roads,tier,attempt:-1,rows,fallback:true,openish:roads,requiredOpenish:1,chainWindow:null});
}
function rowFromSegment(segment,index){return segment.rows[index-segment.start]||null;}
function safeObstacleAtSegment(segment,x,y){
 for(let ry=Math.max(segment.start,Math.floor(y)-1);ry<=Math.min(segment.end,Math.ceil(y)+1);ry++){
  if(Math.abs(y-ry)>=.43)continue;const row=rowFromSegment(segment,ry);if(!row||!row.safe)continue;
  for(const c of row.blocked||[])if(Math.abs(x-c)<.56)return true;
 }return false;
}
function collisionAtSegment(segment,x,y,tick){
 for(let ry=Math.max(segment.start,Math.floor(y)-1);ry<=Math.min(segment.end,Math.ceil(y)+1);ry++){
  if(Math.abs(y-ry)>=.49)continue;const row=rowFromSegment(segment,ry);if(!row||row.safe)continue;
  for(const car of cars(row,tick))if(Math.abs(x-car.x)<car.width/2+.20)return true;
 }return false;
}
function intervalSafe(segment,x0,y0,x1,y1,startTick,duration){
 for(let dt=1;dt<=duration;dt++){const p=dt/duration,x=x0+(x1-x0)*p,y=y0+(y1-y0)*p;if(safeObstacleAtSegment(segment,x,y)||collisionAtSegment(segment,x,y,startTick+dt))return false;}return true;
}
function durationFor(dir){return dir==='left'||dir==='right'?LATERAL_STEP:FORWARD_STEP;}
function xKey(x){return Math.round(x/LATERAL_DISTANCE);}
function traverseTicks(segment,startTick=0){
 const horizon=SOLVER_HORIZON_TICKS,queue=[],seen=new Set();
 for(let xi=0;xi<=Math.round((COLS-1)/LATERAL_DISTANCE);xi++){const x=xi*LATERAL_DISTANCE;if(safeObstacleAtSegment(segment,x,segment.start))continue;queue.push({x,y:segment.start,t:0});seen.add(`0:${xi}:${segment.start}`);}
 let head=0;const push=(node)=>{if(node.t>horizon)return;const key=`${Math.floor(node.t/SOLVER_TIME_BUCKET)}:${xKey(node.x)}:${node.y}`;if(seen.has(key))return;seen.add(key);queue.push(node);};
 while(head<queue.length){const n=queue[head++];if(n.y>=segment.end)return n.t;
  if(intervalSafe(segment,n.x,n.y,n.x,n.y,startTick+n.t,WAIT_TICKS))push({x:n.x,y:n.y,t:n.t+WAIT_TICKS});
  for(const d of ['forward','left','right']){const [dx,dy]=DIR[d],nx=n.x+dx,ny=n.y+dy,duration=durationFor(d);if(nx<0||nx>COLS-1||ny<segment.start||ny>segment.end)continue;if(intervalSafe(segment,n.x,n.y,nx,ny,startTick+n.t,duration))push({x:nx,y:ny,t:n.t+duration});}
 }
 return Infinity;
}
function canTraverseSegment(segment,startTick=0){return Number.isFinite(traverseTicks(segment,startTick));}
function humanReadableSegment(segment){
 const roads=segment.rows.filter(r=>!r.safe);if(!roads.length)return false;
 if(segment.openish<segment.requiredOpenish)return false;
 const tier=segment.tier,maxOccupancy=tier<.15?.38:tier<.55?.45:.50,minBigGap=tier<.15?3.3:tier<.55?2.75:2.45;
 let generous=0;
 for(const row of roads){
  if((row.occupancy||0)>maxOccupancy)return false;
  if((row.maxGapSeconds||0)<minBigGap)return false;
  if((row.maxGapSeconds||0)>=4.0)generous++;
 }
 if(generous<Math.max(1,Math.ceil(roads.length*.34)))return false;
 const offsets=[0,Math.floor(HZ*1.83),Math.floor(HZ*4.17)],times=offsets.map(t=>traverseTicks(segment,t));
 if(times.some(t=>!Number.isFinite(t)))return false;
 // A mathematically valid segment that takes forever to unlock is not fun.
 const maxSeconds=segment.index<2?6.2:segment.roads<=4?8.2:segment.roads<=6?10.8:13.8;
 return Math.max(...times)/HZ<=maxSeconds;
}
function segmentValid(segment){return humanReadableSegment(segment);}
function buildSegment(seed,segmentIndex,start){
 for(let attempt=0;attempt<SEGMENT_ATTEMPTS;attempt++){const seg=candidateSegment(seed,segmentIndex,start,attempt);if(segmentValid(seg))return seg;}
 const fallback=fallbackSegment(seed,segmentIndex,start);if(!segmentValid(fallback))throw Error('No se pudo construir un tramo jugable');return fallback;
}
function storeSegmentRows(s,segment){for(const row of segment.rows){const existing=s.rows.get(row.index);if(existing?.safe&&row.safe){const keep=new Set(row.blocked||[]);existing.blocked=(existing.blocked||[]).filter(c=>keep.has(c));s.rows.set(row.index,existing);}else s.rows.set(row.index,row);}}
function ensureSegmentsThrough(s,index){
 if(!s.segments.length){const first=buildSegment(s.seed,0,0);s.segments.push(first);storeSegmentRows(s,first);maybeAssignGoldenSegment(s,first);}
 while(s.segments[s.segments.length-1].end<index){const prev=s.segments[s.segments.length-1],next=buildSegment(s.seed,s.segments.length,prev.end);s.segments.push(next);storeSegmentRows(s,next);maybeAssignGoldenSegment(s,next);}
}
function activeSegmentForState(s){
 ensureSegmentsThrough(s,Math.max(1,Math.floor(s.y)+1));
 return s.segments.find(seg=>s.y>=seg.start&&s.y<seg.end)||s.segments[s.segments.length-1]||null;
}
function fireLaneTickForState(s,row,tick=s.tick){
 if(!s||!isFireLane(row))return null;const seg=activeSegmentForState(s);if(!seg||row.segmentIndex!==seg.index)return null;
 if(s.fireSegments[seg.index]==null)s.fireSegments[seg.index]=tick;
 return Math.max(0,tick-s.fireSegments[seg.index]);
}
function isFireLaneActive(s,row){return fireLaneTickForState(s,row,s?.tick??0)!=null;}
function rowAt(s,index){index=Math.max(0,Math.floor(Number(index)||0));if(!s.rows.has(index)){ensureSegmentsThrough(s,index);if(!s.rows.has(index)){const seg=s.segments.find(item=>index>=item.start&&index<=item.end);const row=seg?rowFromSegment(seg,index):null;if(row)s.rows.set(index,row);}}return s.rows.get(index)||safeRow(index,s.seed);}
function create(seed=302026){
 const s={seed:seed>>>0,tick:0,x:4,y:0,maxRow:0,move:null,queued:null,rows:new Map(),segments:[],events:[],over:false,reason:'',started:false,
  police:{active:false,distance:POLICE_INITIAL_DISTANCE,lastProgressTick:0,lastMaxRow:0,streak:0,lastStreakTick:-999999,band:'hidden',startedTick:null},
  crosswalk:{goodCrossings:0,rewardReady:false,goldenSegmentIndex:null,goldenAfterSegmentIndex:null,progress:null,completedSegments:new Set(),gate:null,trafficRows:{},eventSeq:0,lastEvent:null},fireSegments:{}};
 ensureSegmentsThrough(s,1);return s;
}
function derivePoliceBand(s){
 const p=s.police;if(s.maxRow<POLICE_WARNING_ROW)return 'hidden';if(!p.active)return 'signal';
 if(p.band==='danger'&&p.distance<=2.85)return 'danger';
 if(p.band==='pressure'&&p.distance<=5.75&&p.distance>2.25)return 'pressure';
 if(p.distance<=2.30)return 'danger';if(p.distance<=5.10)return 'pressure';return 'safe';
}
function policeSnapshot(s){
 const p=s.police,t=policeTuningForRow(s.maxRow),idle=Math.max(0,(s.tick-p.lastProgressTick)/HZ),grace=Math.max(0,t.graceSeconds-idle);
 return {warning:s.maxRow>=POLICE_WARNING_ROW,active:p.active,distance:p.distance,maxDistance:POLICE_MAX_DISTANCE,band:derivePoliceBand(s),streak:p.streak,graceSeconds:t.graceSeconds,graceRemaining:grace,approachRowsPerSecond:t.approachRowsPerSecond,recoveryPerRow:t.recoveryPerRow};
}
function updatePolice(s){
 const p=s.police;if(s.maxRow>=POLICE_ACTIVE_ROW&&!p.active){p.active=true;p.distance=POLICE_INITIAL_DISTANCE;p.lastProgressTick=s.tick;p.lastMaxRow=s.maxRow;p.streak=0;p.lastStreakTick=s.tick;p.startedTick=s.tick;}
 if(s.maxRow>p.lastMaxRow){
  const delta=s.maxRow-p.lastMaxRow;p.lastMaxRow=s.maxRow;
  if(p.active){const tuning=policeTuningForRow(s.maxRow),chained=s.tick-p.lastStreakTick<=POLICE_STREAK_TICKS;p.streak=chained?p.streak+delta:delta;p.lastStreakTick=s.tick;
   const chainBonus=Math.min(.55,Math.max(0,p.streak-1)*.12);p.distance=clamp(p.distance+delta*(tuning.recoveryPerRow+chainBonus),POLICE_CAPTURE_DISTANCE,POLICE_MAX_DISTANCE);p.lastProgressTick=s.tick;}
 }
 if(!p.active){p.band=derivePoliceBand(s);return;}
 const tuning=policeTuningForRow(s.maxRow),idleTicks=s.tick-p.lastProgressTick;if(idleTicks>Math.round(tuning.graceSeconds*HZ))p.distance=Math.max(POLICE_CAPTURE_DISTANCE,p.distance-tuning.approachRowsPerSecond/HZ);
 if(s.tick-p.lastStreakTick>POLICE_STREAK_TICKS)p.streak=0;p.band=derivePoliceBand(s);
 if(p.distance<=POLICE_CAPTURE_DISTANCE){s.over=true;s.reason='police';s.queued=null;}
}
function emitCrosswalkEvent(s,type,extra={}){const cs=s.crosswalk;cs.eventSeq++;cs.lastEvent={seq:cs.eventSeq,type,...extra};}
function maybeAssignGoldenSegment(s,seg){
 const cs=s.crosswalk;if(!cs?.rewardReady||cs.goldenSegmentIndex!=null||!seg?.crosswalk)return null;
 if(seg.index<=Number(cs.goldenAfterSegmentIndex??-1))return null;cs.goldenSegmentIndex=seg.index;return seg.crosswalk;
}
function assignNextGoldenCrosswalk(s,afterSegmentIndex){
 const cs=s.crosswalk;cs.rewardReady=true;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=afterSegmentIndex;
 for(const seg of s.segments)if(seg.index>afterSegmentIndex&&seg.crosswalk){cs.goldenSegmentIndex=seg.index;return seg.crosswalk;}
 return null;
}
function activateGoldenCrosswalk(s,seg){
 const cs=s.crosswalk,cw=seg.crosswalk,allowedByRow={};
 for(const row of seg.rows){
  if(row.safe)continue;const left=cw.center-cw.width/2,right=cw.center+cw.width/2;
  allowedByRow[row.index]=cars(row,s.tick).filter(car=>car.x+car.width/2>=left&&car.x-car.width/2<=right).map(car=>car.id);
  if(!isFireLane(row))cs.trafficRows[row.index]=trafficRowSnapshot(row,cw,seg.index,s.tick);
 }
 cs.gate={segmentIndex:seg.index,activatedTick:s.tick,releaseTick:null,allowedByRow};emitCrosswalkEvent(s,'priority',{segmentIndex:seg.index});
}
function releaseGoldenGate(s,immediate=false){const gate=s.crosswalk.gate;if(!gate)return;gate.releaseTick=immediate?s.tick:s.tick+CROSSWALK_RELEASE_TICKS;}
function loseGoldenCrosswalk(s){const cs=s.crosswalk;if(!cs.rewardReady&&!cs.goldenSegmentIndex)return;releaseGoldenGate(s,true);cs.goodCrossings=0;cs.rewardReady=false;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=null;cs.progress=null;emitCrosswalkEvent(s,'lost',{count:0});}
function beginCrosswalkIfNeeded(s,dir,targetX,targetY){
 if(dir!=='forward')return;const seg=segmentForRow(s,targetY);if(!seg?.crosswalk||Math.abs(s.y-seg.start)>.001)return;const cs=s.crosswalk,cw=seg.crosswalk;
 if(!xInsideCrosswalk(cw,targetX)){if(cs.goldenSegmentIndex===seg.index)cs.progress={segmentIndex:seg.index,valid:false,golden:true};return;}
 cs.progress={segmentIndex:seg.index,valid:true,golden:cs.goldenSegmentIndex===seg.index};
 if(cs.progress.golden&&cs.rewardReady)activateGoldenCrosswalk(s,seg);
}
function updateCrosswalkProgress(s){
 const cs=s.crosswalk,p=position(s),progress=cs.progress;if(!progress)return;const seg=s.segments.find(item=>item.index===progress.segmentIndex);if(!seg?.crosswalk){cs.progress=null;return;}
 if(!xInsideCrosswalk(seg.crosswalk,p.x)){if(progress.valid&&progress.golden)releaseGoldenGate(s,true);progress.valid=false;}
 if(s.move?.dir==='backward'){if(progress.valid&&progress.golden)releaseGoldenGate(s,true);progress.valid=false;}
}
function finishCrosswalkIfNeeded(s){
 const cs=s.crosswalk,progress=cs.progress;if(!progress)return;const seg=s.segments.find(item=>item.index===progress.segmentIndex);if(!seg?.crosswalk)return;
 if(Math.abs(s.y-seg.end)>.001)return;
 const valid=progress.valid&&xInsideCrosswalk(seg.crosswalk,s.x),golden=progress.golden;cs.progress=null;
 if(golden){
  if(valid&&cs.rewardReady){releaseGoldenGate(s,false);cs.goodCrossings=0;cs.rewardReady=false;cs.goldenSegmentIndex=null;cs.goldenAfterSegmentIndex=null;cs.completedSegments.add(seg.index);emitCrosswalkEvent(s,'consumed',{count:0,segmentIndex:seg.index});}
  else loseGoldenCrosswalk(s);
  return;
 }
 if(valid&&!cs.completedSegments.has(seg.index)){
  cs.completedSegments.add(seg.index);cs.goodCrossings=Math.min(CROSSWALK_GOAL,cs.goodCrossings+1);
  if(cs.goodCrossings>=CROSSWALK_GOAL){assignNextGoldenCrosswalk(s,seg.index);emitCrosswalkEvent(s,'unlock',{count:CROSSWALK_GOAL,goldenSegmentIndex:cs.goldenSegmentIndex});}
  else emitCrosswalkEvent(s,'good',{count:cs.goodCrossings});
 }
}
function checkGoldenSkipped(s){const cs=s.crosswalk;if(!cs.rewardReady||cs.goldenSegmentIndex==null)return;const seg=s.segments.find(item=>item.index===cs.goldenSegmentIndex);if(seg&&s.maxRow>=seg.end&&!cs.completedSegments.has(seg.index)&&(!cs.progress||cs.progress.segmentIndex!==seg.index))loseGoldenCrosswalk(s);}
function updateCrosswalkGate(s){const gate=s.crosswalk.gate;if(gate?.releaseTick!=null&&s.tick>gate.releaseTick)s.crosswalk.gate=null;}
function crosswalkSnapshot(s){const cs=s.crosswalk;return {goodCrossings:cs.goodCrossings,goal:CROSSWALK_GOAL,rewardReady:cs.rewardReady,goldenSegmentIndex:cs.goldenSegmentIndex,activeSegmentIndex:gateHolding(s,cs.gate?.segmentIndex??-1)?cs.gate.segmentIndex:null,eventSeq:cs.eventSeq,lastEvent:cs.lastEvent?{...cs.lastEvent}:null};}
function position(s){if(!s.move)return {x:s.x,y:s.y,lift:0};const p=Math.min(1,(s.tick-s.move.at)/s.move.duration);return {x:s.x+s.move.dx*p,y:s.y+s.move.dy*p,lift:Math.sin(p*Math.PI)};}
function safeObstacleAtState(s,x,y){
 for(let ry=Math.max(0,Math.floor(y)-1);ry<=Math.ceil(y)+1;ry++){
  if(Math.abs(y-ry)>=.43)continue;const row=rowAt(s,ry);if(!row.safe)continue;
  for(const c of row.blocked||[])if(Math.abs(x-c)<.56)return true;
 }return false;
}
function movementHitsSafeObstacle(s,x0,y0,x1,y1,duration){
 for(let dt=1;dt<=duration;dt++){const p=dt/duration;if(safeObstacleAtState(s,x0+(x1-x0)*p,y0+(y1-y0)*p))return true;}return false;
}
function begin(s,dir){const [dx,dy]=DIR[dir],x=s.x+dx,y=s.y+dy,duration=durationFor(dir);if(x<0||x>COLS-1||y<Math.max(0,s.maxRow-3)||movementHitsSafeObstacle(s,s.x,s.y,x,y,duration))return false;beginCrosswalkIfNeeded(s,dir,x,y);s.move={at:s.tick,dx,dy,duration,dir};s.started=true;return true;}
function input(s,dir,record=true){if(s.over||!DIR[dir]||s.events.length>=MAX_EVENTS)return false;if(s.move){if(s.queued)return false;s.queued=dir;}else if(!begin(s,dir))return false;if(record)s.events.push({t:s.tick,d:dir});return true;}
function collision(s){const p=position(s);for(let y=Math.max(0,Math.floor(p.y)-1);y<=Math.ceil(p.y)+1;y++){if(Math.abs(p.y-y)>=.49)continue;for(const car of carsForState(s,rowAt(s,y),s.tick))if(Math.abs(p.x-car.x)<car.width/2+.20)return true;}return false;}
function step(s){
 if(s.over)return s;s.tick++;updateCrosswalkProgress(s);updateCrosswalkGate(s);updateCrosswalkTraffic(s);
 if(collision(s)){s.over=true;s.reason='traffic';s.queued=null;return s;}
 if(s.move&&s.tick-s.move.at>=s.move.duration){s.x+=s.move.dx;s.y+=s.move.dy;s.x=Math.round(s.x/LATERAL_DISTANCE)*LATERAL_DISTANCE;s.move=null;if(s.y>s.maxRow)s.maxRow=s.y;finishCrosswalkIfNeeded(s);checkGoldenSkipped(s);if(s.queued){const d=s.queued;s.queued=null;begin(s,d);}}
 updatePolice(s);if(s.over)return s;
 if(s.tick>=MAX_TICKS){s.over=true;s.reason='extraction';s.queued=null;}
 if(s.tick%HZ===0){for(const y of s.rows.keys())if(y<s.maxRow-12)s.rows.delete(y);for(const key of Object.keys(s.crosswalk.trafficRows||{}))if(Number(key)<s.maxRow-14)delete s.crosswalk.trafficRows[key];for(const [segIndex] of Object.entries(s.fireSegments||{})){const seg=s.segments[Number(segIndex)];if(seg&&seg.end<s.maxRow-14)delete s.fireSegments[segIndex];}}
 return s;
}
function replay(seed,events,ticks){
 if(!Array.isArray(events)||events.length>MAX_EVENTS||!Number.isInteger(ticks)||ticks<1||ticks>MAX_TICKS)throw Error('Registro de partida inválido');let prev=-1;
 for(const e of events){if(!e||!Number.isInteger(e.t)||e.t<prev||e.t<0||e.t>=ticks||!DIR[e.d])throw Error('Movimiento inválido');prev=e.t;}
 const s=create(seed);let i=0;while(s.tick<ticks){while(i<events.length&&events[i].t===s.tick){if(!input(s,events[i++].d,false))throw Error('Movimiento no permitido');}step(s);if(s.over&&s.tick!==ticks)throw Error('La partida ya había terminado');}
 if(!s.over||i!==events.length)throw Error('Partida incompleta');return {score:s.maxRow,reason:s.reason,ticks:s.tick,police:policeSnapshot(s),crosswalk:crosswalkSnapshot(s)};
}
function segmentDiagnostics(s,index){ensureSegmentsThrough(s,Math.max(1,index));const seg=s.segments.find(x=>index>=x.start&&index<=x.end)||s.segments[s.segments.length-1];return seg?{index:seg.index,start:seg.start,end:seg.end,roads:seg.roads,tier:seg.tier,attempt:seg.attempt,fallback:seg.fallback,chainWindow:seg.chainWindow||null,crosswalk:seg.crosswalk?{...seg.crosswalk}:null,families:seg.rows.filter(r=>!r.safe).map(r=>r.family),speeds:seg.rows.filter(r=>!r.safe).map(r=>r.speed),gaps:seg.rows.filter(r=>!r.safe).map(r=>r.gapSeconds),occupancies:seg.rows.filter(r=>!r.safe).map(r=>r.occupancy),safeBlocks:seg.rows.filter(r=>r.safe).map(r=>({row:r.index,blocked:[...(r.blocked||[])]})),fireLane:seg.rows.find(r=>isFireLane(r))?.index??null,valid:segmentValid(seg)}:null;}
const api={VERSION,HZ,STEP,FORWARD_STEP,LATERAL_STEP,LATERAL_DISTANCE,COLS,MAX_TICKS,MAX_EVENTS,WAIT_TICKS,SOLVER_HORIZON_TICKS,SOLVER_TIME_BUCKET,POLICE_WARNING_ROW,POLICE_ACTIVE_ROW,POLICE_MAX_DISTANCE,POLICE_INITIAL_DISTANCE,POLICE_STREAK_TICKS,CROSSWALK_GOAL,DIR,VEHICLE_SPECS,TRAFFIC_FAMILIES,hashSeed,tierForRow,pursuitTierForRow,policeTuningForRow,crosswalkForSegment,fireLaneIndexForSegment,isFireLane,isFireLaneActive,fireLaneTickForState,safeBlockedFor,roadCountFor,cars,carsForState,crosswalkAt,crosswalkSnapshot,buildSegment,canTraverseSegment,traverseTicks,humanReadableSegment,segmentValid,rowAt,create,position,input,collision,policeSnapshot,step,replay,segmentDiagnostics};
root.DANI_ARCADE_ENGINE=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
