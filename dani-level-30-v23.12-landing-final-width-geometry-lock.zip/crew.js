(() => {
  'use strict';

  const cfg = window.BIRTHDAY_CONFIG || {};
  const core = window.DANI_CORE;
  if (!core || !window.DANI_UI) {
    console.error('DANI_CORE no se ha cargado.');
    return;
  }
  const { $, $$, reducedMotion, hashString: hashName, storage, createEventClock } = core;
  const AUTH_TOKEN_KEY = 'dani30-auth-token-v1';
  const LEGACY_SESSION_TOKEN_KEY = 'dani30-session-token-v1';
  const ACTIVE_MODE_KEY = 'dani30-session-mode-v1';
  const ENTRY_DISMISSED_KEY = 'dani30-entry-dismissed-v1';
  const LAST_PLAYER_ID_KEY = 'dani30-last-player-id-v1';
  const eventClock = createEventClock({ start:cfg.eventStart || cfg.partyModeWindow?.start, end:cfg.partyModeWindow?.end, timeZone:cfg.eventTimeZone || 'Europe/Madrid' });

  const AVATARS = ['😎','🤠','🥷','👑','💀','🤖','👽','🦈','🐸','🦊','🐺','🐵','🧠','💪','🎮','🪩','🎺','🏎️','🍕','🍸','🧑‍🚀','🕵️','🦹','🤡'];
  const SPECIALTY_CATALOG = [
    { key:'crossfit', label:'CROSSFIT', emoji:'🏋️' },
    { key:'informatica', label:'INFORMÁTICA', emoji:'💻' },
    { key:'fiesta', label:'FIESTA', emoji:'🪩' },
    { key:'cocina', label:'COCINA', emoji:'🍳' },
    { key:'gaming', label:'GAMING', emoji:'🎮' },
    { key:'labia', label:'LABIA', emoji:'🗣️' },
    { key:'fallas', label:'FALLAS', emoji:'🎺' },
    { key:'padel', label:'PÁDEL', emoji:'🎾' },
    { key:'creatividad', label:'CREATIVIDAD', emoji:'🎨' },
    { key:'nutricion', label:'NUTRICIÓN', emoji:'🥗' },
    { key:'mecanica', label:'MECÁNICA', emoji:'🔧' },
    { key:'medicina', label:'MEDICINA', emoji:'🩺' },
    { key:'ensenanza', label:'ENSEÑANZA', emoji:'🎓' },
    { key:'contabilidad', label:'CONTABILIDAD', emoji:'📊' },
    { key:'baile', label:'BAILE', emoji:'🕺' },
    { key:'supervivir-after', label:'SOBREVIVIR AL AFTER', emoji:'🌅' },
    { key:'aparcar', label:'ENCONTRAR APARCAMIENTO', emoji:'🅿️' },
    { key:'ultima', label:'CONVENCER PARA UNA ÚLTIMA', emoji:'🥃' }
  ];

  const legacySessionToken = storage.get(sessionStorage, LEGACY_SESSION_TOKEN_KEY);
  const initialToken = storage.get(localStorage, AUTH_TOKEN_KEY) || legacySessionToken;
  if (initialToken) storage.set(localStorage, AUTH_TOKEN_KEY, initialToken);
  storage.remove(sessionStorage, LEGACY_SESSION_TOKEN_KEY);
  let primary = initialToken ? { token:initialToken, profile:null } : null;
  // Remove identity/profile caches created by older builds. D1 + the validated auth token are authoritative.
  storage.remove(localStorage, 'dani30-crew-primary-v1', 'dani30-local-crew-v1', 'dani30-local-wanted-v1', 'dani30-v8-identity');
  let recoveryOpen = false;
  let pendingHeistGrant = null;
  let recoveryReturnFocus = null;
  let crewRequest = null;
  let crewReadyPromise = Promise.resolve();
  let crewError = '';
  let sessionInvalid = false;
  let crewCache = [];
  let selectedAvatar = primary?.profile?.avatar || '🎮';
  let selectedSpecialtyKeys = [];
  let avatarCatalogExpanded = false;
  let avatarFallbackPickerOpen = false;
  let specialtyCatalogExpanded = false;
  let activeCharacterBlock = null;
  let selectedPartyPlayer = null;
  let identityReason = 'entry';
  let identityForceRoster = false;
  let identityBottomSheet = null;
  let identityDismissedRememberedId = null;
  let partyLoginBusy = false;
  let adminPinMemory = '';
  let adminLoginBusy = false;
  const ADMIN_PIN_LENGTH = Math.max(1, Math.min(12, Number(cfg.adminPinLength) || 4));
  let lastAdminPlayers = [];
  let adminGuestFilter = 'all';
  let adminGuestSearch = '';
  let adminDangerArmTimer = 0;
  let activeMode = 'invite';
  let backendAvailable = null;
  let refreshTimer = null;
  let inviteCrewSnapshot = null;
  let crewPanelOpen = false;
  let heistPreviewExpanded = false;
  let pendingRsvpAttempt = null;
  let progressSaveQueue = Promise.resolve();
  let lastInviteSignature = null;
  let selectedCrewProfileId = null;
  let surfacePageScrollY = 0;
  let surfacePageScrollLocked = false;
  let crewProfileCloseTimer = null;
  let crewProfileSlideController = null;
  let identityBackSlideController = null;
  let crewBottomSheet = null;
  let characterBottomSheet = null;
  let characterEditSlideController = null;
  let activeCharacterEditorNode = null;
  let activeCharacterEditorOrigin = null;
  let characterActivityRequestNonce = 0;
  let characterActivityExpanded = false;
  let pendingPhotoData = '';
  let photoCropSource = null;
  const photoCropPointers = new Map();
  let photoCropState = { zoom:1, offsetX:0, offsetY:0, dragLast:null, pinchDistance:0, pinchZoom:1 };

  function updateBackendBadge() {
    const badge = $('#backendStatusBadge');
    if (!badge) return;
    badge.textContent = backendAvailable === true ? 'D1' : (backendAvailable === false ? 'SIN BD' : '…');
    badge.classList.toggle('is-online', backendAvailable === true);
  }

  function normalizeProfile(profile = {}) {
    return {
      id: profile.id || `local-${hashName(profile.name || 'player')}`,
      crewNumber: Number(profile.crewNumber || ((hashName(profile.name || 'player') % 900) + 100)),
      name: String(profile.name || 'PLAYER').slice(0, 40),
      attendance: profile.attendance || 'yes',
      dietary: String(profile.dietary || '').slice(0, 120),
      avatar: String(profile.avatar || '🎮').slice(0, 16),
      photoData: typeof profile.photoData === 'string' ? profile.photoData : '',
      photoUrl: typeof profile.photoUrl === 'string' ? profile.photoUrl : '',
      bio: String(profile.bio || '').slice(0, 90),
      specialties: Array.isArray(profile.specialties) ? profile.specialties.slice(0, 3) : [],
      specialAbility: String(profile.specialAbility || '').slice(0, 90),
      gameStars: Math.max(0, Number(profile.gameStars ?? profile.wantedScore ?? 0)),
      wantedScore: Math.max(0, Number(profile.gameStars ?? profile.wantedScore ?? 0)),
      locationUnlocked: Boolean(profile.locationUnlocked),
      briefingCompleted: Boolean(profile.briefingCompleted),
      completedMissions: Array.isArray(profile.completedMissions) ? profile.completedMissions.slice(0, 24) : [],
      discoveredMissions: Array.isArray(profile.discoveredMissions) ? profile.discoveredMissions.slice(0, 24) : (Array.isArray(profile.completedMissions) ? profile.completedMissions.slice(0, 24) : []),
      wantedLevel: Math.max(0, Math.min(5, Number(profile.wantedLevel || 0))),
      walletBalance: Math.max(0, Number(profile.walletBalance ?? profile.cash ?? 0)),
      cash: Math.max(0, Number(profile.walletBalance ?? profile.cash ?? 0)),
      cashCollectedCount: Math.max(0, Math.min(5, Number(profile.cashCollectedCount || 0))),
      missionRespect: Math.max(0, Number(profile.missionRespect || 0)),
      recordCleanCount: Math.max(0, Number(profile.recordCleanCount || 0)),
      nextRecordCleanCost: Math.max(0, Number(profile.nextRecordCleanCost || 200)),
      socialRespect: Math.max(0, Number(profile.socialRespect || 0)),
      respectBreakdown: profile.respectBreakdown && typeof profile.respectBreakdown === 'object' ? { ...profile.respectBreakdown } : { social:Math.max(0, Number(profile.socialRespect || 0)), missions:Math.max(0, Number(profile.missionRespect || 0)) },
      respect: Math.max(0, Number(profile.respect || 0)),
      respectedByViewer: Boolean(profile.respectedByViewer),
      hasPin: profile.hasPin !== undefined ? Boolean(profile.hasPin) : true,
      uiPrefs: profile.uiPrefs && typeof profile.uiPrefs === 'object' ? { ...profile.uiPrefs } : {}
    };
  }


  function canBrowseCrew(profile = primary?.profile) {
    return profile?.attendance === 'yes';
  }

  function hasHeistAccess(profile) {
    return Boolean(profile && profile.attendance === 'yes' && profile.briefingCompleted && profile.locationUnlocked);
  }

  function identityRequiresHeistAccess() {
    return identityReason === 'entry' || (identityReason === 'switch' && activeMode === 'party');
  }

  function identityPlayers(players = crewCache) {
    let source = Array.isArray(players) ? [...players] : [];
    if (identityRequiresHeistAccess()) source = source.filter(hasHeistAccess);
    if (identityReason === 'switch' && primary?.profile?.id) {
      source = source.filter((player) => player.id !== primary.profile.id);
    }
    return source;
  }

  function isAppSurfaceMobile() {
    return window.matchMedia('(max-width:720px)').matches;
  }

  // La ficha interna de La Banda usa el mismo breakpoint que la superficie compartida.
  function isCrewMobile() {
    return isAppSurfaceMobile();
  }

  function lockAppSurfacePageScroll() {
    if (surfacePageScrollLocked) return;
    surfacePageScrollY = window.scrollY || document.documentElement.scrollTop || 0;
    document.body.style.top = `-${surfacePageScrollY}px`;
    document.body.classList.add('app-surface-open');
    surfacePageScrollLocked = true;
  }

  function unlockAppSurfacePageScroll() {
    if (!surfacePageScrollLocked) return;
    document.body.classList.remove('app-surface-open');
    document.body.style.top = '';
    const restoreY = surfacePageScrollY;
    surfacePageScrollLocked = false;
    surfacePageScrollY = 0;
    window.scrollTo({ top: restoreY, behavior: 'auto' });
  }

  function renderAvatarStack(root, players = crewCache, maxVisible = 3) {
    if (!root) return;
    root.replaceChildren();
    const visible = players.slice(0, maxVisible);
    root.hidden = visible.length === 0;
    visible.forEach((player) => {
      const avatar = document.createElement('span');
      avatar.className = 'crew-access__avatar';
      applyAvatarVisual(avatar, player);
      root.appendChild(avatar);
    });
    if (players.length > visible.length) {
      const more = document.createElement('span');
      more.className = 'crew-access__more';
      more.textContent = `+${players.length - visible.length}`;
      root.appendChild(more);
    }
  }

  function renderCrewAccessPeople(players = crewCache) {
    renderAvatarStack($('#crewAccessPeople'), players, 3);
    renderAvatarStack($('#crewQuickPeople'), players, 3);
  }

  function applyCrewDisclosure(profile = primary?.profile) {
    if (canBrowseCrew(profile)) return;
    crewPanelOpen = false;
    closeCrewProfile();
    closeCrewDirectory();
  }

  function setPrimary(session) {
    const previousId = primary?.profile?.id;
    const nextProfile = session?.profile ? normalizeProfile(session.profile) : null;
    if (previousId && nextProfile?.id && previousId !== nextProfile.id) {
      lastPlayerRankingRole = null;
      window.DANI_APP?.resetPlayerProgress?.();
    }
    sessionInvalid = false;
    primary = session?.token ? { token:session.token, profile:nextProfile } : null;
    if (primary?.token) storage.set(localStorage, AUTH_TOKEN_KEY, primary.token);
    else storage.remove(localStorage, AUTH_TOKEN_KEY);
    if (nextProfile?.id) storage.set(localStorage, LAST_PLAYER_ID_KEY, nextProfile.id);
    applyCrewDisclosure(nextProfile);
    renderHudEconomy();
    window.DANI_ARCADE?.syncProfile?.();
    window.DANI_SAFE?.syncProfile?.();
    window.DANI_INFILTRATION?.syncProfile?.();
    window.DANI_POINTBLIND?.syncProfile?.();
  }

  function getLocalProfile() {
    return primary?.profile ? normalizeProfile(primary.profile) : null;
  }


  async function api(path, { method = 'GET', body, token, adminPin, requestKey } = {}) {
    const headers = { accept: 'application/json' };
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (token) headers.authorization = `Bearer ${token}`;
    if (adminPin) headers['x-admin-pin'] = adminPin;
    if (requestKey) headers['x-rsvp-key'] = requestKey;

    let response;
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 12000);
    try {
      response = await fetch(`/api/${path}`, {
        method,
        headers,
        signal:controller.signal,
        body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch (cause) {
      const error = new Error('No se ha podido conectar. Comprueba tu conexión y vuelve a intentarlo.');
      error.status = 0;
      error.cause = cause;
      throw error;
    } finally { window.clearTimeout(timeout); }

    let data = {};
    try { data = await response.json(); } catch { throw new Error('Respuesta inesperada del servidor. Vuelve a intentarlo.'); }
    if (!response.ok) {
      const error = new Error(data.message || data.error || `HTTP_${response.status}`);
      error.status = response.status;
      error.code = data.error;
      error.data = data;
      throw error;
    }
    if (data.ok !== true) throw new Error('El servidor no ha confirmado la operación.');
    backendAvailable = true;
    updateBackendBadge();
    return data;
  }



  function pinNeeded(attendance = 'yes') {
    return attendance === 'yes' && (!primary?.token || primary?.profile?.hasPin === false);
  }

  function updatePinField(forceShow = false) {
    const field = $('#pinField');
    const input = $('#playerPin');
    if (!field || !input) return;
    const attendance = $('input[name="attendance"]:checked')?.value || 'yes';
    const show = Boolean((forceShow || pinNeeded(attendance)) && attendance === 'yes');
    const wasHidden = field.hidden;
    field.hidden = !show;
    if (!show) {
      input.value = '';
      window.DANI_PIN_LOCK?.reset?.({ announce:false });
    } else if (wasHidden) {
      window.DANI_PIN_LOCK?.reset?.();
    }
  }

  async function saveRsvp({ name, attendance, dietary, declineMessage, pin: suppliedPin }) {
    const requestSession = primary;
    const pin = String(suppliedPin ?? ($('#playerPin')?.value || '')).trim();
    if (sessionInvalid) return {ok:false, message:'Recupera tu personaje con tu PIN antes de continuar.', focusId:'recoverPlayer'};
    if (attendance === 'yes' && pinNeeded(attendance) && !/^\d{4}$/.test(pin)) {
      updatePinField(true);
      return {ok:false, message:'Elige los cuatro dígitos de tu combinación para proteger el personaje.', focusId:'pinLock'};
    }
    const payload = {
      name,
      attendance,
      dietary,
      declineMessage,
      briefingCompleted: Boolean(window.DANI_APP?.getState?.().briefingCompleted)
    };
    if (/^\d{4}$/.test(pin)) payload.pin = pin;
    const signature = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(payload)))), b => b.toString(16).padStart(2,'0')).join('');
    let attempt = pendingRsvpAttempt;
    if (!primary?.token && attempt?.signature !== signature) {
      const bytes = crypto.getRandomValues(new Uint8Array(24));
      attempt = {signature, key:Array.from(bytes, b => b.toString(16).padStart(2,'0')).join('')};
      pendingRsvpAttempt = attempt;
    }
    try {
      const data = primary?.token
        ? await api('me', {method:'PATCH', body:payload, token:primary.token})
        : await api('rsvp', {method:'POST', body:payload, requestKey:attempt.key});
      if (primary !== requestSession) return {ok:false, message:'El jugador ha cambiado. Comprueba la sesión antes de continuar.'};
      setPrimary({token:data.sessionToken || requestSession.token, profile:data.player});
      pendingRsvpAttempt = null;
      $('#playerPin').value = '';
      updatePinField(); refreshCrew();
      return {ok:true};
    } catch (error) {
      if (error.status === 401 && primary) {
        sessionInvalid = true;
        return {ok:false, message:'Ese personaje ya existe. Recupéralo con tu PIN para continuar.', focusId:'recoverPlayer'};
      }
      return {ok:false, message:error.message || 'No se ha podido guardar. Vuelve a intentarlo.'};
    }
  }

  async function unconfirm() {
    const requestSession = primary;
    if (!primary?.token) return {ok:false, message:'Recupera tu personaje antes de modificar la asistencia.'};
    try {
      const data = await api('me', {method:'PATCH', body:{attendance:'no'}, token:primary.token});
      if (primary?.token !== requestSession?.token) return {ok:false, message:'El jugador ha cambiado.'};
      setPrimary({token:requestSession.token, profile:data.player});
      refreshCrew();
      return {ok:true};
    } catch (error) { return {ok:false, message:error.message}; }
  }

  function saveProgress(patch = {}) {
    if (!primary?.token) return Promise.resolve({ ok:false, skipped:true });
    const allowed = {};
    if (patch.briefingCompleted !== undefined) allowed.briefingCompleted = Boolean(patch.briefingCompleted);
    if (!Object.keys(allowed).length) return Promise.resolve({ ok:true, skipped:true });
    const token = primary.token;

    progressSaveQueue = progressSaveQueue
      .catch(() => undefined)
      .then(async () => {
        if (primary?.token !== token) return { ok:false, message:'El jugador ha cambiado.' };
        try {
          const data = await api('me', { method:'PATCH', body:allowed, token });
          if (primary?.token !== token) return { ok:false, message:'El jugador ha cambiado.' };
          setPrimary({ token, profile:data.player });
          return { ok:true, profile:getLocalProfile() };
        } catch (error) {
          console.warn('No se ha podido sincronizar el progreso con D1.', error);
          return { ok:false, message:error.message };
        }
      });

    return progressSaveQueue;
  }

  async function unlockLocation() {
    const requestSession = primary;
    if (!primary?.token) throw new Error('Recupera tu personaje para continuar.');
    const data = await api('location/unlock', {method:'POST', token:primary.token});
    if (primary?.token !== requestSession?.token) throw new Error('El jugador ha cambiado.');
    setPrimary({...requestSession, profile:{...requestSession.profile, locationUnlocked:true}});
    return data;
  }

  async function getSecureLocation() {
    if (!primary?.token) throw new Error('NO_SECURE_BACKEND');
    return api('location', { token:primary.token });
  }

  function profilePhotoSource(profile) {
    const data = typeof profile?.photoData === 'string' && /^data:image\/(?:jpeg|png|webp);base64,/i.test(profile.photoData) ? profile.photoData : '';
    if (data) return data;
    const url = typeof profile?.photoUrl === 'string' && /^\/api\/player-photo\//.test(profile.photoUrl) ? profile.photoUrl : '';
    return url;
  }

  function hasUsablePhoto(profile) {
    return Boolean(profilePhotoSource(profile));
  }

  function applyAvatarVisual(node, profile, { alt = '', lazy = true } = {}) {
    if (!node) return;
    node.replaceChildren();
    const photoSource = profilePhotoSource(profile);
    node.classList.toggle('has-photo', Boolean(photoSource));
    if (photoSource) {
      const image = document.createElement('img');
      image.src = photoSource;
      image.alt = alt;
      image.decoding = 'async';
      if (lazy) image.loading = 'lazy';
      node.appendChild(image);
      return;
    }
    node.textContent = profile?.avatar || '🎮';
  }

  function openPhotoViewer(profile) {
    const photoSource = profilePhotoSource(profile);
    if (!photoSource) return;
    const dialog = $('#photoViewerDialog');
    const image = $('#photoViewerImage');
    if (!dialog || !image) return;
    image.src = photoSource;
    image.alt = `Foto ampliada de ${profile.name || 'personaje'}`;
    if (!dialog.open) dialog.showModal();
  }

  function closePhotoViewer() {
    const dialog = $('#photoViewerDialog');
    if (dialog?.open) dialog.close();
    const image = $('#photoViewerImage');
    if (image) {
      image.src = '';
      image.style.transition = '';
      image.style.transform = '';
      image.style.opacity = '';
    }
  }

  function bindPhotoViewerSwipe() {
    const viewer = $('#photoViewer');
    const image = $('#photoViewerImage');
    if (!viewer || !image) return;

    let gesture = null;
    const resetVisual = () => {
      image.style.transition = 'transform .18s ease, opacity .18s ease';
      image.style.transform = '';
      image.style.opacity = '';
      window.setTimeout(() => { image.style.transition = ''; }, 190);
    };

    image.addEventListener('pointerdown', (event) => {
      if (event.pointerType === 'mouse') return;
      gesture = { id:event.pointerId, x:event.clientX, y:event.clientY };
      image.setPointerCapture?.(event.pointerId);
      image.style.transition = 'none';
    });

    image.addEventListener('pointermove', (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      const dx = event.clientX - gesture.x;
      const dy = event.clientY - gesture.y;
      const distance = Math.hypot(dx, dy);
      image.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(${Math.max(.92, 1 - distance / 1100)})`;
      image.style.opacity = String(Math.max(.36, 1 - distance / 260));
    });

    const finish = (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      const dx = event.clientX - gesture.x;
      const dy = event.clientY - gesture.y;
      const distance = Math.hypot(dx, dy);
      gesture = null;
      try { image.releasePointerCapture?.(event.pointerId); } catch {}
      if (distance >= 58) {
        if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
          closePhotoViewer();
          return;
        }
        const ux = dx / distance;
        const uy = dy / distance;
        const fling = Math.max(window.innerWidth, window.innerHeight) * .42;
        image.style.transition = 'transform .14s ease-out, opacity .14s ease-out';
        image.style.transform = `translate3d(${dx + ux * fling}px, ${dy + uy * fling}px, 0) scale(.9)`;
        image.style.opacity = '0';
        window.setTimeout(closePhotoViewer, 145);
        return;
      }
      resetVisual();
    };

    image.addEventListener('pointerup', finish);
    image.addEventListener('pointercancel', () => { gesture = null; resetVisual(); });
  }

  function pendingCharacterHasPhoto() {
    return typeof pendingPhotoData === 'string' && /^data:image\/(?:jpeg|png|webp);base64,/i.test(pendingPhotoData);
  }

  function setAvatarFallbackPickerOpen(open) {
    const hasPhoto = pendingCharacterHasPhoto();
    avatarFallbackPickerOpen = Boolean(open) && !hasPhoto;
    const picker = $('#characterAvatarFallbackPicker');
    const preview = $('#characterPhotoPreview');
    if (picker) picker.hidden = !avatarFallbackPickerOpen;
    if (preview) preview.setAttribute('aria-expanded', String(avatarFallbackPickerOpen));
  }

  function updateCharacterPhotoPreview() {
    const image = $('#characterPhotoImage');
    const fallback = $('#characterPhotoFallback');
    const remove = $('#removeCharacterPhoto');
    const choose = $('#chooseCharacterPhoto');
    const preview = $('#characterPhotoPreview');
    const help = $('#characterVisualHelp');
    const hasPhoto = pendingCharacterHasPhoto();
    if (image) {
      image.hidden = !hasPhoto;
      image.src = hasPhoto ? pendingPhotoData : '';
    }
    if (fallback) {
      fallback.hidden = hasPhoto;
      fallback.textContent = selectedAvatar || '🎮';
    }
    if (remove) remove.hidden = !hasPhoto;
    if (choose) choose.textContent = hasPhoto ? 'CAMBIAR FOTO' : 'ELEGIR FOTO';
    if (help) help.textContent = hasPhoto
      ? 'Tu foto sustituye al avatar. Tócala para ampliarla o cámbiala cuando quieras.'
      : 'Sube una foto o toca el avatar para cambiarlo. La foto tiene prioridad.';
    if (preview) {
      preview.classList.toggle('has-photo', hasPhoto);
      preview.setAttribute('aria-label', hasPhoto ? 'Ampliar foto del personaje' : 'Elegir otro avatar');
    }
    if (hasPhoto) avatarFallbackPickerOpen = false;
    setAvatarFallbackPickerOpen(avatarFallbackPickerOpen);
  }

  function resetPhotoCropState() {
    photoCropState = { zoom:1, offsetX:0, offsetY:0, dragLast:null, pinchDistance:0, pinchZoom:1 };
    photoCropPointers.clear();
    const zoom = $('#photoCropZoom');
    if (zoom) zoom.value = '1';
    updatePhotoCropTransform();
  }

  function photoCropMetrics() {
    const viewport = $('#photoCropViewport');
    if (!viewport || !photoCropSource) return null;
    const size = viewport.clientWidth;
    const base = Math.max(size / photoCropSource.naturalWidth, size / photoCropSource.naturalHeight);
    const scale = base * photoCropState.zoom;
    const width = photoCropSource.naturalWidth * scale;
    const height = photoCropSource.naturalHeight * scale;
    return { size, base, scale, width, height };
  }

  function clampPhotoCropOffsets() {
    const metrics = photoCropMetrics();
    if (!metrics) return;
    const maxX = Math.max(0, (metrics.width - metrics.size) / 2);
    const maxY = Math.max(0, (metrics.height - metrics.size) / 2);
    photoCropState.offsetX = Math.max(-maxX, Math.min(maxX, photoCropState.offsetX));
    photoCropState.offsetY = Math.max(-maxY, Math.min(maxY, photoCropState.offsetY));
  }

  function updatePhotoCropTransform() {
    const image = $('#photoCropImage');
    const metrics = photoCropMetrics();
    if (!image || !metrics) return;
    clampPhotoCropOffsets();
    image.style.width = `${metrics.width}px`;
    image.style.height = `${metrics.height}px`;
    image.style.transform = `translate(calc(-50% + ${photoCropState.offsetX}px), calc(-50% + ${photoCropState.offsetY}px))`;
  }

  function closePhotoCrop() {
    photoCropPointers.clear();
    photoCropSource = null;
    const dialog = $('#photoCropDialog');
    if (dialog?.open) dialog.close();
    const input = $('#characterPhotoInput');
    if (input) input.value = '';
    const cropImage = $('#photoCropImage');
    if (cropImage) cropImage.src = '';
    const message = $('#photoCropMessage');
    if (message) message.textContent = '';
  }

  async function openPhotoCrop(file) {
    const message = $('#characterMessage');
    if (!file) return;
    if (!/^image\/(jpeg|png|webp|heic|heif)$/i.test(file.type)) {
      if (message) message.textContent = 'Usa una imagen JPG, PNG, WebP o una foto compatible de tu móvil.';
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      if (message) message.textContent = 'La imagen es demasiado grande. Elige una de menos de 12 MB.';
      return;
    }
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(new Error('No se ha podido leer la imagen.'));
      reader.readAsDataURL(file);
    });
    const image = new Image();
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('No se ha podido abrir la imagen.'));
      image.src = dataUrl;
    });
    photoCropSource = image;
    const cropImage = $('#photoCropImage');
    if (cropImage) cropImage.src = dataUrl;
    const dialog = $('#photoCropDialog');
    if (!dialog) return;
    dialog.showModal();
    requestAnimationFrame(() => resetPhotoCropState());
  }

  function bindPhotoCropInteractions() {
    const viewport = $('#photoCropViewport');
    const zoom = $('#photoCropZoom');
    if (!viewport || !zoom) return;
    const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
    viewport.addEventListener('pointerdown', (event) => {
      if (!photoCropSource) return;
      viewport.setPointerCapture?.(event.pointerId);
      photoCropPointers.set(event.pointerId, { x:event.clientX, y:event.clientY });
      if (photoCropPointers.size === 1) {
        photoCropState.dragLast = { x:event.clientX, y:event.clientY };
      } else if (photoCropPointers.size === 2) {
        const [a,b] = [...photoCropPointers.values()];
        photoCropState.pinchDistance = distance(a,b);
        photoCropState.pinchZoom = photoCropState.zoom;
        photoCropState.dragLast = null;
      }
    });
    viewport.addEventListener('pointermove', (event) => {
      if (!photoCropPointers.has(event.pointerId) || !photoCropSource) return;
      photoCropPointers.set(event.pointerId, { x:event.clientX, y:event.clientY });
      if (photoCropPointers.size >= 2) {
        const [a,b] = [...photoCropPointers.values()];
        const currentDistance = distance(a,b);
        if (photoCropState.pinchDistance > 0) {
          photoCropState.zoom = Math.max(1, Math.min(3, photoCropState.pinchZoom * currentDistance / photoCropState.pinchDistance));
          zoom.value = String(photoCropState.zoom);
          updatePhotoCropTransform();
        }
        return;
      }
      if (photoCropState.dragLast) {
        photoCropState.offsetX += event.clientX - photoCropState.dragLast.x;
        photoCropState.offsetY += event.clientY - photoCropState.dragLast.y;
        photoCropState.dragLast = { x:event.clientX, y:event.clientY };
        updatePhotoCropTransform();
      }
    });
    const release = (event) => {
      photoCropPointers.delete(event.pointerId);
      if (photoCropPointers.size === 1) {
        const remaining = [...photoCropPointers.values()][0];
        photoCropState.dragLast = { ...remaining };
      } else {
        photoCropState.dragLast = null;
        photoCropState.pinchDistance = 0;
      }
    };
    viewport.addEventListener('pointerup', release);
    viewport.addEventListener('pointercancel', release);
    zoom.addEventListener('input', () => {
      photoCropState.zoom = Math.max(1, Math.min(3, Number(zoom.value || 1)));
      updatePhotoCropTransform();
    });
  }

  function applyPhotoCrop() {
    const metrics = photoCropMetrics();
    if (!metrics || !photoCropSource) return;
    const imageLeft = metrics.size / 2 + photoCropState.offsetX - metrics.width / 2;
    const imageTop = metrics.size / 2 + photoCropState.offsetY - metrics.height / 2;
    const sx = Math.max(0, -imageLeft / metrics.scale);
    const sy = Math.max(0, -imageTop / metrics.scale);
    const sourceSize = metrics.size / metrics.scale;
    let outputSize = 512;
    let quality = .82;
    let dataUrl = '';
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const canvas = document.createElement('canvas');
      canvas.width = outputSize;
      canvas.height = outputSize;
      const ctx = canvas.getContext('2d', { alpha:false });
      ctx.fillStyle = '#f7f3ef';
      ctx.fillRect(0,0,outputSize,outputSize);
      ctx.drawImage(photoCropSource, sx, sy, sourceSize, sourceSize, 0, 0, outputSize, outputSize);
      dataUrl = canvas.toDataURL('image/jpeg', quality);
      if (dataUrl.length <= 220000) break;
      quality -= .1;
      if (attempt === 2) outputSize = 420;
    }
    if (!/^data:image\/jpeg;base64,/i.test(dataUrl) || dataUrl.length > 250000) {
      $('#photoCropMessage').textContent = 'No se ha podido optimizar la foto. Prueba con otra imagen.';
      return;
    }
    pendingPhotoData = dataUrl;
    updateCharacterPhotoPreview();
    const message = $('#characterMessage');
    if (message) message.textContent = 'Foto ajustada. Guarda los cambios para aplicarla.';
    closePhotoCrop();
  }

  function syncAvatarPickerSelection() {
    $$('#avatarOptions .avatar-option').forEach((button) => {
      const selected = button.dataset.avatar === selectedAvatar;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  function buildAvatarPicker() {
    const root = $('#avatarOptions');
    if (!root) return;
    root.replaceChildren();
    const baseVisible = avatarCatalogExpanded ? AVATARS : AVATARS.slice(0, 6);
    const visible = AVATARS.includes(selectedAvatar) || !selectedAvatar ? baseVisible : [selectedAvatar, ...baseVisible.filter((emoji) => emoji !== selectedAvatar)];
    visible.forEach((emoji) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'avatar-option';
      button.textContent = emoji;
      button.dataset.avatar = emoji;
      button.setAttribute('aria-label', `Usar avatar ${emoji}`);
      button.addEventListener('click', () => {
        selectedAvatar = emoji;
        updateCharacterPhotoPreview();
        syncAvatarPickerSelection();
      });
      root.appendChild(button);
    });
    syncAvatarPickerSelection();
    const more = $('#toggleAvatarCatalog');
    if (more) more.textContent = avatarCatalogExpanded ? 'VER MENOS' : 'VER MÁS';
  }

  function buildSpecialtyPicker() {
    const root = $('#specialtyChipGrid');
    if (!root) return;
    root.replaceChildren();
    const visible = specialtyCatalogExpanded ? SPECIALTY_CATALOG : SPECIALTY_CATALOG.slice(0, 6);
    visible.forEach((specialty) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'specialty-chip';
      button.dataset.specialtyKey = specialty.key;
      button.textContent = `${specialty.emoji} ${specialty.label}`;
      button.addEventListener('click', () => toggleSpecialty(specialty.key));
      root.appendChild(button);
    });
    renderSpecialtySelection();
    const more = $('#toggleSpecialtyCatalog');
    if (more) more.textContent = specialtyCatalogExpanded ? 'VER MENOS' : 'VER TODAS';
  }

  function toggleSpecialty(key) {
    const index = selectedSpecialtyKeys.indexOf(key);
    if (index >= 0) selectedSpecialtyKeys.splice(index, 1);
    else if (selectedSpecialtyKeys.length < 3) selectedSpecialtyKeys.push(key);
    else {
      $('#characterMessage').textContent = 'Puedes elegir un máximo de 3 especialidades.';
      return;
    }
    $('#characterMessage').textContent = '';
    renderSpecialtySelection();
  }

  function renderSpecialtySelection() {
    $$('#specialtyChipGrid .specialty-chip').forEach((button) => {
      const selected = selectedSpecialtyKeys.includes(button.dataset.specialtyKey);
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    const count = $('#specialtySelectionCount');
    if (count) count.textContent = `${selectedSpecialtyKeys.length}/3`;
  }

  function specialtiesFromKeys() {
    return selectedSpecialtyKeys.slice(0, 3).map((key) => SPECIALTY_CATALOG.find((item) => item.key === key)).filter(Boolean);
  }

  function summaryChip(text, className = '') {
    const span = document.createElement('span');
    span.className = `character-summary-chip${className ? ` ${className}` : ''}`;
    span.textContent = text;
    return span;
  }

  function operationObjectiveCodes() {
    // El progreso visible del golpe cuenta TODO el contenido que el invitado
    // debe completar. La tipología interna de cada tarjeta no cambia este total.
    return Object.keys(cfg.missions || {}).map((code) => String(code).toUpperCase());
  }

  function operationObjectiveProgress(profile = getLocalProfile()) {
    const available = operationObjectiveCodes();
    const completed = new Set((Array.isArray(profile?.completedMissions) ? profile.completedMissions : []).map((code) => String(code).toUpperCase()));
    return {
      completed: available.filter((code) => completed.has(code)).length,
      total: available.length
    };
  }

  function missionDisplayName(code) {
    const mission = cfg.missions?.[String(code || '').toUpperCase()];
    return mission?.title || 'Juego de la operación';
  }

  function syncCharacterOperationVisibility() {
    const block = $('#characterOperationBlock');
    if (!block) return;
    const visible = activeMode === 'party';
    block.hidden = !visible;
    if (!visible && activeCharacterBlock === 'heist') {
      finalizeCharacterBlockPanelClose();
    }
  }

  function renderPartyOperationSummary(profile = getLocalProfile()) {
    const card = $('#partyOperationSummary');
    if (!card) return;
    const visible = activeMode === 'party' && Boolean(profile);
    card.hidden = !visible;
    if (!visible) return;
    const progress = operationObjectiveProgress(profile);
    const remaining = Math.max(0, progress.total - progress.completed);
    const progressText = $('#partyOperationProgress');
    const meta = $('#partyOperationMeta');
    const bar = $('#partyOperationProgressBar');
    if (progressText) progressText.textContent = `${progress.completed}/${progress.total}`;
    if (meta) {
      if (progress.total > 0 && progress.completed >= progress.total) {
        meta.textContent = '✓ Todos los objetivos completados.';
      } else if (progress.completed <= 0) {
        meta.textContent = `${remaining} ${remaining === 1 ? 'objetivo por descubrir' : 'objetivos por descubrir'}.`;
      } else {
        meta.textContent = `✓ ${progress.completed} ${progress.completed === 1 ? 'completado' : 'completados'} · ${remaining} ${remaining === 1 ? 'por descubrir' : 'por descubrir'}.`;
      }
    }
    if (bar) {
      const pct = progress.total > 0 ? Math.max(0, Math.min(100, (progress.completed / progress.total) * 100)) : 0;
      bar.style.width = `${pct}%`;
    }
    card.classList.toggle('is-complete', progress.total > 0 && progress.completed >= progress.total);
  }

  function renderCharacterOperation(profile = getLocalProfile()) {
    if (!profile) { renderPartyOperationSummary(null); return; }
    renderPartyOperationSummary(profile);
    const stars = Math.max(0, Number(profile.gameStars ?? profile.wantedScore ?? 0));
    const cash = Math.max(0, Number(profile.walletBalance ?? profile.cash ?? 0));
    const respect = Math.max(0, Number(profile.respect || 0));
    const progress = operationObjectiveProgress(profile);
    const cleanCost = Math.max(0, Number(profile.nextRecordCleanCost || 200));
    const cleanCount = Math.max(0, Number(profile.recordCleanCount || 0));
    if ($('#characterOperationCash')) $('#characterOperationCash').textContent = formatCash(cash);
    if ($('#characterOperationRespect')) $('#characterOperationRespect').textContent = String(respect);
    if ($('#characterOperationStars')) $('#characterOperationStars').textContent = `${stars} ★`;
    if ($('#characterOperationMissions')) $('#characterOperationMissions').textContent = `${progress.completed}/${progress.total}`;
    if ($('#characterOperationStatus')) {
      $('#characterOperationStatus').textContent = progress.total > 0 && progress.completed >= progress.total
        ? 'OBJETIVOS COMPLETADOS'
        : (stars > 0 ? 'EN EL RADAR' : (progress.completed > 0 ? 'EN CURSO' : 'SIN MOVIMIENTOS'));
    }

    const summary = $('#characterOperationSummary');
    if (summary) {
      summary.replaceChildren(
        summaryChip(`✓ OBJETIVOS ${progress.completed}/${progress.total}`),
        summaryChip(`💵 ${formatCash(cash)}`),
        summaryChip(`✦ ${respect} RESPETO`),
        summaryChip(`★ ${stars}`, stars > 0 ? 'is-ability' : 'is-muted')
      );
    }

    const panel = $('#characterRecordPanel');
    const title = $('#characterRecordTitle');
    const copy = $('#characterRecordCopy');
    const button = $('#cleanCharacterRecord');
    panel?.classList.toggle('is-wanted', stars > 0);
    panel?.classList.toggle('is-clean', stars < 1);
    if (title) title.textContent = stars > 0 ? `${stars} ★ EN TU EXPEDIENTE` : '✓ EXPEDIENTE LIMPIO';
    if (copy) {
      copy.textContent = stars > 0
        ? `Soborno ${cleanCount + 1}: elimina 1 ★ por ${formatCash(cleanCost)}. El siguiente será más caro.`
        : '';
    }
    if (button) {
      button.hidden = stars < 1;
      button.disabled = stars < 1 || cash < cleanCost;
      button.textContent = cash < cleanCost
        ? `NECESITAS ${formatCash(cleanCost)} · BOTÍN ${formatCash(cash)}`
        : `PAGAR ${formatCash(cleanCost)} · ELIMINAR 1 ★`;
    }
  }

  function economyActivityLabel(event) {
    if (event?.sourceType === 'loot') return 'BOTÍN OCULTO';
    if (event?.sourceType === 'arcade') { const id=String(event?.sourceId||'').toUpperCase(); if(['CAJA30','SAQUEO30'].includes(id))return 'BOTÍN 30'; if(id==='PUNTOCIEGO30')return 'PUNTO CIEGO 30'; if(id==='INFILTRACION30')return 'BRECHA 30'; return 'FUGA 30'; }
    if (event?.sourceType === 'mission' || event?.sourceType === 'game') return missionDisplayName(event.sourceId);
    if (event?.sourceId === 'EXPEDIENTE' && event?.actionId === 'clean-star') return 'LIMPIEZA DE EXPEDIENTE';
    if (event?.sourceType === 'system') return 'EXPEDIENTE';
    return 'ACTIVIDAD DE LA OPERACIÓN';
  }

  function economyActivityDetail(event) {
    if (event?.sourceType === 'loot') return `BILLETE ${event?.meta?.billIndex || ''}`.trim();
    if (event?.sourceType === 'arcade' && String(event?.actionId || '').includes('podium')) { const parts=String(event.actionId).split('-'),id=String(event?.sourceId||'').toUpperCase(); const game=['CAJA30','SAQUEO30'].includes(id)?'BOTÍN 30':id==='PUNTOCIEGO30'?'PUNTO CIEGO 30':id==='INFILTRACION30'?'BRECHA 30':'FUGA 30'; return `PODIO ${game} · #${parts.at(-1) || ''}`; }
    if (event?.actionId === 'retry') return 'SEGUNDA OPORTUNIDAD';
    if (event?.actionId === 'clean-star') return `SOBORNO ${event?.meta?.cleanNumber || ''}`.trim();
    if (event?.actionId === 'success') return 'OBJETIVO COMPLETADO';
    if (event?.actionId === 'loss' || event?.actionId === 'settlement') return 'RESULTADO REGISTRADO';
    if (event?.actionId === 'complete') {
      const activity = cfg.missions?.[String(event?.sourceId || '').toUpperCase()];
      return 'OBJETIVO COMPLETADO';
    }
    return 'MOVIMIENTO REGISTRADO';
  }

  function deltaChip(text, positive = true) {
    const span = document.createElement('span');
    span.className = positive ? 'is-positive' : 'is-negative';
    span.textContent = text;
    return span;
  }

  async function renderCharacterActivity() {
    const list = $('#characterActivityList');
    const toggle = $('#characterActivityToggle');
    if (!list || !primary?.token || activeMode !== 'party') {
      if (toggle) toggle.hidden = true;
      return;
    }
    const nonce = ++characterActivityRequestNonce;
    const loading = document.createElement('p');
    loading.className = 'character-activity__empty';
    loading.textContent = 'CARGANDO MOVIMIENTOS…';
    list.replaceChildren(loading);
    try {
      const events = await getEconomyActivity(12);
      if (nonce !== characterActivityRequestNonce) return;
      list.replaceChildren();
      if (!events.length) {
        const empty = document.createElement('p');
        empty.className = 'character-activity__empty';
        empty.textContent = 'Aún no hay movimientos.';
        list.appendChild(empty);
        return;
      }
      const visibleEvents = characterActivityExpanded ? events : events.slice(0, 3);
      for (const event of visibleEvents) {
        const item = document.createElement('article');
        item.className = 'character-activity__item';
        const main = document.createElement('div');
        main.className = 'character-activity__main';
        const title = document.createElement('strong');
        title.textContent = economyActivityLabel(event);
        const detail = document.createElement('small');
        detail.textContent = economyActivityDetail(event);
        main.append(title, detail);
        const delta = document.createElement('div');
        delta.className = 'character-activity__delta';
        if (event.cashDelta) delta.appendChild(deltaChip(`${event.cashDelta > 0 ? '+' : '−'}$${Math.abs(event.cashDelta)}`, event.cashDelta > 0));
        if (event.respectDelta) delta.appendChild(deltaChip(`+${event.respectDelta} RESPETO`, true));
        if (event.starsDelta) delta.appendChild(deltaChip(`${event.starsDelta > 0 ? '+' : '−'}${Math.abs(event.starsDelta)} ★`, event.starsDelta < 0));
        if (!delta.childNodes.length) delta.appendChild(deltaChip('REGISTRADO', true));
        item.append(main, delta);
        list.appendChild(item);
      }
      if (toggle) {
        toggle.hidden = events.length <= 3;
        toggle.textContent = characterActivityExpanded ? 'VER MENOS' : `VER HISTORIAL · ${events.length}`;
      }
    } catch (error) {
      if (nonce !== characterActivityRequestNonce) return;
      const failed = document.createElement('p');
      failed.className = 'character-activity__empty';
      failed.textContent = 'No se ha podido cargar la actividad ahora mismo.';
      list.replaceChildren(failed);
    }
  }

  function renderCharacterFile(profile = getLocalProfile()) {
    if (!profile) return;
    applyAvatarVisual($('#characterFileAvatar'), profile, { alt:`Foto de ${profile.name || 'jugador'}`, lazy:false });
    $('#characterFileName').textContent = profile.name || 'PLAYER';
    $('#characterFileCrew').textContent = `MIEMBRO #${String(profile.crewNumber || 0).padStart(3, '0')}`;
    $('#characterFileBio').textContent = profile.bio || 'Añade una descripción';
    const photoButton = $('#characterFilePhotoButton');
    if (photoButton) {
      photoButton.disabled = false;
      photoButton.classList.toggle('has-photo', hasUsablePhoto(profile));
      photoButton.setAttribute('aria-label', hasUsablePhoto(profile) ? `Ampliar foto de ${profile.name}` : 'Editar avatar del personaje');
    }

    syncCharacterOperationVisibility();
    if (activeMode === 'party') renderCharacterOperation(profile);

    const identity = $('#identityBlockSummary');
    identity?.replaceChildren(summaryChip('Foto, nombre y descripción', 'is-muted'));
    const character = $('#characterBlockSummary');
    character?.replaceChildren();
    const specs = Array.isArray(profile.specialties) ? profile.specialties : [];
    if (specs.length) specs.forEach((item) => character?.appendChild(summaryChip(`${item.emoji || '•'} ${item.label || ''}`)));
    else character?.appendChild(summaryChip('ELIGE TUS ESPECIALIDADES', 'is-muted'));
    character?.appendChild(summaryChip(profile.specialAbility ? `⚡ ${profile.specialAbility}` : '⚡ AÑADE TU HABILIDAD', 'is-ability'));
    const operation = $('#operationBlockSummary');
    operation?.replaceChildren(summaryChip(profile.dietary ? `🍽️ ${profile.dietary}` : '🍽️ SIN ALERGIAS INDICADAS', profile.dietary ? '' : 'is-muted'));
    const security = $('#securityBlockSummary');
    security?.replaceChildren(summaryChip(profile.hasPin === false ? '🔓 PIN PENDIENTE' : '🔐 PIN CONFIGURADO'));
  }

  function populateCharacterEditor(profile) {
    selectedAvatar = profile.avatar || '🎮';
    pendingPhotoData = profile.photoData || '';
    selectedSpecialtyKeys = (profile.specialties || []).map((item) => item.key).filter((key) => SPECIALTY_CATALOG.some((item) => item.key === key)).slice(0, 3);
    $('#characterName').value = profile.name || '';
    $('#characterDietary').value = profile.dietary || '';
    $('#characterPin').value = '';
    $('#characterBio').value = profile.bio || '';
    $('#characterSpecialAbility').value = profile.specialAbility || '';
    avatarCatalogExpanded = false;
    avatarFallbackPickerOpen = false;
    specialtyCatalogExpanded = false;
    buildAvatarPicker();
    buildSpecialtyPicker();
    updateCharacterPhotoPreview();
    renderCharacterFile(profile);
  }

  const CHARACTER_BLOCK_META = {
    heist:{ title:'Tu operación', subtitle:'Objetivos · botín · respeto · buscado' },
    identity:{ title:'Identidad', subtitle:'' },
    character:{ title:'Especialidades', subtitle:'' },
    operation:{ title:'Alergias e intolerancias', subtitle:'' },
    security:{ title:'PIN de acceso', subtitle:'' }
  };

  function characterBlockSection(block) {
    return block ? $(`.character-file-block[data-character-block="${block}"]`) : null;
  }

  function restoreCharacterEditorNode() {
    if (!activeCharacterEditorNode) return;
    activeCharacterEditorNode.hidden = true;
    if (activeCharacterEditorOrigin?.isConnected) activeCharacterEditorOrigin.appendChild(activeCharacterEditorNode);
    activeCharacterEditorNode = null;
    activeCharacterEditorOrigin = null;
  }

  function syncCharacterBlockState(block = null, { mobilePanel = false } = {}) {
    activeCharacterBlock = block;
    $$('.character-file-block').forEach((section) => {
      const active = section.dataset.characterBlock === block;
      section.classList.toggle('is-editing', active);
      const editor = $('.character-file-block__editor', section);
      if (editor) editor.hidden = mobilePanel ? true : !active;
      section.tabIndex = active ? -1 : 0;
      section.setAttribute('role', active ? 'group' : 'button');
      section.setAttribute('aria-expanded', String(active));
      section.setAttribute('aria-label', `${active ? 'Editando' : 'Editar'} ${CHARACTER_BLOCK_META[section.dataset.characterBlock]?.title || 'expediente'}`);
    });
    $('#characterMessage').textContent = '';
  }

  function finalizeCharacterBlockPanelClose() {
    const stage = $('#characterFileStage');
    const overview = $('#characterFileOverview');
    const panel = $('#characterFileEditPanel');
    characterEditSlideController?.reset();
    restoreCharacterEditorNode();
    stage?.classList.remove('has-detail');
    if (stage) stage.dataset.state = 'overview';
    overview?.setAttribute('aria-hidden', 'false');
    panel?.setAttribute('aria-hidden', 'true');
    if (panel) panel.scrollTop = 0;
    activeCharacterBlock = null;
    $$('.character-file-block').forEach((section) => {
      section.classList.remove('is-editing');
      section.tabIndex = 0;
      section.setAttribute('role', 'button');
      section.setAttribute('aria-expanded', 'false');
      section.setAttribute('aria-label', `Editar ${section.dataset.characterBlock}`);
      const editor = $('.character-file-block__editor', section);
      if (editor) editor.hidden = true;
    });
  }

  function openCharacterBlockPanel(block) {
    const stage = $('#characterFileStage');
    const overview = $('#characterFileOverview');
    const panel = $('#characterFileEditPanel');
    const slot = $('#characterFileEditSlot');
    const section = characterBlockSection(block);
    const editor = section ? $('.character-file-block__editor', section) : null;
    if (!stage || !overview || !panel || !slot || !section || !editor) return;

    finalizeCharacterBlockPanelClose();
    syncCharacterBlockState(block, { mobilePanel:true });
    activeCharacterEditorNode = editor;
    activeCharacterEditorOrigin = section;
    editor.hidden = false;
    slot.replaceChildren(editor);

    const meta = CHARACTER_BLOCK_META[block] || { title:'EXPEDIENTE', subtitle:'Actualiza este bloque.' };
    if ($('#characterFileEditTitle')) $('#characterFileEditTitle').textContent = meta.title;
    if ($('#characterFileEditSubtitle')) { $('#characterFileEditSubtitle').textContent = meta.subtitle; $('#characterFileEditSubtitle').hidden = !meta.subtitle; }
    overview.setAttribute('aria-hidden', 'true');
    panel.setAttribute('aria-hidden', 'false');
    panel.scrollTop = 0;
    stage.dataset.state = 'detail';
    stage.classList.add('has-detail');
  }

  function closeCharacterBlockPanel({ animate = true } = {}) {
    if (!activeCharacterBlock) { finalizeCharacterBlockPanelClose(); return; }
    if (animate && isAppSurfaceMobile() && characterEditSlideController) {
      characterEditSlideController.settle(true);
      return;
    }
    finalizeCharacterBlockPanelClose();
  }

  function setActiveCharacterBlock(block = null) {
    if (!block) {
      if (isAppSurfaceMobile()) closeCharacterBlockPanel({ animate:true });
      else { restoreCharacterEditorNode(); syncCharacterBlockState(null); }
      return;
    }
    if (isAppSurfaceMobile()) { openCharacterBlockPanel(block); return; }
    restoreCharacterEditorNode();
    syncCharacterBlockState(block);
  }

  function setCharacterEditorOpen(open) {
    const dialog = $('#characterEditorDialog');
    const sheet = $('#characterEditor');
    if (!dialog || !sheet) return;
    if (open) {
      resetCharacterSheetPosition();
      finalizeCharacterBlockPanelClose();
      if (!dialog.open) {
        dialog.showModal();
        lockAppSurfacePageScroll();
      }
      sheet.focus?.({ preventScroll:true });
    } else if (dialog.open) {
      finalizeCharacterBlockPanelClose();
      resetCharacterSheetPosition();
      dialog.close();
      unlockAppSurfacePageScroll();
    }
  }

  function openCharacterEditor({ auto = false, targetBlock = null } = {}) {
    const profile = getLocalProfile();
    if (!profile) return;
    populateCharacterEditor(profile);
    setActiveCharacterBlock(null);
    $('#characterMessage').textContent = auto ? 'TU EXPEDIENTE ESTÁ CREADO · PERSONALIZAR ES OPCIONAL' : '';
    setCharacterEditorOpen(true);
    characterActivityExpanded = false;
    syncCharacterOperationVisibility();
    if (activeMode === 'party') {
      renderCharacterOperation(profile);
      renderCharacterActivity();
    }
    if (targetBlock && (targetBlock !== 'heist' || activeMode === 'party')) {
      window.requestAnimationFrame(() => setActiveCharacterBlock(targetBlock));
    }
  }

  function resetCharacterBlock(block) {
    const profile = getLocalProfile();
    if (!profile) return;
    populateCharacterEditor(profile);
    setActiveCharacterBlock(block);
  }

  async function saveCharacterBlock(block) {
    if (!primary?.profile || sessionInvalid) { $('#characterMessage').textContent = 'Recupera tu personaje antes de guardar.'; return; }
    const requestSession = primary;
    const patch = {};
    if (block === 'identity') {
      const name = ($('#characterName')?.value || '').trim();
      if (!name) { $('#characterMessage').textContent = 'Introduce un nombre o alias para el personaje.'; return; }
      patch.name = name;
      patch.bio = ($('#characterBio')?.value || '').trim();
      patch.photoData = pendingPhotoData || '';
      patch.avatar = selectedAvatar || '🎮';
    } else if (block === 'character') {
      patch.specialties = specialtiesFromKeys();
      patch.specialAbility = ($('#characterSpecialAbility')?.value || '').trim();
    } else if (block === 'operation') {
      patch.dietary = ($('#characterDietary')?.value || '').trim();
    } else if (block === 'security') {
      const pin = ($('#characterPin')?.value || '').trim();
      if (!/^\d{4}$/.test(pin)) { $('#characterMessage').textContent = 'El nuevo PIN debe tener exactamente 4 cifras.'; return; }
      patch.pin = pin;
    } else return;

    $('#characterMessage').textContent = 'GUARDANDO CAMBIOS…';
    try {
      const data = await api('me', { method:'PATCH', body:patch, token:primary.token });
      if (primary?.token !== requestSession?.token) return;
      setPrimary({ token:requestSession.token, profile:data.player });
      window.DANI_APP?.syncProfile?.(getLocalProfile());
      populateCharacterEditor(getLocalProfile());
      setActiveCharacterBlock(null);
      $('#characterMessage').textContent = '';
      window.DANI_APP?.announceHud?.('EXPEDIENTE ACTUALIZADO', { detail:'CAMBIOS GUARDADOS', tone:'success', level:'routine' });
      refreshCrew();
    } catch (error) {
      $('#characterMessage').textContent = error.message || 'Error al guardar.';
    }
  }

  function formatCash(value) {
    return `$${Math.max(0, Number(value || 0)).toLocaleString('es-ES')}`;
  }

  function renderHudEconomy() {
    const profile = primary?.profile;
    const metrics = $('#hudPlayerMetrics');
    const fundsMetric = $('#hudPlayerFundsMetric');
    const funds = $('#hudPlayerFunds');
    const quickFunds = $('#hudQuickFunds');
    const respect = $('#hudPlayerRespect');
    const visible = profile?.attendance === 'yes';
    if (metrics) metrics.hidden = !visible;
    if (quickFunds) quickFunds.hidden = !(visible && activeMode === 'party');
    if (!visible) return;
    const self = crewCache.find((player) => player.id === profile.id);
    if (fundsMetric) fundsMetric.hidden = false;
    const cashLabel = formatCash(profile.walletBalance ?? profile.cash);
    if (funds) funds.textContent = cashLabel;
    if (quickFunds) quickFunds.textContent = cashLabel;
    if (respect) respect.textContent = String(profile.respect ?? self?.respect ?? 0);
  }

  function operationProgress(player) {
    const own = primary?.profile?.id === player?.id ? primary.profile : null;
    const inCrew = player?.attendance === 'yes' || Boolean(player?.crewNumber);
    const briefingDone = Boolean(player?.briefingCompleted || own?.briefingCompleted || inCrew);
    const joined = Boolean(player?.attendance === 'yes' || own?.attendance === 'yes' || inCrew);
    const refugeDone = Boolean(player?.locationUnlocked || own?.locationUnlocked);
    const prepDone = Boolean(player?.partyPrepReviewed || own?.uiPrefs?.partyPrepReviewed);
    const eventPhase = window.DANI_APP?.getEventSnapshot?.()?.phase || 'before';
    const preparationComplete = prepDone && eventPhase !== 'before';
    let current = 1;
    if (briefingDone) current = 2;
    if (joined) current = 3;
    if (refugeDone) current = 4;
    if (prepDone) current = 5;
    if (preparationComplete) current = 5;
    const completedThrough = preparationComplete ? 5 : Math.max(0, current - 1);
    const states = Array.from({ length:5 }, (_, index) => {
      const stage = index + 1;
      if (stage <= completedThrough) return 'completed';
      if (!preparationComplete && stage === current) return 'active';
      return preparationComplete ? 'completed' : 'locked';
    });
    const labels = {
      1:'EL PLAN',
      2:'ÚNETE A LA BANDA',
      3:'LOCALIZA EL REFUGIO',
      4:'PREPÁRATE PARA EL GOLPE',
      5:'CONSIGUE DINERO PARA EL GOLPE'
    };
    return {
      current,
      states,
      prepared:prepDone,
      finalStage:prepDone && !preparationComplete,
      label:preparationComplete ? 'PREPARACIÓN COMPLETADA' : `FASE ${String(current).padStart(2,'0')} · ${labels[current]}`
    };
  }

  function buildCrewPhaseStepper(progress) {
    const stepper = document.createElement('span');
    stepper.className = 'crew-phase-stepper';
    stepper.setAttribute('aria-hidden','true');
    progress.states.forEach((stateName, index) => {
      const node = document.createElement('i');
      node.className = `is-${stateName}`;
      node.textContent = stateName === 'completed' ? '✓' : String(index + 1);
      stepper.appendChild(node);
    });
    return stepper;
  }

  function renderCrewProgress(root, progress, { compact = false } = {}) {
    if (!root) return;
    root.replaceChildren();
    root.classList.toggle('is-prepared', progress.prepared);
    root.classList.toggle('is-final-stage', progress.finalStage);
    root.appendChild(buildCrewPhaseStepper(progress));
    if (!compact) {
      const copy = document.createElement('small');
      copy.textContent = progress.label;
      root.appendChild(copy);
    }
    root.setAttribute('aria-label', progress.label);
    root.title = progress.label;
  }

  function makeCrewCard(player, { selectable = false, selected = false, onSelect } = {}) {
    const article = document.createElement('article');
    article.className = `crew-card${selectable ? ' crew-card--selectable' : ''}${selected ? ' crew-card--selected' : ''}`;
    if (selected) article.setAttribute('aria-pressed', 'true');
    if (selectable) {
      article.setAttribute('role', 'button');
      article.tabIndex = 0;
    }
    const head = document.createElement('div');
    head.className = 'crew-card__head';
    const avatar = document.createElement('span');
    avatar.className = 'crew-card__avatar';
    applyAvatarVisual(avatar, player, { alt:`Foto de ${player.name || 'jugador'}` });
    const info = document.createElement('div');
    const name = document.createElement('b');
    name.textContent = player.name || 'PLAYER';
    const id = document.createElement('small');
    id.textContent = `MIEMBRO #${String(player.crewNumber || 0).padStart(3, '0')}`;
    info.append(name, id);
    head.append(avatar, info);
    const bio = document.createElement('p');
    bio.textContent = player.bio || '';
    bio.hidden = !player.bio;
    article.append(head, bio);
    if (player.specialties?.length) {
      const specialties = document.createElement('div');
      specialties.className = 'crew-card__specialties';
      player.specialties.slice(0, 3).forEach((item) => specialties.appendChild(summaryChip(`${item.emoji || '•'} ${item.label || ''}`)));
      article.appendChild(specialties);
    }
    if (selectable && onSelect) {
      article.addEventListener('click', () => onSelect(player));
      article.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect(player); }
      });
    }
    return article;
  }


  function makeCrewDirectoryRow(player) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'crew-member-card app-surface__drag-pass';
    card.dataset.playerId = player.id;
    card.setAttribute('aria-label', `Abrir expediente de ${player.name}`);
    const progress = operationProgress(player);

    const head = document.createElement('span');
    head.className = 'crew-member-card__head';
    const avatar = document.createElement('span');
    avatar.className = 'crew-member-card__avatar';
    applyAvatarVisual(avatar, player, { alt:`Foto de ${player.name || 'jugador'}` });
    if (hasUsablePhoto(player)) {
      avatar.classList.add('is-clickable');
      avatar.title = 'Ampliar foto';
      avatar.addEventListener('click', (event) => { event.stopPropagation(); openPhotoViewer(player); });
    }
    const identity = document.createElement('span');
    identity.className = 'crew-member-card__identity';
    const nameLine = document.createElement('span');
    nameLine.className = 'crew-member-card__name';
    const name = document.createElement('b');
    name.textContent = player.name || 'PLAYER';
    nameLine.appendChild(name);
    if (primary?.profile?.id === player.id) {
      const you = document.createElement('em');
      you.textContent = 'TÚ';
      nameLine.appendChild(you);
    }
    const progressLine = document.createElement('span');
    progressLine.className = 'crew-member-card__progress';
    renderCrewProgress(progressLine, progress, { compact:true });
    identity.append(nameLine, progressLine);
    head.append(avatar, identity);

    const bio = document.createElement('span');
    bio.className = 'crew-member-card__bio';
    bio.textContent = player.bio || '';
    bio.hidden = !player.bio;

    const specialtyPreview = document.createElement('span');
    specialtyPreview.className = 'crew-member-card__specialties';
    (player.specialties || []).slice(0, 2).forEach((item) => {
      const chip = document.createElement('span');
      chip.textContent = `${item.emoji || '•'} ${item.label || 'ESPECIALIDAD'}`;
      specialtyPreview.appendChild(chip);
    });
    if (!specialtyPreview.childElementCount) specialtyPreview.hidden = true;

    const foot = document.createElement('span');
    foot.className = 'crew-member-card__foot';
    const respect = document.createElement('span');
    respect.className = 'crew-respect-badge';
    respect.innerHTML = `<span class="crew-respect-badge__mark" aria-hidden="true">✦</span><span class="crew-respect-badge__copy"><small>RESPETO</small><strong>${Math.max(0, Number(player.respect || 0))}</strong></span>`;
    const arrow = document.createElement('span');
    arrow.className = 'crew-member-card__arrow';
    arrow.setAttribute('aria-hidden','true');
    arrow.textContent = '→';
    foot.append(respect, arrow);

    card.append(head, bio, specialtyPreview, foot);
    card.addEventListener('click', () => openCrewProfile(player.id));
    return card;
  }

  function renderCrewProfile() {
    const panel = $('#crewProfilePanel');
    const layout = $('#crewBrowserLayout');
    if (!panel || !selectedCrewProfileId) return;
    const player = crewCache.find((item) => item.id === selectedCrewProfileId);
    if (!player) {
      closeCrewProfile({ animate:false });
      return;
    }
    const progress = operationProgress(player);
    const profileAvatar = $('#crewProfileAvatar');
    applyAvatarVisual(profileAvatar, player, { alt:`Foto de ${player.name || 'jugador'}`, lazy:false });
    if (profileAvatar) {
      profileAvatar.classList.toggle('is-clickable', hasUsablePhoto(player));
      const clickablePhoto = hasUsablePhoto(player);
      profileAvatar.onclick = clickablePhoto ? () => openPhotoViewer(player) : null;
      profileAvatar.tabIndex = clickablePhoto ? 0 : -1;
      profileAvatar.setAttribute('role', clickablePhoto ? 'button' : 'img');
      profileAvatar.setAttribute('aria-label', clickablePhoto ? `Ampliar foto de ${player.name || 'personaje'}` : `Avatar de ${player.name || 'personaje'}`);
      profileAvatar.onkeydown = clickablePhoto ? (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openPhotoViewer(player); } } : null;
      profileAvatar.setAttribute('title', clickablePhoto ? 'Ampliar foto' : '');
    }
    $('#crewProfileName').textContent = player.name || 'PLAYER';
    renderCrewProgress($('#crewProfileProgress'), progress);
    $('#crewProfileBio').textContent = player.bio || '';
    $('#crewProfileBio').hidden = !player.bio;
    $('#crewProfileRespect').textContent = String(Math.max(0, Number(player.respect || 0)));
    $('#crewProfileCash').textContent = formatCash(player.walletBalance ?? player.cash);

    const specialtyRoot = $('#crewProfileSpecialties');
    specialtyRoot.replaceChildren();
    if (player.specialties?.length) {
      player.specialties.slice(0, 3).forEach((item) => specialtyRoot.appendChild(summaryChip(`${item.emoji || '•'} ${item.label || ''}`)));
    } else {
      const empty = document.createElement('p');
      empty.className = 'crew-profile-sheet__empty';
      empty.textContent = 'Este personaje todavía no ha definido especialidades.';
      specialtyRoot.appendChild(empty);
    }
    $('#crewProfileAbility').textContent = player.specialAbility || '';
    $('#crewProfileAbilityWrap').hidden = !player.specialAbility;
    specialtyRoot.hidden = !player.specialties?.length;
    $('.crew-profile-sheet__section-title').hidden = !player.specialties?.length;

    const live = activeMode === 'party';
    const missionMetric = $('#crewProfileMissionsMetric');
    const wantedMetric = $('#crewProfileWantedMetric');
    missionMetric.hidden = !live;
    wantedMetric.hidden = !live;
    if (live) {
      const testProgress = competitionProgress(player);
      $('#crewProfileMissions').textContent = `${testProgress.done}/${testProgress.total}`;
      const stars = Math.max(0, Number(player.gameStars ?? player.wantedScore ?? 0));
      $('#crewProfileWanted').textContent = `${stars} ${stars === 1 ? '★' : '★'}`;
    }

    const action = $('#crewProfileRespectAction');
    const viewer = primary?.profile;
    const canRespect = viewer?.attendance === 'yes' && viewer.id !== player.id;
    action.hidden = !canRespect;
    action.disabled = !canRespect || Boolean(player.respectedByViewer);
    action.textContent = player.respectedByViewer ? 'RESPETO ENVIADO ✓' : '✦ DAR RESPETO';
    $('#crewProfileMessage').textContent = '';
  }

  function finalizeCrewProfileClose() {
    const panel = $('#crewProfilePanel');
    const layout = $('#crewBrowserLayout');
    if (crewProfileCloseTimer) {
      window.clearTimeout(crewProfileCloseTimer);
      crewProfileCloseTimer = null;
    }
    if (panel) {
      panel.hidden = true;
      panel.classList.remove('is-swiping');
      panel.style.transform = '';
      panel.style.transition = '';
    }
    layout?.classList.remove('has-profile');
    selectedCrewProfileId = null;
  }

  function openCrewProfile(playerId) {
    const panel = $('#crewProfilePanel');
    const layout = $('#crewBrowserLayout');
    if (!panel || !layout) return;
    if (crewProfileCloseTimer) {
      window.clearTimeout(crewProfileCloseTimer);
      crewProfileCloseTimer = null;
    }
    selectedCrewProfileId = playerId;
    panel.hidden = false;
    panel.classList.remove('is-swiping');
    panel.style.transition = '';
    panel.style.transform = '';
    renderCrewProfile();
    if (isCrewMobile() && !reducedMotion) {
      layout.classList.remove('has-profile');
      panel.style.transform = 'translate3d(100%,0,0)';
      panel.getBoundingClientRect();
      layout.classList.add('has-profile');
      panel.style.transform = '';
    } else {
      layout.classList.add('has-profile');
    }
    panel.scrollTop = 0;
  }

  function closeCrewProfile({ animate = true } = {}) {
    const panel = $('#crewProfilePanel');
    const layout = $('#crewBrowserLayout');
    if (!panel || panel.hidden) {
      finalizeCrewProfileClose();
      return;
    }
    if (!animate || !isCrewMobile() || reducedMotion) {
      finalizeCrewProfileClose();
      return;
    }
    panel.classList.remove('is-swiping');
    panel.style.transition = '';
    panel.style.transform = '';
    layout?.classList.remove('has-profile');
    crewProfileCloseTimer = window.setTimeout(finalizeCrewProfileClose, 220);
  }

  // Controlador horizontal común para paneles detalle móviles.
  // La Banda e Identificación comparten la misma física, umbral y transición.
  function createMobileSlideBackController({
    gestureRoot,
    panel,
    isEnabled,
    onBack,
    onRestore,
    minBackDistance = 110,
    backThreshold = 0.28,
    edgeGuard = 24
  }) {
    let swipe = null;
    let settleTimer = null;

    const clearTimer = () => {
      if (settleTimer) {
        window.clearTimeout(settleTimer);
        settleTimer = null;
      }
    };

    const reset = () => {
      clearTimer();
      swipe = null;
      panel.classList.remove('is-swiping');
      panel.style.transition = '';
      panel.style.transform = '';
    };

    const settle = (goBack) => {
      panel.classList.remove('is-swiping');
      panel.style.transition = reducedMotion ? 'none' : 'transform .18s cubic-bezier(.2,.76,.25,1)';
      panel.style.transform = goBack ? 'translate3d(100%,0,0)' : 'translate3d(0,0,0)';

      const finish = () => {
        settleTimer = null;
        if (goBack) {
          onBack?.();
          // onBack cambia el estado/clase de la vista; después podemos retirar
          // el estilo inline sin provocar un salto visual.
          panel.style.transition = '';
          panel.style.transform = '';
          panel.classList.remove('is-swiping');
          return;
        }
        reset();
        onRestore?.();
      };

      if (reducedMotion) finish();
      else settleTimer = window.setTimeout(finish, 190);
    };

    gestureRoot.addEventListener('touchstart', (event) => {
      if (!isEnabled?.() || event.touches.length !== 1) return;
      const touch = event.touches[0];
      // Mantiene libre el gesto de historial de Safari en el borde extremo.
      if (touch.clientX < edgeGuard) return;
      swipe = { startX:touch.clientX, startY:touch.clientY, dx:0, active:false };
    }, { passive:true });

    gestureRoot.addEventListener('touchmove', (event) => {
      if (!swipe || event.touches.length !== 1 || !isEnabled?.()) return;
      const touch = event.touches[0];
      const dx = touch.clientX - swipe.startX;
      const dy = touch.clientY - swipe.startY;
      if (!swipe.active) {
        if (dx <= 10 || Math.abs(dx) <= Math.abs(dy) * 1.2) return;
        swipe.active = true;
        panel.classList.add('is-swiping');
      }
      event.preventDefault();
      swipe.dx = Math.max(0, dx);
      panel.style.transform = `translate3d(${Math.min(panel.clientWidth, swipe.dx)}px,0,0)`;
    }, { passive:false });

    const finishSwipe = () => {
      if (!swipe) return;
      const wasActive = swipe.active;
      const shouldGoBack = wasActive && swipe.dx >= Math.min(minBackDistance, panel.clientWidth * backThreshold);
      swipe = null;
      if (wasActive) settle(shouldGoBack);
    };

    gestureRoot.addEventListener('touchend', finishSwipe, { passive:true });
    gestureRoot.addEventListener('touchcancel', finishSwipe, { passive:true });

    return { reset, settle };
  }

  function bindCrewProfileSwipe() {
    const panel = $('#crewProfilePanel');
    if (!panel || crewProfileSlideController) return;
    crewProfileSlideController = createMobileSlideBackController({
      gestureRoot:panel,
      panel,
      isEnabled:() => isCrewMobile() && !panel.hidden,
      onBack:finalizeCrewProfileClose,
      onRestore:() => $('#crewBrowserLayout')?.classList.add('has-profile')
    });
  }

  // V21.31 · controlador único para todas las app-surface móviles.
  function createMobileBottomSheetController({
    sheet,
    isMobile,
    getScrollRoot,
    isBlocked,
    onClose,
    closeThreshold = 0.14,
    minCloseDistance = 110,
    dragRatio = 0.92
  }) {
    let swipe = null;
    let closeTimer = null;

    const reset = () => {
      if (closeTimer) {
        window.clearTimeout(closeTimer);
        closeTimer = null;
      }
      sheet.classList.remove('is-dragging');
      sheet.style.transition = '';
      sheet.style.transform = '';
      swipe = null;
    };

    const settle = (shouldClose) => {
      sheet.classList.remove('is-dragging');
      if (shouldClose) {
        if (reducedMotion) {
          reset();
          onClose();
          return;
        }
        sheet.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
        sheet.style.transform = 'translate3d(0,100%,0)';
        closeTimer = window.setTimeout(() => {
          reset();
          onClose();
        }, 190);
        return;
      }
      sheet.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
      sheet.style.transform = 'translate3d(0,0,0)';
      window.setTimeout(reset, 190);
    };

    sheet.addEventListener('touchstart', (event) => {
      if (!isMobile() || event.touches.length !== 1 || isBlocked?.(event.target)) return;
      // La cabecera / drag-zone siempre puede iniciar el cierre, aunque el body
      // conserve scroll. Fuera de ella, solo tomamos el gesto si el scroll está arriba.
      const fromDragZone = Boolean(event.target?.closest?.('.app-surface__drag-zone'));
      const scrollRoot = fromDragZone ? null : (getScrollRoot?.(event.target) || null);
      if (scrollRoot && scrollRoot.scrollTop > 1) return;
      const touch = event.touches[0];
      swipe = { startY:touch.clientY, startX:touch.clientX, dy:0, active:false, scrollRoot };
    }, { passive:true });

    sheet.addEventListener('touchmove', (event) => {
      if (!swipe || event.touches.length !== 1) return;
      const touch = event.touches[0];
      const dy = touch.clientY - swipe.startY;
      const dx = touch.clientX - swipe.startX;
      if (!swipe.active) {
        if (swipe.scrollRoot && swipe.scrollRoot.scrollTop > 1) { swipe = null; return; }
        if (dy <= 7 || Math.abs(dy) <= Math.abs(dx) * 1.15) return;
        swipe.active = true;
        sheet.classList.add('is-dragging');
      }
      event.preventDefault();
      swipe.dy = Math.max(0, dy);
      const distance = Math.min(sheet.clientHeight, swipe.dy * dragRatio);
      sheet.style.transform = `translate3d(0,${distance}px,0)`;
    }, { passive:false });

    const finish = () => {
      if (!swipe) return;
      const wasActive = swipe.active;
      const shouldClose = wasActive && swipe.dy >= Math.min(minCloseDistance, sheet.clientHeight * closeThreshold);
      swipe = null;
      if (wasActive) settle(shouldClose);
    };
    sheet.addEventListener('touchend', finish, { passive:true });
    sheet.addEventListener('touchcancel', finish, { passive:true });

    return { reset, settle };
  }

  function appSurfaceScrollRoot(target, fallback = null) {
    return target?.closest?.('.app-surface__scroll') || fallback;
  }

  function appSurfaceSwipeBlocked(target) {
    const control = target?.closest?.('button,a,input,textarea,select,label,[contenteditable="true"]');
    if (!control) return false;
    return !control.classList.contains('app-surface__drag-pass');
  }

  function resetCrewSheetPosition() {
    crewBottomSheet?.reset();
  }

  function bindCrewSheetSwipe() {
    const sheet = $('#crewBrowserSheet');
    if (!sheet || crewBottomSheet) return;
    crewBottomSheet = createMobileBottomSheetController({
      sheet,
      isMobile:isAppSurfaceMobile,
      getScrollRoot:(target) => target?.closest?.('.crew-browser__slide,.crew-profile-panel') || appSurfaceScrollRoot(target, $('#crewBrowserMain')),
      isBlocked:appSurfaceSwipeBlocked,
      onClose:closeCrewDirectory
    });
  }


  function resetCharacterSheetPosition() {
    characterBottomSheet?.reset();
    characterEditSlideController?.reset();
  }

  function bindCharacterSheetSwipe() {
    const sheet = $('#characterEditor');
    const overview = $('#characterFileOverview');
    if (!sheet || !overview || characterBottomSheet) return;
    characterBottomSheet = createMobileBottomSheetController({
      sheet,
      isMobile:isAppSurfaceMobile,
      getScrollRoot:(target) => appSurfaceScrollRoot(target, overview),
      isBlocked:appSurfaceSwipeBlocked,
      onClose:() => setCharacterEditorOpen(false)
    });
  }

  function bindCharacterBlockSwipe() {
    const panel = $('#characterFileEditPanel');
    const stage = $('#characterFileStage');
    if (!panel || !stage || characterEditSlideController) return;
    characterEditSlideController = createMobileSlideBackController({
      gestureRoot:panel,
      panel,
      isEnabled:() => isAppSurfaceMobile() && stage.classList.contains('has-detail'),
      onBack:finalizeCharacterBlockPanelClose
    });
  }

  async function giveRespect(playerId, button = $('#crewProfileRespectAction')) {
    if (!primary?.token || !playerId || button?.disabled) return;
    if (button) {
      button.disabled = true;
      button.textContent = 'ENVIANDO…';
    }
    try {
      const data = await api('crew/respect', { method:'POST', body:{ playerId }, token:primary.token });
      const player = crewCache.find((item) => item.id === playerId);
      if (player) {
        player.respect = Math.max(0, Number(data.respect ?? player.respect ?? 0));
        player.socialRespect = Math.max(0, Number(data.socialRespect ?? player.socialRespect ?? 0));
        player.missionRespect = Math.max(0, Number(data.missionRespect ?? player.missionRespect ?? 0));
        player.respectBreakdown = { social:player.socialRespect, missions:player.missionRespect };
        player.respectedByViewer = true;
      }
      renderCrewDirectory(crewCache);
      renderCrewProfile();
      renderHudEconomy();
    } catch (error) {
      if (button) {
        button.disabled = false;
        button.textContent = '✦ DAR RESPETO';
      }
      const message = $('#crewProfileMessage');
      if (message) message.textContent = error.message || 'No se ha podido enviar respeto.';
    }
  }

  function makeInviteCrewSnapshot(players = crewCache) {
    const prepared = players.filter((player) => operationProgress(player).prepared).length;
    return {
      count:players.length,
      prepared,
      ids:new Set(players.map((player) => String(player.id || '')).filter(Boolean)),
      players
    };
  }

  function crossedFiveMilestone(previous, next) {
    if (!(next > previous)) return null;
    const milestone = Math.floor(next / 5) * 5;
    return milestone >= 5 && milestone > previous ? milestone : null;
  }

  function announceInviteCrewChanges(players = crewCache) {
    const next = makeInviteCrewSnapshot(players);
    const previous = inviteCrewSnapshot;
    inviteCrewSnapshot = next;
    if (activeMode !== 'invite' || !previous) return;

    const ownId = String(primary?.profile?.id || '');
    const added = players.filter((player) => {
      const id = String(player?.id || '');
      return id && id !== ownId && !previous.ids.has(id);
    });
    const memberMilestone = crossedFiveMilestone(previous.count, next.count);
    const preparedMilestone = crossedFiveMilestone(previous.prepared, next.prepared);

    if (next.count > previous.count) {
      if (memberMilestone) {
        window.DANI_APP?.announceHud?.('LA BANDA CRECE', {
          detail:`YA SOMOS ${next.count}`,
          level:'social', spontaneous:true, priority:1,
          dedupeKey:`crew-members-${memberMilestone}`
        });
      } else if (added.length === 1) {
        window.DANI_APP?.announceHud?.('NUEVO MIEMBRO', {
          detail:`${String(added[0].name || 'ALGUIEN').toUpperCase()} SE HA UNIDO`,
          level:'social', spontaneous:true, priority:1,
          dedupeKey:`crew-joined-${added[0].id}`
        });
      } else if (added.length > 1) {
        window.DANI_APP?.announceHud?.('LA BANDA CRECE', {
          detail:`YA SOMOS ${next.count}`,
          level:'social', spontaneous:true, priority:1,
          dedupeKey:`crew-count-${next.count}`
        });
      }
    }

    if (preparedMilestone) {
      window.DANI_APP?.announceHud?.('LA BANDA SE PREPARA', {
        detail:`${next.prepared} MIEMBROS LISTOS`,
        level:'social', spontaneous:true, priority:0,
        dedupeKey:`crew-prepared-${preparedMilestone}`
      });
    }
  }

  function startCrewRefreshTimer() {
    if (refreshTimer) { window.clearInterval(refreshTimer); refreshTimer = null; }
    const delay = activeMode === 'party' ? 20000 : 45000;
    refreshTimer = window.setInterval(() => {
      if (document.hidden) return;
      refreshCrew();
      if (activeMode === 'party') renderWantedRanking();
    }, delay);
  }

  async function fetchCrew() {
    const data = await api('crew', { token:primary?.token });
    crewCache = (data.players || []).map(normalizeProfile);
    const self = primary?.profile && crewCache.find((player) => player.id === primary.profile.id);
    if (self && primary?.profile) {
      primary.profile.respect = self.respect;
      primary.profile.socialRespect = self.socialRespect;
      primary.profile.missionRespect = self.missionRespect;
      primary.profile.respectBreakdown = { ...self.respectBreakdown };
      primary.profile.walletBalance = self.walletBalance;
      primary.profile.cash = self.walletBalance;
      primary.profile.gameStars = self.gameStars;
      primary.profile.wantedScore = self.gameStars;
    }
    renderHudEconomy();
    return crewCache;
  }

  function setCrewRefreshBusy(busy) {
    const grid = $('#crewGrid');
    const sheet = $('#crewBrowserSheet');
    if (grid) grid.setAttribute('aria-busy', busy ? 'true' : 'false');
    if (sheet) sheet.toggleAttribute('data-refreshing', Boolean(busy));
  }

  async function refreshCrew() {
    if (crewRequest) return crewRequest;
    setCrewRefreshBusy(true);
    crewRequest = (async () => {
      try {
        await fetchCrew();
        crewError = '';
        announceInviteCrewChanges(crewCache);
      }
      catch { crewError = 'No se ha podido actualizar la banda. Los datos anteriores pueden estar desactualizados.'; }
      for (const id of ['crewStatus','loginCrewStatus']) {
        if ($('#'+id)) $('#'+id).textContent = crewError;
      }
      $('#retryCrew').hidden = !crewError;
      renderCrewDirectory(crewCache);
      renderPartyPlayerGrid(crewCache);
      renderPartyOperationSummary(getLocalProfile());
      if (!$('#crewProfilePanel')?.hidden) renderCrewProfile();
      return crewCache;
    })();
    try { return await crewRequest; } finally { crewRequest = null; setCrewRefreshBusy(false); }
  }

  function renderCrewDirectory(players = crewCache) {
    const root = $('#crewGrid');
    const prepared = players.filter((player) => operationProgress(player).prepared).length;
    const unlocked = canBrowseCrew();
    const count = $('#crewCount');
    const accessTitle = $('#crewAccessTitle');
    const toggle = $('#toggleCrewPanel');
    const lock = $('#crewLock');
    const arrow = $('#crewChevron');
    const quick = $('#crewQuickAccess');
    const quickCount = $('#crewQuickCount');
    const quickStatus = $('#crewQuickStatus');
    const quickState = $('#crewQuickState');
    const kicker = $('#crewHubKicker');
    const browserKicker = $('#crewBrowserKicker');
    const browserSubtitle = $('#crewBrowserSubtitle');
    const crewHub = $('#crewHub');
    crewHub?.classList.toggle('is-live', activeMode === 'party');
    crewHub?.classList.toggle('is-waiting', activeMode === 'invite' && Boolean(primary?.profile?.locationUnlocked));
    renderCrewAccessPeople(players);

    const socialTitle = activeMode === 'party'
      ? 'LA BANDA'
      : (players.length ? `${players.length} EN LA BANDA` : 'LA BANDA SE ESTÁ REUNIENDO');
    const socialDetail = !unlocked
      ? 'ÚNETE PARA ACCEDER'
      : (activeMode === 'party'
        ? `${players.length} ${players.length === 1 ? 'JUGADOR' : 'JUGADORES'} · EN ACTIVO`
        : `${prepared} ${prepared === 1 ? 'PREPARADO' : 'PREPARADOS'}`);
    if (accessTitle) accessTitle.textContent = socialTitle;
    if (count) count.textContent = socialDetail;
    const quickDetail = !unlocked
      ? 'ÚNETE PARA ACCEDER'
      : (activeMode === 'party'
        ? `${players.length} ${players.length === 1 ? 'MIEMBRO' : 'MIEMBROS'} · EN ACTIVO`
        : `${players.length} ${players.length === 1 ? 'MIEMBRO' : 'MIEMBROS'} · ${prepared} ${prepared === 1 ? 'PREPARADO' : 'PREPARADOS'}`);
    if (quickCount) quickCount.textContent = activeMode === 'party' ? 'CLASIFICACIÓN' : 'LA BANDA';
    if (quickStatus) quickStatus.textContent = quickDetail;
    if (quickState) quickState.textContent = unlocked ? '→' : '🔒';
    for (const entry of [quick]) {
      if (!entry) continue;
      entry.disabled = !unlocked;
      entry.setAttribute('aria-disabled', String(!unlocked));
      entry.title = unlocked ? (activeMode === 'party' ? 'Ver Clasificación y La Banda' : 'Ver La Banda') : `${players.length || 'La banda'} · completa Reúne a la banda para acceder`;
    }
    if (kicker) kicker.textContent = activeMode === 'party' ? 'LA BANDA · EN ACTIVO' : 'LA BANDA';
    if (browserKicker) browserKicker.textContent = activeMode === 'party' ? 'EL GOLPE · EN ACTIVO' : 'LA BANDA';
    const browserTitle = $('#crewBrowserTitle');
    if (browserTitle) browserTitle.textContent = activeMode === 'party' ? 'El golpe' : 'La banda';
    if (browserSubtitle) browserSubtitle.textContent = activeMode === 'party' ? 'Clasificación y banda de la operación.' : 'Quién está dentro y cómo avanza la operación.';
    if (lock) lock.hidden = unlocked;
    if (arrow) arrow.hidden = !unlocked;
    if (toggle) {
      toggle.disabled = !unlocked;
      toggle.setAttribute('aria-disabled', String(!unlocked));
      toggle.title = unlocked ? (activeMode === 'party' ? 'Ver Clasificación y La Banda' : 'Ver La Banda') : 'Únete a la banda para acceder al equipo';
    }

    const membersMetric = $('#crewMembersMetric');
    const preparedMetric = $('#crewPreparedMetric');
    const overview = $('#crewOverview');
    const viewSwitch = $('#crewViewSwitch');
    const viewContext = $('#crewViewContext');
    const partyViews = activeMode === 'party';
    if (!partyViews && crewBrowserView !== 'band') crewBrowserView = 'band';
    if (viewSwitch) viewSwitch.hidden = !partyViews;
    if (viewContext) viewContext.hidden = !partyViews;
    $('#crewViewBand')?.classList.toggle('is-active', crewBrowserView === 'band');
    $('#crewViewWanted')?.classList.toggle('is-active', crewBrowserView === 'wanted');
    $('#crewViewBand')?.setAttribute('aria-pressed', String(crewBrowserView === 'band'));
    $('#crewViewWanted')?.setAttribute('aria-pressed', String(crewBrowserView === 'wanted'));
    setCrewViewIndicator(crewBrowserView === 'band' ? 1 : 0);
    const membersLabel = $('#crewMembersMetricLabel');
    const preparedLabel = $('#crewPreparedMetricLabel');

    // En El Golpe ambas vistas comparten una franja contextual de la misma altura.
    // En Invitación mantenemos el resumen clásico de La Banda.
    if (overview) overview.hidden = partyViews;
    if (partyViews) {
      renderCrewViewContext(players, prepared);
    } else {
      if (membersLabel) membersLabel.textContent = 'MIEMBROS';
      if (preparedLabel) preparedLabel.textContent = 'PREPARADOS';
      if (membersMetric) membersMetric.textContent = String(players.length);
      if (preparedMetric) {
        preparedMetric.textContent = String(prepared);
        preparedMetric.parentElement?.setAttribute('title', 'Han completado la Fase 4 y ya están en la fase final de preparación.');
        preparedMetric.parentElement?.setAttribute('aria-label', `${prepared} preparados: han completado la Fase 4 y ya están en la fase final de preparación`);
      }
    }

    if (!root) return;
    // Las dos caras se renderizan siempre. Así el panel vecino ya existe mientras
    // el dedo lo arrastra dentro del carrusel y no aparece un vacío a mitad del gesto.
    root.replaceChildren();
    players.forEach((player) => root.appendChild(makeCrewDirectoryRow(player)));
    if (!players.length) {
      const empty = document.createElement('p');
      empty.className = 'crew-empty';
      empty.textContent = crewError ? 'Lista no disponible. Pulsa Reintentar.' : 'La banda se está reuniendo.';
      root.appendChild(empty);
    }
    renderWantedRanking(players);
    syncPriorityHud(players);
  }

  function closeCrewDirectory() {
    const dialog = $('#crewDirectoryDialog');
    crewPanelOpen = false;
    closeCrewProfile({ animate:false });
    resetCrewSheetPosition();
    if (dialog?.open) dialog.close();
    unlockAppSurfacePageScroll();
  }

  async function setCrewPanelOpen(open, { refresh = true } = {}) {
    const dialog = $('#crewDirectoryDialog');
    if (!dialog) return;
    if (!open || !canBrowseCrew()) {
      closeCrewDirectory();
      return;
    }
    crewPanelOpen = true;
    closeCrewProfile({ animate:false });
    if (activeMode !== 'party') crewBrowserView = 'band';
    renderCrewDirectory(crewCache);
    resetCrewSheetPosition();
    if (!dialog.open) {
      dialog.showModal();
      lockAppSurfacePageScroll();
    }
    // Evita que <dialog> enfoque automáticamente la primera tarjeta/botón y
    // dibuje un aro de foco al abrir La Banda.
    $('#crewBrowserSheet')?.focus?.({ preventScroll:true });
    $('#crewRankingSlide')?.scrollTo?.({ top:0, behavior:'auto' });
    $('#crewBandSlide')?.scrollTo?.({ top:0, behavior:'auto' });
    if (refresh) await refreshCrew();
  }

  function onInviteState(inviteState) {
    updatePinField();
    const signature = `${inviteState?.attendance || 'none'}:${inviteState?.locationUnlocked ? '1' : '0'}`;
    if (inviteState?.attendance !== 'yes') {
      crewPanelOpen = false;
      closeCrewProfile();
      setCharacterEditorOpen(false);
    }
    applyCrewDisclosure(primary?.profile);
    if (signature !== lastInviteSignature) {
      lastInviteSignature = signature;
      refreshCrew();
    } else {
      renderCrewDirectory(crewCache);
    }
  }

  async function collectMoney(index) {
    if (!primary?.token) throw new Error('Recupera tu personaje para guardar los fondos.');
    const data = await api('money/collect', { method:'POST', body:{ index }, token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    renderPartyOperationSummary(getLocalProfile());
    return { amount:Number(data.amount || 0), profile:getLocalProfile() };
  }

  async function escapePolice() {
    if (!primary?.token) return { ok:false };
    const data = await api('money/escape', { method:'POST', token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    renderPartyOperationSummary(getLocalProfile());
    return { ok:true, profile:getLocalProfile() };
  }



  async function completePartyPrep() {
    if (!primary?.token) throw new Error('Únete a la banda para guardar la preparación.');
    const prefs = { ...(getLocalProfile()?.uiPrefs || {}), partyPrepReviewed:true };
    const data = await api('me', { method:'PATCH', body:{ uiPrefs:prefs }, token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    return { ok:true, profile:getLocalProfile() };
  }

  async function discoverArcade() {
    if (!primary?.token) throw new Error('Únete a la banda para descubrir el arcade.');
    const prefs = { ...(getLocalProfile()?.uiPrefs || {}), arcadeDiscovered:true };
    const data = await api('me', { method:'PATCH', body:{ uiPrefs:prefs }, token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    return { ok:true, profile:getLocalProfile() };
  }

  async function clandestineLeaderboard() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en Operaciones Clandestinas.');
    return api('clandestine/leaderboard', { token:primary.token });
  }

  async function arcadeLeaderboard() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en el arcade.');
    return api('arcade/leaderboard', { token:primary.token });
  }

  async function arcadeStart() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en el arcade.');
    const rulesVersion=Math.max(0,Math.floor(Number(window.DANI_ARCADE_ENGINE?.VERSION)||0));
    return api('arcade/start', { method:'POST', body:{rulesVersion}, token:primary.token });
  }

  async function arcadeFinish(runId, score, proof={}) {
    if (!primary?.token) throw new Error('La sesión del arcade ya no está disponible.');
    const clientScore=Math.max(0,Math.floor(Number(score)||0));
    return api('arcade/finish', { method:'POST', body:{ runId, score:clientScore, ...proof }, token:primary.token });
  }

  async function infiltrationLeaderboard() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en BRECHA 30.');
    return api('infiltration/leaderboard', { token:primary.token });
  }

  async function infiltrationStart() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en BRECHA 30.');
    return api('infiltration/start', { method:'POST', token:primary.token });
  }

  async function infiltrationFinish(runId, events = []) {
    if (!primary?.token) throw new Error('La sesión de BRECHA 30 ya no está disponible.');
    return api('infiltration/finish', {
      method:'POST',
      body:{ runId:String(runId || ''), events:Array.isArray(events) ? events.slice(0, 4096) : [] },
      token:primary.token
    });
  }

  async function safeLeaderboard() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en BOTÍN 30.');
    return api('safe/leaderboard', { token:primary.token });
  }

  async function safeStart() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en BOTÍN 30.');
    return api('safe/start', { method:'POST', body:{rulesVersion:10}, token:primary.token });
  }

  async function safeFinish(runId, proof = {}) {
    if (!primary?.token) throw new Error('La sesión de BOTÍN 30 ya no está disponible.');
    return api('safe/finish', {
      method:'POST',
      body:{
        runId:String(runId || ''),
        rulesVersion:Math.max(0,Math.floor(Number(proof?.rulesVersion)||0)),
        durationMs:Math.max(0,Math.floor(Number(proof?.durationMs)||0)),
        events:(Array.isArray(proof?.events)?proof.events:[]).slice(0,5).map((entry)=>({t:Math.max(0,Math.round((Number(entry?.t)||0)*1000000)/1000000),type:'tap'}))
      },
      token:primary.token
    });
  }

  async function pointBlindLeaderboard() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en PUNTO CIEGO 30.');
    return api('pointblind/leaderboard', { token:primary.token });
  }

  async function pointBlindStart() {
    if (!primary?.token) throw new Error('Recupera tu personaje para entrar en PUNTO CIEGO 30.');
    return api('pointblind/start', { method:'POST', body:{ rulesVersion:1 }, token:primary.token });
  }

  async function pointBlindFinish(runId, proof = {}) {
    if (!primary?.token) throw new Error('La sesión de PUNTO CIEGO 30 ya no está disponible.');
    return api('pointblind/finish', {
      method:'POST',
      body:{
        runId:String(runId || ''),
        rulesVersion:Math.max(0,Math.floor(Number(proof?.rulesVersion)||0)),
        durationMs:Math.max(0,Math.floor(Number(proof?.durationMs)||0)),
        events:(Array.isArray(proof?.events)?proof.events:[]).slice(0,3).map((entry)=>({t:Math.max(0,Math.round((Number(entry?.t)||0)*1000000)/1000000),type:'tap'}))
      },
      token:primary.token
    });
  }

  async function discoverMission(code) {
    if (!primary?.token) throw new Error('Recupera tu personaje para desbloquear el objetivo.');
    const data = await api('missions/discover', { method:'POST', body:{ code }, token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    window.DANI_APP?.syncProfile?.(getLocalProfile());
    renderPartyOperationSummary(getLocalProfile());
    return { ok:true, alreadyDiscovered:Boolean(data.alreadyDiscovered), code:data.code, profile:getLocalProfile() };
  }

  async function completeMission(code) {
    if (!primary?.token) throw new Error('Recupera tu personaje para guardar la misión.');
    const data = await api('missions/complete', { method:'POST', body:{ code }, token:primary.token });
    setPrimary({ token:primary.token, profile:data.player });
    renderPartyOperationSummary(getLocalProfile());
    refreshCrew();
    return { ok:true, alreadyCompleted:Boolean(data.alreadyCompleted), reward:data.reward || {}, profile:getLocalProfile() };
  }

  // La tarjeta solo declara la acción. D1 decide importes, estrellas, precios y
  // si esa acción completa o no una misión. Así el cliente no puede fabricar recursos.
  async function applyEconomy({ sourceType='game', sourceId, actionId, eventId='', meta={} } = {}) {
    if (!primary?.token) throw new Error('Recupera tu personaje para guardar el resultado.');
    const data = await api('economy/apply', {
      method:'POST',
      body:{ sourceType, sourceId, actionId, eventId:eventId || `evt-${globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`}`, meta },
      token:primary.token
    });
    setPrimary({ token:primary.token, profile:data.player });
    window.DANI_APP?.syncProfile?.(getLocalProfile());
    renderCharacterOperation(getLocalProfile());
    refreshCrew();
    return { ok:true, duplicate:Boolean(data.duplicate), eventId:data.eventId, profile:getLocalProfile() };
  }

  async function getEconomyActivity(limit = 12) {
    if (!primary?.token) return [];
    const safeLimit = Math.max(1, Math.min(30, Number.parseInt(limit, 10) || 12));
    const data = await api(`economy/activity?limit=${safeLimit}`, { token:primary.token });
    return Array.isArray(data.events) ? data.events : [];
  }

  async function cleanCharacterRecord() {
    const profile = getLocalProfile();
    const stars = Math.max(0, Number(profile?.gameStars ?? profile?.wantedScore ?? 0));
    if (!profile || stars < 1) return;
    const cost = Math.max(0, Number(profile.nextRecordCleanCost || 200));
    if (Math.max(0, Number(profile.walletBalance ?? profile.cash ?? 0)) < cost) {
      $('#characterMessage').textContent = `Necesitas ${formatCash(cost)} para limpiar una estrella.`;
      return;
    }
    const button = $('#cleanCharacterRecord');
    if (button) { button.disabled = true; button.setAttribute('aria-busy','true'); }
    $('#characterMessage').textContent = 'NEGOCIANDO SOBORNO…';
    try {
      await applyEconomy({ sourceType:'system', sourceId:'EXPEDIENTE', actionId:'clean-star', meta:{ requestedFrom:'my-file' } });
      const updated = getLocalProfile();
      renderCharacterFile(updated);
      await renderCharacterActivity();
      $('#characterMessage').textContent = '';
      window.DANI_APP?.announceHud?.('EXPEDIENTE LIMPIADO', { detail:`-${formatCash(cost)} · −1 ★`, tone:'success', duration:2600 });
    } catch (error) {
      $('#characterMessage').textContent = error.message || 'No se ha podido limpiar el expediente.';
      renderCharacterOperation(getLocalProfile());
    } finally {
      if (button) { button.removeAttribute('aria-busy'); button.disabled = false; }
      renderCharacterOperation(getLocalProfile());
    }
  }

  function setHeistPreviewExpanded(expanded, { animate = true } = {}) {
    const preview = $('#heistPreview');
    const toggle = $('#heistPreviewToggle');
    const details = $('#heistPreviewDetails');
    if (!preview || !toggle || !details) return;
    const next = Boolean(expanded);
    heistPreviewExpanded = next;
    preview.classList.toggle('is-expanded', next);
    toggle.setAttribute('aria-expanded', String(next));
    details.setAttribute('aria-hidden', String(!next));
    if (!next && animate && !reducedMotion) {
      preview.classList.remove('is-pop-closing');
      void preview.offsetWidth;
      preview.classList.add('is-pop-closing');
      window.setTimeout(() => preview.classList.remove('is-pop-closing'), 320);
    }
  }

  function toggleHeistPreview() {
    setHeistPreviewExpanded(!heistPreviewExpanded);
  }

  function heistPreparationContext(profile, snapshot) {
    const prefs = profile?.uiPrefs || {};
    if (snapshot.phase === 'after') return {
      title:'OPERACIÓN COMPLETADA',
      text:'El día del golpe ya ha terminado. La preparación queda como recuerdo de la operación.'
    };
    if (snapshot.phase === 'live') return {
      title:'ENTRA Y EJECUTA EL PLAN',
      text:'El acceso a El Golpe ya está abierto desde esta misma tarjeta.'
    };
    if (profile?.attendance !== 'yes') return {
      title:'ÚNETE A LA BANDA',
      text:'Confirma tu asistencia para formar parte de la operación y desbloquear la preparación.'
    };
    if (!profile.locationUnlocked) return {
      title:'LOCALIZA EL REFUGIO',
      text:'Completa el hack de la Fase 03 para descubrir el punto de encuentro.'
    };
    if (!prefs.partyPrepReviewed) return {
      title:'PREPÁRATE PARA EL GOLPE',
      text:'Revisa cómo venir como NPC y el inventario que necesitarás el día del evento.'
    };
    return {
      title:'CONSIGUE FONDOS',
      text:'La Fase 05 está abierta: mejora tus marcas en Operaciones Clandestinas mientras llega el gran día.'
    };
  }

  function isPartyDate() {
    return eventClock.snapshot().phase === 'live';
  }

  function updatePhaseNavigation(snapshot = eventClock.snapshot()) {
    const live = snapshot.phase === 'live';
    const after = snapshot.phase === 'after';
    const before = snapshot.phase === 'before';
    const calendarDays = Math.max(0, Number(snapshot.calendarDaysRemaining || 0));
    const button = $('#enterPartyFromInvite');
    const preview = $('#heistPreview');
    const kicker = $('#heistPreviewKicker');
    const stateNode = $('#heistPreviewState');
    const text = $('#heistPreviewText');
    const detailHeadline = $('#heistDetailHeadline');
    const detailText = $('#heistDetailText');
    const detailAccess = $('#heistDetailAccessValue');
    const detailNextTitle = $('#heistDetailNextTitle');
    const detailNextText = $('#heistDetailNextText');
    const profile = getLocalProfile();
    const prefs = profile?.uiPrefs || {};

    let stateLabel = 'EN PREPARACIÓN';
    if (after) stateLabel = 'FINALIZADO';
    else if (live) stateLabel = 'EN CURSO';
    else if (snapshot.isEventDay) stateLabel = 'HOY';
    else if (calendarDays === 1) stateLabel = 'MAÑANA';
    else if (calendarDays <= 7) stateLabel = 'ESTA SEMANA';

    if (kicker) kicker.textContent = 'EL GOLPE';
    if (stateNode) stateNode.textContent = stateLabel;
    if (text) {
      if (live) text.textContent = 'La operación está activa.';
      else if (after) text.textContent = 'Operación completada.';
      else if (profile?.attendance !== 'yes') text.textContent = 'El objetivo final de Operación 30.';
      else if (!profile.locationUnlocked) text.textContent = 'Sigue preparando la operación.';
      else if (!prefs.partyPrepReviewed) text.textContent = 'Revisa lo que necesitarás ese día.';
      else text.textContent = 'Última fase: consigue fondos antes del gran día.';
    }

    const context = heistPreparationContext(profile, snapshot);
    if (detailHeadline) {
      if (live) detailHeadline.textContent = 'El Golpe está en marcha.';
      else if (after) detailHeadline.textContent = 'Operación completada.';
      else if (snapshot.isEventDay) detailHeadline.textContent = 'Hoy se ejecuta el plan.';
      else if (calendarDays === 1) detailHeadline.textContent = 'Mañana empieza El Golpe.';
      else if (calendarDays <= 7) detailHeadline.textContent = 'La cuenta atrás entra en su última semana.';
      else detailHeadline.textContent = 'Todo conduce al 12 de diciembre.';
    }
    if (detailText) {
      if (live) detailText.textContent = 'La preparación ha terminado. El acceso al evento ya está abierto.';
      else if (after) detailText.textContent = 'El periodo de preparación ha finalizado y El Golpe queda cerrado.';
      else if (snapshot.isEventDay) detailText.textContent = 'A las 13:00 se cierra la preparación y se abre el acceso a El Golpe.';
      else detailText.textContent = 'Las cinco fases de Operación 30 te preparan para llegar listo al día del evento.';
    }
    if (detailAccess) detailAccess.textContent = live ? 'DISPONIBLE' : after ? 'FINALIZADO' : snapshot.isEventDay ? 'A LAS 13:00' : 'EN PREPARACIÓN';
    if (detailNextTitle) detailNextTitle.textContent = context.title;
    if (detailNextText) detailNextText.textContent = context.text;

    if (button) {
      button.hidden = !live;
      button.textContent = 'ENTRAR AL GOLPE →';
      button.disabled = !live;
      button.classList.toggle('is-live', live);
    }
    preview?.classList.toggle('is-live', live);
    preview?.classList.toggle('is-after', after);
    preview?.classList.toggle('is-event-day', before && snapshot.isEventDay);
    preview?.classList.toggle('is-imminent', before && !snapshot.isEventDay && calendarDays <= 7);
  }

  function setMode(mode, { persistDev = true } = {}) {
    activeMode = mode === 'party' ? 'party' : 'invite';
    const main = $('main');
    const party = $('#partyMode');
    const hud = $('#hud');
    if (main) main.hidden = activeMode === 'party';
    if (party) party.hidden = activeMode !== 'party';
    document.body.classList.toggle('party-mode-active', activeMode === 'party');
    document.body.dataset.experienceMode = activeMode;
    window.DANI_ARCADE?.syncAccess?.();
    updatePhaseNavigation();
    syncCharacterOperationVisibility();
    renderPartyOperationSummary(getLocalProfile());
    renderHudEconomy();

    $$('#devModeSwitch [data-mode]').forEach((button) => button.classList.toggle('is-active', button.dataset.mode === activeMode));
    storage.set(sessionStorage, ACTIVE_MODE_KEY, activeMode);
    if (cfg.developmentMode && persistDev) {
      storage.set(sessionStorage, 'dani30-dev-mode', activeMode);
    }

    setCharacterEditorOpen(false);
    const crewHub = $('#crewHub');
    const crewHost = activeMode === 'party' ? $('#partyCrewHost') : $('#inviteCrewHost');
    if (crewHub && crewHost) crewHost.appendChild(crewHub);
    closeCrewDirectory();
    crewBrowserView = activeMode === 'party' ? 'wanted' : 'band';
    renderCrewDirectory(crewCache);
    if (activeMode === 'party') {
      if (hud) hud.hidden = false;
      window.DANI_APP?.setExperienceMode?.('party', activeParty()?.profile || null);
      enterPartyMode();
      window.scrollTo({ top:0, behavior:'auto' });
    } else {
      window.DANI_APP?.setExperienceMode?.('invite', getLocalProfile());
      window.DANI_APP?.renderState?.();
      startCrewRefreshTimer();
    }
  }

  async function enterPartyMode() {
    const players = await refreshCrew();
    renderPartyPlayerGrid(players);
    const candidate = primary;
    if (!cfg.developmentMode && !hasHeistAccess(candidate?.profile)) {
      setMode('invite', { persistDev:false });
      window.DANI_APP?.openPreparation?.({ scroll:true });
      return;
    }
    if (candidate?.profile?.attendance === 'yes') {
      try {
        const data = await api('me', { token:candidate.token });
        const updated = { token:candidate.token, profile:data.player };
        setPrimary(updated);
        if (!cfg.developmentMode && !hasHeistAccess(data.player)) {
          setMode('invite', { persistDev:false });
          window.DANI_APP?.openPreparation?.({ scroll:true });
          return;
        }
        showPartyDashboard(updated);
      } catch {
        setMode('invite', { persistDev:false });
        window.DANI_APP?.openPreparation?.({ scroll:true });
        return;
      }
    } else if (cfg.developmentMode) showPartyLogin();
    else {
      setMode('invite', { persistDev:false });
      window.DANI_APP?.openPreparation?.({ scroll:true });
      return;
    }

    startCrewRefreshTimer();
  }

  function identityCopy(reason = identityReason) {
    if (reason === 'recover') return {
      kicker:'RECUPERA TU PERSONAJE',
      title:'¿Quién eres?',
      intro:'Identifica tu personaje y continúa donde lo dejaste.'
    };
    if (reason === 'switch') return activeMode === 'party' ? {
      kicker:'CAMBIO DE IDENTIDAD',
      title:'Elige otro personaje',
      intro:'Solo aparecen personajes que ya tienen acceso a El Golpe.'
    } : {
      kicker:'CAMBIO DE IDENTIDAD',
      title:'Elige otro personaje',
      intro:'Selecciona uno existente o empieza un personaje nuevo.'
    };
    return {
      kicker:'ACCESO AL GOLPE',
      title:'Identifica a tu personaje',
      intro:'Selecciona tu identidad para entrar en la operación.'
    };
  }

  function updateIdentityCopy() {
    const copy = identityCopy();
    if ($('#identitySelectorKicker')) $('#identitySelectorKicker').textContent = copy.kicker;
    if ($('#identitySelectorTitle')) $('#identitySelectorTitle').textContent = copy.title;
    if ($('#identitySelectorIntro')) $('#identitySelectorIntro').textContent = copy.intro;
    const createWrap = $('#identityCreateNewWrap');
    if (createWrap) createWrap.hidden = !(activeMode === 'invite' && identityReason === 'switch');
  }

  function updatePartyPinSlots() {
    const pin = ($('#partyPin')?.value || '').replace(/\D/g, '').slice(0, 4);
    const slots = $$('#partyPinCode .identity-pin-slots span');
    slots.forEach((slot, index) => {
      slot.classList.toggle('is-filled', index < pin.length);
      slot.textContent = index < pin.length ? '●' : '';
    });
  }

  function syncIdentityStage() {
    const stage = $('#identityStage');
    if (!stage) return;
    const verify = stage.classList.contains('is-verify');
    stage.dataset.state = verify ? 'verify' : 'roster';
  }

  function setIdentityStage(state, { focusPin = false } = {}) {
    const stage = $('#identityStage');
    const roster = $('#partyIdentityRoster');
    const verify = $('#partyPinEntry');
    if (!stage || !roster || !verify) return;
    const isVerify = state === 'verify';
    resetIdentityBackSwipe();
    stage.classList.toggle('is-verify', isVerify);
    stage.classList.toggle('is-roster', !isVerify);
    roster.setAttribute('aria-hidden', String(isVerify));
    verify.setAttribute('aria-hidden', String(!isVerify));
    syncIdentityStage();
    $('#accountLoginSlot')?.scrollTo?.({ top:0, behavior:'smooth' });
    if (focusPin) window.setTimeout(() => $('#partyPin')?.focus?.({ preventScroll:true }), reducedMotion ? 0 : 230);
  }

  function updateIdentityViewport() {
    const dialog = $('#accountDialog');
    const sheet = $('#identitySheet');
    if (!dialog || !sheet || !dialog.open) return;
    const viewport = window.visualViewport;
    const visibleHeight = viewport?.height || window.innerHeight;
    const keyboardOpen = Boolean(viewport && visibleHeight < window.innerHeight * .78);
    const bottomOffset = viewport ? Math.max(0, window.innerHeight - visibleHeight - viewport.offsetTop) : 0;
    const normalSheetHeight = Math.min(820, visibleHeight * 0.92);
    const targetSheetHeight = keyboardOpen ? (visibleHeight - 8) : normalSheetHeight;
    dialog.classList.toggle('is-keyboard-open', keyboardOpen);
    dialog.style.setProperty('--identity-vv-offset', `${Math.floor(bottomOffset)}px`);
    sheet.style.setProperty('--identity-sheet-max', `${Math.max(260, Math.floor(targetSheetHeight))}px`);
    if (keyboardOpen && document.activeElement === $('#partyPin')) {
      requestAnimationFrame(() => $('#partyPinCode')?.scrollIntoView?.({ block:'center', behavior:'smooth' }));
    }
  }

  function resetIdentitySheetPosition() {
    identityBottomSheet?.reset();
  }

  function closeIdentityDialog({ restoreFocus = true } = {}) {
    const dialog = $('#accountDialog');
    if (!dialog?.open) return;
    resetIdentitySheetPosition();
    dialog.classList.remove('is-keyboard-open');
    dialog.close();
    unlockAppSurfacePageScroll();
    $('#partyLogin').hidden = true;
    const returnTarget = recoveryReturnFocus?.isConnected ? recoveryReturnFocus : $('#startMission');
    recoveryOpen = false;
    recoveryReturnFocus = null;
    pendingHeistGrant = null;
    if (restoreFocus) returnTarget?.focus?.({ preventScroll:true });
  }

  function bindIdentitySheetSwipe() {
    const sheet = $('#identitySheet');
    const scrollRoot = $('#accountLoginSlot');
    if (!sheet || !scrollRoot || identityBottomSheet) return;
    identityBottomSheet = createMobileBottomSheetController({
      sheet,
      isMobile:isAppSurfaceMobile,
      getScrollRoot:(target) => appSurfaceScrollRoot(target, scrollRoot),
      isBlocked:appSurfaceSwipeBlocked,
      onClose:closeIdentityDialog
    });
  }


  function resetIdentityBackSwipe() {
    identityBackSlideController?.reset();
  }

  function bindIdentityBackSwipe() {
    const verify = $('#partyPinEntry');
    const stage = $('#identityStage');
    if (!verify || !stage || identityBackSlideController) return;
    identityBackSlideController = createMobileSlideBackController({
      gestureRoot:verify,
      panel:verify,
      isEnabled:() => isAppSurfaceMobile() && stage.classList.contains('is-verify'),
      onBack:showIdentityRoster
    });
  }

  function openIdentityDialog() {
    const dialog = $('#accountDialog');
    const sheet = $('#identitySheet');
    const slot = $('#accountLoginSlot');
    const login = $('#partyLogin');
    if (!dialog || !sheet || !slot || !login) return;
    slot.appendChild(login);
    login.hidden = false;
    resetIdentitySheetPosition();
    if (!dialog.open) {
      dialog.showModal();
      lockAppSurfacePageScroll();
    }
    sheet.focus?.({ preventScroll:true });
    updateIdentityViewport();
  }

  function makeIdentityRow(player) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'identity-row app-surface__drag-pass';
    const lastPlayerId = storage.get(localStorage, LAST_PLAYER_ID_KEY);
    if (lastPlayerId && player.id === lastPlayerId) button.classList.add('is-last-used');

    const avatar = document.createElement('span');
    avatar.className = 'identity-row__avatar';
    applyAvatarVisual(avatar, player, { alt:`Foto de ${player.name || 'jugador'}` });

    const info = document.createElement('span');
    info.className = 'identity-row__info';
    const name = document.createElement('strong');
    name.textContent = player.name || 'PLAYER';
    const crew = document.createElement('small');
    crew.textContent = `MIEMBRO #${String(player.crewNumber || 0).padStart(3, '0')}`;
    info.append(name, crew);

    const meta = document.createElement('span');
    meta.className = 'identity-row__meta';
    if (lastPlayerId && player.id === lastPlayerId) {
      const recent = document.createElement('small');
      recent.textContent = 'ÚLTIMO USADO';
      meta.appendChild(recent);
    }
    const arrow = document.createElement('span');
    arrow.className = 'identity-row__arrow';
    arrow.setAttribute('aria-hidden', 'true');
    arrow.textContent = '→';
    meta.appendChild(arrow);

    button.append(avatar, info, meta);
    button.addEventListener('click', () => selectPartyPlayer(player));
    return button;
  }

  function showIdentityRoster() {
    selectedPartyPlayer = null;
    $('#partyLoginMessage').textContent = '';
    $('#partyPin').value = '';
    updatePartyPinSlots();
    setIdentityStage('roster');
    renderPartyPlayerGrid();
    requestAnimationFrame(() => $('#identitySheet')?.focus?.({ preventScroll:true }));
  }

  function showIdentityVerification(player, { detected = false } = {}) {
    selectedPartyPlayer = normalizeProfile(player);
    $('#partyLoginMessage').textContent = '';
    $('#partyPinCode')?.classList.remove('is-error', 'is-verifying');
    $('#partyPin').value = '';
    updatePartyPinSlots();

    applyAvatarVisual($('#partyIdentityAvatar'), selectedPartyPlayer, { alt:`Foto de ${selectedPartyPlayer.name}` });
    $('#partyIdentityName').textContent = selectedPartyPlayer.name;
    $('#partyIdentityCrew').textContent = `MIEMBRO #${String(selectedPartyPlayer.crewNumber || 0).padStart(3, '0')}`;
    $('#partyIdentityVerifyKicker').textContent = detected ? 'IDENTIDAD DETECTADA' : 'VERIFICACIÓN DE IDENTIDAD';
    $('#partyPinLabel').textContent = `PIN DE ${selectedPartyPlayer.name.toUpperCase()}`;
    $('#partyIdentityBack').textContent = detected ? 'NO SOY YO' : '← ATRÁS';

    setIdentityStage('verify', { focusPin:!detected });
  }

  function prepareIdentitySelector({ forceRoster = identityForceRoster } = {}) {
    updateIdentityCopy();
    const available = identityPlayers(crewCache);
    const lastPlayerId = storage.get(localStorage, LAST_PLAYER_ID_KEY);
    const remembered = !forceRoster && lastPlayerId && lastPlayerId !== identityDismissedRememberedId
      ? available.find((player) => player.id === lastPlayerId)
      : null;
    if (remembered) showIdentityVerification(remembered, { detected:true });
    else showIdentityRoster();
  }

  function showPartyLogin({ forceRoster = false, reason = 'entry' } = {}) {
    identityReason = reason;
    identityForceRoster = forceRoster;
    selectedPartyPlayer = null;
    // Al cambiar de personaje mantenemos el dashboard detrás del modal. Si el
    // usuario cancela, sigue siendo el personaje anterior; no existe un estado
    // de El Golpe sin identidad cargada.
    if (!(reason === 'switch' && primary?.profile)) $('#partyDashboard').hidden = true;
    $('#partyLoginMessage').textContent = '';
    updateIdentityCopy();
    openIdentityDialog();
    prepareIdentitySelector({ forceRoster });
    if (activeMode === 'party') window.DANI_APP?.setExperienceMode?.('party', primary?.profile || null);
  }

  function renderPartyPlayerGrid(players = crewCache) {
    const root = $('#partyPlayerGrid');
    if (!root) return;
    const source = identityPlayers(players).sort((a,b) => (a.name || '').localeCompare(b.name || '', 'es', { sensitivity:'base' }));
    root.replaceChildren();
    source.forEach((player) => root.appendChild(makeIdentityRow(player)));
    if (!source.length) {
      const empty = document.createElement('p');
      empty.className = 'crew-empty';
      empty.textContent = crewError
        ? 'No se ha podido cargar la lista de personajes en este momento.'
        : identityRequiresHeistAccess()
          ? 'No hay otros personajes con acceso a El Golpe.'
          : identityReason === 'switch'
            ? 'No hay otros personajes todavía.'
            : 'Aún no hay personajes confirmados.';
      root.appendChild(empty);
    }
  }

  function selectPartyPlayer(player) {
    showIdentityVerification(player);
  }

  async function loginParty() {
    if (!selectedPartyPlayer || partyLoginBusy) return;
    const input = $('#partyPin');
    const pin = (input?.value || '').trim();
    if (!/^\d{4}$/.test(pin)) {
      $('#partyLoginMessage').textContent = 'Introduce las cuatro cifras de tu PIN.';
      input?.focus();
      return;
    }
    partyLoginBusy = true;
    $('#partyPinCode')?.classList.add('is-verifying');
    $('#partyPinCode')?.classList.remove('is-error');
    $('#partyLoginMessage').textContent = 'VERIFICANDO IDENTIDAD…';
    try {
      const data = await api('login', {
        method:'POST',
        body:{ playerId:selectedPartyPlayer.id, pin, requireHeistAccess:identityRequiresHeistAccess() || Boolean(pendingHeistGrant) }
      });
      const session = { token:data.sessionToken, profile:data.player };
      setPrimary(session);
      identityDismissedRememberedId = null;
      $('#connectionStatus').hidden = true;
      $('#partyLoginMessage').textContent = 'IDENTIDAD CONFIRMADA ✓';

      if (pendingHeistGrant) {
        const grant = pendingHeistGrant;
        pendingHeistGrant = null;
        window.DANI_APP?.syncProfile?.(normalizeProfile(session.profile));
        closeIdentityDialog({ restoreFocus:false });
        grant();
      } else {
        showPartyDashboard(session);
      }
    } catch (error) {
      $('#partyLoginMessage').textContent = error.message || 'PIN INCORRECTO · INTÉNTALO DE NUEVO';
      $('#partyPinCode')?.classList.add('is-error');
      if (input) {
        input.value = '';
        updatePartyPinSlots();
        input.focus({ preventScroll:true });
      }
    } finally {
      partyLoginBusy = false;
      $('#partyPinCode')?.classList.remove('is-verifying');
    }
  }

  function showPartyDashboard(session) {
    const profile = normalizeProfile(session.profile);
    const wasRecovery = recoveryOpen;
    window.DANI_APP?.syncProfile?.(profile);
    if ($('#accountDialog')?.open) closeIdentityDialog({ restoreFocus:false });
    if (wasRecovery && activeMode !== 'party') {
      window.DANI_APP?.openPreparation?.({ scroll:false });
      window.setTimeout(() => window.DANI_APP?.announceHud?.('PERSONAJE RECUPERADO', {
        detail:`BIENVENIDO DE NUEVO, ${String(profile.name || 'PLAYER').toUpperCase()}`,
        tone:'success', level:'social', priority:2, dedupeKey:`recovered-${profile.id || 'player'}`
      }), reducedMotion ? 0 : 180);
      return;
    }
    $('#partyLogin').hidden = true;
    $('#partyDashboard').hidden = false;
    window.DANI_APP?.setExperienceMode?.('party', profile);
    renderPartyOperationSummary(profile);
    refreshCrew();
  }

  function logoutCharacter() {
    setCharacterEditorOpen(false);
    window.DANI_APP?.setHudMenuOpen?.(false);
    selectedPartyPlayer = null;

    // Cambiar de personaje es una sustitución de identidad, no un logout previo.
    // La sesión actual se conserva hasta que el nuevo PIN se valida, de modo que
    // cerrar el selector nunca deja El Golpe en un estado sin personaje.
    if (activeMode === 'party') {
      showPartyLogin({ forceRoster:true, reason:'switch' });
      renderPartyPlayerGrid();
    } else {
      openRecovery(null, { forceRoster:true, reason:'switch' });
    }
  }

  function exitHeist() {
    if (activeMode !== 'party') return;
    setCharacterEditorOpen(false);
    window.DANI_APP?.setHudMenuOpen?.(false);
    closeIdentityDialog({ restoreFocus:false });
    setMode('invite', { persistDev:false });
    window.DANI_APP?.openPreparation?.({ scroll:true, target:'safehouseLocation' });
  }

  function startNewCharacterFromIdentity() {
    if (activeMode === 'party' || identityReason !== 'switch') return;
    const previousId = primary?.profile?.id || null;
    closeIdentityDialog({ restoreFocus:false });
    setPrimary(null);
    if (previousId) identityDismissedRememberedId = previousId;
    storage.remove(localStorage, LAST_PLAYER_ID_KEY);
    storage.remove(sessionStorage, 'dani30-pending-briefing-v1');
    window.DANI_APP?.resetPlayerProgress?.();
    window.DANI_APP?.syncProfile?.(null);
    window.DANI_APP?.setExperienceMode?.('invite', null);
    window.DANI_APP?.openPreparation?.({ scroll:false });
    window.setTimeout(() => window.DANI_APP?.scrollToId?.('operationStage1'), 60);
  }

  async function requestHeistAccess(onGranted) {
    if (typeof onGranted !== 'function') return false;
    recoveryReturnFocus = document.activeElement;
    recoveryOpen = false;
    pendingHeistGrant = onGranted;

    // Una sesión todavía válida entra sin volver a pedir PIN, pero El Golpe
    // exige las tres fases completadas también en el estado persistido de D1.
    const candidate = primary;
    if (candidate?.token && candidate?.profile?.attendance === 'yes') {
      try {
        const data = await api('me', { token:candidate.token });
        const updated = { token:candidate.token, profile:data.player };
        setPrimary(updated);
        window.DANI_APP?.syncProfile?.(normalizeProfile(data.player));
        if (hasHeistAccess(data.player) || cfg.developmentMode) {
          const grant = pendingHeistGrant;
          pendingHeistGrant = null;
          grant?.();
          return true;
        }
        pendingHeistGrant = null;
        window.DANI_APP?.renderState?.();
        return false;
      } catch {
        // Conservamos LAST_PLAYER_ID para poder ofrecer IDENTIDAD DETECTADA,
        // pero eliminamos el token inválido antes de pedir el PIN de nuevo.
        setPrimary(null);
      }
    }

    identityReason = 'entry';
    identityForceRoster = false;
    selectedPartyPlayer = null;
    $('#loginCrewStatus').textContent = 'ACTUALIZANDO IDENTIDADES…';
    $('#partyPlayerGrid').replaceChildren();
    updateIdentityCopy();
    openIdentityDialog();
    await refreshCrew();
    prepareIdentitySelector({ forceRoster:false });
    return false;
  }

  function activeParty() {
    return primary;
  }

  let crewBrowserView = 'band';
  let lastPlayerRankingRole = null;

  function competitiveMissionCodes() {
    // Nombre interno legado: de cara al jugador El Fantasma exige completar
    // todos los objetivos activos del golpe, no una subcategoría invisible.
    return operationObjectiveCodes();
  }

  function competitionProgress(player) {
    const codes = competitiveMissionCodes();
    const completed = new Set((player?.completedMissions || []).map((code) => String(code).toUpperCase()));
    const done = codes.filter((code) => completed.has(code)).length;
    return { done, total:codes.length, eligible:codes.length > 0 && done >= codes.length };
  }

  function currentStars(player) {
    return Math.max(0, Number(player?.gameStars ?? player?.wantedScore ?? 0));
  }

  function wantedRanking(players = crewCache) {
    return [...(players || [])]
      .filter((player) => player?.attendance !== 'no')
      .sort((a,b) => (currentStars(b)-currentStars(a)) || (Number(b.respect||0)-Number(a.respect||0)) || String(a.name||'').localeCompare(String(b.name||''), 'es'));
  }

  function priorityTargets(players = crewCache) {
    const ranking = wantedRanking(players);
    if (!ranking.length) return [];
    const max = currentStars(ranking[0]);
    if (max <= 0) return [];
    return ranking.filter((player) => currentStars(player) === max);
  }

  function cleanCandidates(players = crewCache) {
    return [...(players || [])]
      .filter((player) => competitionProgress(player).eligible)
      .sort((a,b) => (currentStars(a)-currentStars(b))
        || (Number(b.walletBalance ?? b.cash ?? 0)-Number(a.walletBalance ?? a.cash ?? 0))
        || (Number(b.respect||0)-Number(a.respect||0))
        || Number(a.crewNumber||0)-Number(b.crewNumber||0));
  }

  function cleanLeaders(players = crewCache) {
    const candidates = cleanCandidates(players);
    if (!candidates.length) return [];
    const first = candidates[0];
    const stars = currentStars(first);
    const wallet = Number(first.walletBalance ?? first.cash ?? 0);
    const respect = Number(first.respect || 0);
    return candidates.filter((player) => currentStars(player) === stars
      && Number(player.walletBalance ?? player.cash ?? 0) === wallet
      && Number(player.respect || 0) === respect);
  }

  function syncPriorityHud(players = crewCache) {
    const hudWanted = $('#hudWanted');
    if (!hudWanted) return;
    const mine = primary?.profile?.id;
    const targets = priorityTargets(players);
    const professionals = cleanLeaders(players);
    const isPriority = activeMode === 'party' && Boolean(mine) && targets.some((player) => player.id === mine);
    const isProfessional = activeMode === 'party' && Boolean(mine) && professionals.some((player) => player.id === mine);
    const nextRole = isProfessional ? 'ghost' : (isPriority ? 'wanted' : 'normal');
    hudWanted.classList.toggle('is-objective-priority', isPriority && !isProfessional);
    hudWanted.classList.toggle('is-professional', isProfessional);
    document.body.classList.toggle('player-is-objective-priority', isPriority && !isProfessional);
    document.body.classList.toggle('player-is-professional', isProfessional);
    if (activeMode === 'party') {
      if (lastPlayerRankingRole !== null && lastPlayerRankingRole !== nextRole) {
        if (nextRole === 'wanted') window.DANI_APP?.announceHud?.('🚨 ERES EL MÁS BUSCADO', { detail:'TU EXPEDIENTE ES EL PEOR DE LA BANDA', tone:'danger', duration:3200, priority:3 });
        else if (nextRole === 'ghost') window.DANI_APP?.announceHud?.('👻 ERES EL FANTASMA', { detail:'TIENES EL EXPEDIENTE MÁS LIMPIO', tone:'success', duration:3200, priority:3 });
        else if (lastPlayerRankingRole === 'wanted') window.DANI_APP?.announceHud?.('YA NO ERES EL MÁS BUSCADO', { detail:'ALGUIEN HA LLAMADO MÁS LA ATENCIÓN', tone:'default', duration:2400, priority:2 });
      }
      lastPlayerRankingRole = nextRole;
    } else {
      lastPlayerRankingRole = null;
    }
    // Refresca solo el HUD. renderState() vuelve a notificar a DANI_CREW y
    // provocaría un ciclo renderCrewDirectory -> renderState -> onInviteState.
    window.DANI_APP?.refreshHud?.();
  }

  function renderCrewViewContext(players = crewCache, prepared = 0) {
    const context = $('#crewViewContext');
    const copy = $('#crewContextCopy');
    const title = $('#crewContextTitle');
    const meta = $('#crewContextMeta');
    const help = $('#crewClassificationHelp');
    if (!context || activeMode !== 'party') return;
    const ranking = crewBrowserView === 'wanted';
    context.classList.toggle('is-ranking', ranking);
    context.classList.toggle('is-band', !ranking);
    if (copy) copy.hidden = ranking;
    if (help) {
      help.hidden = !ranking;
      if (!ranking) help.open = false;
    }
    if (title) title.textContent = `${players.length} ${players.length === 1 ? 'MIEMBRO' : 'MIEMBROS'} · ${prepared} ${prepared === 1 ? 'PREPARADO' : 'PREPARADOS'}`;
    if (meta) meta.textContent = 'La banda que está dentro de la operación.';
  }

  function setCrewViewIndicator(progress = null, { dragging = false } = {}) {
    const switcher = $('#crewViewSwitch');
    const track = $('#crewViewTrack');
    const fallback = crewBrowserView === 'band' ? 1 : 0;
    const value = Math.max(0, Math.min(1, progress == null ? fallback : Number(progress)));
    if (switcher) {
      switcher.style.setProperty('--crew-view-progress', String(value));
      switcher.classList.toggle('is-dragging', Boolean(dragging));
    }
    if (track) {
      track.style.setProperty('--crew-view-progress', String(value));
      track.classList.toggle('is-dragging', Boolean(dragging));
    }
  }

  function setCrewBrowserView(view = 'band', { focus = false } = {}) {
    const next = activeMode === 'party' && view === 'wanted' ? 'wanted' : 'band';
    crewBrowserView = next;
    closeCrewProfile({ animate:false });
    const bandButton = $('#crewViewBand');
    const wantedButton = $('#crewViewWanted');
    bandButton?.classList.toggle('is-active', next === 'band');
    wantedButton?.classList.toggle('is-active', next === 'wanted');
    bandButton?.setAttribute('aria-pressed', String(next === 'band'));
    wantedButton?.setAttribute('aria-pressed', String(next === 'wanted'));
    setCrewViewIndicator(next === 'band' ? 1 : 0);
    renderCrewDirectory(crewCache);
    if (focus) (next === 'wanted' ? wantedButton : bandButton)?.focus?.({ preventScroll:true });
  }

  function bindCrewViewSwipe() {
    const surface = $('#crewBrowserMain');
    if (!surface || surface.dataset.viewSwipeBound === '1') return;
    surface.dataset.viewSwipeBound = '1';
    let swipe = null;
    let suppressClickUntil = 0;

    surface.addEventListener('click', (event) => {
      if (Date.now() >= suppressClickUntil) return;
      event.preventDefault();
      event.stopPropagation();
    }, true);

    surface.addEventListener('touchstart', (event) => {
      if (!isCrewMobile() || activeMode !== 'party' || !crewPanelOpen || selectedCrewProfileId || event.touches.length !== 1) return;
      const touch = event.touches[0];
      // Reserva el borde izquierdo para el gesto de historial de Safari.
      if (touch.clientX < 22) return;
      const baseProgress = crewBrowserView === 'band' ? 1 : 0;
      swipe = { startX:touch.clientX, startY:touch.clientY, dx:0, active:false, baseProgress };
    }, { passive:true });

    surface.addEventListener('touchmove', (event) => {
      if (!swipe || event.touches.length !== 1) return;
      const touch = event.touches[0];
      const dx = touch.clientX - swipe.startX;
      const dy = touch.clientY - swipe.startY;
      if (!swipe.active) {
        if (Math.abs(dx) < 9 || Math.abs(dx) <= Math.abs(dy) * 1.18) return;
        swipe.active = true;
      }
      event.preventDefault();
      swipe.dx = dx;
      const width = Math.max(1, surface.clientWidth);
      // Wanted vive a progress 0 y Banda a progress 1. El contenido y la
      // cápsula recorren exactamente el mismo porcentaje que el dedo.
      const progress = Math.max(0, Math.min(1, swipe.baseProgress - (dx / width)));
      setCrewViewIndicator(progress, { dragging:true });
    }, { passive:false });

    const finish = () => {
      if (!swipe) return;
      const { active, dx } = swipe;
      swipe = null;
      const width = Math.max(1, surface.clientWidth);
      const threshold = Math.min(82, Math.max(54, width * .18));
      const goBand = active && dx <= -threshold && crewBrowserView === 'wanted';
      const goRanking = active && dx >= threshold && crewBrowserView === 'band';

      if (!goBand && !goRanking) {
        setCrewViewIndicator(crewBrowserView === 'band' ? 1 : 0, { dragging:false });
        return;
      }
      suppressClickUntil = Date.now() + 360;
      setCrewBrowserView(goBand ? 'band' : 'wanted');
    };
    surface.addEventListener('touchend', finish, { passive:true });
    surface.addEventListener('touchcancel', () => {
      if (!swipe) return;
      swipe = null;
      setCrewViewIndicator(crewBrowserView === 'band' ? 1 : 0, { dragging:false });
    }, { passive:true });
  }

  function wantedStarsLabel(value) {
    const stars = Math.max(0, Number(value || 0));
    return `${stars} ★`;
  }

  function competitionProgressLabel(player) {
    const progress = competitionProgress(player);
    if (!progress.total) return 'OBJETIVOS · —';
    return `OBJETIVOS ${progress.done}/${progress.total}`;
  }

  function makeWantedCard(player, position, { priority = false, clean = false } = {}) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = `crew-member-card crew-member-card--wanted app-surface__drag-pass${priority ? ' is-priority' : ''}${clean ? ' is-clean' : ''}`;
    card.dataset.playerId = player.id;
    card.setAttribute('aria-label', `Abrir expediente de ${player.name}, ${wantedStarsLabel(player.gameStars)}, ${competitionProgressLabel(player)}`);

    const head = document.createElement('span');
    head.className = 'crew-member-card__head';
    const avatar = document.createElement('span');
    avatar.className = 'crew-member-card__avatar';
    applyAvatarVisual(avatar, player, { alt:`Foto de ${player.name || 'jugador'}` });
    const identity = document.createElement('span');
    identity.className = 'crew-member-card__identity';
    const nameLine = document.createElement('span');
    nameLine.className = 'crew-member-card__name';
    const name = document.createElement('b');
    name.textContent = player.name || 'PLAYER';
    nameLine.appendChild(name);
    if (primary?.profile?.id === player.id) {
      const you = document.createElement('em');
      you.textContent = 'TÚ';
      nameLine.appendChild(you);
    }
    const progressLine = document.createElement('span');
    progressLine.className = 'crew-member-card__progress';
    const rank = document.createElement('i');
    rank.textContent = `#${String(position).padStart(2,'0')}`;
    const progressText = document.createElement('small');
    progressText.textContent = competitionProgressLabel(player);
    progressLine.append(rank, progressText);
    identity.append(nameLine, progressLine);
    head.append(avatar, identity);

    const bio = document.createElement('span');
    bio.className = 'crew-member-card__bio crew-member-card__wanted-copy';
    if (priority && clean) bio.textContent = 'EXPEDIENTE EN LOS DOS EXTREMOS';
    else if (priority) bio.textContent = 'PEOR EXPEDIENTE ACTUAL';
    else if (clean) bio.textContent = 'MEJOR EXPEDIENTE ACTUAL';
    else bio.textContent = 'EXPEDIENTE EN EL RADAR';

    const badges = document.createElement('span');
    badges.className = 'crew-member-card__specialties crew-member-card__wanted-badges';
    const starChip = document.createElement('span');
    starChip.className = 'is-stars';
    starChip.textContent = `★ ${currentStars(player)}`;
    badges.append(starChip);

    const foot = document.createElement('span');
    foot.className = 'crew-member-card__foot';
    const context = document.createElement('span');
    context.className = 'crew-wanted-context';
    context.innerHTML = `<small>${priority ? 'PEOR EXPEDIENTE' : (clean ? 'MEJOR EXPEDIENTE' : 'NIVEL DE BÚSQUEDA')}</small><strong>★ ${currentStars(player)}</strong>`;
    const arrow = document.createElement('span');
    arrow.className = 'crew-member-card__arrow';
    arrow.setAttribute('aria-hidden','true');
    arrow.textContent = '→';
    foot.append(context, arrow);

    card.append(head, bio, badges, foot);
    card.addEventListener('click', () => openCrewProfile(player.id));
    return card;
  }

  function makeCompetitionSpotlight({ tone = 'priority', title, player, players = [], detail, empty = false }) {
    const element = document.createElement(player && !empty ? 'button' : 'div');
    if (element instanceof HTMLButtonElement) element.type = 'button';
    element.className = `crew-competition-spotlight crew-competition-spotlight--${tone}${empty ? ' is-empty' : ''}`;
    const icon = document.createElement('span');
    icon.className = 'crew-competition-spotlight__icon';
    icon.setAttribute('aria-hidden','true');
    icon.textContent = tone === 'clean' ? '👻' : '🚨';
    const copy = document.createElement('span');
    copy.className = 'crew-competition-spotlight__copy';
    const kicker = document.createElement('small');
    kicker.textContent = title;
    const name = document.createElement('strong');
    name.textContent = player?.name || 'AÚN SIN CANDIDATO';
    const meta = document.createElement('span');
    const tied = players.length > 1 ? ` · ${players.length} EMPATADOS` : '';
    meta.textContent = `${detail || ''}${tied}`.trim();
    copy.append(kicker, name, meta);
    element.append(icon, copy);
    if (player && !empty) {
      const arrow = document.createElement('span');
      arrow.className = 'crew-competition-spotlight__arrow';
      arrow.setAttribute('aria-hidden','true');
      arrow.textContent = '→';
      element.appendChild(arrow);
      element.addEventListener('click', () => openCrewProfile(player.id));
    }
    return element;
  }

  function renderWantedRanking(players = crewCache) {
    const root = $('#crewWantedView');
    if (!root) return;
    root.replaceChildren();

    const ranking = wantedRanking(players);
    const priority = priorityTargets(players);
    const clean = cleanLeaders(players);
    const objectiveTotal = competitiveMissionCodes().length;

    const spotlights = document.createElement('div');
    spotlights.className = 'crew-competition-spotlights';
    if (priority.length) {
      const leader = priority[0];
      spotlights.appendChild(makeCompetitionSpotlight({
        tone:'priority', title:'EL MÁS BUSCADO',
        player:leader, players:priority, detail:`PEOR EXPEDIENTE · ★ ${currentStars(leader)}`
      }));
    } else {
      spotlights.appendChild(makeCompetitionSpotlight({ tone:'priority', title:'EL MÁS BUSCADO', detail:'Todavía nadie ha llamado la atención de la policía.', empty:true }));
    }

    if (clean.length) {
      const leader = clean[0];
      const progress = competitionProgress(leader);
      spotlights.appendChild(makeCompetitionSpotlight({
        tone:'clean', title:'EL FANTASMA',
        player:leader, players:clean, detail:`MEJOR EXPEDIENTE · ★ ${currentStars(leader)} · ${progress.done}/${progress.total} OBJETIVOS`
      }));
    } else {
      spotlights.appendChild(makeCompetitionSpotlight({
        tone:'clean', title:'EL FANTASMA',
        detail:objectiveTotal ? `Completa los ${objectiveTotal} objetivos para poder convertirte en El Fantasma.` : 'Todavía no hay objetivos activos.',
        empty:true
      }));
    }
    root.appendChild(spotlights);

    if (!ranking.length) {
      const empty = document.createElement('div');
      empty.className = 'crew-wanted-empty';
      empty.innerHTML = '<span aria-hidden="true">☆</span><div><strong>LA CLASIFICACIÓN ESTÁ VACÍA</strong><p>Cuando la banda empiece a jugar, los expedientes aparecerán aquí.</p></div>';
      root.appendChild(empty);
      return;
    }

    const featuredIds = new Set([priority[0]?.id, clean[0]?.id].filter(Boolean));
    const remaining = ranking.filter((player) => !featuredIds.has(player.id));
    if (!remaining.length) return;

    const section = document.createElement('section');
    section.className = 'crew-ranking-rest';
    const heading = document.createElement('div');
    heading.className = 'crew-ranking-rest__heading';
    heading.innerHTML = '<strong>RESTO DE LA CLASIFICACIÓN</strong>';
    const list = document.createElement('div');
    list.className = 'crew-wanted-grid';
    remaining.forEach((player) => {
      const position = ranking.findIndex((entry) => entry.id === player.id) + 1;
      list.appendChild(makeWantedCard(player, position));
    });
    section.append(heading, list);
    root.appendChild(section);
  }

  function forgotPin() {
    const name = selectedPartyPlayer?.name || 'este jugador';
    $('#partyLoginMessage').textContent = 'Pide a Dani que te restablezca el PIN.';
  }

  async function adminLogin() {
    if (adminLoginBusy) return;
    const input = $('#adminPin');
    const pin = (input?.value || '').trim();
    if (!pin) return;
    adminLoginBusy = true;
    const button = $('#adminLogin');
    if (button) button.disabled = true;
    $('#adminMessage').textContent = 'VERIFICANDO ACCESO…';
    try {
      const data = await api('admin/crew', { adminPin:pin });
      adminPinMemory = pin;
      $('#adminAuth').hidden = true;
      $('#adminPanel').hidden = false;
      $('#adminMessage').textContent = '';
      setAdminPanelMessage('');
      configureAdminTools();
      renderAdminCrew(data.players || []);
      await Promise.all([refreshAdminArcade(), refreshAdminDashboard()]);
      syncAdminArcadeDebugUi();
    } catch (error) {
      $('#adminMessage').textContent = error.message || 'ACCESO DENEGADO';
      if (input) { input.select?.(); input.focus?.(); }
    } finally {
      adminLoginBusy = false;
      if (button) button.disabled = false;
    }
  }

  function setAdminPanelMessage(message = '') {
    const node = $('#adminPanelMessage');
    if (node) node.textContent = message;
  }

  function setAdminTab(tab='overview') {
    $$('#adminTabs [data-admin-tab]').forEach((button)=>{const active=button.dataset.adminTab===tab;button.classList.toggle('is-active',active);button.setAttribute('aria-selected',String(active));});
    $$('[data-admin-panel]').forEach((panel)=>{const active=panel.dataset.adminPanel===tab;panel.classList.toggle('is-active',active);panel.hidden=!active;});
    const card=$('#adminDialog')?.querySelector('.admin-dialog__card'); if(card)card.scrollTop=0;
  }

  function adminRelativeTime(value) {
    const parsed=Date.parse(String(value||'').replace(' ','T')+(String(value||'').includes('Z')?'':'Z')); if(!Number.isFinite(parsed))return '';
    const diff=Math.max(0,Date.now()-parsed),mins=Math.floor(diff/60000); if(mins<1)return 'ahora'; if(mins<60)return `hace ${mins} min`; const hours=Math.floor(mins/60); if(hours<24)return `hace ${hours} h`; const days=Math.floor(hours/24);return `hace ${days} d`;
  }

  function renderAdminActivity(items=[]) {
    const root=$('#adminActivityFeed'),count=$('#adminActivityCount'); if(!root)return; if(count)count.textContent=String(items.length);
    root.replaceChildren();
    if(!items.length){const empty=document.createElement('div');empty.className='admin-feed-empty';empty.textContent='Todavía no hay actividad registrada.';root.appendChild(empty);return;}
    items.forEach((item)=>{const row=document.createElement('article');row.className=`admin-feed-row is-${item.severity||'info'}`;const dot=document.createElement('span');dot.className='admin-feed-row__dot';const copy=document.createElement('div');const title=document.createElement('b');title.textContent=item.title||'Actividad';const detail=document.createElement('small');detail.textContent=item.detail||item.actorName||'';copy.append(title,detail);const time=document.createElement('time');time.textContent=adminRelativeTime(item.createdAt);row.append(dot,copy,time);root.appendChild(row);});
  }

  function renderAdminAttention(players=[]) {
    const root=$('#adminAttentionList'),count=$('#adminAttentionCount'); if(!root)return;
    const items=[];
    players.forEach((raw)=>{
      if(raw.attendance==='no'&&String(raw.declineMessage||'').trim())items.push({tone:'message',icon:'✉',title:`${raw.name} no puede venir`,detail:String(raw.declineMessage).trim()});
      if(raw.attendance==='yes'&&String(raw.dietary||'').trim())items.push({tone:'dietary',icon:'!',title:raw.name,detail:String(raw.dietary).trim()});
    });
    if(count)count.textContent=String(items.length);root.replaceChildren();
    if(!items.length){const empty=document.createElement('div');empty.className='admin-attention-empty';empty.innerHTML='<b>TODO EN ORDEN</b><small>No hay mensajes ni avisos pendientes.</small>';root.appendChild(empty);return;}
    items.slice(0,8).forEach((item)=>{const row=document.createElement('button');row.type='button';row.className=`admin-attention-row is-${item.tone}`;row.innerHTML=`<span>${item.icon}</span><span><b></b><small></small></span><span>›</span>`;row.querySelector('b').textContent=item.title;row.querySelector('small').textContent=item.detail;row.addEventListener('click',()=>setAdminTab('guests'));root.appendChild(row);});
  }

  function updateAdminNotificationModeUI() {
    const mode=$('#adminNotificationMode')?.value||'hybrid',options=$('#adminImmediateEventOptions'),help=$('#adminNotificationModeHelp');
    const copy={
      hybrid:'Recomendado: solo se envían al momento los tipos de aviso que marques debajo. Puedes pedir un resumen completo cuando quieras.',
      immediate:'Todo al momento: cada actividad registrada — altas, bajas, juegos y acciones de administración — genera un email. Puede producir bastantes avisos.',
      daily:'Solo resumen: no se envían avisos inmediatos. Por ahora el resumen se lanza con “ENVIAR RESUMEN AHORA”; el envío diario automático todavía no está programado.',
      off:'Desactivado: no se envía ningún aviso automático. El botón de prueba sigue disponible para comprobar la conexión.'
    };
    if(help)help.textContent=copy[mode]||copy.hybrid;
    if(options){options.classList.toggle('is-disabled',mode!=='hybrid');options.querySelectorAll('input').forEach((input)=>{input.disabled=mode!=='hybrid';});}
  }

  function renderAdminNotificationSettings(settings={},provider={}) {
    const mode=$('#adminNotificationMode'); if(mode)mode.value=settings.mode||'hybrid';
    if($('#adminNotifyDeclines'))$('#adminNotifyDeclines').checked=settings.immediateDecline!==false;
    if($('#adminNotifyRsvp'))$('#adminNotifyRsvp').checked=Boolean(settings.immediateRsvp);
    if($('#adminNotifyGames'))$('#adminNotifyGames').checked=Boolean(settings.immediateGames);
    const state=$('#adminEmailProviderState'); if(state){state.textContent=provider.configured?'LISTO':'INCOMPLETO';state.classList.toggle('is-good',Boolean(provider.configured));}
    const recipient=$('#adminNotificationRecipient');if(recipient)recipient.textContent=provider.recipientConfigured?(provider.recipientHint||'CONFIGURADO'):'ADMIN_TO_EMAIL sin configurar';
    const sender=$('#adminNotificationSender');if(sender)sender.textContent=provider.sender||'Operación 30 <onboarding@resend.dev>';
    const hint=$('#adminNotificationHint');
    if(hint){
      if(!provider.apiKeyConfigured)hint.textContent='Falta RESEND_API_KEY en Cloudflare. Guárdala como secreto y vuelve a desplegar la web.';
      else if(!provider.recipientConfigured)hint.textContent='Falta ADMIN_TO_EMAIL en Cloudflare. Pon aquí el mismo correo con el que creaste tu cuenta de Resend mientras uses el dominio de pruebas.';
      else if(provider.senderMode==='resend-test')hint.textContent='Conexión preparada en modo de pruebas de Resend. No necesitas ADMIN_FROM_EMAIL: se usa onboarding@resend.dev automáticamente.';
      else hint.textContent='Conexión preparada con tu remitente personalizado de Resend.';
    }
    updateAdminNotificationModeUI();
  }

  function renderAdminDashboard(payload={}) {
    const data=payload.dashboard||{};
    if($('#adminConfirmedCount'))$('#adminConfirmedCount').textContent=String(data.confirmed??0);if($('#adminDeclinedCount'))$('#adminDeclinedCount').textContent=String(data.declined??0);if($('#adminProfileCount'))$('#adminProfileCount').textContent=String(data.total??0);
    if($('#adminMessageCount'))$('#adminMessageCount').textContent=String(data.messages??0);if($('#adminDietaryCount'))$('#adminDietaryCount').textContent=String(data.dietary??0);if($('#adminActivity24Count'))$('#adminActivity24Count').textContent=String(data.activity24h??0);
    const sync=$('#adminLastSync');if(sync)sync.textContent=`Actualizado ${new Date().toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})}`;
    renderAdminActivity(payload.activity||[]);renderAdminNotificationSettings(data.notifications||{},payload.emailProvider||{});
  }

  async function refreshAdminDashboard() {
    if(!adminPinMemory)return null;
    try{const data=await api('admin/dashboard',{adminPin:adminPinMemory});renderAdminDashboard(data);return data;}catch(error){setAdminPanelMessage(error.message||'No se ha podido actualizar el centro de mando.');return null;}
  }

  async function saveAdminNotifications() {
    if(!adminPinMemory)return;const button=$('#adminSaveNotifications');if(button)button.disabled=true;
    try{const data=await api('admin/notifications',{method:'PATCH',adminPin:adminPinMemory,body:{enabled:$('#adminNotificationMode')?.value!=='off',mode:$('#adminNotificationMode')?.value||'hybrid',immediateDecline:Boolean($('#adminNotifyDeclines')?.checked),immediateRsvp:Boolean($('#adminNotifyRsvp')?.checked),immediateGames:Boolean($('#adminNotifyGames')?.checked),dailyDigest:true}});renderAdminNotificationSettings(data.settings||{},data.provider||{});setAdminPanelMessage('Modo de avisos guardado.');}catch(error){setAdminPanelMessage(error.message||'No se han podido guardar las alertas.');}finally{if(button)button.disabled=false;}
  }

  async function sendAdminNotification(kind='test') {
    if(!adminPinMemory)return;const button=kind==='digest'?$('#adminSendDigest'):$('#adminTestNotifications');if(button)button.disabled=true;
    setAdminPanelMessage(kind==='digest'?'GENERANDO RESUMEN…':'ENVIANDO EMAIL DE PRUEBA…');
    try{const data=await api(kind==='digest'?'admin/notifications/digest':'admin/notifications/test',{method:'POST',adminPin:adminPinMemory,body:{}});setAdminPanelMessage(kind==='digest'?`Resumen enviado a ${data.to||'tu correo'} · ${data.count||0} movimientos incluidos`:`Email de prueba enviado a ${data.to||'tu correo'}.`);await refreshAdminDashboard();}catch(error){setAdminPanelMessage(error.message||'No se pudo enviar el email.');}finally{if(button)button.disabled=false;}
  }

  async function exportAdminData() {
    if(!adminPinMemory)return;setAdminPanelMessage('GENERANDO BACKUP…');
    try{const data=await api('admin/export',{adminPin:adminPinMemory});const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`operacion-30-backup-${new Date().toISOString().slice(0,10)}.json`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);setAdminPanelMessage('Backup JSON descargado.');}catch(error){setAdminPanelMessage(error.message||'No se pudo exportar el backup.');}
  }

  function renderAdminDietaryOverview(players = []) {
    const root = $('#adminDietaryOverview');
    const count = $('#adminDietaryCount');
    if (!root) return;
    const entries = players
      .filter((player) => player.attendance === 'yes' && String(player.dietary || '').trim())
      .map((player) => ({ name:player.name || 'Sin nombre', dietary:String(player.dietary || '').trim() }));
    if (count) count.textContent = String(entries.length);
    root.replaceChildren();
    if (!entries.length) {
      const empty = document.createElement('div');
      empty.className = 'admin-dietary-empty';
      empty.textContent = 'No hay alergias, intolerancias o dietas indicadas.';
      root.appendChild(empty);
      return;
    }
    entries.forEach((entry) => {
      const row = document.createElement('div');
      row.className = 'admin-dietary-row';
      const name = document.createElement('b');
      name.textContent = entry.name;
      const dietary = document.createElement('span');
      dietary.textContent = entry.dietary;
      row.append(name, dietary);
      root.appendChild(row);
    });
  }

  const ADMIN_TIME_PREVIEW_KEY = 'dani30-event-preview-mode-v1';
  const ADMIN_TIME_PREVIEW_LABELS = Object.freeze({ real:'REAL', week:'7 DÍAS ANTES', day:'24 H ANTES', eventday:'DÍA DEL EVENTO', live:'EN CURSO' });

  function currentAdminTimePreviewMode() {
    const mode = storage.get(sessionStorage, ADMIN_TIME_PREVIEW_KEY) || 'real';
    return ADMIN_TIME_PREVIEW_LABELS[mode] ? mode : 'real';
  }

  function renderAdminTimePreview() {
    const mode = currentAdminTimePreviewMode();
    const label = $('#adminTimePreviewLabel');
    if (label) label.textContent = ADMIN_TIME_PREVIEW_LABELS[mode];
    $$('#adminTimePreviewOptions [data-admin-time-preview]').forEach((button) => {
      button.classList.toggle('is-active', button.dataset.adminTimePreview === mode);
      button.setAttribute('aria-pressed', String(button.dataset.adminTimePreview === mode));
    });
  }

  function setAdminTimePreview(mode) {
    const next = ADMIN_TIME_PREVIEW_LABELS[mode] ? mode : 'real';
    if (next === 'real') storage.remove(sessionStorage, ADMIN_TIME_PREVIEW_KEY);
    else storage.set(sessionStorage, ADMIN_TIME_PREVIEW_KEY, next);
    renderAdminTimePreview();
    setMode('invite', { persistDev:false });
    updatePhaseNavigation(eventClock.snapshot());
    closeAdmin();
    window.DANI_APP?.showInviteLanding?.();
  }

  function renderAdminEventStatus(players = []) {
    const root = $('#adminEventStatus');
    if (!root) return;
    const snapshot = eventClock.snapshot();
    const confirmed = players.filter((p) => p.attendance === 'yes');
    const locationReady = confirmed.filter((p) => Boolean(p.locationUnlocked)).length;
    const maxWanted = confirmed.filter((p) => Number(p.cashCollectedCount || 0) >= 5).length;
    const messages = players.filter((p) => String(p.declineMessage || '').trim()).length;
    const phaseLabel = snapshot.phase === 'live' ? 'EN CURSO' : (snapshot.phase === 'after' ? 'CERRADO' : 'PREPARADO');
    const phaseTone = snapshot.phase === 'live' ? 'is-good' : (snapshot.phase === 'after' ? '' : 'is-warn');

    const rows = [
      { title:'El Golpe', detail:snapshot.phase === 'live' ? 'La experiencia está disponible para los invitados.' : (snapshot.phase === 'after' ? 'El evento ya ha finalizado.' : 'La experiencia permanece bloqueada hasta el evento.'), value:phaseLabel, tone:phaseTone },
      { title:'Refugio desbloqueado', detail:'Confirmados que ya completaron el acceso a la ubicación.', value:`${locationReady}/${confirmed.length}`, tone:locationReady === confirmed.length && confirmed.length ? 'is-good' : '' },
      { title:'★★★★★ completadas', detail:'Personajes que ya encontraron los 5 billetes ocultos.', value:String(maxWanted), tone:maxWanted ? 'is-good' : '' },
      { title:'Mensajes recibidos', detail:'Respuestas dejadas al indicar que no pueden asistir.', value:String(messages), tone:messages ? 'is-warn' : '' }
    ];

    root.replaceChildren();
    rows.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'admin-state-row';
      const copy = document.createElement('div');
      copy.className = 'admin-state-row__copy';
      const title = document.createElement('b');
      title.textContent = item.title;
      const detail = document.createElement('small');
      detail.textContent = item.detail;
      copy.append(title, detail);
      const pill = document.createElement('span');
      pill.className = `admin-state-pill${item.tone ? ` ${item.tone}` : ''}`;
      pill.textContent = item.value;
      row.append(copy, pill);
      root.appendChild(row);
    });
  }

  function renderAdminArcade(data = null) {
    const phase = $('#adminArcadePhase');
    const timeline=eventClock.snapshot();
    const previewClosed=Boolean(timeline.previewMode)&&(timeline.previewMode==='eventday'||timeline.phase!=='before');
    const displayClosed=Boolean(data?.phase==='closed'||previewClosed);
    if (phase) phase.textContent=data?(displayClosed?(data.phase==='closed'?'CERRADO':'SIMULADO · FINAL'):'ABIERTO'):'—';

    const renderMiniOperation=(op,prefix,formatter)=>{
      const phaseNode=$(`#admin${prefix}Phase`),playersNode=$(`#admin${prefix}Players`),gamesNode=$(`#admin${prefix}Games`),bestNode=$(`#admin${prefix}Best`),podiumNode=$(`#admin${prefix}Podium`);
      if(!podiumNode)return;
      if(!op||op.available===false){
        if(phaseNode)phaseNode.textContent='NO DISP.';if(playersNode)playersNode.textContent='0';if(gamesNode)gamesNode.textContent='0';if(bestNode)bestNode.textContent='—';
        podiumNode.innerHTML='<small class="admin-operation-empty">Sin datos disponibles</small>';return;
      }
      if(phaseNode)phaseNode.textContent=displayClosed?'FINAL':(op.phase==='closed'?'CERRADO':'ABIERTO');
      if(playersNode)playersNode.textContent=String(op.players||0);if(gamesNode)gamesNode.textContent=String(op.games||0);if(bestNode)bestNode.textContent=formatter(op.best);
      const board=Array.isArray(op.leaderboard)?op.leaderboard:[];podiumNode.replaceChildren();
      for(let rank=1;rank<=3;rank+=1){const entry=board.find(item=>Number(item.rank)===rank),line=document.createElement('div');line.className='admin-operation-mini-row';const medal=document.createElement('span');medal.textContent=rank===1?'🥇':rank===2?'🥈':'🥉';const name=document.createElement('b');name.textContent=entry?.name||'—';const score=document.createElement('small');score.textContent=entry?formatter(Number(entry.score||0)):'Sin marca';line.append(medal,name,score);podiumNode.appendChild(line);}
    };

    if(!data){
      renderMiniOperation(null,'Infiltration',()=> '—');renderMiniOperation(null,'Blind',()=> '—');renderMiniOperation(null,'Safe',()=> '—');renderMiniOperation(null,'Fuga',()=> '—');return;
    }
    const operations=data.operations||{},championship=operations.championship||data.championship||null;
    const champPhase=$('#adminChampionshipPhase'),champEligible=$('#adminChampionshipEligible'),champPodium=$('#adminChampionshipPodium');
    if(champPhase)champPhase.textContent=championship?(championship.phase==='closed'?'FINAL':'ABIERTO'):'—';if(champEligible)champEligible.textContent=String(championship?.eligiblePlayers||0);
    if(champPodium){champPodium.replaceChildren();const board=Array.isArray(championship?.leaderboard)?championship.leaderboard:[];for(let rank=1;rank<=3;rank+=1){const entry=board.find(x=>Number(x.rank)===rank),line=document.createElement('div');line.className='admin-operation-mini-row';const medal=document.createElement('span');medal.textContent=rank===1?'🥇':rank===2?'🥈':'🥉';const name=document.createElement('b');name.textContent=entry?.name||'—';const score=document.createElement('small');score.textContent=entry?.prize?`$${Number(entry.prize.cash||0).toLocaleString('es-ES')} · +${entry.prize.respect} respeto`:'Pendiente';line.append(medal,name,score);champPodium.appendChild(line);}}
    renderMiniOperation(operations.infiltration,'Infiltration',value=>Number.isFinite(value)&&value>=0?`${value} teclas`:'—');
    renderMiniOperation(operations.blind,'Blind',value=>value==null?'—':`${(Number(value)/1000).toFixed(3)} s`);
    renderMiniOperation(operations.safe||operations.caja,'Safe',value=>value?`${(Number(value)/100).toFixed(1)}%`:'—');
    renderMiniOperation({available:true,phase:data.phase,players:data.players,games:data.games,best:data.best,leaderboard:data.leaderboard},'Fuga',value=>value?`${value.toLocaleString('es-ES')} pasos`:'—');
  }

  async function refreshAdminArcade() {
    if (!adminPinMemory) return null;
    try {
      const data=await api('admin/arcade',{adminPin:adminPinMemory});
      renderAdminArcade(data);return data;
    } catch (error) { renderAdminArcade(null); return null; }
  }

  function renderAdminCrew(players) {
    lastAdminPlayers = Array.isArray(players) ? players.slice() : [];
    const list = $('#adminCrewList');
    if (!list) return;
    const confirmed = players.filter((p) => p.attendance === 'yes').length;
    const declined = players.filter((p) => p.attendance === 'no').length;
    if ($('#adminConfirmedCount')) $('#adminConfirmedCount').textContent = String(confirmed);
    if ($('#adminDeclinedCount')) $('#adminDeclinedCount').textContent = String(declined);
    if ($('#adminProfileCount')) $('#adminProfileCount').textContent = String(players.length);
    renderAdminEventStatus(players);
    renderAdminDietaryOverview(players);
    renderAdminTimePreview();
    renderAdminAttention(players);
    const query=adminGuestSearch.trim().toLocaleLowerCase('es');
    const visible=players.filter((raw)=>{
      if(adminGuestFilter==='yes'&&raw.attendance!=='yes')return false;if(adminGuestFilter==='no'&&raw.attendance!=='no')return false;if(adminGuestFilter==='messages'&&!String(raw.declineMessage||'').trim())return false;if(adminGuestFilter==='dietary'&&!String(raw.dietary||'').trim())return false;
      if(query&&!`${raw.name||''} ${raw.dietary||''} ${raw.declineMessage||''}`.toLocaleLowerCase('es').includes(query))return false;return true;
    });
    if ($('#adminGuestCount')) $('#adminGuestCount').textContent = visible.length===players.length?String(players.length):`${visible.length}/${players.length}`;

    list.replaceChildren();
    if (!visible.length) {
      const empty = document.createElement('div');
      empty.className = 'admin-state-row';
      empty.textContent = 'Todavía no hay respuestas.';
      list.appendChild(empty);
      return;
    }

    visible.forEach((raw) => {
      const player = normalizeProfile(raw);
      const row = document.createElement('article');
      row.className = 'admin-player-row';

      const top = document.createElement('div');
      top.className = 'admin-player-row__top';
      const identity = document.createElement('div');
      identity.className = 'admin-player-row__identity';
      const title = document.createElement('b');
      title.textContent = `${player.avatar} ${player.name} · #${String(player.crewNumber).padStart(3,'0')}`;
      const detail = document.createElement('small');
      const details = [];
      if (raw.attendance === 'yes') {
        if (raw.dietary) details.push(raw.dietary);
        if (raw.locationUnlocked) details.push('refugio desbloqueado');
        if (Number(raw.cashCollectedCount || 0) >= 5) details.push('★★★★★');
      } else if (raw.updatedAt) {
        const date = new Date(raw.updatedAt.replace(' ', 'T') + (raw.updatedAt.includes('Z') ? '' : 'Z'));
        if (!Number.isNaN(date.getTime())) details.push(date.toLocaleDateString('es-ES'));
      }
      detail.textContent = details.length ? details.join(' · ') : (raw.attendance === 'yes' ? 'Sin observaciones' : 'Respuesta registrada');
      identity.append(title, detail);

      const status = document.createElement('span');
      status.className = `admin-player-status${raw.attendance === 'yes' ? '' : ' is-no'}`;
      status.textContent = raw.attendance === 'yes' ? 'CONFIRMADO' : 'NO VIENE';
      top.append(identity, status);
      row.appendChild(top);

      if (raw.declineMessage) {
        const message = document.createElement('p');
        message.className = 'admin-decline-message';
        message.textContent = raw.declineMessage;
        row.appendChild(message);
      }

      const action = document.createElement('button');
      action.type = 'button';
      action.className = 'btn btn--soft admin-reset-pin';
      action.textContent = 'RESTABLECER PIN';
      const result = document.createElement('span');
      result.className = 'admin-temp-pin';
      action.addEventListener('click', async () => {
        action.disabled = true;
        result.textContent = 'GENERANDO…';
        try {
          const data = await api('admin/reset-pin', { method:'POST', body:{ playerId:player.id }, adminPin:adminPinMemory });
          result.textContent = `NUEVO PIN · ${data.temporaryPin}`;
        } catch (error) {
          result.textContent = error.message || 'ERROR';
        } finally { action.disabled = false; }
      });

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'btn btn--danger admin-delete-player';
      remove.textContent = 'ELIMINAR';
      remove.addEventListener('click', async () => {
        const accepted = window.confirm(`¿Eliminar definitivamente a ${player.name}? Esta acción no se puede deshacer.`);
        if (!accepted) return;
        remove.disabled = true;
        try {
          await api('admin/delete-player', { method:'POST', body:{ playerId:player.id }, adminPin:adminPinMemory });
          if (primary?.profile?.id === player.id) {
            setPrimary(null);
            window.DANI_APP?.syncProfile?.(null);
            if (activeMode === 'party') showPartyLogin();
            else window.DANI_APP?.setExperienceMode?.('invite', null);
          }
          const refreshed = await api('admin/crew', { adminPin:adminPinMemory });
          renderAdminCrew(refreshed.players || []);
          await refreshAdminArcade();
          setAdminPanelMessage(`${player.name} eliminado.`);
          refreshCrew();
        } catch (error) {
          result.textContent = error.message || 'NO SE HA PODIDO ELIMINAR';
          remove.disabled = false;
        }
      });

      const actions = document.createElement('div');
      actions.className = 'admin-player-row__actions';
      actions.append(action, remove, result);
      row.appendChild(actions);
      list.appendChild(row);
    });
  }

  function clearLocalIdentityAfterDatabaseChange() {
    setPrimary(null);
    storage.remove(localStorage, AUTH_TOKEN_KEY, LAST_PLAYER_ID_KEY, 'dani30-crew-primary-v1', 'dani30-local-crew-v1', 'dani30-local-wanted-v1');
    window.DANI_APP?.resetPlayerProgress?.();
    window.DANI_APP?.syncProfile?.(null);
    if (activeMode === 'party') setMode('invite', { persistDev:false });
    refreshCrew();
  }

  function resetAdminDangerArm(button) {
    if (!button) return;
    button.classList.remove('is-armed');
    const hint = button.querySelector('small');
    if (hint?.dataset.defaultText) hint.textContent = hint.dataset.defaultText;
    delete button.dataset.armed;
    if (adminDangerArmTimer) window.clearTimeout(adminDangerArmTimer);
    adminDangerArmTimer = 0;
  }

  function armAdminDangerAction(button, confirmationText, action) {
    if (!button || !adminPinMemory) return;
    const hint = button.querySelector('small');
    if (hint && !hint.dataset.defaultText) hint.dataset.defaultText = hint.textContent;
    if (button.dataset.armed !== '1') {
      $$('.admin-danger-action').forEach((other) => { if (other !== button) resetAdminDangerArm(other); });
      button.dataset.armed = '1';
      button.classList.add('is-armed');
      if (hint) hint.textContent = confirmationText;
      if (adminDangerArmTimer) window.clearTimeout(adminDangerArmTimer);
      adminDangerArmTimer = window.setTimeout(() => resetAdminDangerArm(button), 6000);
      return;
    }
    resetAdminDangerArm(button);
    action();
  }

  async function mutateAdminDatabase(mode) {
    if (!adminPinMemory) return;
    const buttons=['#adminClearDatabase','#adminSeedDatabase','#adminClearGames','#adminResetProgress','#adminClearActivity','#adminPrepareProduction'].map((selector)=>$(selector)).filter(Boolean);
    buttons.forEach((button)=>{button.disabled=true;});
    setAdminPanelMessage(mode==='seed'?'CREANDO DATOS DE PRUEBA…':mode==='games'?'LIMPIANDO CLASIFICACIONES…':mode==='progress'?'REINICIANDO PROGRESO…':mode==='activity'?'LIMPIANDO ACTIVIDAD…':mode==='production'?'PREPARANDO PRODUCCIÓN…':'VACIANDO INVITADOS…');
    try {
      const data = await api('admin/database/reset', { method:'POST', body:{ mode }, adminPin:adminPinMemory });
      if(['seed','empty','production'].includes(mode)) clearLocalIdentityAfterDatabaseChange();
      else if(mode==='progress') window.DANI_APP?.resetPlayerProgress?.();
      renderAdminCrew(data.players || []);
      configureAdminTools();
      await refreshAdminArcade();
      setAdminPanelMessage(mode==='seed'?`Datos de prueba cargados · ${data.count||0} perfiles · PIN 1234`:mode==='games'?'Clasificaciones y partidas eliminadas.':mode==='progress'?'Progreso reiniciado; invitados conservados.':mode==='activity'?'Registro de actividad limpiado.':mode==='production'?'Producción preparada: datos de invitados y juego a cero.':'Invitados y progreso eliminados.');await refreshAdminDashboard();
    } catch (error) {
      setAdminPanelMessage(error.message || 'NO SE HA PODIDO MODIFICAR LA BASE DE DATOS');
    } finally {
      buttons.forEach((button)=>{button.disabled=false;});
    }
  }

  async function refreshAdminData() {
    if (!adminPinMemory) return;
    const button = $('#adminRefreshData');
    if (button) button.disabled = true;
    setAdminPanelMessage('ACTUALIZANDO…');
    try {
      const data = await api('admin/crew', { adminPin:adminPinMemory });
      renderAdminCrew(data.players || []);
      configureAdminTools();
      await Promise.all([refreshAdminArcade(),refreshAdminDashboard()]);
      syncAdminArcadeDebugUi();
      setAdminPanelMessage(`Actualizado · ${new Date().toLocaleTimeString('es-ES', { hour:'2-digit', minute:'2-digit' })}`);
    } catch (error) {
      setAdminPanelMessage(error.message || 'NO SE HAN PODIDO ACTUALIZAR LOS DATOS');
    } finally {
      if (button) button.disabled = false;
    }
  }

  function lockAdminPanel() {
    adminPinMemory = '';
    $('#adminPanel').hidden = true;
    $('#adminAuth').hidden = false;
    $('#adminPin').value = '';
    $('#adminMessage').textContent = '';
    setAdminPanelMessage('');
    window.setTimeout(() => $('#adminPin')?.focus(), 80);
  }

  function focusAdminPin({ select = false } = {}) {
    const input = $('#adminPin');
    if (!input || $('#adminAuth')?.hidden) return;
    try { input.focus({ preventScroll:true }); } catch { input.focus(); }
    if (select) input.select?.();
  }

  function openAdmin() {
    const dialog = $('#adminDialog');
    if (!dialog) return;
    $('#adminAuth').hidden = false;
    $('#adminPanel').hidden = true;
    const pin = $('#adminPin');
    if (pin) { pin.value = ''; pin.maxLength = ADMIN_PIN_LENGTH; }
    $('#adminMessage').textContent = '';
    adminPinMemory = '';
    adminGuestFilter='all';adminGuestSearch='';setAdminTab('overview');
    if($('#adminGuestSearch'))$('#adminGuestSearch').value='';
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
    // Intento inmediato + siguiente frame para escritorio/Android. El pointerup del
    // gesto oculto vuelve a enfocar para que iOS pueda abrir el teclado dentro del gesto.
    focusAdminPin();
    window.requestAnimationFrame(() => focusAdminPin());
    window.setTimeout(() => focusAdminPin(), 60);
  }

  function closeAdmin() {
    const dialog = $('#adminDialog');
    if (!dialog) return;
    if (typeof dialog.close === 'function' && dialog.open) dialog.close();
    else dialog.removeAttribute('open');
  }

  function configureAdminTools() {
    const preview = $('#adminPreviewHeist');
    if (!preview) return;
    const live = eventClock.snapshot().phase === 'live';
    preview.hidden = !(cfg.heistTestAccess || live || cfg.developmentMode);
    renderAdminTimePreview();
  }

  function bindHiddenAdminAccess() {
    const holdMs = 1600;
    $$('[data-admin-trigger]').forEach((target) => {
      let timer = 0;
      let startX = 0;
      let startY = 0;
      let opened = false;
      const cancel = () => {
        if (timer) window.clearTimeout(timer);
        timer = 0;
      };
      target.addEventListener('pointerdown', (event) => {
        if (event.button != null && event.button !== 0) return;
        cancel();
        opened = false;
        startX = event.clientX;
        startY = event.clientY;
        timer = window.setTimeout(() => {
          timer = 0;
          opened = true;
          window.DANI_APP?.setHudMenuOpen?.(false);
          openAdmin();
        }, holdMs);
      });
      target.addEventListener('pointermove', (event) => {
        if (Math.hypot(event.clientX - startX, event.clientY - startY) > 14) cancel();
      });
      target.addEventListener('pointerup', () => {
        cancel();
        if (opened) focusAdminPin();
      });
      ['pointercancel','pointerleave'].forEach((name) => target.addEventListener(name, cancel));
      target.addEventListener('contextmenu', (event) => {
        if (timer || opened) event.preventDefault();
      });
    });
  }

  async function hydratePrimary() {
    if (!primary?.token) return;
    const token = primary.token;
    try {
      const data = await api('me', { token });
      setPrimary({ token, profile:data.player });
      $('#connectionStatus').hidden = true;
      $('#connectionStatus').textContent = '';
    } catch (error) {
      if (error.status === 401 || error.status === 404) {
        // D1 is authoritative: deleted or expired players must not survive in the browser.
        setPrimary(null);
        sessionInvalid = false;
        $('#connectionStatus').hidden = true;
        $('#connectionStatus').textContent = '';
        window.DANI_APP?.syncProfile?.(null);
      } else {
        $('#connectionStatus').hidden = false;
        $('#connectionStatus').textContent = 'No se ha podido consultar el servidor. Reintenta cuando tengas conexión.';
      }
    }
  }

  function initModeSwitch() {
    const dev = $('#devModeSwitch');
    if (cfg.developmentMode && dev) {
      dev.hidden = false;
      $$('[data-mode]', dev).forEach((button) => button.addEventListener('click', () => setMode(button.dataset.mode)));
    }
    const entryDismissed = storage.get(sessionStorage, ENTRY_DISMISSED_KEY) === '1';
    let mode = entryDismissed ? storage.get(sessionStorage, ACTIVE_MODE_KEY, 'invite') : 'invite';
    if (cfg.developmentMode && entryDismissed) {
      mode = storage.get(sessionStorage, 'dani30-dev-mode', mode);
    }
    if (mode === 'party' && !isPartyDate() && !cfg.developmentMode) mode = 'invite';
    if (mode === 'party' && !cfg.developmentMode && !hasHeistAccess(primary?.profile)) mode = 'invite';
    setMode(mode === 'party' ? 'party' : 'invite', { persistDev:false });
  }

  function bindNumericPinInput(input) {
    if (!input) return;
    input.addEventListener('input', () => {
      const numeric = input.value.replace(/\D/g, '').slice(0, 4);
      if (input.value !== numeric) input.value = numeric;
    });
  }

  function bindEvents() {
    bindNumericPinInput($('#characterPin'));
    bindNumericPinInput($('#partyPin'));
    bindHiddenAdminAccess();
    $$('input[name="attendance"]').forEach((radio) => radio.addEventListener('change', () => updatePinField()));
    $('#toggleCrewPanel')?.addEventListener('click', () => setCrewPanelOpen(true));
    $('#crewQuickAccess')?.addEventListener('click', () => setCrewPanelOpen(true));
    $('#closeCrewProfile')?.addEventListener('click', closeCrewProfile);
    $('#closeCrewDirectory')?.addEventListener('click', closeCrewDirectory);
    $('#crewDirectoryDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); closeCrewDirectory(); });
    $('#crewDirectoryDialog')?.addEventListener('click', (event) => { if (event.target === event.currentTarget) closeCrewDirectory(); });
    $('#crewProfileRespectAction')?.addEventListener('click', () => giveRespect(selectedCrewProfileId));
    $('#crewDirectoryDialog')?.addEventListener('close', unlockAppSurfacePageScroll);
    bindCrewProfileSwipe();
    bindCrewSheetSwipe();
    bindCharacterSheetSwipe();
    bindCharacterBlockSwipe();
    bindPhotoCropInteractions();
    $('#chooseCharacterPhoto')?.addEventListener('click', () => $('#characterPhotoInput')?.click());
    $('#characterPhotoPreview')?.addEventListener('click', () => {
      if (pendingCharacterHasPhoto()) {
        openPhotoViewer({ ...(getLocalProfile() || {}), photoData:pendingPhotoData });
        return;
      }
      setAvatarFallbackPickerOpen(!avatarFallbackPickerOpen);
      if (avatarFallbackPickerOpen) buildAvatarPicker();
    });
    $('#characterPhotoInput')?.addEventListener('change', async (event) => {
      const input = event.currentTarget;
      input.disabled = true;
      try {
        await openPhotoCrop(input.files?.[0]);
      } catch (error) {
        $('#characterMessage').textContent = error.message || 'No se ha podido abrir esa imagen.';
        input.value = '';
      } finally {
        input.disabled = false;
      }
    });
    $('#removeCharacterPhoto')?.addEventListener('click', () => { pendingPhotoData = ''; avatarFallbackPickerOpen = true; updateCharacterPhotoPreview(); buildAvatarPicker(); $('#characterMessage').textContent = 'Foto eliminada. Guarda los cambios para aplicarlo.'; });
    $('#resetPhotoCrop')?.addEventListener('click', resetPhotoCropState);
    $('#cancelPhotoCrop')?.addEventListener('click', closePhotoCrop);
    $('#cancelPhotoCropX')?.addEventListener('click', closePhotoCrop);
    $('#applyPhotoCrop')?.addEventListener('click', applyPhotoCrop);
    $('#photoCropDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); closePhotoCrop(); });
    $('#characterEditor')?.addEventListener('submit', (event) => event.preventDefault());
    $('#characterEditorDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); setCharacterEditorOpen(false); });
    $('#characterEditorDialog')?.addEventListener('close', () => { finalizeCharacterBlockPanelClose(); resetCharacterSheetPosition(); unlockAppSurfacePageScroll(); });
    $('#characterEditorDialog')?.addEventListener('click', (event) => { if (event.target === event.currentTarget) setCharacterEditorOpen(false); });
    $('#closeCharacterEditor')?.addEventListener('click', () => setCharacterEditorOpen(false));
    $('#closeCharacterBlockEditor')?.addEventListener('click', () => closeCharacterBlockPanel({ animate:true }));
    $$('.character-file-block').forEach((section) => {
      const openBlock = () => {
        if (section.classList.contains('is-editing')) return;
        resetCharacterBlock(section.dataset.characterBlock);
      };
      section.addEventListener('click', (event) => {
        if (event.target.closest('button,input,textarea,select,a,label')) return;
        openBlock();
      });
      section.addEventListener('keydown', (event) => {
        if ((event.key === 'Enter' || event.key === ' ') && !section.classList.contains('is-editing')) {
          event.preventDefault();
          openBlock();
        }
      });
    });
    $$('[data-cancel-character-block]').forEach((button) => button.addEventListener('click', () => { populateCharacterEditor(getLocalProfile()); setActiveCharacterBlock(null); }));
    $$('[data-save-character-block]').forEach((button) => button.addEventListener('click', guarded(() => saveCharacterBlock(button.dataset.saveCharacterBlock))));
    $('#toggleAvatarCatalog')?.addEventListener('click', () => { avatarCatalogExpanded = !avatarCatalogExpanded; buildAvatarPicker(); });
    $('#toggleSpecialtyCatalog')?.addEventListener('click', () => { specialtyCatalogExpanded = !specialtyCatalogExpanded; buildSpecialtyPicker(); });
    $('#characterFilePhotoButton')?.addEventListener('click', () => {
      const profile = getLocalProfile();
      if (!profile) return;
      if (hasUsablePhoto(profile)) { openPhotoViewer(profile); return; }
      resetCharacterBlock('identity');
      avatarFallbackPickerOpen = true;
      updateCharacterPhotoPreview();
      buildAvatarPicker();
    });
    $('#photoViewerDialog')?.addEventListener('cancel', (event) => { event.preventDefault(); closePhotoViewer(); });
    $('#photoViewerDialog')?.addEventListener('click', (event) => {
      if (event.target !== $('#photoViewerImage')) closePhotoViewer();
    });
    bindPhotoViewerSwipe();
    $('#partyLoginButton')?.addEventListener('click', guarded(loginParty));
    $('#partyPin')?.addEventListener('input', () => {
      const input = $('#partyPin');
      input.value = input.value.replace(/\D/g, '').slice(0, 4);
      $('#partyPinCode')?.classList.remove('is-error');
      $('#partyLoginMessage').textContent = '';
      updatePartyPinSlots();
      if (input.value.length === 4) loginParty();
    });
    $('#partyPin')?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); loginParty(); } });
    $('#partyIdentityBack')?.addEventListener('click', () => {
      const lastPlayerId = storage.get(localStorage, LAST_PLAYER_ID_KEY);
      if (selectedPartyPlayer?.id && selectedPartyPlayer.id === lastPlayerId && $('#partyIdentityVerifyKicker')?.textContent === 'IDENTIDAD DETECTADA') {
        identityDismissedRememberedId = selectedPartyPlayer.id;
      }
      showIdentityRoster();
    });
    $('#partyPinCode')?.addEventListener('click', () => $('#partyPin')?.focus?.({ preventScroll:true }));
    $('#partyPin')?.addEventListener('focus', () => window.setTimeout(updateIdentityViewport, 60));
    $('#partyPin')?.addEventListener('blur', () => window.setTimeout(updateIdentityViewport, 120));
    $('#forgotPin')?.addEventListener('click', forgotPin);
    $('#cleanCharacterRecord')?.addEventListener('click', (event) => { event.preventDefault(); cleanCharacterRecord(); });
    $('#characterActivityToggle')?.addEventListener('click', (event) => {
      event.preventDefault();
      characterActivityExpanded = !characterActivityExpanded;
      renderCharacterActivity();
    });
    $('#partyOperationSummary')?.addEventListener('click', () => {
      openCharacterEditor({ targetBlock:'heist' });
    });
    $('#hudEditCharacter')?.addEventListener('click', () => {
      window.DANI_APP?.setHudMenuOpen?.(false);
      openCharacterEditor();
    });
    $('#hudLogoutCharacter')?.addEventListener('click', logoutCharacter);
    $('#hudExitHeist')?.addEventListener('click', exitHeist);
    $('#identityCreateNew')?.addEventListener('click', startNewCharacterFromIdentity);
    $('#heistPreviewToggle')?.addEventListener('click', (event) => { event.stopPropagation(); toggleHeistPreview(); });
    $('#heistPreview')?.addEventListener('click', (event) => {
      if (event.target.closest('#enterPartyFromInvite,#heistPreviewToggle')) return;
      toggleHeistPreview();
    });
    $('#enterPartyFromInvite')?.addEventListener('click', (event) => { event.stopPropagation(); window.DANI_APP?.requestHeistEntry?.(); });
    $('#adminPreviewHeist')?.addEventListener('click', () => {
      if (!adminPinMemory) return;
      closeAdmin();
      window.DANI_APP?.requestHeistEntry?.({ test:true });
    });
    $('#adminPreviewWanted')?.addEventListener('click', async () => {
      if (!adminPinMemory) return;
      const dialog = $('#adminDialog');
      const card = dialog?.querySelector('.admin-dialog__card');
      const scrollTop = card?.scrollTop || 0;
      closeAdmin();
      await window.DANI_APP?.previewWantedEffect?.();
      if (!adminPinMemory || !dialog) return;
      $('#adminAuth').hidden = true;
      $('#adminPanel').hidden = false;
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
      window.requestAnimationFrame(() => { if (card) card.scrollTop = scrollTop; });
    });
    document.addEventListener('dani:event-clock', (event) => updatePhaseNavigation(event.detail));
    $('#adminLogin')?.addEventListener('click', guarded(adminLogin));
    $('#adminPin')?.addEventListener('input', (event) => {
      const input = event.currentTarget;
      const digits = String(input.value || '').replace(/\D+/g, '').slice(0, ADMIN_PIN_LENGTH);
      if (input.value !== digits) input.value = digits;
      if (digits.length === ADMIN_PIN_LENGTH && !adminLoginBusy) {
        // El último dígito valida directamente: no hace falta pulsar ENTRAR.
        window.queueMicrotask(() => $('#adminLogin')?.click());
      }
    });
    $('#adminPin')?.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      $('#adminLogin')?.click();
    });
    $$('#adminTimePreviewOptions [data-admin-time-preview]').forEach((button) => {
      button.addEventListener('click', () => setAdminTimePreview(button.dataset.adminTimePreview || 'real'));
    });
    $$('#adminTabs [data-admin-tab]').forEach((button)=>button.addEventListener('click',()=>setAdminTab(button.dataset.adminTab||'overview')));
    $$('#adminGuestFilters [data-admin-guest-filter]').forEach((button)=>button.addEventListener('click',()=>{
      adminGuestFilter=button.dataset.adminGuestFilter||'all';$$('#adminGuestFilters [data-admin-guest-filter]').forEach((item)=>item.classList.toggle('is-active',item===button));renderAdminCrew(lastAdminPlayers);
    }));
    $('#adminGuestSearch')?.addEventListener('input',(event)=>{adminGuestSearch=String(event.currentTarget.value||'');renderAdminCrew(lastAdminPlayers);});
    $('#adminNotificationMode')?.addEventListener('change',updateAdminNotificationModeUI);
    $('#adminSaveNotifications')?.addEventListener('click',guarded(saveAdminNotifications));
    $('#adminTestNotifications')?.addEventListener('click',()=>sendAdminNotification('test'));
    $('#adminSendDigest')?.addEventListener('click',()=>sendAdminNotification('digest'));
    $('#adminExportData')?.addEventListener('click',guarded(exportAdminData));
    $('#adminExportDataSecondary')?.addEventListener('click',guarded(exportAdminData));
    $('#adminRefreshDataSecondary')?.addEventListener('click',guarded(refreshAdminData));
    $('#adminSeedDatabase')?.addEventListener('click', () => armAdminDangerAction(
      $('#adminSeedDatabase'),
      'Esto sustituirá todos los datos actuales. Pulsa otra vez para confirmar.',
      () => mutateAdminDatabase('seed')
    ));
    $('#adminClearDatabase')?.addEventListener('click', () => armAdminDangerAction(
      $('#adminClearDatabase'),
      'Se eliminarán todos los datos de la app. Pulsa otra vez para confirmar.',
      () => mutateAdminDatabase('empty')
    ));
    $('#adminClearGames')?.addEventListener('click',()=>armAdminDangerAction($('#adminClearGames'),'Borrará partidas, récords y podios. Pulsa otra vez para confirmar.',()=>mutateAdminDatabase('games')));
    $('#adminResetProgress')?.addEventListener('click',()=>armAdminDangerAction($('#adminResetProgress'),'Mantendrá perfiles y PIN, pero pondrá progreso y juegos a cero. Pulsa otra vez.',()=>mutateAdminDatabase('progress')));
    $('#adminClearActivity')?.addEventListener('click',()=>armAdminDangerAction($('#adminClearActivity'),'Vaciará el historial de supervisión y emails. Pulsa otra vez.',()=>mutateAdminDatabase('activity')));
    $('#adminPrepareProduction')?.addEventListener('click',()=>armAdminDangerAction($('#adminPrepareProduction'),'ESTO DEJA LA WEB SIN INVITADOS NI MARCAS. Pulsa otra vez para preparar producción.',()=>mutateAdminDatabase('production')));
    $('#adminRefreshData')?.addEventListener('click', guarded(refreshAdminData));
    $('#adminLockPanel')?.addEventListener('click', lockAdminPanel);
    $('#devResetSession')?.addEventListener('click', () => {
      if (!cfg.developmentMode) return;
      storage.remove(sessionStorage, 'dani30-dev-mode', ACTIVE_MODE_KEY, ENTRY_DISMISSED_KEY, 'dani30-heist-transition-seen-v1', 'dani30-pending-briefing-v1', 'dani30-missions', 'dani30-hunt', 'dani30-v11-missions', 'dani30-v18-hunt');
      window.location.reload();
    });
    $('#devResetBrowser')?.addEventListener('click', () => {
      if (!cfg.developmentMode || !window.confirm('Borrar la identidad y el progreso LOCAL de este navegador? No borra D1.')) return;
      storage.remove(localStorage, AUTH_TOKEN_KEY, LAST_PLAYER_ID_KEY, 'dani30-crew-primary-v1', 'dani30-local-crew-v1', 'dani30-local-wanted-v1', 'dani30-v8-identity', 'dani30-ui', 'dani30-v11-ui');
      storage.remove(sessionStorage, 'dani30-dev-mode', ACTIVE_MODE_KEY, ENTRY_DISMISSED_KEY, 'dani30-heist-transition-seen-v1', 'dani30-pending-briefing-v1', 'dani30-missions', 'dani30-hunt', 'dani30-v11-missions', 'dani30-v18-hunt');
      window.location.reload();
    });

  }


  function guarded(action) {
    let busy = false;
    return async (event) => {
      event?.preventDefault();
      if (busy) return;
      const button = event.currentTarget.matches('form') ? event.currentTarget.querySelector('[type="submit"]') : event.currentTarget;
      busy = true; button.disabled = true; button.setAttribute('aria-busy','true');
      try { await action(event); } finally { busy = false; button.disabled = false; button.removeAttribute('aria-busy'); }
    };
  }

  function closeRecovery() {
    closeIdentityDialog();
  }

  async function openRecovery(event, { forceRoster = false, reason = 'recover' } = {}) {
    recoveryReturnFocus = event?.currentTarget || document.activeElement;
    recoveryOpen = true;
    identityReason = reason;
    identityForceRoster = forceRoster;
    selectedPartyPlayer = null;
    window.DANI_APP?.setHudMenuOpen?.(false);
    $('#loginCrewStatus').textContent = 'ACTUALIZANDO IDENTIDADES…';
    $('#partyPlayerGrid').replaceChildren();
    updateIdentityCopy();
    openIdentityDialog();
    await refreshCrew();
    prepareIdentitySelector({ forceRoster });
  }

  async function init() {
    buildAvatarPicker();
    buildSpecialtyPicker();
    bindEvents();
    $('#recoverPlayer')?.addEventListener('click', openRecovery);
    $('#hudRecoverCharacter')?.addEventListener('click', openRecovery);
    $('#closeAccount').addEventListener('click', closeRecovery);
    $('#accountDialog').addEventListener('cancel', (event) => { event.preventDefault(); closeRecovery(); });
    $('#accountDialog').addEventListener('click', (event) => { if (event.target === $('#accountDialog')) closeRecovery(); });
    $('#accountDialog').addEventListener('close', unlockAppSurfacePageScroll);
    bindIdentitySheetSwipe();
    bindIdentityBackSwipe();
    window.visualViewport?.addEventListener('resize', updateIdentityViewport);
    window.visualViewport?.addEventListener('scroll', updateIdentityViewport);
    $('#retryCrew').addEventListener('click', refreshCrew);
    $('#crewViewBand')?.addEventListener('click', () => setCrewBrowserView('band'));
    $('#crewViewWanted')?.addEventListener('click', () => setCrewBrowserView('wanted'));
    bindCrewViewSwipe();
    window.addEventListener('online', async () => { await hydratePrimary(); window.DANI_APP?.syncProfile?.(getLocalProfile()); refreshCrew(); });
    updatePinField();
    updateBackendBadge();
    await hydratePrimary();
    window.DANI_APP?.syncProfile?.(getLocalProfile());
    await setCrewPanelOpen(crewPanelOpen, { refresh:false });
    await refreshCrew();
    initModeSwitch();
    if (new URLSearchParams(window.location.search).get('admin') === '1') {
      window.setTimeout(openAdmin, 80);
    }
  }

  window.DANI_CREW = {
    saveRsvp,
    unconfirm,
    unlockLocation,
    getSecureLocation,
    getLocalProfile,
    saveProgress,
    completePartyPrep,
    discoverArcade,
    clandestineLeaderboard,
    arcadeLeaderboard,
    arcadeStart,
    arcadeFinish,
    infiltrationLeaderboard,
    infiltrationStart,
    infiltrationFinish,
    safeLeaderboard,
    safeStart,
    safeFinish,
    pointBlindLeaderboard,
    pointBlindStart,
    pointBlindFinish,
    discoverMission,
    completeMission,
    applyEconomy,
    getEconomyActivity,
    collectMoney,
    escapePolice,
    isHeistAvailable:isPartyDate,
    requestHeistAccess,
    enterHeistAuthorized:() => {
      if (cfg.developmentMode || hasHeistAccess(primary?.profile)) setMode('party', { persistDev:false });
      else { setMode('invite', { persistDev:false }); window.DANI_APP?.openPreparation?.({ scroll:true }); }
    },
    // Alias legado por compatibilidad interna; las nuevas entradas deben pasar por requestHeistAccess.
    enterHeist:() => requestHeistAccess(() => setMode('party', { persistDev:false })),
    onInviteState,
    refreshCrew,
    whenReady:() => crewReadyPromise
  };

  crewReadyPromise = init();
})();
