(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

  function hashString(value) {
    let hash = 2166136261;
    for (const char of String(value || '').toLowerCase()) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  const storage = Object.freeze({
    getJSON(area, key, fallback) {
      try {
        const raw = area?.getItem?.(key);
        return raw == null ? fallback : JSON.parse(raw);
      } catch {
        return fallback;
      }
    },
    setJSON(area, key, value) {
      try {
        area?.setItem?.(key, JSON.stringify(value));
        return true;
      } catch {
        return false;
      }
    },
    get(area, key, fallback = null) {
      try {
        return area?.getItem?.(key) ?? fallback;
      } catch {
        return fallback;
      }
    },
    set(area, key, value) {
      try {
        area?.setItem?.(key, String(value));
        return true;
      } catch {
        return false;
      }
    },
    remove(area, ...keys) {
      try {
        keys.forEach((key) => area?.removeItem?.(key));
        return true;
      } catch {
        return false;
      }
    }
  });

  function resolveElement(value) {
    return typeof value === 'string' ? $(value) : value;
  }

  function setDisclosureState({ trigger, panel, shell, open, hideTrigger = true, emit = true }) {
    const triggerEl = resolveElement(trigger);
    const panelEl = resolveElement(panel);
    const shellEl = resolveElement(shell);
    const expanded = Boolean(open);

    if (triggerEl) {
      triggerEl.hidden = hideTrigger && expanded;
      triggerEl.setAttribute('aria-expanded', String(expanded));
    }
    if (panelEl) panelEl.hidden = !expanded;
    shellEl?.classList.toggle('is-collapsed', !expanded);

    if (emit) {
      document.dispatchEvent(new CustomEvent('dani:disclosure-change', {
        detail: {
          open: expanded,
          triggerId: triggerEl?.id || null,
          panelId: panelEl?.id || null,
          shellId: shellEl?.id || null
        }
      }));
    }
    return expanded;
  }


  function createDropdown({ shell, trigger, panel, openClass = 'is-open', canOpen = () => true, label }) {
    const shellEl = resolveElement(shell);
    const triggerEl = resolveElement(trigger);
    const panelEl = resolveElement(panel);
    if (!shellEl || !triggerEl || !panelEl) return null;

    let open = false;

    const applyLabel = () => {
      if (!label) return;
      const value = typeof label === 'function' ? label(open) : label;
      if (value) triggerEl.setAttribute('aria-label', value);
    };

    const setOpen = (next) => {
      const expanded = Boolean(next) && Boolean(canOpen());
      open = expanded;
      shellEl.classList.toggle(openClass, expanded);
      triggerEl.setAttribute('aria-expanded', String(expanded));
      panelEl.hidden = !expanded;
      panelEl.setAttribute('aria-hidden', String(!expanded));
      applyLabel();
      return expanded;
    };

    const toggle = () => setOpen(!open);

    triggerEl.addEventListener('click', (event) => {
      event.stopPropagation();
      toggle();
    });
    panelEl.addEventListener('click', (event) => event.stopPropagation());
    document.addEventListener('click', () => setOpen(false));
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') setOpen(false);
    });

    setOpen(false);
    return Object.freeze({ setOpen, toggle, isOpen: () => open, refreshLabel: applyLabel });
  }

  function createDisclosureGroup({ items = [], openClass = 'is-open', canOpen = () => true, allowCollapse = true }) {
    const normalized = items.map((item) => ({
      id: String(item.id),
      shell: resolveElement(item.shell),
      trigger: resolveElement(item.trigger),
      panel: resolveElement(item.panel)
    })).filter((item) => item.shell && item.trigger && item.panel);

    if (!normalized.length) return null;
    let openId = null;

    const findItem = (id) => normalized.find((item) => item.id === String(id));

    const apply = ({ emit = true } = {}) => {
      normalized.forEach((item) => {
        const open = item.id === openId;
        item.shell.classList.toggle(openClass, open);
        item.trigger.setAttribute('aria-expanded', String(open));
        item.panel.hidden = !open;
      });

      if (emit) {
        document.dispatchEvent(new CustomEvent('dani:disclosure-change', {
          detail: {
            open: Boolean(openId),
            group: true,
            openId
          }
        }));
      }
      return openId;
    };

    const setOpen = (id, { emit = true } = {}) => {
      const requested = id == null ? null : String(id);
      if (requested) {
        const item = findItem(requested);
        if (!item || !canOpen(requested)) return false;
      }
      openId = requested;
      apply({ emit });
      return true;
    };

    const toggle = (id) => {
      const requested = String(id);
      if (openId === requested && allowCollapse) return setOpen(null);
      return setOpen(requested);
    };

    normalized.forEach((item) => {
      item.trigger.addEventListener('click', () => toggle(item.id));
    });

    apply({ emit:false });
    return Object.freeze({
      setOpen,
      toggle,
      getOpen: () => openId,
      refresh: () => apply({ emit:false })
    });
  }




  function createMobileBottomSheetController({
    sheet,
    isMobile = () => window.matchMedia?.('(max-width:720px)').matches ?? true,
    getScrollRoot = (target) => target?.closest?.('.app-surface__scroll') || null,
    isBlocked,
    onClose,
    closeThreshold = 0.14,
    minCloseDistance = 110,
    dragRatio = 0.92
  } = {}) {
    if (!sheet || typeof onClose !== 'function') return null;
    let swipe = null;
    let closeTimer = null;

    const reset = () => {
      if (closeTimer) {
        window.clearTimeout(closeTimer);
        closeTimer = null;
      }
      sheet.classList.remove('is-dragging');
      sheet.style.transition = '';
      sheet.style.transform = '';
      swipe = null;
    };

    const settle = (shouldClose) => {
      sheet.classList.remove('is-dragging');
      if (shouldClose) {
        if (reducedMotion) {
          reset();
          onClose();
          return;
        }
        sheet.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
        sheet.style.transform = 'translate3d(0,100%,0)';
        closeTimer = window.setTimeout(() => {
          closeTimer = null;
          sheet.classList.remove('is-dragging');
          // Keep the sheet translated off-screen while its owner closes/hides it.
          // Resetting transform before the container is hidden causes a visible reopen/close bounce.
          onClose({ source:'swipe' });
        }, 190);
        return;
      }
      sheet.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
      sheet.style.transform = 'translate3d(0,0,0)';
      window.setTimeout(reset, 190);
    };

    sheet.addEventListener('touchstart', (event) => {
      if (!isMobile() || event.touches.length !== 1 || isBlocked?.(event.target)) return;
      const fromDragZone = Boolean(event.target?.closest?.('.app-surface__drag-zone'));
      const scrollRoot = fromDragZone ? null : (getScrollRoot?.(event.target) || null);
      if (scrollRoot && scrollRoot.scrollTop > 1) return;
      const touch = event.touches[0];
      swipe = { startY:touch.clientY, startX:touch.clientX, dy:0, active:false, scrollRoot };
    }, { passive:true });

    sheet.addEventListener('touchmove', (event) => {
      if (!swipe || event.touches.length !== 1) return;
      const touch = event.touches[0];
      const dy = touch.clientY - swipe.startY;
      const dx = touch.clientX - swipe.startX;
      if (!swipe.active) {
        if (swipe.scrollRoot && swipe.scrollRoot.scrollTop > 1) { swipe = null; return; }
        if (dy <= 7 || Math.abs(dy) <= Math.abs(dx) * 1.15) return;
        swipe.active = true;
        sheet.classList.add('is-dragging');
      }
      event.preventDefault();
      swipe.dy = Math.max(0, dy);
      const distance = Math.min(sheet.clientHeight, swipe.dy * dragRatio);
      sheet.style.transform = `translate3d(0,${distance}px,0)`;
    }, { passive:false });

    const finish = () => {
      if (!swipe) return;
      const wasActive = swipe.active;
      const shouldClose = wasActive && swipe.dy >= Math.min(minCloseDistance, sheet.clientHeight * closeThreshold);
      swipe = null;
      if (wasActive) settle(shouldClose);
    };
    sheet.addEventListener('touchend', finish, { passive:true });
    sheet.addEventListener('touchcancel', finish, { passive:true });

    return Object.freeze({ reset, settle });
  }

  function createOperationStage({ id, marker = '', eyebrow = '', title = '', status = '', state = 'active', panelClass = '', shellClass = '' } = {}) {
    const safeId = String(id || `operation-stage-${Date.now()}`);
    const shell = document.createElement('section');
    shell.id = safeId;
    shell.className = ['operation-stage', shellClass, state ? `is-${state}` : ''].filter(Boolean).join(' ');

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.id = `${safeId}Toggle`;
    trigger.className = 'operation-stage__toggle';
    trigger.setAttribute('aria-controls', `${safeId}Panel`);
    trigger.setAttribute('aria-expanded', 'false');

    const identity = document.createElement('span');
    identity.className = 'operation-stage__identity';
    const markerEl = document.createElement('span');
    markerEl.className = 'operation-stage__marker';
    markerEl.textContent = marker;
    const copy = document.createElement('span');
    const eyebrowEl = document.createElement('small');
    eyebrowEl.textContent = eyebrow;
    const titleEl = document.createElement('strong');
    titleEl.textContent = title;
    copy.append(eyebrowEl, titleEl);
    identity.append(markerEl, copy);

    const statusEl = document.createElement('span');
    statusEl.className = 'operation-stage__status';
    const statusText = document.createElement('span');
    statusText.textContent = status;
    const chevron = document.createElement('i');
    chevron.setAttribute('aria-hidden', 'true');
    statusEl.append(statusText, chevron);
    trigger.append(identity, statusEl);

    const panel = document.createElement('div');
    panel.id = `${safeId}Panel`;
    panel.className = ['operation-stage__panel', panelClass].filter(Boolean).join(' ');
    panel.hidden = true;

    shell.append(trigger, panel);
    return Object.freeze({ shell, trigger, panel, marker: markerEl, eyebrow: eyebrowEl, title: titleEl, status: statusText });
  }

  function createOperationStageGroup(options = {}) {
    return createDisclosureGroup({ openClass:'is-open', ...options });
  }


  function createEventClock({ start, end = null, timeZone = 'Europe/Madrid' } = {}) {
    const startMs = Date.parse(start || '');
    const endMs = Date.parse(end || '');
    const hasStart = Number.isFinite(startMs);
    const hasEnd = Number.isFinite(endMs);

    function dateKey(timestamp) {
      if (!Number.isFinite(timestamp)) return '';
      try {
        const parts = new Intl.DateTimeFormat('en-CA', {
          timeZone,
          year:'numeric', month:'2-digit', day:'2-digit'
        }).formatToParts(new Date(timestamp));
        const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
        return `${values.year}-${values.month}-${values.day}`;
      } catch {
        const date = new Date(timestamp);
        return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
      }
    }

    function previewTimestamp() {
      if (!hasStart) return null;
      let mode = '';
      try { mode = sessionStorage.getItem('dani30-event-preview-mode-v1') || ''; } catch {}
      const day = 24 * 60 * 60 * 1000;
      if (mode === 'week') return { mode, now:startMs - (7 * day) };
      if (mode === 'day') return { mode, now:startMs - day };
      if (mode === 'eventday') return { mode, now:startMs - (4 * 60 * 60 * 1000) };
      if (mode === 'live') return { mode, now:startMs + (15 * 60 * 1000) };
      return null;
    }

    function calendarDayDistance(fromTimestamp, toTimestamp) {
      const fromKey = dateKey(fromTimestamp), toKey = dateKey(toTimestamp);
      if (!fromKey || !toKey) return null;
      const [fy,fm,fd] = fromKey.split('-').map(Number);
      const [ty,tm,td] = toKey.split('-').map(Number);
      const fromUtc = Date.UTC(fy, fm - 1, fd);
      const toUtc = Date.UTC(ty, tm - 1, td);
      return Math.round((toUtc - fromUtc) / 86400000);
    }

    function snapshot(now = null) {
      const preview = now == null ? previewTimestamp() : null;
      const current = Number(now == null ? (preview?.now ?? Date.now()) : now);
      if (!hasStart) return Object.freeze({ phase:'unknown', startMs:null, endMs:null, remainingMs:null, calendarDaysRemaining:null, isEventDay:false, timeZone, previewMode:preview?.mode || '' });
      const phase = current < startMs ? 'before' : (hasEnd && current > endMs ? 'after' : 'live');
      const calendarDaysRemaining = Math.max(0, Number(calendarDayDistance(current,startMs) || 0));
      return Object.freeze({
        phase,
        startMs,
        endMs:hasEnd ? endMs : null,
        remainingMs:Math.max(0, startMs - current),
        calendarDaysRemaining,
        isEventDay:dateKey(current) === dateKey(startMs),
        timeZone,
        previewMode:preview?.mode || ''
      });
    }

    function formatCountdown(remainingMs, { eventDay = false } = {}) {
      const totalSeconds = Math.max(0, Math.floor(Number(remainingMs || 0) / 1000));
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      if (eventDay || days === 0) return `${String(hours).padStart(2,'0')} H · ${String(minutes).padStart(2,'0')} MIN · ${String(seconds).padStart(2,'0')} S`;
      if (days < 7) return `${days} DÍAS · ${String(hours).padStart(2,'0')} H`;
      return `${days} DÍAS`;
    }

    return Object.freeze({ snapshot, formatCountdown, startMs:hasStart ? startMs : null, endMs:hasEnd ? endMs : null, timeZone });
  }


  window.DANI_CORE = Object.freeze({ $, $$, reducedMotion, hashString, storage, createEventClock });
  window.DANI_UI = Object.freeze({ setDisclosureState, createDropdown, createDisclosureGroup, createOperationStage, createOperationStageGroup, createMobileBottomSheetController });
})();
