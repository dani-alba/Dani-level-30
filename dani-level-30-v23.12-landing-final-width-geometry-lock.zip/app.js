(() => {
  'use strict';

  const cfg = window.BIRTHDAY_CONFIG;
  if (!cfg) {
    console.error('BIRTHDAY_CONFIG no se ha cargado.');
    return;
  }

  const core = window.DANI_CORE;
  if (!core || !window.DANI_UI) {
    console.error('DANI_CORE no se ha cargado.');
    return;
  }

  const { $, $$, reducedMotion: reduceMotion, hashString: hashName, storage, createEventClock } = core;
  const { createDropdown, createOperationStage, createOperationStageGroup } = window.DANI_UI;
  const ENTRY_DISMISSED_KEY = 'dani30-entry-dismissed-v1';
  const PENDING_BRIEFING_KEY = 'dani30-pending-briefing-v1';
  const HEIST_TRANSITION_SEEN_KEY = 'dani30-heist-transition-seen-v1';
  const LEGACY_PROGRESS_KEYS = Object.freeze({
    ui:'dani30-ui',
    oldUi:'dani30-v11-ui',
    missions:'dani30-missions',
    oldMissions:'dani30-v11-missions',
    hunt:'dani30-hunt',
    oldHunt:'dani30-v18-hunt'
  });
  const HERO_TRANSITION_MS = 2280;
  const eventClock = createEventClock({ start:cfg.eventStart || cfg.partyModeWindow?.start, end:cfg.partyModeWindow?.end, timeZone:cfg.eventTimeZone || 'Europe/Madrid' });

  const waitMs = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));
  const waitForFrames = (count = 2) => new Promise((resolve) => {
    const step = (remaining) => window.requestAnimationFrame(() => remaining > 1 ? step(remaining - 1) : resolve());
    step(Math.max(1, Number(count) || 1));
  });

  async function preloadInviteExperience() {
    // Build the final invitation state while it is still visually hidden behind the landing cover.
    // This intentionally buys layout stability during the one-off cinematic transition.
    renderState();
    if (!moneySlots.length) createMoneySlots();

    const crewReady = (async () => {
      try { await window.DANI_CREW?.whenReady?.(); } catch {}
    })();
    const fontsReady = (async () => {
      try { await document.fonts?.ready; } catch {}
    })();
    const critical = Promise.allSettled([crewReady, fontsReady]);

    // Never turn the entrance into a loading screen. Slow network work can finish silently later.
    await Promise.race([critical, waitMs(1350)]);
    await waitForFrames(2);
    return true;
  }
  let hackCompleted = false;
  let hackGeneration = 0;
  let rsvpBusy = false;
  let locationRequestId = 0;
  let hackSaving = false;
  let welcomeTimer;
  const HUD_ANNOUNCEMENT_DURATIONS = Object.freeze({
    routine:2800,
    social:3800,
    important:4700,
    critical:5800
  });
  const HUD_SPONTANEOUS_COOLDOWN_MS = 45000;
  const hudAnnouncementQueue = [];
  const hudAnnouncementSeen = new Set();
  let hudAnnouncementActive = false;
  let hudAnnouncementTimer = null;
  let hudAnnouncementResumeTimer = null;
  let hudLastSpontaneousShownAt = 0;

  const state = loadState();
  let rsvpEditing = false;
  let experienceMode = 'invite';
  let activeProfile = null;
  let activeMissionCode = null;
  let heistTransitionBusy = false;
  let hackPlaying = false;
  let hackSequence = [];
  let hackInput = [];
  let hackRound = 1;
  let missionOpen = storage.get(sessionStorage, ENTRY_DISMISSED_KEY) === '1';
  let eventClockTimerId = null;
  let wantedLevel = 0;
  let moneySlots = [];
  let moneySyncTimerId = null;
  let moneyNextSpawnAt = 0;
  let moneyClaimInFlight = false;
  let policeTimerId = null;
  let policeStartTimerId = null;
  let policeActive = false;
  let hudMenuController = null;
  let hudProfileSwipe = null;
  let hudProfileCloseTimer = null;
  let operationAccordion = null;
  let partyObjectiveAccordion = null;
  let operationInitialized = false;
  let operationProgressStage = null;
  let keepStage3OpenAfterHack = false;
  let pinCombinationController = null;

  function createPinCombinationController() {
    const root = $('#pinLock');
    const hiddenInput = $('#playerPin');
    const status = $('#pinLockStatus');
    if (!root || !hiddenInput) return null;

    const digits = [null, null, null, null];
    const rollers = $$('.combination-wheel__roller', root);
    const drag = new Map();
    let completionTimer = null;
    let wasComplete = false;

    const normalizedDigit = (value) => ((Number(value) % 10) + 10) % 10;
    const displayAround = (digit, offset) => digit === null ? '·' : String(normalizedDigit(digit + offset));

    function renderWheel(index, { tick = false } = {}) {
      const roller = rollers[index];
      if (!roller) return;
      const digit = digits[index];
      roller.querySelector('[data-pin-prev]').textContent = displayAround(digit, -1);
      roller.querySelector('[data-pin-current]').textContent = digit === null ? '–' : String(digit);
      roller.querySelector('[data-pin-next]').textContent = displayAround(digit, 1);
      if (digit === null) {
        roller.removeAttribute('aria-valuenow');
        roller.setAttribute('aria-valuetext', 'Sin elegir');
      } else {
        roller.setAttribute('aria-valuenow', String(digit));
        roller.setAttribute('aria-valuetext', String(digit));
      }
      if (tick && !reduceMotion) {
        roller.classList.remove('is-ticking');
        void roller.offsetWidth;
        roller.classList.add('is-ticking');
        window.setTimeout(() => roller.classList.remove('is-ticking'), 150);
      }
    }

    function syncValue({ announce = true } = {}) {
      const complete = digits.every((digit) => Number.isInteger(digit));
      hiddenInput.value = complete ? digits.join('') : '';
      root.classList.toggle('is-complete', complete);
      status?.classList.toggle('is-complete', complete);
      if (status && announce) status.textContent = complete ? 'COMBINACIÓN LISTA ✓' : 'DESLIZA, GIRA LA RUEDA O USA ↑ ↓';
      if (complete && !wasComplete && !reduceMotion) {
        window.clearTimeout(completionTimer);
        root.classList.remove('is-locking');
        void root.offsetWidth;
        root.classList.add('is-locking');
        completionTimer = window.setTimeout(() => root.classList.remove('is-locking'), 520);
      }
      wasComplete = complete;
    }

    function setDigit(index, value, { tick = true } = {}) {
      if (index < 0 || index > 3) return;
      digits[index] = normalizedDigit(value);
      renderWheel(index, { tick });
      syncValue();
    }

    function stepDigit(index, step) {
      const current = digits[index];
      const base = current === null ? (step >= 0 ? -1 : 0) : current;
      setDigit(index, base + step);
    }

    function reset({ announce = true } = {}) {
      digits.fill(null);
      hiddenInput.value = '';
      root.classList.remove('is-complete', 'is-locking');
      wasComplete = false;
      rollers.forEach((_, index) => renderWheel(index));
      if (status && announce) status.textContent = 'DESLIZA, GIRA LA RUEDA O USA ↑ ↓';
    }

    function focus() {
      rollers[0]?.focus({ preventScroll:true });
    }

    $$('.combination-wheel__step', root).forEach((button) => {
      button.addEventListener('click', () => stepDigit(Number(button.dataset.pinIndex), Number(button.dataset.pinStep)));
    });

    rollers.forEach((roller) => {
      const index = Number(roller.dataset.pinIndex);
      roller.addEventListener('keydown', (event) => {
        if (/^[0-9]$/.test(event.key)) {
          event.preventDefault();
          setDigit(index, Number(event.key));
          rollers[Math.min(index + 1, rollers.length - 1)]?.focus();
          return;
        }
        if (event.key === 'ArrowUp') { event.preventDefault(); stepDigit(index, 1); }
        if (event.key === 'ArrowDown') { event.preventDefault(); stepDigit(index, -1); }
      });
      let lastWheelAt = 0;
      roller.addEventListener('wheel', (event) => {
        event.preventDefault();
        const now = performance.now();
        if (now - lastWheelAt < 72) return;
        lastWheelAt = now;
        stepDigit(index, event.deltaY < 0 ? 1 : -1);
      }, { passive:false });
      roller.addEventListener('pointerdown', (event) => {
        if (event.pointerType === 'mouse' && event.button !== 0) return;
        drag.set(event.pointerId, { y:event.clientY, carry:0 });
        roller.setPointerCapture?.(event.pointerId);
        roller.classList.add('is-dragging');
      });
      roller.addEventListener('pointermove', (event) => {
        const info = drag.get(event.pointerId);
        if (!info) return;
        const movement = event.clientY - info.y;
        info.y = event.clientY;
        info.carry += movement;
        const threshold = 24;
        while (Math.abs(info.carry) >= threshold) {
          // Finger up (negative movement) advances 0 → 1 → 2; finger down goes backwards.
          const step = info.carry < 0 ? 1 : -1;
          stepDigit(index, step);
          info.carry += threshold * step;
        }
      });
      const endDrag = (event) => {
        if (!drag.has(event.pointerId)) return;
        drag.delete(event.pointerId);
        roller.classList.remove('is-dragging');
        if (roller.hasPointerCapture?.(event.pointerId)) roller.releasePointerCapture(event.pointerId);
      };
      roller.addEventListener('pointerup', endDrag);
      roller.addEventListener('pointercancel', endDrag);
    });

    reset({ announce:false });
    return { reset, focus, isComplete:() => digits.every(Number.isInteger), value:() => hiddenInput.value };
  }

  function defaultState() {
    return {
      briefingCompleted: false,
      attendance: null,
      playerName: '',
      dietary: '',
      locationUnlocked: false,
      completedMissions: [],
      discoveredMissions: []
    };
  }

  function loadState() {
    const next = defaultState();
    next.briefingCompleted = storage.get(sessionStorage, PENDING_BRIEFING_KEY) === '1';
    // El progreso persistente ya no se lee del navegador. Limpiamos las claves legacy
    // para impedir que una versión antigua contradiga a D1.
    storage.remove(localStorage, LEGACY_PROGRESS_KEYS.ui, LEGACY_PROGRESS_KEYS.oldUi);
    storage.remove(sessionStorage, LEGACY_PROGRESS_KEYS.missions, LEGACY_PROGRESS_KEYS.oldMissions, LEGACY_PROGRESS_KEYS.hunt, LEGACY_PROGRESS_KEYS.oldHunt);
    return next;
  }

  function saveState() {
    if (!activeProfile && state.briefingCompleted) storage.set(sessionStorage, PENDING_BRIEFING_KEY, '1');
    else storage.remove(sessionStorage, PENDING_BRIEFING_KEY);
  }

  function syncProfile(profile) {
    const resetHack = activeProfile?.id !== profile?.id || state.attendance !== (profile?.attendance || null) || state.locationUnlocked !== Boolean(profile?.locationUnlocked);
    activeProfile = profile || null;
    if (!profile) {
      state.attendance = null;
      state.playerName = '';
      state.dietary = '';
      state.locationUnlocked = false;
      state.completedMissions = [];
      state.discoveredMissions = [];
      wantedLevel = 0;
      // Si todavía no existe identidad, el briefing puede sobrevivir únicamente
      // durante esta pestaña para que el onboarding no salte hacia atrás.
      state.briefingCompleted = storage.get(sessionStorage, PENDING_BRIEFING_KEY) === '1';
    } else {
      state.attendance = profile.attendance || null;
      state.playerName = profile.name || '';
      state.dietary = profile.dietary || '';
      state.locationUnlocked = Boolean(profile.locationUnlocked);
      state.briefingCompleted = Boolean(profile.briefingCompleted || profile.attendance);
      state.completedMissions = Array.isArray(profile.completedMissions) ? profile.completedMissions.slice() : [];
      state.discoveredMissions = Array.from(new Set([
        ...(Array.isArray(profile.discoveredMissions) ? profile.discoveredMissions : []),
        ...state.completedMissions
      ].map((code) => normalizeCode(code)).filter(Boolean)));
      wantedLevel = Math.max(0, Math.min(5, Number(profile.wantedLevel || 0)));
      storage.remove(sessionStorage, PENDING_BRIEFING_KEY);
    }
    saveState();
    renderState({ resetHack });
  }

  function scrollToElement(element, { block = 'start' } = {}) {
    element?.scrollIntoView({ behavior:reduceMotion ? 'auto' : 'smooth', block });
  }

  function scrollToId(id) {
    scrollToElement(document.getElementById(id));
  }

  function eventSnapshot() {
    return eventClock.snapshot();
  }

  function renderEventCountdown(snapshot = eventSnapshot()) {
    const heroCountdown = $('#heroCountdown');
    const heroLabel = $('#heroCountdownLabel');
    const heroValue = $('#heroCountdownValue');
    const previewCountdown = $('#heistPreviewCountdown');
    const previewLabel = $('#heistPreviewCountdownLabel');
    const previewValue = $('#heistPreviewCountdownValue');
    const before = snapshot.phase === 'before';
    const label = snapshot.isEventDay ? 'HOY ES EL DÍA · EL GOLPE COMIENZA EN' : 'EL GOLPE COMIENZA EN';
    const value = before ? eventClock.formatCountdown(snapshot.remainingMs, { eventDay:snapshot.isEventDay }) : '';
    const calendarDays = Math.max(0, Number(snapshot.calendarDaysRemaining || 0));

    if (heroCountdown) heroCountdown.hidden = !before || missionOpen;
    if (heroLabel) heroLabel.textContent = label;
    if (heroValue) heroValue.textContent = value;

    if (previewCountdown) previewCountdown.hidden = !before;
    if (previewLabel && previewValue && before) {
      if (snapshot.isEventDay) {
        previewLabel.textContent = 'HOY · EMPIEZA EN';
        previewValue.textContent = eventClock.formatCountdown(snapshot.remainingMs, { eventDay:true });
      } else if (calendarDays === 1) {
        previewLabel.textContent = 'EL GOLPE ES';
        previewValue.textContent = 'MAÑANA';
      } else {
        previewLabel.textContent = 'FALTAN';
        previewValue.textContent = `${calendarDays} ${calendarDays === 1 ? 'DÍA' : 'DÍAS'}`;
      }
    }
  }

  function startEventClockTicker() {
    let previousPhase = eventSnapshot().phase;
    renderEventCountdown();
    if (eventClockTimerId !== null) window.clearInterval(eventClockTimerId);
    eventClockTimerId = window.setInterval(() => {
      const snapshot = eventSnapshot();
      renderEventCountdown(snapshot);
      document.dispatchEvent(new CustomEvent('dani:event-clock', { detail:snapshot }));
      if (snapshot.phase !== previousPhase) {
        previousPhase = snapshot.phase;
        renderEntryState();
        renderOperationProgression();
      }
    }, 1000);
  }

  function finishHeistTransition(onComplete) {
    const overlay = $('#heistTransition');
    overlay?.classList.remove('show');
    overlay?.setAttribute('aria-hidden', 'true');
    $('main').inert = false;
    $('#partyMode').inert = false;
    $('#hud').inert = false;
    heistTransitionBusy = false;
    window.setTimeout(() => onComplete?.(), reduceMotion ? 0 : 120);
  }

  function showHeistTransition(onComplete) {
    if (heistTransitionBusy || reduceMotion) {
      onComplete?.();
      return;
    }
    const overlay = $('#heistTransition');
    if (!overlay) {
      onComplete?.();
      return;
    }
    heistTransitionBusy = true;
    const profile = window.DANI_CREW?.getLocalProfile?.();
    $('#heistIdentity').textContent = profile?.name ? `${profile.name} · LA BANDA TE ESPERA` : 'LA BANDA TE ESPERA';
    storage.set(localStorage, heistSeenKey(), '1');
    overlay.classList.add('show');
    overlay.setAttribute('aria-hidden', 'false');
    $('main').inert = true;
    $('#partyMode').inert = true;
    $('#hud').inert = true;
    window.setTimeout(() => finishHeistTransition(onComplete), 1500);
  }

  function heistSeenKey() {
    const profile = window.DANI_CREW?.getLocalProfile?.();
    return `${HEIST_TRANSITION_SEEN_KEY}-${profile?.id || 'guest'}-${eventSnapshot().phase}`;
  }

  function requestHeistEntry({ test = false } = {}) {
    const snapshot = eventSnapshot();
    const testAccess = Boolean(test && cfg.heistTestAccess);
    if (snapshot.phase !== 'live' && !cfg.developmentMode && !testAccess) return false;

    // La identidad es la puerta de entrada a El Golpe. Primero se valida al
    // personaje y solo después se ejecuta la transición y se cambia de modo.
    const enterAfterIdentity = () => {
      const enter = () => window.DANI_CREW?.enterHeistAuthorized?.();
      if (storage.get(localStorage, heistSeenKey()) === '1' || reduceMotion) enter();
      else showHeistTransition(enter);
    };

    const gate = window.DANI_CREW?.requestHeistAccess;
    if (typeof gate === 'function') gate(enterAfterIdentity);
    else enterAfterIdentity();
    return true;
  }

  function resetHackUi() {
    $('#moneyHuntLayer').hidden = false;
    hackGeneration++;
    hackPlaying = false;
    hackSequence = [];
    hackInput = [];
    hackRound = 1;

    $('#hackRound').textContent = 'RONDA 1 / 3';
    $('#hackMessage').textContent = state.locationUnlocked ? 'ACCESO YA CONCEDIDO' : 'LISTO PARA INICIAR';
    $('#hackMessage').classList.remove('terminal__screen--error', 'terminal__screen--success');
    $('#startHack').textContent = state.locationUnlocked ? 'UBICACIÓN LOCALIZADA' : 'INICIAR HACKEO';
    $('#startHack').disabled = state.attendance !== 'yes' || state.locationUnlocked;

    $$('#hackPads button').forEach((button) => {
      button.disabled = true;
      button.classList.remove('flash', 'tap-feedback', 'wrong-feedback');
    });
  }

  function resetSecureProgress() {
    hackCompleted = false;
    state.locationUnlocked = false;
    state.completedMissions = [];
    state.discoveredMissions = [];
    activeMissionCode = null;
    setMissionCodeDrawer(false);
    if ($('#missionCode')) $('#missionCode').value = '';
    renderPartyObjectives();
    closePoliceEffectVisual();
    wantedLevel = 0;
    renderWantedLevel();
    $('#moneyHuntLayer')?.replaceChildren();
    resetHackUi();
  }


  function directGoogleMapsUrl(destination) {
    if (!destination) return destination;
    try {
      const url = new URL(destination, window.location.href);
      const raw = url.searchParams.get('query') || url.searchParams.get('destination') || '';
      const match = decodeURIComponent(raw).match(/(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/);
      if (!match) return destination;
      return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${match[1]},${match[2]}`)}&travelmode=driving`;
    } catch {
      return destination;
    }
  }

  async function renderLocation() {
    const requestId = ++locationRequestId;
    $('#retryLocation').hidden = true;
    $('#locationName').textContent = cfg.location?.name || 'PUNTO DE ENCUENTRO';

    const mapsButton = $('#mapsButton');
    const parkingButton = $('#parkingButton');
    mapsButton.href = '#';
    parkingButton.href = '#';
    mapsButton.classList.add('is-loading');
    parkingButton.classList.add('is-loading');
    $('#locationHint').hidden = true;
    $('#locationHint').textContent = '';

    try {
      const secure = await window.DANI_CREW?.getSecureLocation?.();
      if (requestId !== locationRequestId) return;
      if (!secure?.location?.mapsUrl) throw new Error('secure-location-unavailable');

      $('#locationName').textContent = secure.location.name || cfg.location?.name || 'PUNTO DE ENCUENTRO';
      mapsButton.removeAttribute('aria-disabled'); parkingButton.removeAttribute('aria-disabled');
      mapsButton.href = directGoogleMapsUrl(secure.location.mapsUrl);
      mapsButton.hidden = false;
      mapsButton.classList.remove('is-loading');

      if (secure.parking?.mapsUrl) {
        parkingButton.href = directGoogleMapsUrl(secure.parking.mapsUrl);
        parkingButton.textContent = `🅿️ ${secure.parking.name || 'ABRIR PARKING'}`;
        parkingButton.hidden = false;
        parkingButton.classList.remove('is-loading');
      } else {
        parkingButton.hidden = true;
      }
      $('#locationHint').hidden = true;
      $('#locationHint').textContent = '';
    } catch {
      if (requestId !== locationRequestId) return;
      $('#retryLocation').hidden = false;
      mapsButton.hidden = false;
      parkingButton.hidden = false;
      mapsButton.classList.remove('is-loading');
      parkingButton.classList.remove('is-loading');
      mapsButton.setAttribute('aria-disabled', 'true');
      parkingButton.setAttribute('aria-disabled', 'true');
      $('#locationHint').hidden = false;
      $('#locationHint').textContent = cfg.developmentMode
        ? 'Ubicación protegida · conecta el backend de Cloudflare para probar los enlaces.'
        : 'No se ha podido recuperar la ubicación. Recarga la página e inténtalo de nuevo.';
    }
  }

  function landingContext() {
    const snapshot = operationStageState();
    const timeline = eventSnapshot();
    const locationReady = snapshot.briefingDone && snapshot.confirmed && snapshot.unlocked;
    const prepReviewed = Boolean(snapshot.partyPrepReviewed);
    const name = activeProfile?.name ? String(activeProfile.name).toUpperCase() : '';

    if (timeline.phase === 'live') {
      return {
        action:'heist', target:null,
        status:'EL GOLPE · EN CURSO',
        label:'ENTRAR EN EL GOLPE',
        lead:name ? `Es la hora, ${name}.` : 'Es la hora.',
        micro:locationReady ? 'La preparación previa sigue disponible como referencia.' : 'El Golpe está en marcha. Tu Operación 30 sigue disponible.',
        secondaryLabel:locationReady ? 'REVISAR OPERACIÓN 30' : 'VER OPERACIÓN 30',
        secondaryTarget:getResumeTarget()
      };
    }

    if (timeline.phase === 'after') {
      return {
        action:'review', target:getResumeTarget(),
        status:'EL GOLPE · FINALIZADO',
        label:locationReady ? 'REVISAR OPERACIÓN 30' : 'REVISAR OPERACIÓN',
        lead:name ? `Operación cerrada, ${name}.` : 'La operación ha finalizado.',
        micro:'El plan y la preparación quedan disponibles como referencia.'
      };
    }

    if (locationReady) {
      if (!prepReviewed) {
        return {
          action:'review', target:'operationStage4',
          status:timeline.isEventDay ? 'HOY ES EL DÍA · PREPARACIÓN ABIERTA' : 'OPERACIÓN 30 · PREPARACIÓN ABIERTA',
          label:'VER FASE 04',
          lead:name ? `Prepara los últimos detalles, ${name}.` : 'Prepara los últimos detalles.',
          micro:'NPC e inventario del golpe pendientes.'
        };
      }
      return {
        action:'review', target:'operationStage5',
        status:timeline.isEventDay ? 'HOY ES EL DÍA · PREPARACIÓN ABIERTA' : 'OPERACIÓN 30 · PREPARACIÓN ABIERTA',
        label:'VER FASE 05',
        lead:name ? `Consigue fondos para el golpe, ${name}.` : 'Consigue fondos para el golpe.',
        micro:'Operaciones clandestinas y clasificación general abiertas.'
      };
    }
    if (snapshot.declined) {
      return {
        action:'review-invite', target:'operationStage2',
        status:'OPERACIÓN 30 · RESPUESTA ENVIADA',
        label:'REVISAR INVITACIÓN',
        lead:'Se te echará de menos por aquí.',
        micro:'Si cambian tus planes, puedes volver a apuntarte.'
      };
    }
    if (snapshot.briefingDone) {
      const next = snapshot.confirmed ? 'LOCALIZA EL REFUGIO' : 'ÚNETE A LA BANDA';
      const completed = Object.values(snapshot.stages).filter((value) => value === 'completed').length;
      return {
        action:'continue', target:getResumeTarget(),
        status:'OPERACIÓN 30 · EN CURSO',
        label:'CONTINUAR OPERACIÓN',
        lead:`Siguiente fase: ${next}.`,
        micro:`${completed}/5 FASES COMPLETADAS`
      };
    }
    return {
      action:'start', target:'operationStage1',
      status:`NUEVA OPERACIÓN DISPONIBLE · ${String(cfg.dateLabel || '12 DICIEMBRE 2026').toUpperCase()}`,
      label:'INICIAR OPERACIÓN',
      lead:'30 años. Una banda. Un golpe pendiente.',
      micro:''
    };
  }

  function renderEntryState() {
    const startButton = $('#startMission');
    const secondaryButton = $('#heroSecondaryAction');
    const hero = $('#home');
    const actions = startButton?.closest('.hero__actions');
    const context = landingContext();

    if ($('#heroStatus')) $('#heroStatus').textContent = context.status;
    if ($('#heroLead')) $('#heroLead').textContent = context.lead;
    if ($('#heroMicro')) { $('#heroMicro').textContent = context.micro; $('#heroMicro').hidden = !context.micro; }
    if (startButton) {
      startButton.textContent = `▶ ${context.label}`;
      startButton.dataset.entryAction = context.action;
      startButton.dataset.entryTarget = context.target || '';
      startButton.disabled = heistTransitionBusy;
      startButton.hidden = missionOpen;
    }
    if (secondaryButton) {
      const hasSecondary = Boolean(context.secondaryLabel && context.secondaryTarget);
      secondaryButton.hidden = missionOpen || !hasSecondary;
      secondaryButton.textContent = context.secondaryLabel || '';
      secondaryButton.dataset.entryTarget = context.secondaryTarget || '';
    }
    if (actions) actions.hidden = missionOpen;

    renderEventCountdown();
    if (experienceMode !== 'party') $('#hud').hidden = !missionOpen;
    if (!missionOpen) setHudMenuOpen(false);
    $('#missionFlow').hidden = !missionOpen;
    document.body.classList.toggle('intro-mode', !missionOpen);

    if (missionOpen) hero.classList.remove('hero--intro', 'hero--transitioning');
    else if (!hero.classList.contains('hero--transitioning')) hero.classList.add('hero--intro');
  }

  function getResumeTarget() {
    if (!state.briefingCompleted) return 'operationStage1';
    if (state.attendance !== 'yes') return 'operationStage2';
    if (!state.locationUnlocked) return 'operationStage3';
    if (!activeProfile?.uiPrefs?.partyPrepReviewed) return 'operationStage4';
    return 'operationStage5';
  }

  function operationStageForTarget(target) {
    if (target === 'safehouseLocation') return 3;
    const match = String(target || '').match(/^operationStage([1-5])$/);
    return match ? Number(match[1]) : null;
  }

  function openPreparation({ scroll = true, target = null } = {}) {
    storage.set(sessionStorage, ENTRY_DISMISSED_KEY, '1');
    missionOpen = true;
    const flow = $('#missionFlow');
    const hero = $('#home');
    if (flow) flow.hidden = false;
    hero?.classList.remove('hero--intro', 'hero--transitioning');
    renderState();
    const destination = target || getResumeTarget();
    const stage = operationStageForTarget(destination);
    if (stage) operationAccordion?.setOpen(stage, { emit:false });
    if (scroll) window.setTimeout(() => scrollToId(destination), 40);
  }

  function renderHud() {
    const stars = $$('#hudWanted [data-hud-wanted]');
    if (experienceMode === 'party') {
      const score = Math.max(0, Number(activeProfile?.wantedScore ?? activeProfile?.gameStars ?? 0));
      const hudWanted = $('#hudWanted');
      const priority = Boolean(hudWanted?.classList.contains('is-objective-priority'));
      const professional = Boolean(hudWanted?.classList.contains('is-professional'));
      if (hudWanted) {
        hudWanted.classList.add('hud__wanted--party');
        hudWanted.classList.remove('is-loot-complete');
        hudWanted.setAttribute('aria-label', `${professional ? 'El Fantasma. ' : (priority ? 'El Más Buscado. ' : '')}Nivel de búsqueda: ${score} estrellas`);
      }
      stars.forEach((star) => {
        star.textContent = '';
        star.classList.remove('is-active','is-score','is-label','is-icon');
      });
      if (stars[0]) {
        stars[0].textContent = professional ? '👻' : (priority ? '🚨' : '★');
        stars[0].classList.add('is-active','is-icon');
      }
      if (stars[1]) { stars[1].textContent = String(score); stars[1].classList.add('is-score'); }
      return;
    }

    const hudWanted = $('#hudWanted');
    hudWanted?.classList.remove('hud__wanted--party');
    hudWanted?.classList.toggle('is-loot-complete', wantedLevel >= 5 && cashCollectedCount() >= 5);
    stars.forEach((star) => star.classList.remove('is-score','is-label'));
    stars.forEach((star) => {
      const level = Number(star.dataset.hudWanted);
      const active = level <= wantedLevel;
      star.textContent = active ? '★' : '☆';
      star.classList.toggle('is-active', active);
    });
  }

  function visibleHudProfile() {
    if (!activeProfile) return null;
    if (experienceMode === 'party') return activeProfile;
    return state.attendance === 'yes' ? activeProfile : null;
  }

  function hudMenuAriaLabel(open) {
    const profile = visibleHudProfile();
    if (!profile) return `${open ? 'Cerrar' : 'Abrir'} selector de personaje`;
    return `${open ? 'Cerrar' : 'Abrir'} personaje ${profile.name || 'activo'}`;
  }

  function renderHudAvatar(node, profile) {
    if (!node) return;
    node.replaceChildren();
    const photo = typeof profile?.photoData === 'string' && /^data:image\/(?:jpeg|png|webp);base64,/i.test(profile.photoData) ? profile.photoData : '';
    node.classList.toggle('has-photo', Boolean(photo));
    node.classList.toggle('is-empty', !profile);
    if (photo) {
      const image = document.createElement('img');
      image.src = photo;
      image.alt = '';
      image.decoding = 'async';
      node.appendChild(image);
    } else {
      node.textContent = profile ? (profile.avatar || '🎮') : '?';
    }
  }

  function renderHudMenuContext() {
    const profile = visibleHudProfile();
    const hasProfile = Boolean(profile);
    const knownProfile = Boolean(activeProfile);
    const playerAvatar = $('#hudPlayerAvatar');
    const label = $('#hudMenuLabel');
    const menuAvatar = $('#hudPlayerMenuAvatar');
    const menuName = $('#hudPlayerMenuName');
    const menuCrew = $('#hudPlayerMenuCrew');
    const menuStatus = $('#hudPlayerMenuStatus');
    const profileKicker = $('#hudProfileKicker');
    const menuShell = $('#hudMenu');
    const actions = $('#hudPlayerActions');
    const empty = $('#hudPlayerMenuEmpty');
    const recoverAction = $('#hudRecoverCharacter');
    const switchHint = $('#hudSwitchCharacterHint');
    const exitHeist = $('#hudExitHeist');

    document.body.dataset.experienceMode = experienceMode;
    menuShell?.classList.toggle('is-empty', !hasProfile);
    renderHudAvatar(playerAvatar, profile);
    if (label) label.textContent = hasProfile ? String(profile.name || 'PLAYER').toUpperCase() : 'SIN PERSONAJE';
    if (profileKicker) profileKicker.textContent = hasProfile ? 'PERSONAJE ACTIVO' : 'SIN PERSONAJE';
    renderHudAvatar(menuAvatar, profile);
    if (menuName) menuName.textContent = hasProfile ? String(profile.name || 'PLAYER').toUpperCase() : 'SIN PERSONAJE';
    if (menuCrew) menuCrew.textContent = hasProfile
      ? `MIEMBRO #${String(profile.crewNumber || 0).padStart(3, '0')}`
      : knownProfile && experienceMode === 'invite'
        ? 'PERSONAJE GUARDADO'
        : 'ÚNETE A LA BANDA PARA CREARLO';
    if (menuStatus) {
      menuStatus.hidden = !hasProfile;
      if (hasProfile) {
        menuStatus.textContent = experienceMode === 'party'
          ? 'EL GOLPE · EN CURSO'
          : profile.locationUnlocked
            ? 'OPERACIÓN 30 · GOLPE PREPARADO'
            : 'OPERACIÓN 30 · EN CURSO';
      }
    }
    if (actions) actions.hidden = !hasProfile;
    if (switchHint) switchHint.textContent = experienceMode === 'party'
      ? 'Elegir otro miembro con acceso'
      : 'Elegir otro o empezar uno nuevo';
    if (exitHeist) exitHeist.hidden = !(hasProfile && experienceMode === 'party');
    if (empty) {
      empty.hidden = hasProfile;
      const title = empty.querySelector('b');
      const copy = empty.querySelector('p span');
      const paused = !hasProfile && knownProfile && experienceMode === 'invite';
      if (title) title.textContent = paused ? 'Tu personaje está guardado' : '¿Ya tienes personaje?';
      if (copy) copy.textContent = paused
        ? 'Vuelve a unirte desde Reúne a la banda.'
        : 'Recupéralo para continuar donde lo dejaste.';
      if (recoverAction) recoverAction.hidden = paused;
    }
    hudMenuController?.refreshLabel?.();
  }

  function setExperienceMode(mode, profile = null) {
    experienceMode = mode === 'party' ? 'party' : 'invite';
    activeProfile = profile || null;
    const hud = $('#hud');

    setHudMenuOpen(false);
    if (experienceMode === 'party') {
      clearMoneyForParty();
      if (hud) hud.hidden = false;
    } else if (missionOpen) {
      scheduleMoneySync(40);
    }
    renderHudMenuContext();
    renderHud();
    if (experienceMode === 'party') renderPartyObjectives();
  }

  function clearMoneyForParty() {
    if (moneySyncTimerId !== null) { window.clearTimeout(moneySyncTimerId); moneySyncTimerId = null; }
    $('#moneyHuntLayer')?.replaceChildren();
    $('#moneyHuntLayer')?.setAttribute('aria-hidden','true');
  }

  function isHudProfileMobile() {
    return window.matchMedia('(max-width:760px)').matches;
  }

  function resetHudProfileSheetPosition() {
    const panel = $('#hudMenuPanel');
    if (!panel) return;
    if (hudProfileCloseTimer) {
      window.clearTimeout(hudProfileCloseTimer);
      hudProfileCloseTimer = null;
    }
    panel.classList.remove('is-dragging');
    panel.style.transition = '';
    panel.style.transform = '';
    hudProfileSwipe = null;
  }

  function settleHudProfileSwipe(shouldClose) {
    const panel = $('#hudMenuPanel');
    if (!panel) return;
    panel.classList.remove('is-dragging');
    if (shouldClose) {
      if (reduceMotion) {
        resetHudProfileSheetPosition();
        hudMenuController?.setOpen(false);
        return;
      }
      panel.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
      panel.style.transform = 'translate3d(0,100%,0)';
      hudProfileCloseTimer = window.setTimeout(() => {
        resetHudProfileSheetPosition();
        hudMenuController?.setOpen(false);
      }, 190);
      return;
    }
    panel.style.transition = 'transform .18s cubic-bezier(.2,.76,.25,1)';
    panel.style.transform = 'translate3d(0,0,0)';
    window.setTimeout(() => {
      if (hudMenuController?.isOpen?.()) resetHudProfileSheetPosition();
    }, 190);
  }

  function bindHudProfileSheetSwipe() {
    const panel = $('#hudMenuPanel');
    if (!panel) return;
    panel.addEventListener('touchstart', (event) => {
      if (!isHudProfileMobile() || event.touches.length !== 1 || panel.scrollTop > 1) return;
      if (event.target.closest('input,textarea,select,button,a,label,[contenteditable="true"]')) return;
      const touch = event.touches[0];
      hudProfileSwipe = { startY:touch.clientY, startX:touch.clientX, dy:0, active:false };
    }, { passive:true });
    panel.addEventListener('touchmove', (event) => {
      if (!hudProfileSwipe || event.touches.length !== 1) return;
      const touch = event.touches[0];
      const dy = touch.clientY - hudProfileSwipe.startY;
      const dx = touch.clientX - hudProfileSwipe.startX;
      if (!hudProfileSwipe.active) {
        if (panel.scrollTop > 1) { hudProfileSwipe = null; return; }
        if (dy <= 7 || Math.abs(dy) <= Math.abs(dx) * 1.15) return;
        hudProfileSwipe.active = true;
        panel.classList.add('is-dragging');
      }
      event.preventDefault();
      hudProfileSwipe.dy = Math.max(0, dy);
      const distance = Math.min(panel.clientHeight, hudProfileSwipe.dy * .92);
      panel.style.transform = `translate3d(0,${distance}px,0)`;
    }, { passive:false });
    const finish = () => {
      if (!hudProfileSwipe) return;
      const wasActive = hudProfileSwipe.active;
      const shouldClose = wasActive && hudProfileSwipe.dy >= Math.min(110, panel.clientHeight * .14);
      hudProfileSwipe = null;
      if (wasActive) settleHudProfileSwipe(shouldClose);
    };
    panel.addEventListener('touchend', finish, { passive:true });
    panel.addEventListener('touchcancel', finish, { passive:true });
  }

  function setHudMenuOpen(open) {
    if (!open) resetHudProfileSheetPosition();
    hudMenuController?.setOpen(Boolean(open));
  }

  function operationStageState() {
    const briefingDone = Boolean(state.briefingCompleted || state.attendance);
    const confirmed = state.attendance === 'yes';
    const declined = state.attendance === 'no';
    const unlocked = confirmed && state.locationUnlocked;
    const partyPrepReviewed = unlocked && Boolean(activeProfile?.uiPrefs?.partyPrepReviewed);
    const preparationClosed = eventSnapshot().phase !== 'before';
    return {
      briefingDone,
      confirmed,
      declined,
      unlocked,
      partyPrepReviewed,
      preparationClosed,
      stages: {
        1: briefingDone ? 'completed' : 'active',
        2: !briefingDone ? 'locked' : confirmed ? 'completed' : declined ? 'rejected' : 'active',
        3: !confirmed ? 'locked' : unlocked ? 'completed' : 'active',
        4: !unlocked ? 'locked' : partyPrepReviewed ? 'completed' : 'active',
        5: !partyPrepReviewed ? 'locked' : preparationClosed ? 'completed' : 'active'
      }
    };
  }

  function preferredOperationStage(snapshot) {
    if (!snapshot.briefingDone) return 1;
    if (!snapshot.confirmed) return 2;
    if (!snapshot.unlocked) return 3;
    if (!snapshot.partyPrepReviewed) return 4;
    if (!snapshot.preparationClosed) return 5;
    return null;
  }

  function renderOperationProgression() {
    const snapshot = operationStageState();
    const nextProgressStage = preferredOperationStage(snapshot);
    const previousProgressStage = operationProgressStage;
    const progressStageChanged = operationInitialized && previousProgressStage !== nextProgressStage;

    const completedCount = [snapshot.briefingDone, snapshot.confirmed, snapshot.unlocked, snapshot.partyPrepReviewed, snapshot.preparationClosed && snapshot.partyPrepReviewed].filter(Boolean).length;
    const complete = completedCount === 5;
    const progress = $('#operationProgress');
    const progressLabel = $('#operationProgressLabel');
    const progressCount = $('#operationProgressCount');
    if (progress) {
      progress.classList.toggle('is-complete', complete);
      progress.classList.toggle('is-final-stage', !complete && nextProgressStage === 5);
    }
    if (progressLabel) progressLabel.textContent = complete ? 'PREPARACIÓN' : `FASE ${String(nextProgressStage || 5).padStart(2,'0')} DE 05`;
    if (progressCount) progressCount.textContent = complete ? 'LISTA ✓' : snapshot.declined ? 'NO ASISTES' : 'EN CURSO';

    const statusText = {
      active:'EN CURSO',
      completed:'',
      locked:'BLOQUEADA',
      rejected:'NO ASISTES'
    };

    for (let stage = 1; stage <= 5; stage += 1) {
      const shell = $(`#operationStage${stage}`);
      const toggle = $(`#operationStage${stage}Toggle`);
      const status = $(`#operationStage${stage}Status`);
      const stageState = snapshot.stages[stage];
      shell?.classList.remove('is-active','is-completed','is-locked','is-rejected');
      shell?.classList.add(`is-${stageState}`);
      if (toggle) {
        toggle.disabled = stageState === 'locked';
        if (stageState === 'active') toggle.setAttribute('aria-current', 'step');
        else toggle.removeAttribute('aria-current');
      }
      if (status) { status.textContent = statusText[stageState]; status.hidden = stageState === 'completed'; }
      if (toggle) toggle.setAttribute('aria-label', `${['', 'El plan', 'Únete a la banda', 'Localiza el refugio', 'Prepárate para el golpe', 'Consigue dinero para el golpe'][stage]}${stageState === 'completed' ? ', completada' : ''}`);
      const marker = shell?.querySelector('.operation-stage__marker');
      if (marker) marker.textContent = stageState === 'completed' ? '✓' : String(stage).padStart(2, '0');
      $$('[data-operation-active-only]', shell).forEach((element) => {
        element.hidden = stageState !== 'active';
      });
    }

    // Una sola fuente de verdad para las cinco fases. Al superar el hack, la Fase 3
    // se mantiene abierta para que la ubicación recién desbloqueada pueda leerse antes
    // de que el usuario avance manualmente a la preparación del golpe.
    if (!operationInitialized) {
      operationAccordion?.setOpen(nextProgressStage, { emit:false });
      operationInitialized = true;
    } else if (progressStageChanged) {
      const holdRefugeOpen = keepStage3OpenAfterHack && previousProgressStage === 3 && nextProgressStage === 4;
      if (holdRefugeOpen) {
        keepStage3OpenAfterHack = false;
        operationAccordion?.setOpen(3, { emit:false });
        operationAccordion?.refresh?.();
      } else {
        operationAccordion?.setOpen(nextProgressStage);
      }
      if (nextProgressStage && previousProgressStage && nextProgressStage > previousProgressStage) {
        pulseMoment($(`#operationStage${previousProgressStage} .operation-stage__marker`), 'moment-check');
        pulseMoment($(`#operationStage${nextProgressStage}Toggle`), 'moment-next');
        window.DANI_MOTION?.pulseProgress?.();
      }
      if (nextProgressStage && !holdRefugeOpen) window.setTimeout(() => scrollToId(`operationStage${nextProgressStage}`), 60);
    } else {
      const opened = Number(operationAccordion?.getOpen?.() || 0);
      if (opened && snapshot.stages[opened] === 'locked') {
        operationAccordion?.setOpen(nextProgressStage);
      } else {
        operationAccordion?.refresh?.();
      }
    }
    operationProgressStage = nextProgressStage;

    const next = $('#heistPreview');
    if (next) next.hidden = false;
    return snapshot;
  }

  async function completeBriefing() {
    if (state.briefingCompleted) return;
    state.briefingCompleted = true;
    saveState();
    if (activeProfile) await window.DANI_CREW?.saveProgress?.({ briefingCompleted:true });
    renderState();
  }

  function animateHeroIntoLayout(onComplete, { readiness = Promise.resolve(), onSplitReady } = {}) {
    const hero = $('#home');
    const startButton = $('#startMission');
    startButton.disabled = true;

    if (reduceMotion) {
      hero.classList.remove('hero--intro', 'hero--transitioning');
      onSplitReady?.();
      onComplete?.();
      return;
    }

    // v23.11: the sun beat now doubles as useful preload time. The final invitation
    // copy and split surfaces do not reveal until critical layout work has settled.
    window.DANI_MOTION?.prepareInviteTransition?.();
    void hero.offsetWidth;
    hero.classList.add('hero--transitioning');
    const splitPromise = window.DANI_MOTION?.playInviteTransition?.({ readiness }) || readiness;
    Promise.resolve(splitPromise).then(() => onSplitReady?.()).catch(() => onSplitReady?.());

    window.setTimeout(() => {
      hero.classList.remove('hero--intro', 'hero--transitioning');
      onComplete?.();
      window.DANI_MOTION?.finishInviteTransition?.();
    }, HERO_TRANSITION_MS);
  }

  function enterOperationFromLanding({ action = 'continue', target = getResumeTarget() } = {}) {
    storage.set(sessionStorage, ENTRY_DISMISSED_KEY, '1');
    const flow = $('#missionFlow');
    const hud = $('#hud');
    missionOpen = true;
    hud.hidden = false;
    flow.hidden = false;
    flow.classList.add('mission-flow--entering');
    flow.inert = true;
    hud.inert = true;

    // Render immediately while hidden behind the landing cover, then let async profile/crew
    // hydration and webfonts settle during the cinematic beat instead of after it.
    const readiness = preloadInviteExperience();

    const reveal = () => {
      flow.classList.remove('mission-flow--entering', 'mission-flow--visible');
      flow.inert = false;
      hud.inert = false;
      scheduleMoneySync(30);
      if (target) window.setTimeout(() => {
        const stage = operationStageForTarget(target);
        if (stage) operationAccordion?.setOpen(stage, { emit:false });
        if (action !== 'start') scrollToId(target);
      }, 60);
    };
    animateHeroIntoLayout(reveal, {
      readiness,
      onSplitReady:() => flow.classList.add('mission-flow--visible')
    });
  }

  function renderState({ resetHack = false } = {}) {
    const confirmed = state.attendance === 'yes';
    const declined = state.attendance === 'no';
    const unlocked = confirmed && state.locationUnlocked;

    renderEntryState();
    announceInviteCountdownMilestone();
    $('#dateLabel').textContent = cfg.dateLabel;
    $('#timeLabel').textContent = cfg.timeLabel;
    $('#safehouseHack').hidden = unlocked;

    if (!rsvpEditing) { $('#playerName').value = state.playerName; $('#dietary').value = state.dietary; }
    if (state.attendance) {
      const radio = document.querySelector(`input[name="attendance"][value="${state.attendance}"]`);
      if (radio) radio.checked = true;
    }

    renderOperationProgression();

    const decision = $('#rsvpDecision');
    const declinedPanel = $('#rsvpDeclined');
    const recoverPlayer = $('#recoverPlayer');
    if (decision) decision.hidden = confirmed || declined || rsvpEditing;
    if (recoverPlayer) recoverPlayer.hidden = Boolean(activeProfile) || rsvpEditing || confirmed;
    if ($('#rsvpForm')) $('#rsvpForm').hidden = !rsvpEditing;
    $('#rsvpConfirmed').hidden = !confirmed || rsvpEditing;
    if (declinedPanel) declinedPanel.hidden = !declined || rsvpEditing;
    if (confirmed) $('#confirmedName').textContent = state.playerName.toUpperCase();

    $('#confirmedContent').hidden = !confirmed;
    $('#unlockedContent').hidden = !unlocked;
    $('#resetDemo').hidden = !cfg.developmentMode;
    $('#devSkipHack').hidden = !(cfg.developmentMode && confirmed && !unlocked);
    $('#devMissionCodes').hidden = !cfg.developmentMode;

    if (unlocked) renderLocation();
    else { locationRequestId++; $('#mapsButton').href = '#'; $('#parkingButton').href = '#'; }
    window.DANI_CREW?.onInviteState?.({ ...state });

    if (resetHack) resetHackUi();
    renderWantedLevel();
    renderHudMenuContext();
    renderHud();
    if (experienceMode === 'party') renderPartyObjectives();
    if (missionOpen && experienceMode === 'invite') {
      // El WANTED máximo es un hito único: tras conseguir el quinto billete las
      // cinco estrellas permanecen, pero la persecución no se repite al recargar.
      scheduleMoneySync(40);
    }
  }

  function pulseMoment(node, className = 'moment-reveal') {
    if (!node || reduceMotion) return;
    node.classList.remove(className);
    void node.offsetWidth;
    node.classList.add(className);
    window.setTimeout(() => node.classList.remove(className), 1200);
  }

  function scheduleHudAnnouncementResume(delay = 450) {
    window.clearTimeout(hudAnnouncementResumeTimer);
    hudAnnouncementResumeTimer = window.setTimeout(() => {
      hudAnnouncementResumeTimer = null;
      runNextHudAnnouncement();
    }, Math.max(80, Number(delay || 0)));
  }

  function hudAnnouncementCanRun(item) {
    if (!item?.spontaneous) return true;
    if (hackPlaying || hackSaving) return false;
    const remainingCooldown = HUD_SPONTANEOUS_COOLDOWN_MS - (Date.now() - hudLastSpontaneousShownAt);
    return remainingCooldown <= 0;
  }

  function runNextHudAnnouncement() {
    if (hudAnnouncementActive || !hudAnnouncementQueue.length) return;
    const hud = $('#hud');
    const title = $('#hudAnnouncementTitle');
    const detail = $('#hudAnnouncementDetail');
    if (!hud || !title || !detail) { hudAnnouncementQueue.length = 0; return; }

    // Los avisos espontáneos nunca interrumpen el hack ni se encadenan como un feed.
    // Las acciones directas del jugador sí pueden adelantarles en la cola.
    const runnableIndex = hudAnnouncementQueue.findIndex(hudAnnouncementCanRun);
    if (runnableIndex < 0) {
      const cooldownRemaining = Math.max(0, HUD_SPONTANEOUS_COOLDOWN_MS - (Date.now() - hudLastSpontaneousShownAt));
      scheduleHudAnnouncementResume(hackPlaying || hackSaving ? 650 : Math.min(Math.max(cooldownRemaining, 250), 5000));
      return;
    }

    const item = hudAnnouncementQueue.splice(runnableIndex, 1)[0];
    if (hud.hidden) {
      // El HUD solo comunica eventos cuando forma parte de la experiencia visible.
      runNextHudAnnouncement();
      return;
    }

    hudAnnouncementActive = true;
    if (item.spontaneous) hudLastSpontaneousShownAt = Date.now();
    moneyNextSpawnAt = 0;
    setHudMenuOpen(false);
    title.textContent = item.title;
    detail.textContent = item.detail || '';
    detail.hidden = !item.detail;
    hud.dataset.announcementTone = item.tone || 'default';
    hud.classList.add('hud--rolling');

    const rollMs = reduceMotion ? 0 : 340;
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => hud.classList.add('hud--announcement-visible'));
    });

    window.clearTimeout(hudAnnouncementTimer);
    // El tiempo de lectura empieza cuando termina la entrada, no mientras el texto aún se mueve.
    hudAnnouncementTimer = window.setTimeout(() => {
      hudAnnouncementTimer = window.setTimeout(() => {
        hud.classList.remove('hud--announcement-visible');
        hudAnnouncementTimer = window.setTimeout(() => {
          hud.classList.remove('hud--rolling');
          delete hud.dataset.announcementTone;
          title.textContent = '';
          detail.textContent = '';
          detail.hidden = true;
          hudAnnouncementActive = false;
          window.setTimeout(runNextHudAnnouncement, reduceMotion ? 0 : 80);
          if (missionOpen && experienceMode === 'invite' && hudAnnouncementQueue.length === 0) {
            scheduleMoneySync(reduceMotion ? 80 : 520);
          }
        }, rollMs);
      }, Math.max(1800, Number(item.duration || HUD_ANNOUNCEMENT_DURATIONS.routine)));
    }, rollMs);
  }

  function announceHud(title, {
    detail = '', tone = 'default', duration = null, level = 'routine', priority = 1,
    spontaneous = false, dedupeKey = ''
  } = {}) {
    const cleanTitle = String(title || '').trim();
    if (!cleanTitle) return;
    const cleanKey = String(dedupeKey || '').trim();
    if (cleanKey && hudAnnouncementSeen.has(cleanKey)) return;
    if (cleanKey) hudAnnouncementSeen.add(cleanKey);
    const defaultDuration = HUD_ANNOUNCEMENT_DURATIONS[level] || HUD_ANNOUNCEMENT_DURATIONS.routine;
    const item = {
      title:cleanTitle,
      detail:String(detail || '').trim(),
      tone,
      duration:duration == null ? defaultDuration : Math.max(1800, Number(duration || defaultDuration)),
      priority:Math.max(0, Number(priority || 0)),
      spontaneous:Boolean(spontaneous),
      dedupeKey:cleanKey
    };
    const insertAt = hudAnnouncementQueue.findIndex((queued) => Number(queued.priority || 0) < item.priority);
    if (insertAt < 0) hudAnnouncementQueue.push(item);
    else hudAnnouncementQueue.splice(insertAt, 0, item);
    runNextHudAnnouncement();
  }

  function announceInviteCountdownMilestone(snapshot = eventSnapshot()) {
    if (!missionOpen || experienceMode !== 'invite' || snapshot.phase !== 'before') return;
    const days = Math.max(0, Number(snapshot.calendarDaysRemaining || 0));
    if (snapshot.isEventDay) {
      announceHud('HOY ES EL GOLPE', {
        detail:`NOS VEMOS A LAS ${String(cfg.timeLabel || '13:00 h').replace(/\s*h\s*$/i, '')}`,
        tone:'default', level:'critical', priority:2, spontaneous:true, dedupeKey:'countdown-today'
      });
    } else if (days === 1) {
      announceHud('MAÑANA ES EL DÍA', {
        detail:'TODO LISTO PARA EL GOLPE',
        tone:'default', level:'critical', priority:2, spontaneous:true, dedupeKey:'countdown-tomorrow'
      });
    } else if (days >= 2 && days <= 7) {
      announceHud('EL GOLPE ES ESTA SEMANA', {
        detail:'LA BANDA ENTRA EN LA RECTA FINAL',
        tone:'default', level:'important', priority:1, spontaneous:true, dedupeKey:'countdown-week'
      });
    }
  }


  function welcomeToCrew(profile, { returning = false } = {}) {
    if (!profile?.id) return;
    const key = `dani30-welcome-${profile.id}`;
    if (!returning && storage.get(localStorage, key)) return;
    storage.set(localStorage, key, '1');
    announceHud('ESTÁS DENTRO', {
      detail:returning ? 'BIENVENIDO DE NUEVO A LA BANDA' : 'BIENVENIDO A LA BANDA',
      tone:'success', level:'social', priority:2, dedupeKey:`joined-${profile.id}`
    });
    announceHud('NUEVA FASE DISPONIBLE', {
      detail:'LOCALIZA EL REFUGIO',
      tone:'default', level:'important', priority:1, dedupeKey:`phase3-${profile.id}`
    });
    pulseMoment($('#crewQuickAccess'), 'moment-crew-join');
  }

  async function submitRsvp(event) {
    event.preventDefault();

    const name = $('#playerName').value.trim();
    const attendance = 'yes';
    const dietary = $('#dietary').value.trim();
    const returningToCrew = state.attendance === 'no';

    if (!name) {
      $('#formMessage').textContent = 'Introduce tu nombre para unirte a la banda.';
      $('#playerName').focus();
      return;
    }

    try {
      const pin = pinCombinationController?.value?.() || ($('#playerPin')?.value || '').trim();
      const crewResult = await window.DANI_CREW?.saveRsvp?.({ name, attendance, dietary, pin });
      if (crewResult?.ok !== true) {
        $('#formMessage').textContent = crewResult.message || 'No se ha podido guardar la confirmación.';
        if (crewResult.focusId === 'pinLock') window.DANI_PIN_LOCK?.focus?.();
        else crewResult.focusId && document.getElementById(crewResult.focusId)?.focus();
        return;
      }
    } catch (error) {
      console.warn('Crew RSVP sync failed', error);
      $('#formMessage').textContent = 'No se ha podido guardar la confirmación. Inténtalo de nuevo.';
      return;
    }

    const joinedProfile = window.DANI_CREW?.getLocalProfile?.() || activeProfile;
    rsvpEditing = false;

    // Resincronizamos el perfil completo en vez de parchear solo la asistencia.
    // Esto es importante cuando alguien pasa de "no voy" a "sí voy": el hackeo
    // podía conservar el disabled del estado anterior aunque la fase ya estuviera activa.
    if (joinedProfile) syncProfile(joinedProfile);
    else {
      state.playerName = name;
      state.dietary = dietary;
      state.attendance = attendance;
      saveState();
      renderState({ resetHack:true });
    }
    $('#formMessage').textContent = '';
    clearTimeout(welcomeTimer);
    welcomeTimer = window.setTimeout(() => {
      if (activeProfile?.id === joinedProfile?.id) welcomeToCrew(joinedProfile, { returning:returningToCrew });
    }, 180);
  }


  function acceptMissionRsvp() {
    rsvpEditing = true;
    $('#rsvpDecision').hidden = true;
    $('#rsvpDeclined').hidden = true;
    $('#rsvpConfirmed').hidden = true;
    $('#rsvpForm').hidden = false;
    $('#formMessage').textContent = '';
    window.setTimeout(() => $('#playerName')?.focus(), 80);
  }

  function backToRsvpDecision() {
    rsvpEditing = false;
    if (state.attendance === 'yes' || state.attendance === 'no') {
      renderState();
      return;
    }
    $('#rsvpForm').hidden = true;
    $('#rsvpDecision').hidden = false;
    $('#formMessage').textContent = '';
    window.DANI_PIN_LOCK?.reset?.();
  }

  function declineMissionRsvp() {
    $('#declineForm').hidden = false;
    $('#declineName').value = state.playerName || '';
    $('#declineStatus').textContent = '';
    $('#rsvpDecision').hidden = true;
    $('#rsvpConfirmed').hidden = true;
    $('#rsvpDeclined').hidden = true;
    $('#recoverPlayer').hidden = true;
  }

  async function submitDecline(event) {
    event.preventDefault();
    const button = $('#declineForm button[type="submit"]');
    const name = ($('#declineName')?.value || '').trim();
    if (!name) {
      $('#declineStatus').textContent = 'Escribe tu nombre para enviar la respuesta.';
      $('#declineName')?.focus();
      return;
    }
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = 'ENVIANDO…';
    $('#declineStatus').textContent = '';
    try {
      const result = await window.DANI_CREW?.saveRsvp?.({ name, attendance:'no', dietary:state.dietary || '', declineMessage:($('#declineMessage')?.value || '').trim() });
      if (!result?.ok) throw new Error(result?.message || 'No se ha podido guardar. Inténtalo de nuevo.');
      const profile = window.DANI_CREW?.getLocalProfile?.();
      if (!profile || profile.attendance !== 'no') throw new Error('No se ha podido confirmar la respuesta. Inténtalo de nuevo.');
      $('#declineForm').hidden = true;
      rsvpEditing = false;
      syncProfile(profile);
    } catch (error) {
      $('#declineStatus').textContent = error?.message || 'No se ha podido guardar. Inténtalo de nuevo.';
    } finally {
      button.disabled = false;
      button.textContent = 'ENVIAR RESPUESTA';
    }
  }

  function makeSequence(length) {
    return Array.from({ length }, () => Math.floor(Math.random() * 4));
  }

  function sleep(milliseconds) {
    const delay = reduceMotion ? Math.min(70, milliseconds) : milliseconds;
    return new Promise((resolve) => window.setTimeout(resolve, delay));
  }

  async function flashSequence(sequence) {
    const generation = hackGeneration;
    const pads = $$('#hackPads button');
    pads.forEach((button) => { button.disabled = true; });
    $('#startHack').disabled = true;
    $('#hackMessage').classList.remove('terminal__screen--error', 'terminal__screen--success');
    $('#hackMessage').textContent = 'MEMORIZA LA SECUENCIA';

    await sleep(500);
    for (const index of sequence) {
      if (generation !== hackGeneration) return;
      pads[index].classList.add('flash');
      await sleep(430);
      if (generation !== hackGeneration) return;
      pads[index].classList.remove('flash');
      await sleep(190);
    }

    if (generation !== hackGeneration) return;
    $('#hackMessage').textContent = `REPÍTELA · 0 / ${sequence.length}`;
    pads.forEach((button) => { button.disabled = false; });
  }

  async function startHack() {
    if (hackPlaying || state.locationUnlocked || state.attendance !== 'yes') return;
    if (hackCompleted) { await completeHack(); return; }
    hackPlaying = true;
    suspendMoneyHunt();
    hackRound = 1;
    $('#startHack').textContent = 'HACKEO EN CURSO';
    await beginHackRound();
  }

  async function beginHackRound() {
    hackInput = [];
    hackSequence = makeSequence(hackRound + 2);
    $('#hackRound').textContent = `RONDA ${hackRound} / 3`;
    await flashSequence(hackSequence);
  }

  function givePadFeedback(button, isWrong = false) {
    button.classList.remove('tap-feedback', 'wrong-feedback');
    void button.offsetWidth;
    button.classList.add(isWrong ? 'wrong-feedback' : 'tap-feedback');
    window.setTimeout(() => {
      button.classList.remove('tap-feedback', 'wrong-feedback');
    }, reduceMotion ? 40 : 230);
  }

  async function handlePad(button) {
    if (!hackPlaying || state.locationUnlocked || button.disabled) return;

    const padIndex = Number(button.dataset.pad);
    const position = hackInput.length;
    const isWrong = padIndex !== hackSequence[position];
    givePadFeedback(button, isWrong);

    hackInput.push(padIndex);
    $('#hackMessage').textContent = `REPÍTELA · ${hackInput.length} / ${hackSequence.length}`;

    if (isWrong) {
      hackPlaying = false;
      scheduleMoneySync(600);
      $('#hackMessage').textContent = 'ACCESO DENEGADO · VUELVE A INTENTARLO';
      $('#hackMessage').classList.add('terminal__screen--error');
      $$('#hackPads button').forEach((pad) => { pad.disabled = true; });
      $('#startHack').disabled = false;
      $('#startHack').textContent = 'REINTENTAR HACKEO';
      return;
    }

    if (hackInput.length !== hackSequence.length) return;

    $$('#hackPads button').forEach((pad) => { pad.disabled = true; });

    if (hackRound < 3) {
      $('#hackMessage').textContent = 'RONDA SUPERADA';
      $('#hackMessage').classList.add('terminal__screen--success');
      hackRound += 1;
      const generation = hackGeneration;
      await sleep(850);
      if (generation !== hackGeneration) return;
      await beginHackRound();
      return;
    }

    hackCompleted = true;
    await completeHack();
  }

  async function completeHack() {
    if (hackSaving) return;
    hackSaving = true;
    hackPlaying = false;
    const playerId = activeProfile?.id;
    const generation = hackGeneration;
    $('#startHack').disabled = true;
    $('#hackMessage').textContent = 'DESCIFRANDO SEÑAL…';
    try {
      await window.DANI_CREW.unlockLocation();
      if (activeProfile?.id !== playerId) return;
      // Profile synchronization may already reveal the location: celebrate in the
      // destination card, rather than delaying persisted progress or hiding controls.
      state.locationUnlocked = true;
      keepStage3OpenAfterHack = true;
      saveState();
      renderState();
      pulseMoment($('#safehouseLocation'), 'moment-refuge');
      window.setTimeout(() => scrollToId('safehouseLocation'), 80);
      announceHud('REFUGIO LOCALIZADO', { detail:'YA SABES DÓNDE ENCONTRARNOS', tone:'success', level:'important', priority:2, dedupeKey:`refuge-${activeProfile?.id || 'player'}` });
    } catch {
      if (activeProfile?.id !== playerId || generation !== hackGeneration) return;
      $('#hackMessage').textContent = 'No se ha podido guardar. Reintenta sin repetir el juego.';
      $('#startHack').disabled = false;
      $('#startHack').textContent = 'REINTENTAR GUARDADO';
    } finally {
      hackSaving = false;
      scheduleMoneySync(600);
    }
  }

  async function completePartyPrep() {
    const button = $('#completePartyPrep');
    if (!button || state.attendance !== 'yes' || !state.locationUnlocked || activeProfile?.uiPrefs?.partyPrepReviewed) return;
    button.disabled = true;
    button.textContent = 'GUARDANDO…';
    try {
      const result = await window.DANI_CREW?.completePartyPrep?.();
      if (!result?.profile) throw new Error('No se ha podido guardar la preparación.');
      syncProfile(result.profile);
      announceHud('PREPARACIÓN COMPLETA', { detail:'YA ESTÁS LISTO PARA EL GOLPE', tone:'success', level:'important', priority:3, dedupeKey:`prep-${activeProfile?.id || 'player'}` });
    } catch (error) {
      button.disabled = false;
      button.textContent = 'CONTINUAR OPERACIÓN';
      announceHud('PREPARACIÓN NO GUARDADA', { detail:error?.message || 'VUELVE A INTENTARLO', tone:'danger', duration:2400, priority:2 });
    }
  }

  function normalizeCode(value) {
    return String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  }

  function operationObjectiveCodes() {
    return Object.keys(cfg.missions || {}).map((code) => normalizeCode(code)).filter(Boolean);
  }

  function operationProgressSnapshot() {
    const all = operationObjectiveCodes();
    const completed = new Set((state.completedMissions || []).map(normalizeCode));
    return { completed:all.filter((code) => completed.has(code)).length, total:all.length };
  }

  function discoveredObjectiveCodes() {
    const completed = (state.completedMissions || []).map(normalizeCode);
    return Array.from(new Set([...(state.discoveredMissions || []).map(normalizeCode), ...completed]))
      .filter((code) => Boolean(cfg.missions?.[code]));
  }

  function objectiveProgressDetail(extra = []) {
    const progress = operationProgressSnapshot();
    return [...extra.filter(Boolean), `${progress.completed}/${progress.total} OBJETIVOS`].join(' · ');
  }

  function setMissionCodeDrawer(open, { focus = false } = {}) {
    const drawer = $('#missionCodeDrawer');
    const toggle = $('#toggleMissionCode');
    if (!drawer || !toggle) return;
    drawer.hidden = !open;
    toggle.setAttribute('aria-expanded', String(Boolean(open)));
    toggle.classList.toggle('is-open', Boolean(open));
    const mark = toggle.querySelector('b');
    if (mark) mark.textContent = open ? '−' : '＋';
    if (open && focus) window.setTimeout(() => $('#missionCode')?.focus?.(), 40);
  }

  function renderObjectiveRules(rules, container) {
    if (!container || !Array.isArray(rules) || rules.length === 0) return;
    const title = document.createElement('b');
    title.textContent = 'CÓMO SE JUEGA';
    const list = document.createElement('ol');
    for (const rule of rules) {
      const item = document.createElement('li');
      item.textContent = rule;
      list.appendChild(item);
    }
    container.append(title, list);
  }

  function economyButton(label, className = 'btn btn--soft') {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = label;
    return button;
  }

  function missionEconomyMessage(root, text = '', tone = '') {
    const message = root?.querySelector('[data-mission-economy-message]');
    if (!message) return;
    message.textContent = text;
    message.classList.toggle('is-error', tone === 'error');
    message.classList.toggle('is-success', tone === 'success');
  }

  async function applyGameEconomy(payload, { root, hudTitle, hudParts = [], completes = false, tone = 'success' } = {}) {
    const buttons = root ? [...root.querySelectorAll('button')] : [];
    buttons.forEach((button) => { button.disabled = true; });
    missionEconomyMessage(root, 'GUARDANDO RESULTADO…');
    try {
      const result = await window.DANI_CREW?.applyEconomy?.(payload);
      if (!result?.profile) throw new Error('No se ha podido guardar el resultado.');
      syncProfile(result.profile);
      if (completes) activeMissionCode = '';
      renderPartyObjectives({ preferredOpenCode:completes ? '' : payload.sourceId });
      const progress = operationProgressSnapshot();
      const allDone = completes && progress.total > 0 && progress.completed >= progress.total;
      announceHud(allDone ? '✓ TODOS LOS OBJETIVOS COMPLETADOS' : (hudTitle || (completes ? '✓ OBJETIVO COMPLETADO' : 'RESULTADO REGISTRADO')), {
        detail:completes ? objectiveProgressDetail(hudParts) : hudParts.join(' · '),
        tone,
        duration:allDone ? 3400 : (completes ? 2900 : 2400),
        priority:allDone ? 3 : (completes ? 2 : 1)
      });
      return result;
    } catch (error) {
      buttons.forEach((button) => { button.disabled = false; });
      missionEconomyMessage(root, error.message || 'No se ha podido guardar.', 'error');
      return null;
    }
  }

  function renderMissionEconomyActions(mission, code, completed, root) {
    if (!root) return;
    root.replaceChildren();
    root.hidden = true;
    const economy = mission?.economy || {};
    if (!economy.resultDriven) return;
    root.hidden = false;

    const head = document.createElement('div');
    head.className = 'mission-economy-actions__head';
    const eyebrow = document.createElement('small');
    eyebrow.textContent = 'RESULTADO DEL JUEGO';
    const heading = document.createElement('strong');
    heading.textContent = completed ? 'RESULTADO REGISTRADO' : (economy.mode === 'pin-stars' ? '¿CON CUÁNTAS ESTRELLAS HAS TERMINADO?' : '¿CÓMO HA TERMINADO EL INTENTO?');
    head.append(eyebrow, heading);
    root.appendChild(head);

    if (completed) {
      const done = document.createElement('p');
      done.className = 'mission-economy-actions__done';
      done.textContent = '✓ Resultado guardado. Si quieres gestionar tus estrellas, hazlo desde Mi expediente.';
      root.appendChild(done);
      return;
    }

    if (economy.mode === 'pin-stars') {
      const row = document.createElement('div');
      row.className = 'mission-economy-actions__score';
      const label = document.createElement('label');
      label.innerHTML = '<span>ESTRELLAS AL FINAL</span>';
      const input = document.createElement('input');
      const maxStars = Math.max(1, Number.parseInt(economy.maxStars, 10) || 30);
      input.type = 'number'; input.inputMode = 'numeric'; input.min = '0'; input.max = String(maxStars); input.value = '0';
      input.setAttribute('aria-label', 'Estrellas al final del juego');
      label.appendChild(input);
      row.appendChild(label);
      root.appendChild(row);

      const copy = document.createElement('p');
      copy.className = 'mission-economy-actions__copy';
      copy.textContent = 'Registra el resultado tal como ha terminado. Después podrás limpiar estrellas desde Mi expediente usando dinero.';
      root.appendChild(copy);

      const actions = document.createElement('div');
      actions.className = 'mission-economy-actions__buttons';
      const register = economyButton('REGISTRAR RESULTADO', 'btn btn--accent');
      actions.append(register);
      root.appendChild(actions);

      register.addEventListener('click', async () => {
        const raw = Math.max(0, Math.min(maxStars, Number.parseInt(input.value, 10) || 0));
        await applyGameEconomy({
          sourceType:'game', sourceId:code, actionId:'settlement',
          eventId:`game-${code}-settlement`, meta:{ rawStars:raw }
        }, { root, hudTitle:'✓ OBJETIVO COMPLETADO', hudParts:[`+${raw} ★`], completes:true });
      });
    }

    if (economy.mode === 'car-retry') {
      const copy = document.createElement('p');
      copy.className = 'mission-economy-actions__copy';
      copy.textContent = 'Si aparcas, objetivo completado. Si fallas, puedes asumir una estrella o gastar dinero para volver a intentarlo.';
      root.appendChild(copy);

      const actions = document.createElement('div');
      actions.className = 'mission-economy-actions__buttons mission-economy-actions__buttons--three';
      const success = economyButton('✓ HE APARCADO', 'btn btn--accent');
      const star = economyButton('ASUMIR +1 ★');
      const retryCost = Math.max(0, Number(economy.retryCost || 0));
      const retry = economyButton(`PAGAR $${retryCost} · REINTENTAR`);
      actions.append(success, star, retry);
      root.appendChild(actions);

      success.addEventListener('click', async () => {
        await applyGameEconomy({
          sourceType:'game', sourceId:code, actionId:'success',
          eventId:`game-${code}-result`, meta:{ outcome:'success' }
        }, { root, hudTitle:'✓ OBJETIVO COMPLETADO', hudParts:['SIN ESTRELLAS'], completes:true });
      });
      star.addEventListener('click', async () => {
        await applyGameEconomy({
          sourceType:'game', sourceId:code, actionId:'loss',
          eventId:`game-${code}-result`, meta:{ outcome:'loss' }
        }, { root, hudTitle:'✓ OBJETIVO COMPLETADO', hudParts:['+1 ★'], completes:true, tone:'danger' });
      });
      retry.addEventListener('click', async () => {
        const result = await applyGameEconomy({
          sourceType:'game', sourceId:code, actionId:'retry',
          meta:{ outcome:'retry' }
        }, { root, hudTitle:'SEGUNDA OPORTUNIDAD', hudParts:[`-$${retryCost}`, 'INTÉNTALO DE NUEVO'], completes:false });
        if (result) {
          [...root.querySelectorAll('button')].forEach((button) => { button.disabled = false; });
          missionEconomyMessage(root, 'REINTENTO DESBLOQUEADO · SUERTE.', 'success');
        }
      });
    }

    const message = document.createElement('p');
    message.className = 'mission-economy-actions__message';
    message.dataset.missionEconomyMessage = '';
    message.setAttribute('role', 'status');
    root.appendChild(message);
  }

  function objectiveCard(code) {
    const mission = cfg.missions?.[code];
    if (!mission || !createOperationStage) return null;
    const completed = (state.completedMissions || []).map(normalizeCode).includes(code);
    const allCodes = operationObjectiveCodes();
    const number = String(Math.max(1, allCodes.indexOf(code) + 1)).padStart(2, '0');
    const stageId = `partyObjective${code.replace(/[^A-Z0-9_-]/gi, '')}`;
    const stage = createOperationStage({
      id:stageId,
      marker:completed ? '✓' : number,
      eyebrow:mission.type || 'OBJETIVO',
      title:mission.title || code,
      status:completed ? 'COMPLETADA' : 'ACTIVA',
      state:completed ? 'completed' : 'active',
      shellClass:'party-objective-stage',
      panelClass:'party-objective-stage__panel'
    });
    stage.shell.dataset.objectiveCode = code;

    const content = document.createElement('div');
    content.className = 'operation-stage__content party-objective-stage__content';
    if (mission.intro) {
      const intro = document.createElement('p');
      intro.className = 'mission-intro';
      intro.textContent = mission.intro;
      content.appendChild(intro);
    }
    const rules = document.createElement('div');
    rules.className = 'mission-rules';
    renderObjectiveRules(mission.rules, rules);
    content.appendChild(rules);
    if (mission.end) {
      const ending = document.createElement('div');
      ending.className = 'mission-end';
      ending.textContent = `FINAL: ${mission.end}`;
      content.appendChild(ending);
    }
    const reward = document.createElement('div');
    reward.className = 'mission-reward';
    reward.textContent = completed ? `${mission.reward} · COMPLETADA` : mission.reward;
    content.appendChild(reward);

    const economyRoot = document.createElement('div');
    economyRoot.className = 'mission-economy-actions';
    economyRoot.hidden = true;
    content.appendChild(economyRoot);
    renderMissionEconomyActions(mission, code, completed, economyRoot);

    if (!completed && !mission.economy?.resultDriven) {
      const footer = document.createElement('div');
      footer.className = 'operation-stage__footer';
      const complete = economyButton('MARCAR COMO COMPLETADA', 'btn btn--accent objective-card__complete');
      complete.addEventListener('click', () => completeMission(code, complete));
      footer.appendChild(complete);
      content.appendChild(footer);
    }
    stage.panel.appendChild(content);
    return stage.shell;
  }

  function renderPartyObjectives({ preferredOpenCode = '' } = {}) {
    const root = $('#missionCards');
    if (!root) return;
    const discovered = discoveredObjectiveCodes();
    const all = operationObjectiveCodes();
    const status = $('#objectiveDiscoverStatus');
    const remaining = Math.max(0, all.length - discovered.length);
    if (status) status.textContent = discovered.length
      ? `${discovered.length} ${discovered.length === 1 ? 'descubierto' : 'descubiertos'} · ${remaining} ${remaining === 1 ? 'por descubrir' : 'por descubrir'}`
      : `${all.length} ${all.length === 1 ? 'objetivo por descubrir' : 'objetivos por descubrir'}`;

    partyObjectiveAccordion = null;
    root.replaceChildren();
    if (!discovered.length) {
      const placeholder = document.createElement('div');
      placeholder.className = 'mission-card-empty';
      placeholder.innerHTML = '<span aria-hidden="true">⌁</span><strong>Introduce un código para desbloquear tu primer objetivo.</strong>';
      root.appendChild(placeholder);
      return;
    }

    const completedSet = new Set((state.completedMissions || []).map(normalizeCode));
    for (const code of discovered) {
      const card = objectiveCard(code);
      if (card) root.appendChild(card);
    }

    const items = discovered.map((code) => {
      const shell = root.querySelector(`[data-objective-code="${CSS.escape(code)}"]`);
      return {
        id:code,
        shell,
        trigger:shell?.querySelector('.operation-stage__toggle'),
        panel:shell?.querySelector('.operation-stage__panel')
      };
    }).filter((item) => item.shell && item.trigger && item.panel);

    partyObjectiveAccordion = createOperationStageGroup?.({ items, canOpen:() => true, allowCollapse:true }) || null;
    const firstPending = discovered.find((code) => !completedSet.has(code)) || '';
    const requested = normalizeCode(preferredOpenCode || activeMissionCode);
    const openCode = discovered.includes(requested) && !completedSet.has(requested) ? requested : firstPending;
    if (openCode) partyObjectiveAccordion?.setOpen(openCode, { emit:false });

    items.forEach((item) => {
      item.trigger.addEventListener('click', () => {
        activeMissionCode = partyObjectiveAccordion?.getOpen?.() || '';
      });
    });
  }

  async function openMission(code) {
    if (!state.locationUnlocked) return;
    const key = normalizeCode(code);
    const mission = cfg.missions?.[key];
    const message = $('#missionCodeMessage');
    if (message) { message.textContent = ''; message.classList.remove('is-error','is-success'); }
    if (!mission) {
      if (message) { message.textContent = 'Ese código no está activo. Comprueba la tarjeta.'; message.classList.add('is-error'); }
      announceHud('CÓDIGO NO VÁLIDO', { detail:'COMPRUEBA LA TARJETA E INTÉNTALO DE NUEVO', tone:'danger', duration:2300, priority:1 });
      return;
    }

    try {
      const result = await window.DANI_CREW?.discoverMission?.(key);
      if (!result?.profile) throw new Error('No se ha podido desbloquear el objetivo.');
      syncProfile(result.profile);
      activeMissionCode = key;
      renderPartyObjectives({ preferredOpenCode:key });
      if ($('#missionCode')) $('#missionCode').value = '';
      setMissionCodeDrawer(false);
      if (result.alreadyDiscovered) {
        announceHud('OBJETIVO YA DESBLOQUEADO', { detail:mission.title, tone:'default', duration:2200, priority:1 });
      } else {
        announceHud('NUEVO OBJETIVO DESBLOQUEADO', { detail:mission.title, tone:'success', duration:3000, priority:2 });
        pulseMoment(document.querySelector(`[data-objective-code="${CSS.escape(key)}"]`), 'moment-reveal');
      }
      window.setTimeout(() => scrollToElement(document.querySelector(`[data-objective-code="${CSS.escape(key)}"]`), { block:'nearest' }), 80);
    } catch (error) {
      if (message) { message.textContent = error.message || 'No se ha podido desbloquear.'; message.classList.add('is-error'); }
    }
  }

  async function completeMission(missionCode, button) {
    const mission = cfg.missions?.[missionCode];
    if (!mission) return;
    if (button) { button.disabled = true; button.textContent = 'GUARDANDO…'; }
    try {
      const result = await window.DANI_CREW?.completeMission?.(missionCode);
      if (!result?.profile) throw new Error('No se ha podido guardar el progreso.');
      syncProfile(result.profile);
      activeMissionCode = '';
      renderPartyObjectives();
      const reward = result.reward || {};
      const pieces = [];
      if (Number(reward.cash || 0) > 0) pieces.push(`+$${Number(reward.cash)}`);
      if (Number(reward.respect || 0) > 0) pieces.push(`+${Number(reward.respect)} RESPETO`);
      if (Number(reward.stars || 0) > 0) pieces.push(`+${Number(reward.stars)} ★`);
      const progress = operationProgressSnapshot();
      const allDone = !result.alreadyCompleted && progress.total > 0 && progress.completed >= progress.total;
      announceHud(result.alreadyCompleted ? '✓ OBJETIVO YA REGISTRADO' : (allDone ? '✓ TODOS LOS OBJETIVOS COMPLETADOS' : '✓ OBJETIVO COMPLETADO'), {
        detail:result.alreadyCompleted ? objectiveProgressDetail(['TU PROGRESO YA ESTABA GUARDADO']) : objectiveProgressDetail(pieces),
        tone:'success', duration:allDone ? 3400 : 2900, priority:allDone ? 3 : 2
      });
    } catch (error) {
      announceHud('OBJETIVO NO GUARDADO', { detail:error.message || 'VUELVE A INTENTARLO', tone:'danger', duration:2600, priority:2 });
      if (button) { button.disabled = false; button.textContent = 'MARCAR COMO COMPLETADA'; }
    }
  }

  function renderWantedLevel() {
    renderHud();
  }

  function moneyBundleMarkup() {
    return '<span class="street-cash__note street-cash__note--1">$</span><span class="street-cash__note street-cash__note--2">$</span><span class="street-cash__note street-cash__note--3">$</span><span class="street-cash__band"></span>';
  }

  function createMoneySlots() {
    // v22.97 · Los billetes ya no dependen de IDs de fases concretas. La estructura
    // de Operación 30 puede crecer o mover bloques sin romper la búsqueda: cada
    // billete busca superficies informativas visibles de la página actual.
    moneySlots = [
      { index:1, id:'cash-1', gate:'confirmed', delay:[2400,3600], first:true, spawned:false, targetElement:null },
      { index:2, id:'cash-2', gate:'confirmed', delay:[4200,6500], spawned:false, targetElement:null },
      { index:3, id:'cash-3', gate:'confirmed', delay:[4800,7200], spawned:false, targetElement:null },
      { index:4, id:'cash-4', gate:'unlocked', delay:[1800,3200], spawned:false, targetElement:null },
      { index:5, id:'cash-5', gate:'unlocked', delay:[3800,6200], spawned:false, targetElement:null }
    ];
  }

  function cashCollectedCount() {
    return Math.max(0, Math.min(5, Number(activeProfile?.cashCollectedCount || 0)));
  }

  function moneyGateOpen(gate) {
    // Nunca existe botín anónimo: hasta que no hay personaje confirmado no se
    // genera ningún billete. El hack y sus transiciones son zonas de concentración.
    if (hackPlaying || hackSaving || !missionOpen || experienceMode !== 'invite' || !activeProfile?.id || state.attendance !== 'yes') return false;
    if (gate === 'confirmed') return true;
    if (gate === 'unlocked') return state.locationUnlocked;
    return false;
  }

  function suspendMoneyHunt() {
    if (moneySyncTimerId !== null) {
      window.clearTimeout(moneySyncTimerId);
      moneySyncTimerId = null;
    }
    moneyNextSpawnAt = 0;
    const layer = $('#moneyHuntLayer');
    if (layer) {
      layer.replaceChildren();
      layer.setAttribute('aria-hidden','true');
      layer.removeAttribute('hidden');
    }
    moneySlots.forEach((slot) => {
      slot.spawned = false;
      slot.targetElement = null;
    });
  }

  function moneyViewportBounds() {
    const hudRect = $('#hud')?.hidden ? null : $('#hud')?.getBoundingClientRect();
    const top = Math.max(14, hudRect ? Math.min(window.innerHeight - 100, hudRect.bottom + 14) : 14);
    return {
      top,
      bottom:Math.max(top + 90, window.innerHeight - 22),
      left:window.innerWidth <= 520 ? 18 : 28,
      right:window.innerWidth - (window.innerWidth <= 520 ? 18 : 28)
    };
  }

  function moneyTargetIsUsable(element) {
    if (!element || !element.isConnected || element.closest('[hidden]')) return false;
    if (element.matches?.('#safehouseHack,.hack,[data-money-exclude]') || element.closest?.('#safehouseHack,.hack,[data-money-exclude]')) return false;
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity || 1) <= .05) return false;
    const rect = element.getBoundingClientRect();
    const viewport = moneyViewportBounds();
    const visibleWidth = Math.min(rect.right, viewport.right) - Math.max(rect.left, viewport.left);
    const visibleHeight = Math.min(rect.bottom, viewport.bottom) - Math.max(rect.top, viewport.top);
    return visibleWidth >= Math.min(150, rect.width * .45) && visibleHeight >= Math.min(74, rect.height * .42);
  }

  function pointOverImportantControl(x, y) {
    const hit = document.elementFromPoint(x, y);
    if (!hit) return false;
    return Boolean(hit.closest('button,a,input,textarea,select,label,[role="button"],[role="link"],.terminal__screen,.operation-progress,#safehouseHack,.hack'));
  }

  function moneyPositionInside(element, slot) {
    if (!moneyTargetIsUsable(element)) return null;
    const rect = element.getBoundingClientRect();
    const viewport = moneyViewportBounds();
    const visible = {
      left:Math.max(rect.left, viewport.left),
      right:Math.min(rect.right, viewport.right),
      top:Math.max(rect.top, viewport.top),
      bottom:Math.min(rect.bottom, viewport.bottom)
    };
    const visibleWidth = visible.right - visible.left;
    const visibleHeight = visible.bottom - visible.top;
    if (visibleWidth < 100 || visibleHeight < 58) return null;

    // Se esconde cerca de los bordes del bloque para que parezca encontrado y no
    // un CTA nuevo. Los controles, el terminal y el hack quedan siempre fuera.
    for (let attempt = 0; attempt < 14; attempt += 1) {
      const side = attempt < 8 ? (Math.random() < .5 ? 'left' : 'right') : (attempt % 2 ? 'left' : 'right');
      const edgeInset = Math.min(window.innerWidth <= 520 ? 42 : 60, Math.max(28, visibleWidth * (.10 + Math.random() * .08)));
      const x = side === 'left' ? visible.left + edgeInset : visible.right - edgeInset;
      const yPad = Math.min(52, Math.max(22, visibleHeight * .14));
      const y = visible.top + yPad + Math.random() * Math.max(10, visibleHeight - yPad * 2);
      if (pointOverImportantControl(x, y)) continue;
      return { x, y:window.scrollY + y, target:element };
    }
    return null;
  }

  function moneySurfaceElements(slot) {
    // Los bloques normalizados de las fases son la fuente principal. Esto hace que
    // Fase 4, Fase 5 y cualquier bloque futuro entren automáticamente en el sistema.
    const candidates = [
      ...document.querySelectorAll('#missionFlow .operation-info-block'),
      $('#heistPreview')
    ].filter(Boolean);
    const unique = [...new Set(candidates)].filter((element) => moneyTargetIsUsable(element));

    // Si todavía no se ha localizado el refugio, los billetes 4/5 ni siquiera
    // consideran superficies posteriores, en línea con la validación del servidor.
    if (slot?.gate === 'unlocked' && !state.locationUnlocked) return [];

    // Mantener la superficie anterior evita saltos si continúa visible; el resto se
    // baraja para que los hallazgos no aparezcan siempre en el mismo sitio.
    const preferred = slot?.targetElement && unique.includes(slot.targetElement) ? slot.targetElement : null;
    const rest = unique.filter((element) => element !== preferred);
    for (let i = rest.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [rest[i], rest[j]] = [rest[j], rest[i]];
    }
    return preferred ? [preferred, ...rest] : rest;
  }

  function findMoneyPosition(slot) {
    const candidates = moneySurfaceElements(slot);
    for (const element of candidates) {
      const position = moneyPositionInside(element, slot);
      if (position) {
        slot.targetElement = element;
        return position;
      }
    }
    slot.targetElement = null;
    return null;
  }

  function moneySpawnDelay(slot) {
    if (reduceMotion) return 300;
    const [min, max] = Array.isArray(slot?.delay) ? slot.delay : [3200,5200];
    return min + Math.round(Math.random() * Math.max(0, max - min));
  }

  function spawnMoneySlot(slot) {
    const layer = $('#moneyHuntLayer');
    if (!layer || slot.spawned || !moneyGateOpen(slot.gate)) return false;
    const position = findMoneyPosition(slot);
    if (!position) return false;

    const bundle = document.createElement('button');
    bundle.type = 'button';
    bundle.className = `street-cash${slot.first ? ' street-cash--first' : ''}`;
    bundle.setAttribute('aria-label', slot.first ? 'Billetes ocultos. Has encontrado botín.' : 'Billetes ocultos');
    bundle.dataset.moneySlot = slot.id;
    bundle.dataset.moneyIndex = String(slot.index);
    bundle.style.left = `${Math.round(position.x)}px`;
    bundle.style.top = `${Math.round(position.y)}px`;
    bundle.style.setProperty('--cash-rot', `${Math.round(-13 + Math.random() * 26)}deg`);
    bundle.style.setProperty('--cash-delay', `${Math.round(Math.random() * 180)}ms`);
    bundle.innerHTML = moneyBundleMarkup();
    bundle.addEventListener('click', stealMoneyBundle, { once:true });
    layer.appendChild(bundle);
    slot.spawned = true;
    return true;
  }

  function syncMoneyBundles() {
    const layer = $('#moneyHuntLayer');
    if (!layer || moneyClaimInFlight) return;
    const collected = cashCollectedCount();
    const available = missionOpen && experienceMode === 'invite' && Boolean(activeProfile?.id) && state.attendance === 'yes' && !hackPlaying && !hackSaving && !policeActive && wantedLevel < 5 && collected < 5;
    if (!available) {
      layer.replaceChildren();
      layer.setAttribute('aria-hidden','true');
      moneyNextSpawnAt = 0;
      return;
    }
    if (!moneySlots.length) createMoneySlots();

    const next = moneySlots.find((slot) => slot.index === collected + 1);
    layer.querySelectorAll('.street-cash').forEach((bundle) => {
      if (!next || bundle.dataset.moneySlot !== next.id) bundle.remove();
    });
    moneySlots.forEach((slot) => { if (!next || slot.id !== next.id) slot.spawned = false; });

    if (!next || !moneyGateOpen(next.gate)) {
      moneyNextSpawnAt = 0;
      layer.setAttribute('aria-hidden','true');
      return;
    }

    // Los mensajes del HUD tienen prioridad. El botín espera a que termine el momento
    // de recompensa para no competir por la atención del jugador.
    if (hudAnnouncementActive || hudAnnouncementQueue.length) {
      moneyNextSpawnAt = 0;
      layer.setAttribute('aria-hidden','true');
      scheduleMoneySync(520);
      return;
    }

    const existing = layer.querySelector(`[data-money-slot="${next.id}"]`);
    if (existing && !existing.classList.contains('is-stolen')) {
      const rect = existing.getBoundingClientRect();
      const viewport = moneyViewportBounds();
      const stillVisible = rect.bottom > viewport.top && rect.top < viewport.bottom && rect.right > viewport.left && rect.left < viewport.right;
      const target = next.targetElement;
      if (stillVisible && moneyTargetIsUsable(target)) {
        layer.setAttribute('aria-hidden','false');
        return;
      }
      // Si el jugador abandona la zona, el secreto no queda perdido detrás:
      // se retira y espera una nueva oportunidad de aparecer durante la exploración.
      existing.remove();
      next.spawned = false;
      next.targetElement = null;
      moneyNextSpawnAt = Date.now() + (reduceMotion ? 120 : 650);
    }

    // No iniciamos siquiera la cuenta atrás hasta tener una superficie válida visible.
    // Esto evita que el tiempo se consuma mientras el usuario está en otra parte.
    if (!findMoneyPosition(next)) {
      layer.setAttribute('aria-hidden','true');
      moneyNextSpawnAt = 0;
      return;
    }

    if (!moneyNextSpawnAt) moneyNextSpawnAt = Date.now() + moneySpawnDelay(next);
    const remaining = moneyNextSpawnAt - Date.now();
    if (remaining > 30) {
      layer.setAttribute('aria-hidden','true');
      scheduleMoneySync(Math.min(remaining, 900));
      return;
    }

    moneyNextSpawnAt = 0;
    next.spawned = false;
    if (spawnMoneySlot(next)) layer.setAttribute('aria-hidden','false');
    else {
      layer.setAttribute('aria-hidden','true');
      scheduleMoneySync(450);
    }
  }

  function scheduleMoneySync(delay = 0) {
    if (moneySyncTimerId !== null) window.clearTimeout(moneySyncTimerId);
    moneySyncTimerId = window.setTimeout(() => {
      moneySyncTimerId = null;
      window.requestAnimationFrame(() => window.requestAnimationFrame(syncMoneyBundles));
    }, delay);
  }

  function announceCashEvent({ amount = 0, cash = activeProfile?.cash || 0, message = '', retained = false, error = false } = {}) {
    const total = `$${Math.max(0, Number(cash || 0)).toLocaleString('es-ES')}`;
    if (error) {
      announceHud('BOTÍN NO GUARDADO', { detail:message || 'VUELVE A INTENTARLO', tone:'danger', duration:2600 });
      return;
    }
    if (retained) {
      announceHud('★★★★★ · NIVEL MÁXIMO', { detail:`BOTÍN A SALVO · ${total}`, tone:'success', duration:3100 });
      return;
    }
    if (amount > 0) {
      const count = Math.max(0, Number(activeProfile?.cashCollectedCount || 0));
      const complete = count >= 5;
      announceHud(complete ? 'BOTÍN RECUPERADO' : `+$${amount} ENCONTRADOS`, {
        detail:complete ? 'HAS ENCONTRADO LOS 5 BILLETES' : `${Math.min(count, 5)}/5 BILLETES`,
        tone:complete ? 'success' : 'cash',
        level:complete ? 'important' : 'routine',
        priority:complete ? 2 : 1
      });
      return;
    }
    announceHud(message || 'BOTÍN ACTUALIZADO', { detail:`TOTAL ${total}`, tone:'cash' });
  }

  function closePoliceEffectVisual() {
    if (policeTimerId !== null) { window.clearTimeout(policeTimerId); policeTimerId = null; }
    if (policeStartTimerId !== null) { window.clearTimeout(policeStartTimerId); policeStartTimerId = null; }
    policeActive = false;
    const overlay = $('#policeOverlay');
    overlay?.classList.remove('show');
    overlay?.setAttribute('aria-hidden','true');
    document.body.classList.remove('police-shake');
  }

  async function finishPoliceEffect() {
    closePoliceEffectVisual();
    $('#moneyHuntLayer')?.replaceChildren();
    $('#moneyHuntLayer')?.setAttribute('aria-hidden','true');
    try {
      const result = await window.DANI_CREW?.escapePolice?.();
      if (result?.profile) syncProfile(result.profile);
      else renderWantedLevel();
      announceCashEvent({ cash:result?.profile?.cash ?? activeProfile?.cash ?? 500, retained:true });
    } catch (error) {
      console.warn('No se ha podido guardar el final de la persecución', error);
      renderWantedLevel();
    }
  }

  function triggerPoliceEffect({ preview = false, onComplete = null } = {}) {
    if (policeActive) return false;
    if (policeStartTimerId !== null) { window.clearTimeout(policeStartTimerId); policeStartTimerId = null; }
    policeActive = true;
    if (!preview) {
      $('#moneyHuntLayer')?.replaceChildren();
      $('#moneyHuntLayer')?.setAttribute('aria-hidden','true');
    }
    const overlay = $('#policeOverlay');
    overlay?.classList.add('show');
    overlay?.setAttribute('aria-hidden','false');
    if (!reduceMotion) document.body.classList.add('police-shake');
    policeTimerId = window.setTimeout(async () => {
      if (preview) closePoliceEffectVisual();
      else await finishPoliceEffect();
      if (typeof onComplete === 'function') onComplete();
    }, reduceMotion ? 900 : 3200);
    return true;
  }

  function previewWantedEffect() {
    return new Promise((resolve) => {
      const started = triggerPoliceEffect({ preview:true, onComplete:() => resolve(true) });
      if (!started) resolve(false);
    });
  }

  async function stealMoneyBundle(event) {
    if (hackPlaying || hackSaving || policeActive || wantedLevel >= 5 || !activeProfile) return;
    const bundle = event.currentTarget;
    if (!bundle || bundle.classList.contains('is-stolen') || bundle.classList.contains('is-claiming')) return;
    const index = Number.parseInt(bundle.dataset.moneyIndex, 10);
    if (!Number.isFinite(index)) return;
    bundle.classList.add('is-claiming');
    bundle.disabled = true;
    moneyClaimInFlight = true;

    try {
      const result = await window.DANI_CREW?.collectMoney?.(index);
      const profile = result?.profile;
      if (!profile) throw new Error('No se han podido guardar los fondos.');
      syncProfile(profile);
      window.DANI_MOTION?.pulseCash?.();
      const slot = moneySlots.find((item) => item.index === index);
      if (slot) slot.spawned = false;
      bundle.classList.remove('is-claiming');
      bundle.classList.add('is-stolen');
      announceCashEvent({ amount:result.amount ?? 100, cash:profile.cash });

      if (!reduceMotion) {
        const hud = $('#hudWanted');
        if (hud) {
          const cashRect = bundle.getBoundingClientRect();
          const hudRect = hud.getBoundingClientRect();
          const dx = hudRect.left + hudRect.width / 2 - (cashRect.left + cashRect.width / 2);
          const dy = hudRect.top + hudRect.height / 2 - (cashRect.top + cashRect.height / 2);
          bundle.style.setProperty('--steal-x', `${Math.round(dx)}px`);
          bundle.style.setProperty('--steal-y', `${Math.round(dy)}px`);
        }
      }
      window.setTimeout(() => {
        bundle.remove();
        moneyClaimInFlight = false;
        moneyNextSpawnAt = 0;
        if (Number(profile.wantedLevel || 0) >= 5 && Number(profile.cashCollectedCount || 0) >= 5) {
          policeStartTimerId = window.setTimeout(triggerPoliceEffect, reduceMotion ? 100 : 180);
        } else {
          scheduleMoneySync(reduceMotion ? 300 : 1200);
        }
      }, reduceMotion ? 20 : 560);
    } catch (error) {
      moneyClaimInFlight = false;
      bundle.classList.remove('is-claiming');
      bundle.disabled = false;
      announceCashEvent({ cash:activeProfile?.cash || 0, message:error.message || 'NO SE HA PODIDO GUARDAR EL BOTÍN', error:true });
      scheduleMoneySync(500);
    }
  }

  function guardDisabledMapLink(event) {
    const link = event.currentTarget;
    if (link.getAttribute('aria-disabled') === 'true' || !link.getAttribute('href') || link.getAttribute('href') === '#') {
      event.preventDefault();
    }
  }

  function resetDemo() {
    const accepted = window.confirm('¿Reiniciar esta visita? Se reabrirá la portada y se limpiará el estado temporal, pero D1 conservará el progreso real del personaje.');
    if (!accepted) return;
    storage.remove(sessionStorage, ENTRY_DISMISSED_KEY, PENDING_BRIEFING_KEY, HEIST_TRANSITION_SEEN_KEY, 'dani30-session-mode-v1', 'dani30-dev-mode');
    window.location.href = window.location.pathname;
  }

  hudMenuController = createDropdown?.({
    shell:'#hudMenu',
    trigger:'#hudMenuToggle',
    panel:'#hudMenuPanel',
    openClass:'is-open',
    canOpen:() => true,
    label:hudMenuAriaLabel
  });
  // El perfil pertenece al HUD: se abre como dropdown anclado, no como sheet gestual.
  operationAccordion = createOperationStageGroup?.({
    items:[1,2,3,4,5].map((stage) => ({
      id:stage,
      shell:`#operationStage${stage}`,
      trigger:`#operationStage${stage}Toggle`,
      panel:`#operationStage${stage}Panel`
    })),
    canOpen:(stage) => operationStageState().stages[Number(stage)] !== 'locked'
  });

  $('#startMission').addEventListener('click', () => {
    if (heistTransitionBusy) return;
    const button = $('#startMission');
    const action = button?.dataset.entryAction || 'start';
    const target = button?.dataset.entryTarget || getResumeTarget();
    if (action === 'heist') {
      requestHeistEntry();
      return;
    }
    enterOperationFromLanding({ action, target });
  });
  $('#heroSecondaryAction')?.addEventListener('click', () => {
    if (heistTransitionBusy) return;
    const target = $('#heroSecondaryAction')?.dataset.entryTarget || getResumeTarget();
    enterOperationFromLanding({ action:'review', target });
  });
  $('#devSkipHack').addEventListener('click', async () => {
    if (!cfg.developmentMode || state.attendance !== 'yes') return;
    hackPlaying = false;
    hackCompleted = true;
    await completeHack();
  });
  $('#acceptMission')?.addEventListener('click', acceptMissionRsvp);
  $('#declineForm').addEventListener('submit', submitDecline);
  $('#declineBack').addEventListener('click', () => { $('#declineForm').hidden = true; renderState(); });
  $('#declineMission')?.addEventListener('click', declineMissionRsvp);
  $('#backToRsvpDecision')?.addEventListener('click', backToRsvpDecision);
  $('#changeDecline')?.addEventListener('click', () => { state.attendance = null; rsvpEditing = false; renderState(); scrollToId('rsvp'); });
  $('#completeBriefing')?.addEventListener('click', () => { completeBriefing(); });
  $('#rsvpForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (rsvpBusy) return;
    const button = event.currentTarget.querySelector('[type="submit"]');
    rsvpBusy = true; button.disabled = true; button.textContent = 'GUARDANDO…';
    try { await submitRsvp(event); } finally { rsvpBusy = false; button.disabled = false; button.textContent = 'CONFIRMAR ASISTENCIA'; }
  });
  $('#unconfirmRsvp').addEventListener('click', declineMissionRsvp);
  $('#startHack').addEventListener('click', startHack);
  $('#completePartyPrep')?.addEventListener('click', completePartyPrep);
  $$('#hackPads button').forEach((button) => button.addEventListener('click', () => handlePad(button)));
  $('#toggleMissionCode')?.addEventListener('click', () => setMissionCodeDrawer(Boolean($('#missionCodeDrawer')?.hidden), { focus:true }));
  $('#redeemMission')?.addEventListener('click', () => openMission($('#missionCode')?.value));
  $('#missionCode').addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      openMission(event.currentTarget.value);
    }
  });
  $$('[data-demo]').forEach((button) => button.addEventListener('click', () => {
    $('#missionCode').value = button.dataset.demo;
    openMission(button.dataset.demo);
  }));
  $$('.map-launch').forEach((link) => link.addEventListener('click', guardDisabledMapLink));
  $('#retryLocation').addEventListener('click', renderLocation);
  $('#resetDemo').addEventListener('click', resetDemo);
  document.addEventListener('dani:disclosure-change', () => {
    if (missionOpen && experienceMode === 'invite') scheduleMoneySync(60);
  });
  window.addEventListener('resize', () => {
    if (missionOpen && experienceMode === 'invite') scheduleMoneySync(90);
  });
  window.addEventListener('scroll', () => {
    if (missionOpen && experienceMode === 'invite') scheduleMoneySync(120);
  }, { passive:true });

  pinCombinationController = createPinCombinationController();
  window.DANI_PIN_LOCK = pinCombinationController;

  function showInviteLanding() {
    storage.remove(sessionStorage, ENTRY_DISMISSED_KEY);
    missionOpen = false;
    experienceMode = 'invite';
    const party = $('#partyMode');
    const main = $('main');
    if (main) main.hidden = false;
    if (party) party.hidden = true;
    document.body.classList.remove('party-mode-active');
    document.body.dataset.experienceMode = 'invite';
    renderState();
    window.scrollTo({ top:0, behavior:'auto' });
  }

  window.DANI_APP = {
    resetPlayerProgress: resetSecureProgress,
    getState: () => ({ ...state }),
    renderState,
    refreshHud: renderHud,
    scrollToId,
    setHudMenuOpen,
    syncProfile,
    setExperienceMode,
    openPreparation,
    requestHeistEntry,
    announceHud,
    previewWantedEffect,
    showInviteLanding,
    getEventSnapshot:eventSnapshot
  };

  setExperienceMode('invite', null);
  if (missionOpen && !moneySlots.length) createMoneySlots();
  renderState();
  startEventClockTicker();
})();
