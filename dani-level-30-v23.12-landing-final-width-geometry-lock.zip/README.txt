v23.12 · LANDING FINAL-WIDTH GEOMETRY LOCK
- Corrige el ensanchado al terminar Landing → Invitados: `main` conserva el gutter y Hero/Operación 30 usan el 100% de ese ancho, sin restar márgenes dos veces.
- La transición mantiene el mismo ancho visible antes y después del settle; sin cambios de gameplay ni datos.

v23.11 · PRELOADED CINEMATIC INVITATION SETTLE
- La transición inicial gana tiempo útil (~2,28 s): el sol actúa como puente mientras se estabiliza la portada de invitados detrás.
- Render previo, espera acotada a fuentes/La Banda y revelado diferido de HUD + Operación 30 para reducir layout shifts al terminar.
- Sin loader visible ni bloqueo por red lenta.

v23.10 · LANDING SUN-PORTAL SPLIT TRANSITION
- Rework de la transición portada inicial → invitados: poster out → sun portal → invitation copy → split HUD/Operation 30.
- Se elimina el ghost morph para evitar cambios de color y saltos tipográficos.

v23.09 · SILENT CREW REFRESH

v23.08 · SEAMLESS LANDING → INVITATION SPLIT MORPH
- GTA Birthday conserva su inclinación de -3° durante toda la animación inicial; desaparece el salto horizontal → diagonal.
- Rework del cambio Landing → Invitados: el contenido inicial viaja mediante una capa visual temporal hacia la geometría final mientras la portada real ya se asienta debajo, evitando el salto de centrado a alineación final.
- El HUD sale desde detrás de la portada hacia arriba y Operación 30 emerge como un único bloque desde detrás de la portada hacia abajo.
- Sin cambios de gameplay, scoring, persistencia ni motores. Reduced Motion conserva entrada inmediata.

v23.07 · CREW OPEN MOTION FIX

v23.06 · CINEMATIC LANDING → INVITATION MORPH
- Rework de la primera entrada: el escenario se construye por capas y el CTA aparece como último beat.
- INICIAR OPERACIÓN transforma el mismo hero inicial en la portada de invitados, sin corte ni loader intermedio.
- El HUD nace desde la zona superior durante la transformación y Operación 30 emerge desde abajo con timing escalonado.
- La transición completa dura ~1,2 s y queda reservada al cambio de capítulo; el scroll normal permanece tranquilo.
- Gameplay, scoring, Worker y D1 no cambian. Reduced Motion mantiene acceso inmediato.

v23.05 · MOTION POLISH PASS
- Evolución de motion design centrada en feedback, jerarquía y transiciones narrativas; no añade movimiento continuo al scroll.
- Primera entrada por capas, press states, progresión de fases, El Golpe expandible, La Banda/perfil, pickup de dinero, entrada a Operaciones Clandestinas y resultados reciben microinteracciones coherentes.
- Gameplay, scoring, Worker y D1 no cambian.
- Reduced Motion conserva el flujo sin depender de animaciones.

v23.04 · INVITE HUD NOTIFICATION DIRECTOR
- Mantiene exactamente el HUD y su animación visual; mejora solo contenido, timing y reglas de aparición.
- Tiempos: rutina ~2,8 s · social ~3,8 s · importante ~4,7 s · crítico ~5,8 s, contados después de la entrada.
- Avisos espontáneos: cooldown 45 s, deduplicación por sesión y bloqueo durante el hack.
- Actividad social basada solo en cambios reales de La Banda; sin actividad inventada.

v23.03 · CONSERVATIVE HUD INTEGRATION
- Evolución visual mínima del HUD fijo superior sobre la base v23.01.
- Misma estructura, scroll, estrellas, personaje, dinero y animación de notificaciones.
- Fondo grafito-ciruela apenas más integrado, sombra más corta, borde más suave y fade inferior de 7–8 px para reducir la sensación de barra pegada sobre el contenido.
- Sin cambios de gameplay ni lógica de negocio.

v23.01 · EL GOLPE CARD BACKGROUND CLEANUP

v23.00 · BRECHA 30 DIFFICULTY REBALANCE
- Engine V7 evita patrones casi completamente llenos y mantiene densidad cognitiva equilibrada.
- Cuadrículas progresivas hasta 8×8, preview fijo y patrones más fragmentados.
- PROJECT-GUIDE.md actualizado con la regla vigente.

DANI LEVEL 30 · v22.99 · DEVELOPMENT CONTRACT + IMPACT-BASED TESTING
===============================================================

START HERE
----------
`PROJECT-GUIDE.md` is the current source of truth for architecture, invariants, handoff and testing strategy.

IMPORTANT FOR NEW CHATS / FUTURE DEVELOPMENT
---------------------------------------------
- Read `PROJECT-GUIDE.md` before modifying the project.
- Use `test-impact-map.json` + `npm run test:impact -- <changed files>` for iterative validation.
- Update the guide and impact map in the SAME change whenever architecture, persistence, game rules or test ownership changes.
- Do not infer current requirements from the historical changelog below. It is retained only for traceability.
- The delivered ZIP is the handoff artifact and must remain self-consistent.

CURRENT VALIDATION POLICY
-------------------------
- Local UI/copy/layout: targeted impact tests only.
- Progression/crew/D1/rankings: affected functional + persistence tests.
- Game engine/scoring/Worker/schema: game + backend/shared parity tests.
- Production/release candidate: full or bounded audit as documented in PROJECT-GUIDE.md.

HISTORICAL CHANGELOG · NON-AUTHORITATIVE
========================================
The entries below describe previous releases. They may mention structures that no longer exist.
They must never override `PROJECT-GUIDE.md`, current code, or current tests.

v22.98 · EXPANDABLE EL GOLPE GATEWAY + CONTEXTUAL UX

v22.97 · MINIMAL CREW + ADAPTIVE HIDDEN CASH

v22.96 · DYNAMIC EL GOLPE GATEWAY

v22.95 · FIVE-PHASE PROGRESS STEPPER

v22.94 · FIVE-PHASE PREPARATION FLOW

v22.93 · OPERATION 30 UNIFIED PHASE PILL SYSTEM

v22.92 · FASE 04 + ARQUITECTURA DE PREPARACIÓN

v22.91 · PUNTO CIEGO READABLE MOTION REWORK

v22.90 · PUNTO CIEGO GAME FEEL SECOND PASS

v22.89 · PUNTO CIEGO CLARITY-FIRST VISUAL REWORK

v22.89 · BOTÍN 30 LAYOUT REBALANCE

v22.87 · FULLSCREEN UNIFIED LOADING SCREENS

v22.86 · PUNTO CIEGO CONSOLE + VAULT SCENE POLISH

v22.85 · BOTÍN 30 V10 · RANDOM START / HIGH-PRECISION CAPTURE

v22.84 · PUNTO CIEGO NARRATIVE SCENE REWORK

v22.83 · BOTÍN 30 V9 · PRECISION REWORK

v22.82 · RESPONSIVE RESULT SCREENS REWORK

v22.81 · PUNTO CIEGO REWORK / POLICE PATROL + CLEANER HUD

v22.80 · UNIFIED GAME SHELLS / COMPACT GENERAL UX
- Arcade narrativo renombrado: BRECHA 30 → PUNTO CIEGO 30 → BOTÍN 30 → FUGA 30.
- Nuevo PUNTO CIEGO 30 (amarillo): 3 patrullas, percepción temporal y pulsación en cualquier zona libre de la pantalla.
- Cada partida contiene una patrulla rápida, una media y una lenta, con orden y tiempos aleatorios deterministas para mantener la competición comparable.
- La puntuación suma el error ABSOLUTO de las tres rondas; adelantarse y retrasarse nunca se compensan. Gana la marca más cercana a 0,000 s.
- Ranking individual de referencia, clasificación general única, actividad, datos de prueba, exportación y resets integrados en Worker/Admin.
- APIs y tablas históricas de BRECHA/BOTÍN conservan identificadores internos anteriores para no romper datos ya existentes.

DANI LEVEL 30 · v22.77 · ADMIN FULLSCREEN LIGHT + EMAIL SETUP FIX
======================================================

BASE
----
- Construida sobre v22.68.
- FUGA pasa a rulesVersion 9 porque cambia el comportamiento real del tráfico y por tanto puede afectar a las marcas.
- V7 y V8 se conservan como histórico. CAJA e INFILTRACIÓN no cambian.

PASOS DE CEBRA
--------------
- Los pasos aparecen con frecuencia baja y son más probables en bloques largos, donde resultan más útiles.
- La pintura existe únicamente sobre la calzada: empieza y termina exactamente en el bordillo, nunca encima de la acera.
- Siempre se reserva su entrada y su salida en ambas zonas seguras: ningún árbol, banco, valla, jardinera, farola u obstáculo puede cerrar el corredor.
- Un cruce válido empieza en una zona segura, permanece dentro del corredor y termina en la zona segura opuesta.
- Cruzar hacia atrás, salir del corredor o simplemente pisarlo no cuenta.

BUEN CIUDADANO · CICLO 1 → 1
-----------------------------
- Un único paso de cebra normal cruzado correctamente desbloquea PRIORIDAD PEATONAL.
- El feedback muestra BUEN CIUDADANO / PRIORIDAD PEATONAL CONSEGUIDA.
- El siguiente paso de cebra generado se convierte en dorado.
- Si se ignora ese paso dorado o se abandona su corredor, la oportunidad se pierde.
- Tras consumirlo, hace falta volver a cruzar otro paso normal para conseguir una nueva prioridad.

PASO DORADO
-----------
- Al entrar correctamente se activa PRIORIDAD PEATONAL.
- El tráfico civil que todavía no ha invadido el paso frena antes de la pintura y mantiene cola/separación.
- Los vehículos que ya estaban dentro cuando se activó pueden terminar de salir.
- La protección solo aplica dentro del corredor del paso.
- Al completar el cruce se mantiene una breve liberación de tráfico para evitar arrancadas bruscas junto al jugador.

BOMBEROS · EXCEPCIÓN DE EMERGENCIA
----------------------------------
- Los carriles de bomberos son carriles de emergencia especiales y más rápidos que antes.
- El camión circula con una velocidad mínima claramente superior al tráfico rápido normal.
- Antes de entrar aparece desde su lado de origen un aviso luminoso y la palabra BOMBEROS parpadeando.
- El camión de bomberos NO respeta PRIORIDAD PEATONAL: si hay una emergencia, atraviesa el paso dorado.
- El aviso previo es la contrapartida de justicia: el jugador debe leerlo y ceder el paso.
- El tráfico civil sí sigue detenido durante la prioridad.

COMPETICIÓN Y D1
-----------------
- FUGA usa rulesVersion 9.
- Se crean crossing_v11_scores, crossing_v11_runs, crossing_v11_awards y crossing_v11_podium_awards.
- crossing_v7_* y crossing_v8_* se conservan como histórico.
- Cliente y Worker comparten el mismo motor determinista V11 y el Worker reconstruye el replay autoritativamente.
- La snapshot local del concurso usa fuga-crossing-v11.

DESPLIEGUE
----------
1. Descomprime el ZIP y despliega todo el contenido manteniendo index.html y _worker.js en la raíz.
2. Conserva bindings y secrets actuales.
3. El Worker crea automáticamente las tablas V11 si todavía no existen.
4. schema.sql incluye V7, V8, V9, V10 y V11 para instalaciones nuevas.
5. Cache-busting: 22.77.

VALIDACIÓN
----------
- Un cruce normal válido -> siguiente paso dorado.
- Paso dorado consumido -> vuelve a requerir otro cruce normal.
- Entrada y salida del paso siempre libres de obstáculos.
- Vehículo civil ya dentro -> continúa.
- Vehículo civil posterior -> se detiene.
- Camión de bomberos -> no se detiene por prioridad y mantiene velocidad de emergencia.
- Ignorar el dorado -> recompensa perdida.
- Replay, API oficial, D1 y ranking se validan con rulesVersion 9.

v22.76 · SESIÓN FUGA
- La partida activa solo vive en la sesión/página actual.
- Cambiar de pestaña o app pausa la partida y permite continuar.
- Salir, recargar, navegar atrás o restaurar la página desde bfcache descarta la partida activa.
- Solo se envía la marca final al ranking; no existe guardado de progreso para reanudar una fuga.


v22.76 · PRIORIDAD PEATONAL · COLAS FÍSICAS
- Los coches retenidos conservan una posición real por carril y ya no atraviesan otros vehículos.
- La cola respeta separación física constante mientras el paso dorado está activo.
- Al liberarse la prioridad, cada vehículo continúa desde su posición detenida sin teletransporte.
- Las luces de freno solo se activan cuando el vehículo está realmente parado.
- BUEN CIUDADANO / PRIORIDAD PEATONAL CONSEGUIDA permanece más tiempo en pantalla.


v22.76 · BOMBEROS V11
- Velocidad de carril de emergencia elevada a 4.35–5.35.
- El aviso previo BOMBEROS se mantiene para conservar justicia y legibilidad.
- Ranking V11 separado; V10 queda como histórico.

v22.76 · AUDIO MÍNIMO FUGA
- Movimiento: feedback muy corto y de volumen bajo.
- Near miss: solo en roces muy cercanos y máximo un efecto sonoro cada 2,8 s; el feedback visual puede aparecer sin repetir sonido.
- BOMBEROS: dos pulsos breves por aparición; no hay sirena continua.
- Atropello/BUSTED: impactos cortos y prioritarios; bloquean momentáneamente el near miss para evitar mezcla.
- Sin ambiente continuo, sin motores por coche y sin nuevas pistas de audio externas.


v22.76 · BOMBEROS EN BLOQUE ACTIVO
- Los eventos de bomberos se reservan al bloque de carretera que el jugador está cruzando.
- El carril de emergencia se sitúa entre los tres primeros carriles del bloque para que el peligro ocurra cerca.
- El evento se activa al entrar al bloque: primero aparece el aviso y el camión entra aproximadamente 1,2 s después.
- Los bloques futuros no muestran ni colisionan con camiones de bomberos antes de ser el bloque activo.


v22.76 · ARCADE UX REWORK
- Selector centrado en jugar: cover, objetivo breve, récord y CTA principal.
- JUGAR inicia directamente INFILTRACIÓN, CAJA o FUGA; las intros dejan de ser una puerta obligatoria.
- INFO y CLASIFICACIÓN se abren como bottom sheets desde el Hub.
- Ranking/premios dejan de ocupar scroll permanente en las pantallas de juego.
- Navegación unificada: × cierra el Arcade; ← durante una partida abre PAUSA.
- Pausa con CONTINUAR / SALIR AL ARCADE para los tres juegos.
- Resultados priorizan OTRA PARTIDA, con clasificación y volver al Arcade como acciones secundarias.
- Sin cambios en reglas competitivas de FUGA V11, CAJA o INFILTRACIÓN.

AUDIO · v22.76
----------------
- Los tres minijuegos usan ahora un master gain moderado (1.9x) para que el audio se perciba con claridad a un volumen normal del dispositivo.
- Se mantienen las diferencias relativas de volumen: movimiento y feedback pequeños siguen por debajo de impactos y eventos importantes.
- BOMBEROS deja de usar el barrido sawtooth anterior. El aviso utiliza dos pulsos fijos tipo emergencia europea con un armónico muy sutil.
- No se añaden loops ambientales ni nuevas pistas de audio.

v22.76 · ARCADE THEME + FUGA ARREST PROXIMITY
- JUGAR usa el color temático de cada juego: INFILTRACIÓN azul, CAJA verde, FUGA rojo.
- Resultados centrados verticalmente y tematizados con el mismo lenguaje de sus portadas.
- La X de Operaciones Clandestinas no cambia visualmente en hover.
- FUGA: cerca de captura el personaje tiembla y suda; aparece “¡DATE PRISA!” debajo del personaje y un pulso sonoro sutil acelera con la proximidad.
- Estos efectos de FUGA son puramente de presentación; no alteran motor, input, colisiones ni dificultad.


v22.76 · SAQUEO 30 V5
- Rework completo de CAJA 30 a SAQUEO 30.
- Dial táctil directo con 5 cerrojos, sentidos alternos y combinación distinta por runId.
- Máximo 1000,0 puntos; penaliza correcciones, recorrido innecesario y distancia final.
- No depende de vibración ni audio: el mecanismo comunica proximidad visualmente.
- Ranking V5 separado de CAJA V4 para preservar justicia competitiva.

v22.76 · SAQUEO 30 · PRECISION BAR V7
- Sustituye Circle Rush V6 por una prueba competitiva de precisión en 5 cierres.
- Una aguja rebota de izquierda a derecha sobre una barra con objetivo visible; cada toque congela la aguja y calcula 0–100% por distancia al centro.
- La velocidad aumenta en cada cierre mientras el tamaño de las zonas de precisión se mantiene constante.
- La precisión mostrada durante la partida es la media acumulada de los intentos completados.
- Resultado final: 85–100% abre la caja limpia; 70–84% la fuerza; menos de 70% activa bloqueo de seguridad; 100% exacto activa GOLPE PERFECTO y lluvia de billetes.
- Ranking V7: precisión media, después mejor peor intento, número de perfectos y duración; Worker reconstruye los 5 taps.
- Ranking V7 independiente; V5/V6 se conservan como histórico.


v22.76 · SAQUEO 30 V8 · GAME FEEL
- La caja se resetea físicamente antes de cada reintento.
- Toda la superficie del juego sirve para fijar la aguja, salvo controles de pausa/salida.
- Barra más gruesa, aguja más fina y mayor separación del HUD.
- Curva de velocidad V8: 1700 / 1300 / 950 / 700 / 520 ms de extremo a extremo.
- Ranking V8 separado de V7 por el aumento material de dificultad.


v22.76 · ADMIN COMMAND CENTER
- Panel de administración reestructurado en Mando, Invitados, Juegos, Actividad y Control.
- Bandeja de atención para bajas con mensaje y alergias/dietas.
- Filtros/búsqueda de invitados, feed de actividad y exportación JSON.
- Mantenimiento selectivo: clasificaciones, progreso, actividad, invitados y preparación de producción.
- Notificaciones de email opcionales mediante Resend REST. Variables recomendadas: RESEND_API_KEY (secreto) y ADMIN_TO_EMAIL (destinatario).
- Sin dominio propio no hace falta ADMIN_FROM_EMAIL: se usa automáticamente `Operación 30 <onboarding@resend.dev>`. En ese modo Resend solo permite enviar al correo propietario de la cuenta de Resend.
- ADMIN_FROM_EMAIL queda como variable opcional para el futuro, cuando exista un dominio verificado.
- Después de crear o modificar variables/secrets de Cloudflare Pages hay que volver a desplegar para que el deployment las reciba.
- El panel permite email de prueba y resumen manual. El resumen diario automático todavía requiere un trigger programado independiente.


v22.77 · ADMIN FULLSCREEN LIGHT + EMAIL
- El panel ocupa el viewport completo y abandona el modal oscuro estrecho.
- Tema claro/blanco para mejorar lectura diurna y densidad de información.
- En pantallas amplias del panel, MANDO/INVITADOS/CONTROL aprovechan columnas adicionales.
- El correo de destino deja de pedirse en el panel: se lee de ADMIN_TO_EMAIL en Cloudflare.
- Resend usa onboarding@resend.dev por defecto mientras no exista dominio propio.
- Diagnóstico visible de API key, destinatario y remitente; los errores reales de Resend se devuelven al panel.
- Modos aclarados: RECOMENDADO (eventos seleccionados), TODO AL MOMENTO, SOLO RESUMEN y DESACTIVADO.


V22.80 · OPERACIÓN 30 GENERAL CHAMPIONSHIP
- One shared podium replaces the four per-game prize podiums.
- Rewards: $1000/+10 respect, $500/+6, $250/+3.
- Only players with a recorded best in all four operations enter the overall table.
- Four hidden normalized components weigh 25% each; public UI does not expose the synthetic score.
- Tie-break: strongest weakest discipline, then next weakest, then earliest completed set.
- Individual rankings remain available as references and no longer grant rewards.

V22.80 · MOBILE GAME SHELL + GENERAL UX REWORK
- PUNTO CIEGO and BOTÍN now reserve the same top navigation band as BRECHA during play.
- PUNTO CIEGO removes its rigid 280 px corridor floor and scales against viewport height.
- BOTÍN removes the oversized fixed play rows; vault size now adapts to both width and viewport height.
- FUGA fullscreen layout is untouched.
- The general championship in Operaciones Clandestinas is now a compact one-line status instead of a hero card.
- General-scoring rules are centralized in a single collapsed disclosure inside the general ranking.
- Per-game ranking text no longer repeats the global scoring explanation.
