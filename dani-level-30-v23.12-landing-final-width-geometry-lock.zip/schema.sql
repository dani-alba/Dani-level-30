-- La web crea esta tabla automáticamente al recibir la primera petición /api/.
-- Este archivo se incluye únicamente como referencia/documentación.
CREATE TABLE IF NOT EXISTS players (
  crew_number INTEGER PRIMARY KEY AUTOINCREMENT,
  id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  attendance TEXT NOT NULL DEFAULT 'yes',
  dietary TEXT NOT NULL DEFAULT '',
  decline_message TEXT NOT NULL DEFAULT '',
  avatar TEXT NOT NULL DEFAULT '🎮',
  photo_data TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  stats_json TEXT NOT NULL DEFAULT '[]',
  specialties_json TEXT NOT NULL DEFAULT '[]',
  special_ability TEXT NOT NULL DEFAULT '',
  pin_hash TEXT,
  pin_salt TEXT,
  session_hash TEXT NOT NULL,
  location_unlocked INTEGER NOT NULL DEFAULT 0,
  briefing_completed INTEGER NOT NULL DEFAULT 0,
  completed_missions_json TEXT NOT NULL DEFAULT '[]',
  discovered_missions_json TEXT NOT NULL DEFAULT '[]',
  wanted_level INTEGER NOT NULL DEFAULT 0,
  wanted_score INTEGER NOT NULL DEFAULT 0, -- legacy alias de game_stars
  game_stars INTEGER NOT NULL DEFAULT 0,
  cash INTEGER NOT NULL DEFAULT 0, -- legacy alias de wallet_balance
  wallet_balance INTEGER NOT NULL DEFAULT 0,
  cash_collected_count INTEGER NOT NULL DEFAULT 0,
  mission_respect INTEGER NOT NULL DEFAULT 0,
  record_clean_count INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  ui_prefs_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_players_attendance ON players(attendance);
CREATE INDEX IF NOT EXISTS idx_players_session ON players(session_hash);

CREATE TABLE IF NOT EXISTS player_sessions (
  session_hash TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_session_player ON player_sessions(player_id);


CREATE TABLE IF NOT EXISTS player_respect (
  giver_id TEXT NOT NULL,
  receiver_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (giver_id, receiver_id)
);

CREATE INDEX IF NOT EXISTS idx_respect_receiver ON player_respect(receiver_id);


-- V21.47 · historial económico. Cada movimiento persistente deja trazabilidad
-- para poder explicar de dónde salen dinero, respeto y estrellas de juego.
CREATE TABLE IF NOT EXISTS economy_events (
  id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  action_id TEXT NOT NULL,
  cash_delta INTEGER NOT NULL DEFAULT 0,
  respect_delta INTEGER NOT NULL DEFAULT 0,
  stars_delta INTEGER NOT NULL DEFAULT 0,
  balance_after INTEGER NOT NULL DEFAULT 0,
  mission_respect_after INTEGER NOT NULL DEFAULT 0,
  game_stars_after INTEGER NOT NULL DEFAULT 0,
  meta_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_economy_player_created ON economy_events(player_id, created_at DESC);


-- V21.88 · Arcade clandestino FUGA 30
CREATE TABLE IF NOT EXISTS arcade_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_arcade_scores_rank ON arcade_scores(high_score DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS arcade_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_arcade_runs_player ON arcade_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS arcade_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);


-- V21.89 · Podio FUGA 30. Premios finales top 3.
CREATE TABLE IF NOT EXISTS arcade_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_arcade_podium_player ON arcade_podium_awards(player_id);

-- V22.10 · CAJA 30 skill rules. Tablas nuevas para no mezclar récords del reglamento V22.09.
CREATE TABLE IF NOT EXISTS safe_skill_scores (
  player_id TEXT PRIMARY KEY,
  best_score_ms INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score_ms INTEGER NOT NULL DEFAULT 0,
  best_elapsed_ms INTEGER NOT NULL DEFAULT 0,
  best_mistakes INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_skill_scores_rank ON safe_skill_scores(best_score_ms ASC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_skill_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  elapsed_ms INTEGER,
  mistakes INTEGER,
  perfects INTEGER NOT NULL DEFAULT 0,
  score_ms INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_skill_runs_player ON safe_skill_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_skill_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score_ms INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_skill_podium_player ON safe_skill_podium_awards(player_id);

-- V22.20 · CAJA 30 sequence rules. Ranking nuevo: niveles 1→5 + precisión continua + desempate por precisión.
CREATE TABLE IF NOT EXISTS safe_sequence_scores (
  player_id TEXT PRIMARY KEY,
  best_score_ms INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score_ms INTEGER NOT NULL DEFAULT 0,
  best_elapsed_ms INTEGER NOT NULL DEFAULT 0,
  best_mistakes INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  best_bonus_ms INTEGER NOT NULL DEFAULT 0,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_worst_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_precision_json TEXT NOT NULL DEFAULT '[]',
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_sequence_scores_rank
  ON safe_sequence_scores(best_score_ms ASC, best_precision_bps DESC, best_worst_precision_bps DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_sequence_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  elapsed_ms INTEGER,
  mistakes INTEGER,
  perfects INTEGER NOT NULL DEFAULT 0,
  bonus_ms INTEGER NOT NULL DEFAULT 0,
  precision_bps INTEGER NOT NULL DEFAULT 0,
  worst_precision_bps INTEGER NOT NULL DEFAULT 0,
  precision_json TEXT NOT NULL DEFAULT '[]',
  perfect_flags_json TEXT NOT NULL DEFAULT '[]',
  score_ms INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_sequence_runs_player ON safe_sequence_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_sequence_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score_ms INTEGER NOT NULL DEFAULT 0,
  winning_precision_bps INTEGER NOT NULL DEFAULT 0,
  winning_worst_precision_bps INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_sequence_podium_player ON safe_sequence_podium_awards(player_id);




-- INFILTRACIÓN 30 · mismo patrón de competición que CAJA 30 y FUGA 30.
CREATE TABLE IF NOT EXISTS operation_infiltration_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  best_rounds_completed INTEGER NOT NULL DEFAULT 0,
  best_failed_round INTEGER NOT NULL DEFAULT 1,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_scores_rank ON operation_infiltration_scores(high_score DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS operation_infiltration_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  rounds_completed INTEGER NOT NULL DEFAULT 0,
  failed_round INTEGER NOT NULL DEFAULT 1,
  result_json TEXT,
  event_log_json TEXT,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_runs_player ON operation_infiltration_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS operation_infiltration_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_podium_player ON operation_infiltration_podium_awards(player_id);

-- V22.61 · FUGA 30 Crossing V3: traffic-variety competition; earlier crossing records retained in their historical tables.
CREATE TABLE IF NOT EXISTS crossing_v3_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v3_scores_rank ON crossing_v3_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v3_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v3_runs_player ON crossing_v3_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v3_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v3_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v3_podium_player ON crossing_v3_podium_awards(player_id);

-- V22.62 · FUGA 30 Crossing V4: variable-gap traffic + half-step lateral control; V3 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v4_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v4_scores_rank ON crossing_v4_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v4_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v4_runs_player ON crossing_v4_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v4_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v4_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v4_podium_player ON crossing_v4_podium_awards(player_id);

-- V22.63 · FUGA 30 Crossing V5: breathable traffic, surprise waves and human-playability validation; V4 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v5_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v5_scores_rank ON crossing_v5_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v5_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v5_runs_player ON crossing_v5_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v5_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v5_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v5_podium_player ON crossing_v5_podium_awards(player_id);


-- V22.64 · FUGA 30 Crossing V6: elastic police pursuit + chained traffic windows; V5 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v6_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v6_scores_rank ON crossing_v6_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v6_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v6_runs_player ON crossing_v6_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v6_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v6_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v6_podium_player ON crossing_v6_podium_awards(player_id);

-- V22.65 · FUGA 30 Crossing V7: tighter pursuit + blocked refuge approaches; V6 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v7_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v7_scores_rank ON crossing_v7_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v7_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v7_runs_player ON crossing_v7_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v7_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v7_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v7_podium_player ON crossing_v7_podium_awards(player_id);



-- V22.60 · CAJA 30 precision V4. Nueva unidad competitiva: puntos (décimas), no tiempo.
CREATE TABLE IF NOT EXISTS safe_precision_scores (
  player_id TEXT PRIMARY KEY,
  best_score_tenths INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score_tenths INTEGER NOT NULL DEFAULT 0,
  best_mistakes INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_hit_precision_json TEXT NOT NULL DEFAULT '[]',
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_precision_scores_rank
  ON safe_precision_scores(best_score_tenths DESC, best_mistakes ASC, best_perfects DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_precision_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 4,
  duration_ms INTEGER,
  score_tenths INTEGER,
  mistakes INTEGER NOT NULL DEFAULT 0,
  perfects INTEGER NOT NULL DEFAULT 0,
  precision_bps INTEGER NOT NULL DEFAULT 0,
  hit_precision_json TEXT NOT NULL DEFAULT '[]',
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_precision_runs_player ON safe_precision_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_precision_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score_tenths INTEGER NOT NULL DEFAULT 0,
  winning_mistakes INTEGER NOT NULL DEFAULT 0,
  winning_perfects INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_precision_podium_player ON safe_precision_podium_awards(player_id);

-- V22.68 · FUGA 30 Crossing V8: pedestrian-priority crosswalk mechanic; V7 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v8_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v8_scores_rank ON crossing_v8_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v8_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v8_runs_player ON crossing_v8_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v8_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v8_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v8_podium_player ON crossing_v8_podium_awards(player_id);

-- V22.69 · FUGA 30 Crossing V9: one-crosswalk reward + emergency vehicle exception; V8 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v9_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v9_scores_rank ON crossing_v9_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v9_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v9_runs_player ON crossing_v9_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v9_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v9_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v9_podium_player ON crossing_v9_podium_awards(player_id);

-- V22.69.4 · FUGA 30 Crossing V10: faster emergency vehicle hazard; V9 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v10_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v10_scores_rank ON crossing_v10_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v10_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v10_runs_player ON crossing_v10_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v10_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v10_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v10_podium_player ON crossing_v10_podium_awards(player_id);

-- V22.69.6 · FUGA 30 Crossing V11: fire emergencies activate in the current road block; V10 retained as history.
CREATE TABLE IF NOT EXISTS crossing_v11_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_crossing_v11_scores_rank ON crossing_v11_scores(high_score DESC, achieved_at ASC);
CREATE TABLE IF NOT EXISTS crossing_v11_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_crossing_v11_runs_player ON crossing_v11_runs(player_id, started_at_ms DESC);
CREATE TABLE IF NOT EXISTS crossing_v11_awards (
  contest_id TEXT PRIMARY KEY,
  winner_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS crossing_v11_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_crossing_v11_podium_player ON crossing_v11_podium_awards(player_id);



-- v22.71 · INFILTRACIÓN 30 V6: run-specific patterns; V5 tables retained as history.
CREATE TABLE IF NOT EXISTS operation_infiltration_v6_scores (
  player_id TEXT PRIMARY KEY,
  high_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score INTEGER NOT NULL DEFAULT 0,
  best_rounds_completed INTEGER NOT NULL DEFAULT 0,
  best_failed_round INTEGER NOT NULL DEFAULT 1,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_v6_scores_rank ON operation_infiltration_v6_scores(high_score DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS operation_infiltration_v6_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  score INTEGER,
  rounds_completed INTEGER NOT NULL DEFAULT 0,
  failed_round INTEGER NOT NULL DEFAULT 1,
  result_json TEXT,
  event_log_json TEXT,
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_v6_runs_player ON operation_infiltration_v6_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS operation_infiltration_v6_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_operation_infiltration_v6_podium_player ON operation_infiltration_v6_podium_awards(player_id);

-- V22.72 · SAQUEO 30 direct-dial precision V5. V4 CAJA tables retained as history.
CREATE TABLE IF NOT EXISTS safe_loot_v5_scores (
  player_id TEXT PRIMARY KEY,
  best_score_tenths INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_score_tenths INTEGER NOT NULL DEFAULT 0,
  best_mistakes INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_hit_precision_json TEXT NOT NULL DEFAULT '[]',
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_scores_rank
  ON safe_loot_v5_scores(best_score_tenths DESC, best_mistakes ASC, best_perfects DESC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_loot_v5_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 5,
  duration_ms INTEGER,
  score_tenths INTEGER,
  mistakes INTEGER NOT NULL DEFAULT 0,
  perfects INTEGER NOT NULL DEFAULT 0,
  precision_bps INTEGER NOT NULL DEFAULT 0,
  hit_precision_json TEXT NOT NULL DEFAULT '[]',
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_runs_player ON safe_loot_v5_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_loot_v5_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score_tenths INTEGER NOT NULL DEFAULT 0,
  winning_mistakes INTEGER NOT NULL DEFAULT 0,
  winning_perfects INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v5_podium_player ON safe_loot_v5_podium_awards(player_id);

-- V22.73 · SAQUEO 30 circle-rush V6. V5 dial tables retained as history.
CREATE TABLE IF NOT EXISTS safe_loot_v6_scores (
  player_id TEXT PRIMARY KEY,
  best_loops INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_loops INTEGER NOT NULL DEFAULT 0,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_last_lap_ms INTEGER NOT NULL DEFAULT 999999,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_scores_rank
  ON safe_loot_v6_scores(best_loops DESC, best_precision_bps DESC, best_last_lap_ms ASC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_loot_v6_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 6,
  duration_ms INTEGER,
  loops INTEGER,
  precision_bps INTEGER NOT NULL DEFAULT 0,
  last_lap_ms INTEGER NOT NULL DEFAULT 0,
  track_breaks INTEGER NOT NULL DEFAULT 0,
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_runs_player ON safe_loot_v6_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_loot_v6_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_loops INTEGER NOT NULL DEFAULT 0,
  winning_precision_bps INTEGER NOT NULL DEFAULT 0,
  winning_last_lap_ms INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v6_podium_player ON safe_loot_v6_podium_awards(player_id);


CREATE TABLE IF NOT EXISTS safe_loot_v7_scores (
  player_id TEXT PRIMARY KEY,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_worst_bps INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  best_duration_ms INTEGER NOT NULL DEFAULT 999999,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_scores_rank
  ON safe_loot_v7_scores(best_precision_bps DESC, best_worst_bps DESC, best_perfects DESC, best_duration_ms ASC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_loot_v7_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 7,
  duration_ms INTEGER,
  average_bps INTEGER,
  worst_bps INTEGER NOT NULL DEFAULT 0,
  perfects INTEGER NOT NULL DEFAULT 0,
  outcome TEXT NOT NULL DEFAULT '',
  attempts_json TEXT NOT NULL DEFAULT '[]',
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_runs_player ON safe_loot_v7_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_loot_v7_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_precision_bps INTEGER NOT NULL DEFAULT 0,
  winning_worst_bps INTEGER NOT NULL DEFAULT 0,
  winning_perfects INTEGER NOT NULL DEFAULT 0,
  winning_duration_ms INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v7_podium_player ON safe_loot_v7_podium_awards(player_id);


-- V22.75 · SAQUEO 30 precision V8. Same visible zones/scoring; materially harder speed curve. V7 retained as history.
CREATE TABLE IF NOT EXISTS safe_loot_v8_scores (
  player_id TEXT PRIMARY KEY,
  best_precision_bps INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_precision_bps INTEGER NOT NULL DEFAULT 0,
  best_worst_bps INTEGER NOT NULL DEFAULT 0,
  best_perfects INTEGER NOT NULL DEFAULT 0,
  best_duration_ms INTEGER NOT NULL DEFAULT 999999,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_scores_rank
  ON safe_loot_v8_scores(best_precision_bps DESC, best_worst_bps DESC, best_perfects DESC, best_duration_ms ASC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS safe_loot_v8_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 8,
  duration_ms INTEGER,
  average_bps INTEGER,
  worst_bps INTEGER NOT NULL DEFAULT 0,
  perfects INTEGER NOT NULL DEFAULT 0,
  outcome TEXT NOT NULL DEFAULT '',
  attempts_json TEXT NOT NULL DEFAULT '[]',
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_runs_player ON safe_loot_v8_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS safe_loot_v8_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_precision_bps INTEGER NOT NULL DEFAULT 0,
  winning_worst_bps INTEGER NOT NULL DEFAULT 0,
  winning_perfects INTEGER NOT NULL DEFAULT 0,
  winning_duration_ms INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_safe_loot_v8_podium_player ON safe_loot_v8_podium_awards(player_id);

-- v22.76 · Admin command center / supervision --------------------------------
CREATE TABLE IF NOT EXISTS admin_activity (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  actor_id TEXT NOT NULL DEFAULT '',
  actor_name TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  meta_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_admin_activity_created ON admin_activity(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_activity_type ON admin_activity(event_type, created_at DESC);

CREATE TABLE IF NOT EXISTS admin_notification_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  enabled INTEGER NOT NULL DEFAULT 0,
  mode TEXT NOT NULL DEFAULT 'hybrid',
  recipient_email TEXT NOT NULL DEFAULT '',
  immediate_rsvp INTEGER NOT NULL DEFAULT 0,
  immediate_decline INTEGER NOT NULL DEFAULT 1,
  immediate_games INTEGER NOT NULL DEFAULT 0,
  daily_digest INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO admin_notification_settings
(id, enabled, mode, recipient_email, immediate_rsvp, immediate_decline, immediate_games, daily_digest)
VALUES (1,0,'hybrid','',0,1,0,1);

CREATE TABLE IF NOT EXISTS admin_notification_log (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL DEFAULT '',
  recipient_email TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT '',
  provider_id TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_admin_notification_log_created ON admin_notification_log(created_at DESC);

-- PUNTO CIEGO 30 · percepción temporal V1
CREATE TABLE IF NOT EXISTS pointblind_v1_scores (
  player_id TEXT PRIMARY KEY,
  best_total_error_ms INTEGER NOT NULL,
  games_played INTEGER NOT NULL DEFAULT 0,
  last_total_error_ms INTEGER NOT NULL DEFAULT 0,
  best_worst_error_ms INTEGER NOT NULL DEFAULT 999999,
  best_single_error_ms INTEGER NOT NULL DEFAULT 999999,
  achieved_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_pointblind_v1_scores_rank
  ON pointblind_v1_scores(best_total_error_ms ASC, best_worst_error_ms ASC, best_single_error_ms ASC, achieved_at ASC);

CREATE TABLE IF NOT EXISTS pointblind_v1_runs (
  run_id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  rules_version INTEGER NOT NULL DEFAULT 1,
  duration_ms INTEGER,
  total_error_ms INTEGER,
  worst_error_ms INTEGER NOT NULL DEFAULT 0,
  best_single_error_ms INTEGER NOT NULL DEFAULT 0,
  attempts_json TEXT NOT NULL DEFAULT '[]',
  event_log_json TEXT NOT NULL DEFAULT '[]',
  finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_pointblind_v1_runs_player ON pointblind_v1_runs(player_id, started_at_ms DESC);

CREATE TABLE IF NOT EXISTS pointblind_v1_podium_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_total_error_ms INTEGER NOT NULL DEFAULT 0,
  winning_worst_error_ms INTEGER NOT NULL DEFAULT 0,
  winning_best_single_error_ms INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank)
);
CREATE INDEX IF NOT EXISTS idx_pointblind_v1_podium_player ON pointblind_v1_podium_awards(player_id);


-- v22.79 · OPERACIÓN 30 general championship. Individual score tables remain the source of truth.
CREATE TABLE IF NOT EXISTS clandestine_championship_awards (
  contest_id TEXT NOT NULL,
  rank INTEGER NOT NULL,
  player_id TEXT NOT NULL,
  winning_score_bps INTEGER NOT NULL DEFAULT 0,
  tiebreak_worst_bps INTEGER NOT NULL DEFAULT 0,
  tiebreak_second_bps INTEGER NOT NULL DEFAULT 0,
  cash_reward INTEGER NOT NULL DEFAULT 0,
  respect_reward INTEGER NOT NULL DEFAULT 0,
  awarded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (contest_id, rank),
  UNIQUE (contest_id, player_id)
);
CREATE INDEX IF NOT EXISTS idx_clandestine_championship_player ON clandestine_championship_awards(player_id);
