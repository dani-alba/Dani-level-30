# DANI LEVEL 30 · PROJECT GUIDE

> **Source of truth for development and handoff.** Read this file before changing the project, especially in a new chat/session. Historical release notes in `README.txt` are a changelog only and do **not** override this document.

## 1. Current product model

- Current project release: **v23.12**.
- Event: **Saturday, 12 December 2026 at 13:00 Europe/Madrid** (`config.js` is authoritative for runtime dates).
- Primary experience: **mobile-first**. Desktop is not a target game surface; preserve the existing desktop/QR behavior.
- `Operación 30` is the preparation journey. `El Golpe` is the birthday/event itself and is a separate destination.

### Operación 30 · five phases

1. **El plan** — briefing/context.
2. **Únete a la banda** — identity + attendance.
3. **Localiza el refugio** — hack, then reveal location. After the hack finishes, Phase 3 stays open so the player can read the unlocked information.
4. **Prepárate para el golpe** — NPC/appearance + event inventory. Completing this phase persists `uiPrefs.partyPrepReviewed`.
5. **Consigue dinero para el golpe** — gateway to Operaciones Clandestinas and the provisional championship state. Phase 5 remains **EN CURSO** until El Golpe begins; it is not treated as an unfinished checklist item.

When El Golpe begins, preparation becomes complete and the five-phase stepper closes visually.

### La Banda

- Summary is intentionally minimal: **MIEMBROS** + **PREPARADOS** only.
- **PREPARADO** means the player completed Phase 4 and reached Phase 5. It does **not** require completing every clandestine game.
- Member cards show only the compact five-node progress stepper; do not add long phase labels back to each card.


### Persistent HUD / notifications

- The top HUD is intentionally conservative: preserve its geometry, sticky behavior, stars, identity/avatar, money and existing roll-up notification choreography.
- Current visual treatment uses a near-opaque **graphite/plum** surface, restrained border/shadow and a **very short lower fade** so scrolling content visually dissolves before passing beneath the sticky bar.
- Do **not** add scroll compaction, extra floating notification cards, strong transparency, neon decoration or structural motion unless explicitly requested.
- The lower fade is atmospheric only; it must never hide controls or change layout/interaction.
- The HUD is the single invite-side notification channel. Keep copy to one short primary line plus an optional short secondary line; explanation belongs in the destination card/phase, not in the HUD.
- Reading-time tiers are centralized in `app.js`: routine ≈ 2.8 s, social ≈ 3.8 s, important ≈ 4.7 s, critical ≈ 5.8 s. The dwell timer starts **after** the roll-in animation completes.
- Spontaneous/social notices have a 45 s cooldown, dedupe within the current session, and must never interrupt the Phase 3 hack. Direct feedback caused by the player's own action may still enter immediately.
- Invite-side social notices must reflect real D1/crew changes only. Never fabricate another guest joining or becoming prepared. The first crew refresh establishes a baseline; later invite refreshes may announce real changes.
- Current invite notification vocabulary includes: joining/recovery, phase unlock, refuge located, preparation complete, hidden-bill progress, real crew/prepared milestones, and last-week/tomorrow/today countdown milestones.

### Motion design contract

- Motion is **feedback and narrative hierarchy**, never decoration for its own sake. Do not add continuous parallax or animate every scroll event.
- Large/chapter transitions are reserved for: initial entry, Operaciones Clandestinas and El Golpe. Ordinary interaction motion stays roughly 120–450 ms.
- Shared tactile press states apply to primary invite/UI controls, while gameplay input physics remain owned by each game.
- Phase progression uses the existing real state transition: completed marker → progress pulse → next phase reveal. Do not fake progress animation without a persisted state change.
- El Golpe expanded content reveals after the shell expands; La Banda/profile use brief entrance/stagger only when opened, not on every background refresh.
- Hidden cash pickup may animate the bill and pulse HUD identity, but server/D1 collection remains authoritative.
- Operaciones Clandestinas gets one short chapter transition only when entering from the preparation layer; returning between game/hub views must stay fast.
- Result screens reveal score/rank/actions hierarchically without delaying or changing the authoritative result.
- `motion-polish.css` + `motion-polish.js` own cross-product motion. Update them and the impact map together when adding a new global motion pattern.
- Every motion feature must preserve a useful static path under `prefers-reduced-motion`.

### El Golpe gateway

- Appears **above La Banda**, before the five preparation phases.
- Closed state is concise: status + time remaining + one contextual sentence.
- Tapping expands a richer contextual panel; tapping again collapses it with a smooth/pop interaction. Respect `prefers-reduced-motion`.
- Calendar-day wording changes at **midnight Europe/Madrid**, not every 24 hours from 13:00.
- Exact event activation still occurs at **13:00**.
- On event day before 13:00, show `HOY` plus an exact hours/minutes/seconds countdown.
- When live, direct access to El Golpe must remain obvious and low-friction even if the card is collapsed.

## 2. Operaciones Clandestinas

- Gateway lives in **Phase 5**, not in the character/profile menu.
- Inside the clandestine area, preserve compact identity context (avatar/name/money) and clear return navigation to Operación 30 / Phase 5.
- Current championship has **4 games**:
  1. BRECHA 30 — memory.
     - Engine rules V7: fixed 3.2 s preview, grid grows up to 8×8, active cells never exceed roughly half the matrix, and generated patterns prefer high spatial spread/fragmentation. This prevents the high-level shortcut of memorizing only a few empty cells.
  2. PUNTO CIEGO 30 — timing/perception.
  3. BOTÍN 30 — precision.
  4. FUGA 30 — reflex/reading.
- General standings require marks in all four games. The four games weigh equally.
- Do not infer the number of Operación 30 phases from the number of games: preparation is **5 phases**, championship is **4 games**.

## 3. Hidden cash invariants

- Hidden bills are attached to a confirmed character; **never spawn before a character is confirmed**.
- Never spawn during the Phase 3 hack or on the hack interaction surface.
- Placement should adapt to currently visible information blocks rather than depend on a brittle hard-coded list of phase IDs.
- Existing progression rule remains: first hidden bills become eligible after joining; later bills become eligible after the refuge is unlocked. Server/D1 validation remains authoritative.

## 4. Things that must not be casually changed

Treat these as invariants unless the user explicitly asks to redesign them:

- `Mi expediente` and `Cambiar personaje` behavior.
- Game scoring/ranking rules and rules versions.
- Browser/Worker deterministic engine parity.
- Existing D1 historical tables/data compatibility.
- Event start time and event-day gating.
- Mobile-first game behavior and desktop QR strategy.
- The distinction between provisional rewards and final rewards.

If a requested change materially affects any invariant, update the relevant tests and this guide in the **same release**.

## 5. Development discipline

### The ZIP is the handoff artifact

Every delivered ZIP must be internally self-consistent. A future chat should be able to work from the ZIP alone without relying on prior conversation context.

For every implementation:

1. Start from the latest ZIP/project state, not an older extracted folder.
2. Remove or replace obsolete source-of-truth logic; do not keep dead current implementations merely because older releases used them.
3. Historical compatibility code may remain only when it is genuinely required for saved data/API compatibility.
4. Update this guide when architecture, flows, persistence, ranking, test coverage, or maintenance rules change.
5. Update `test-impact-map.json` when a new module/test relationship is introduced.
6. Update release/cache versioning when runtime boot assets change.
7. Package files at ZIP root (`index.html` at root), never inside an extra wrapper directory.

### Documentation hierarchy

1. **`PROJECT-GUIDE.md`** — current architecture and invariants; authoritative.
2. **`test-impact-map.json`** — machine-readable test-impact map; authoritative for targeted validation.
3. **`VERSION-*`** — exact release summary.
4. **`README.txt`** — current entry point + historical changelog. Historical entries are not current requirements.
5. Tests/code — implementation authority when documentation and code disagree; fix the documentation in the same change.

## 6. Test strategy: validation by impact

Do **not** run every game engine after an unrelated CSS/copy/home-layout change. Validation must be proportional to what changed.

### Level A · local UI/copy/layout

Examples: typography, El Golpe card, pill spacing, text, order of sections.

Run the relevant UI group plus release checks. Do **not** run unrelated game engines.

### Level B · functional/transversal

Examples: phases, profile progression, crew state, hidden money, ranking gateway, D1 fields.

Run the affected functional groups + backend/persistence tests where applicable + release checks.

### Level C · game/engine/backend rules

Examples: scoring, game mechanics, deterministic plans, `_worker.js`, rulesVersion, schema migrations.

Run the game's engine/client/API tests, shared-engine parity when relevant, persistence/backend tests and release checks.

### Release candidate / production stabilization

Run the full suite only when:

- the user says the version is ready/stable/for production;
- a shared engine/backend/schema change has broad impact;
- or a targeted failure suggests an unknown regression.

Some FUGA/CROSSING tests are intentionally expensive in this environment. Use targeted tests during iteration; for release audit use the bounded per-file audit so a slow test cannot hide the status of every other file.

## 7. Test commands

No npm install is required; scripts use Node built-ins only.

```bash
npm run test:ui
npm run test:phases
npm run test:crew
npm run test:arcade
npm run test:infiltration
npm run test:pointblind
npm run test:safe
npm run test:fuga
npm run test:backend
npm run test:release
```

Target tests from the files changed in the current implementation:

```bash
npm run test:impact -- styles.css crew.js index.html
```

Preview which tests would run without executing them:

```bash
node scripts/test-impact.mjs --list styles.css crew.js
```

Bounded all-files audit (reports PASS / FAIL / TIMEOUT per test file instead of hanging as one opaque suite):

```bash
npm run test:audit
```

True unbounded full suite (release-only; may be slow):

```bash
npm run test:full
```

## 8. Mandatory test maintenance rule

Whenever a feature is added, removed or relocated:

- add/update its focused test;
- remove assertions that describe behavior that no longer exists;
- update the impact map so future changes select that test automatically;
- do not preserve stale tests simply to keep historical behavior passing.

A release is not considered internally consistent if the implementation changed but its current tests/documentation still describe the previous architecture.

## 9. New-chat handoff checklist

When this ZIP is opened in a new ChatGPT chat/session:

1. Read `PROJECT-GUIDE.md` first.
2. Read the current `VERSION-*` file.
3. Inspect only the modules/tests relevant to the requested change.
4. Use `test:impact` during iteration.
5. Update this guide + impact map if the architectural contract changes.
6. Run broader/full validation only when the risk level requires it.

This is the default workflow unless the user explicitly asks for a different validation level.


### Landing → invitation sun-portal transition (v23.12)

- The landing poster and invitation cover share the same hero world, but the typography does **not** morph between layouts.
- On entry, the landing copy fades out while still centered and white; never move/recolour it through an intermediate layout.
- The hero sun is the visual hand-off: a brief bloom/ring pulse takes focus while the shell contracts to invitation geometry.
- Invitation copy then appears directly in its final position/style, visually emerging from the sun focal point.
- The HUD peels upward and `Operación 30` peels downward from behind the hero as a single block.
- Do not reintroduce a cloned/ghost copy of `.hero__content`; it previously caused colour/context discontinuities.
- Keep reduced-motion behavior functional and immediate.

### Motion stability: La Banda
- La Banda refreshes its member list immediately after the dialog opens. Animate the stable list shell, never individual `.crew-member-card` rows during dialog entrance; otherwise refreshed rows can replay entrance animations and appear to flicker/jump.

### Silent crew refresh (v23.09)
- Opening **La Banda** renders cached/current data immediately and refreshes from the server silently.
- Normal refreshes must never insert loading copy into the document flow or move cards vertically.
- `#crewStatus` is reserved for actionable errors; routine network activity uses `aria-busy` only.
- First-load empty state may occupy the list area, but background refreshes must not create transient layout rows.

### Landing → invitation preload/settle contract (v23.11)

- The one-off landing transition is intentionally allowed ~2.28 s of cinematic time. Use that time to stabilize the real invitation surface; do not replace it with a visible loader.
- `missionFlow` is unhidden and rendered behind the cover before the split reveal. Critical readiness currently includes the Crew initialization promise and `document.fonts.ready`, bounded by a 1350 ms timeout.
- Slow network work must never block entry indefinitely. If the bounded preload expires, complete the transition and let late data update silently.
- HUD and Operation 30 remain inert until the split reveal has begun and the final settle completes.
- Avoid adding post-transition `renderState()` calls that can reflow the page immediately after the cinematic settles; render/hydrate behind the cover instead.

### Landing width/geometry stability contract (v23.12)

- `main` is the single owner of the horizontal page gutter during Landing → Invitados.
- While `motion-invite-entering` is active, `#home.hero--transitioning` and `#missionFlow.mission-flow--entering` must remain `width:100%` of `main`; never apply a second `calc(100% - Npx)` to them.
- The hero transition may animate height, padding, radius, light and content, but its final visible width must already equal the post-transition width before the split reveal starts.
- Removing transition classes must not change the horizontal geometry of the hero or Operation 30. A width change at cleanup is a regression/layout shift.
